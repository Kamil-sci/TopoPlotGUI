import tkinter as tk
from asyncio import log
from tkinter import ttk
from collections import namedtuple
from tkinter import filedialog, END
from tkinter.filedialog import asksaveasfilename
from PIL import Image, ImageTk
import re
import os
from numpy import *
from tkinter import messagebox
import math
import time
import klayout.db as db
from scipy.optimize import root as sci_root
from scipy.interpolate import CubicSpline  # Уже импортировано
import os  # Уже импортировано
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
import pandas as pd # For excel export
import DCObjectItems_MW
import MultObjectItems_MW
import openpyxl
import builtins 
import numpy as np

import logging # Или используйте print
'''
# keys for ObjectCoords items
YDC_blocks = ('Ynands','YNnands','Ynors','YNnors','Ynand_base','Ynor_base',
              'Yforward_inv','Ybackward_inv','YC','YT','YH','YL','YII','Yempty')
XDC_blocks = ('Xnands','XNnands','Xnors','XNnors','Xnand_base','Xnor_base',
              'Xforward_inv','Xbackward_inv','XC','XT','XH','XL','XII','Xempty')
XCONNECT_blocks = ('BT','BC','BII','BL0','BL1','PULSEX','XVdd','PULSEXVdd')
'''

#            ['OP',      'DN',      'DP',      'PO',      'NW',      'ME',      'M2',      'M3',      'M4',       'M5',       'VI',       'V2',       'V3',       'V4',       'V5',       'CO']
blocks = ('SRAM', 'PC', 'PULSEY', 'PULSEX', 'BUFFER', 'DCY', 'DCX', 'WRITE', 'RSA', 'CONTROL', 'OUT',
          'bottomPC', 'YCONNECT', 'XCONNECT', 'topPULSE', 'forPCctrl',  'VddLine', 'VddTop', 'vddpulsex')

# top_area   = {
# 'SkyWater130': ('nwell', 'nmos', 'pmos', 'ndiff', 'pdiff', 'ndiffc', 'pdiffc', 'psubdiff', 'nsubdiff', 'psubdiffcont', 'nsubdiffcont', 'poly', 'polycont', 'locali', 'viali', 'metal1', 'via1', 'metal2', 'via2', 'metal3', 'OP', 'comment'),
# 'Microwind65': ('DN', 'DP', 'NW', 'PO', 'ME', 'M2', 'M3', 'M4', 'M5', 'CO', 'VI', 'V2', 'V3', 'V4', 'aarea', 'OP')
# }

cif_codes_mw = ('16',      '17',      '1',       '13',      '23',      '27',      '34',      '36',
                '53',       '19',       '25',       '32',       '35',       '52',       '2',       'ii')
gds_layers_mw = (2,         3,         5,         4,         6,         7,         8,         9,
                 10,         16,         11,         12,         13,         14,         17,         1)
lyp_layers_mw = ('L2D0_DN', 'L3D0_DP', 'L5D0_NW', 'L4D0_PO', 'L6D0_ME', 'L7D0_M2', 'L8D0_M3', 'L9D0_M4',
                 'L10D0_M5', 'L16D0_CO', 'L11D0_VI', 'L12D0_V2', 'L13D0_V3', 'L14D0_V4', 'L15D0_V5', 'L1D0_OP')

lookup = {
    'SkyWater130': {
        'nwell': {
            'color': 'green4',
            'border': '',
            'fill': ''
        },
        'nmos': {
            'color': 'olive',
            'border': '',
            'fill': 'olive'
        },
        'pmos': {
            'color': 'brown',
            'border': '',
            'fill': 'brown'
        },
        'ndiff': {
            'color': 'green1',
            'border': '',
            'fill': 'green1'
        },
        'pdiff': {
            'color': '#9C661F',
            'border': '',
            'fill': '#9C661F'
        },
        'ndiffc': {
            'color': 'black',
            'border': '',
            'fill': 'black'
        },
        'pdiffc': {
            'color': 'black',
            'border': '',
            'fill': 'black'
        },
        'psubdiff': {
            'color': 'burlywood',
            'border': '',
            'fill': 'burlywood'
        },
        'nsubdiff': {
            'color': 'greenyellow',
            'border': '',
            'fill': 'greenyellow'
        },
        'psubdiffcont': {
            'color': 'black',
            'border': '',
            'fill': 'black'
        },
        'nsubdiffcont': {
            'color': 'black',
            'border': '',
            'fill': 'black'
        },
        'poly': {
            'color': 'red',
            'border': '',
            'fill': 'red'
        },
        'polycont': {
            'color': 'black',
            'border': '',
            'fill': 'black'
        },
        'locali': {
            'color': 'cyan',
            'border': '',
            'fill': 'cyan'
        },
        'viali': {
            'color': 'deepskyblue',
            'border': '--',
            'fill': ''
        },
        'metal1': {
            'color': 'magenta',
            'border': '--',
            'fill': 'magenta'
        },
        'via1': {
            'color': 'violetred',
            'border': '-.-',
            'fill': ''
        },
        'metal2': {
            'color': 'blue',
            'border': '-.-',
            'fill': ''
        },
        'via2': {
            'color': 'gray',
            'border': '-',
            'fill': ''
        },
        'metal3': {
            'color': 'gray',
            'border': '--',
            'fill': ''
        },
        'OP': {
            'color': 'orange',
            'border': '-',
            'fill': ''
        },
        'comment': {
            'color': 'gray',
            'border': '-',
            'fill': ''
        }
    },
    'Microwind65': {
        'DN': {
            'color': 'green',
            'border': '',
            'fill': 'green'
        },
        'DP': {
            'color': 'brown',
            'border': '',
            'fill': 'brown'
        },
        'NW': {
            'color': 'green',
            'border': '',
            'fill': ''
        },
        'PO': {
            'color': 'red',
            'border': '',
            'fill': 'red'
        },
        'ME': {
            'color': '#0000FF',
            'border': '-',
            'fill': '#0000FF'
        },
        'M2': {
            'color': '#00008B',
            'border': '-.',
            'fill': '#00008B'
        },
        'M3': {
            'color': '#000068',
            'border': '-.-',
            'fill': ''
        },
        'M4': {
            'color': 'green',
            'border': '-.-',
            'fill': ''
        },
        'M5': {
            'color': 'black',
            'border': '--',
            'fill': ''
        },
        'CO': {
            'color': 'black',
            'border': '',
            'fill': 'black'
        },
        'VI': {
            'color': 'gray',
            'border': '-.',
            'fill': 'gray'
        },
        'V2': {
            'color': 'gray',
            'border': '-.-',
            'fill': ''
        },
        'V3': {
            'color': 'gray',
            'border': '-',
            'fill': ''
        },
        'V4': {
            'color': 'black',
            'border': '-.-',
            'fill': ''
        },
        'aarea': {
            'color': 'black',
            'border': '',
            'fill': ''
        },
        'OP': {
            'color': 'orange',
            'border': '-',
            'fill': ''
        }
    }
}

colors = {tech: tuple([component['color']
                      for component in lookup[tech].values()]) for tech in lookup.keys()}
borders = {tech: tuple([component['border']
                       for component in lookup[tech].values()]) for tech in lookup.keys()}
fills = {tech: tuple([component['fill'] for component in lookup[tech].values()])
         for tech in lookup.keys()}
top_area = {tech: tuple([layout for layout in lookup[tech].keys()])
            for tech in lookup.keys()}

cif_areas_mw = {}
lyp_codes_mw = {}
gds_codes_mw = {}

for i in range(len(top_area['Microwind65'])):
    cif_areas_mw[top_area['Microwind65'][i]] = cif_codes_mw[i]
    lyp_codes_mw[top_area['Microwind65'][i]] = lyp_layers_mw[i]
    gds_codes_mw[top_area['Microwind65'][i]] = gds_layers_mw[i]

lyp_codes_sw = {
    'cif': {
        'nwell': 'L2D0_nwell',
        'nmos': 'L3D0_nmos',
        'pmos': 'L4D0_pmos',
        'ndiff': 'L5D0_ndiff',
        'pdiff': 'L6D0_pdiff',
        'ndiffc': 'L7D0_ndiffc',
        'pdiffc': 'L8D0_pdiffc',
        'psubdiff': 'L9D0_psubdiff',
        'nsubdiff': 'L10D0_nsubdiff',
        'psubdiffcont': 'L11D0_psubdiffcont',
        'nsubdiffcont': 'L12D0_nsubdiffcont',
        'poly': 'L13D0_poly',
        'polycont': 'L14D0_polycont',
        'locali': 'L15D0_locali',
        'viali': 'L16D0_viali',
        'metal1': 'L17D0_metal1',
        'via1': 'L18D0_via1',
        'metal2': 'L19D0_metal2',
        'via2': 'L20D0_via2',
        'metal3': 'L21D0_metal3',
        'OP': 'L1D0_OP',
        'comment': 'L0D0_comment'
    },
    'gds': {
        'nwell': 2,
        'nmos': 3,
        'pmos': 4,
        'ndiff': 5,
        'pdiff': 6,
        'ndiffc': 7,
        'pdiffc': 8,
        'psubdiff': 9,
        'nsubdiff': 10,
        'psubdiffcont': 11,
        'nsubdiffcont': 12,
        'poly': 13,
        'polycont': 14,
        'locali': 15,
        'viali': 16,
        'metal1': 17,
        'via1': 18,
        'metal2': 19,
        'via2': 20,
        'metal3': 21,
        'OP': 1,
        'comment': 0
    }
}
rec_keys = ('rec_coord', 'rec_outline', 'rec_fill', 'rec_border', 'rec_tag')

mos_models = ['Level1', 'Level3', 'BSIM4']
level_1_params = ['vto', 'gamma', 'kappa', 'phi', 'u0', 'tox', 'nss']
level_3_params = ['vto', 'vmax', 'gamma', 'theta',
                  'kappa', 'phi', 'ld', 'u0', 'tox', 'nss']
BSIM_4_params = ['vtho', 'k1', 'k2', 'xj', 'toxe', 'ndep', 'd0vt', 'd1vt', 'vfb',
                 'u0', 'ua', 'uc', 'vsat', 'pscbe1', 'ute', 'kt1', 'lint', 'wint', 'pclm']
precharges = []
y_pulses = []
x_pulses = []
area_props = {
    'SkyWater130': {},
    'Microwind65': {}
}

for tech in area_props.keys():
    for i in range(len(top_area[tech])):
        area_props[tech][top_area[tech][i]] = {
            'fill_color': fills[tech][i],
            'border_color': colors[tech][i],
            'border_dash': borders[tech][i]
        }

Element = namedtuple("Element", ["width", "length", "area_type"])
area_types = ("NMOS", "PMOS")

list_of_el = [None, None, None]
num_color_area = [None]

sechenie_coords = []

# list_of_objects = [None]
# coords_of_objects = [None]
# list_object_colors = [None]

# x_0 = [None]
# x_1 = [None]
# y_0 = [None]
# y_1 = [None]
# min_shift_h = [None]
# min_shift_v = [None]
# shifted_rect = [None]
# new_rect = [None]

for i in range(4):
    sechenie_coords.append(None)


class LineForm(tk.Toplevel):
    areas = top_area

    def __init__(self, master, mos_models):
        super().__init__(master)  # , text="options")
        self.mos_models = mos_models
        # self.GridUnits = tk.IntVar()
        # self.entry_tech = tk.Entry(self, textvariable = self.GridUnits)
        # tk.Label(self, text="Gate Length:").grid(row=0, column=0)
        # self.entry_tech.grid(row=0, column=1)
        # tk.Label(self, text="nm").grid(row=0, column=2)

        self.mos_model = tk.StringVar()
        self.mos_model.set(self.mos_models[0])
        model_label = tk.Label(self, text="Model")
        model_option = tk.OptionMenu(self, self.mos_model, *self.mos_models)

        # self.area = tk.StringVar()
        # self.area.set(self.areas[0])
        # area_label = tk.Label(self, text="area")
        # area_option = tk.OptionMenu(self, self.area, *self.areas)

        # line_width_label = tk.Label(self, text="thicness of line")
        # self.line_width = tk.Spinbox(self, values=(1, 2, 3, 4), width=5)

        # line_width_label.grid(sticky=tk.W, row=5, column=0)
        # self.line_width.grid(row=5, column=1, pady=10)

        model_label.grid(sticky=tk.W, row=1, column=0)
        model_option.grid(row=1, column=1, pady=10)

        # area_label.grid(sticky=tk.W, row=2, column=0)
        # area_option.grid(row=2, column=1, pady=10)

        # self.info_txt = tk.Text(self,  height=5, width=30) # added one text box
        # self.info_txt.grid(row=3,column=0, pady=10)

    # def get_width(self):
        # return int(self.line_width.get())

    def get_model(self):
        return self.mos_model.get()

    # def get_area(self):
        # return self.area.get()

    # def get_tech(self):
        # return self.GridUnits.get()

    # def let_write_1(self, info_str):
        # self.info_txt.delete('1.0',END) # remove the previous content
        # self.info_txt.insert(tk.END, f'Type of area: {info_str[0]}\nCoords of (x0, y0): {info_str[1][0], info_str[1][1]}\nLength, Width (lambda):{info_str[1][2], info_str[1][3]}\nBlock parameters: t = {info_str[2]} ns')

    # def let_write_2(self, info_str):
        # self.info_txt.delete('1.0',END) # remove the previous content
        # self.info_txt.insert(tk.END, f'Type of area: {info_str[0]}\nCoords of (x0, y0): {info_str[1][0], info_str[1][1]}\nLength, Width (lambda):{info_str[1][2], info_str[1][3]}')


class DeviceSynthes(tk.Toplevel):
    def __init__(self, parent, foundry):
        super().__init__(parent)
        if foundry == 'SkyWater130':
            self.sram_blocks = (
                'SRAM',
                'PC',
                'PULSEY',
                'PULSEX',
                'BUFFER',
                'DCY',
                'DCX',
                'WRITE',
                'RSA',
                'CONTROL',
                'OUT',
                'bottomPC',
                'XCONNECT',
                'topPULSE',
                'forPCctrl',
                'VddLine',
                'VddTop',
                'vddpulsex'
            )
        elif foundry == 'Microwind65':
            self.sram_blocks = (
                'SRAM',
                'PC',
                'PULSEY',
                'PULSEX',
                'BUFFER',
                'DCY',
                'DCX',
                'WRITE',
                'RSA',
                'CONTROL',
                'OUT',
                'bottomPC',
                'YCONNECT',
                'XCONNECT',
                'topPULSE',
                'forPCctrl',
                'VddLine',
                'VddTop',
                'vddpulsex'
            )
        self.columns = tk.IntVar()
        self.rows = tk.IntVar()

        label = tk.Label(self, text="Device Synthesis:")
        entry_columns = tk.Entry(self, textvariable=self.columns)
        entry_rows = tk.Entry(self, textvariable=self.rows)
        btn = tk.Button(self, text="Apply", command=self.destroy)

        label.grid(row=0, columnspan=2)
        tk.Label(self, text="M (rows bit depth):").grid(row=1, column=0)
        tk.Label(self, text="N (columns bit depth):").grid(row=2, column=0)
        entry_columns.grid(row=1, column=1)
        entry_rows.grid(row=2, column=1)
        btn.grid(row=3, columnspan=2)

        self.checkbuttons_variables = {
            block: tk.BooleanVar() for block in self.sram_blocks}
        j = 0
        k = 0
        for i, block in enumerate(self.sram_blocks):
            self.cb = tk.Checkbutton(
                self, onvalue=1, offvalue=0, text=block, variable=self.checkbuttons_variables[block])
            if i >= 9:
                j = 1
                k = 9
            self.cb.grid(row=i + 8 - k, column=j, padx=5, pady=5, sticky="w")

        for block in self.sram_blocks:
            self.checkbuttons_variables[block].set(1)

    def open(self):
        self.grab_set()
        self.wait_window()
        columns = self.columns.get()
        rows = self.rows.get()
        self.choosed_blocks = {}
        for block in self.sram_blocks:
            self.choosed_blocks[block] = self.checkbuttons_variables[block].get(
            )
        return [2**columns, 2**rows, self.choosed_blocks]


class YDCSyn(tk.Toplevel):
    dc_blocks = ['by blocks', 'by matrix']

    def __init__(self, parent):
        super().__init__(parent)
        self.inputs = tk.IntVar()

        label = tk.Label(self, text="Y Decoder Synthesis:")
        entry_inputs = tk.Entry(self, textvariable=self.inputs)
        btn = tk.Button(self, text="Apply", command=self.destroy)

        label.grid(row=0, columnspan=2)
        tk.Label(self, text="i (inputs):").grid(row=2, column=0)
        entry_inputs.grid(row=2, column=1)
        btn.grid(row=4, columnspan=2)

        self.dc_block = tk.StringVar()
        self.dc_block.set(self.dc_blocks[0])
        dc_block_label = tk.Label(self, text="Choose DC version")
        dc_block_option = tk.OptionMenu(self, self.dc_block, *self.dc_blocks)

        dc_block_label.grid(sticky=tk.W, row=3, column=0)
        dc_block_option.grid(row=3, column=1)

    def open(self):
        self.grab_set()
        self.wait_window()
        inputs = self.inputs.get()
        outputs = 2**inputs
        dc_block = self.dc_block.get()
        return [outputs, inputs, dc_block]


class XDCSyn(tk.Toplevel):
    dc_blocks = ['by blocks', 'by matrix']

    def __init__(self, parent):
        super().__init__(parent)
        self.inputs = tk.IntVar()

        label = tk.Label(self, text="X Decoder Synthesis:")
        entry_inputs = tk.Entry(self, textvariable=self.inputs)
        btn = tk.Button(self, text="Apply", command=self.destroy)

        label.grid(row=0, columnspan=2)
        tk.Label(self, text="j (inputs):").grid(row=2, column=0)
        entry_inputs.grid(row=2, column=1)
        btn.grid(row=4, columnspan=2)

        self.dc_block = tk.StringVar()
        self.dc_block.set(self.dc_blocks[0])
        dc_block_label = tk.Label(self, text="Choose DC version")
        dc_block_option = tk.OptionMenu(self, self.dc_block, *self.dc_blocks)

        dc_block_label.grid(sticky=tk.W, row=3, column=0)
        dc_block_option.grid(row=3, column=1)

    def open(self):
        self.grab_set()
        self.wait_window()
        inputs = self.inputs.get()
        outputs = 2**inputs
        dc_block = self.dc_block.get()
        return [outputs, inputs, dc_block]


class XDCCon(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.inputs = tk.IntVar()

        label = tk.Label(self, text="X Connect Synthesis:")
        entry_inputs = tk.Entry(self, textvariable=self.inputs)
        btn = tk.Button(self, text="Apply", command=self.destroy)

        label.grid(row=0, columnspan=2)
        tk.Label(self, text="j (inputs):").grid(row=2, column=0)
        entry_inputs.grid(row=2, column=1)
        btn.grid(row=4, columnspan=2)

    def open(self):
        self.grab_set()
        self.wait_window()
        inputs = self.inputs.get()
        outputs = 2**inputs
        return [outputs, inputs]


class ProgressBarWindow(tk.Toplevel):
    def __init__(self, parent, amount_of_cells):
        super().__init__(parent)
        self.amount_of_cells = amount_of_cells

        self.label = tk.Label(self, text="Exporting...")
        self.label.grid(row=0, columnspan=2)

        self.progress = ttk.Progressbar(
            self, orient=tk.HORIZONTAL, length=500, mode='determinate')
        self.progress.grid(row=1, columnspan=2)

        self.update()

        # tk.Button(self, text = 'Start', command = self.bar).grid(row=2, columnspan=2)
    def bar(self, cell_num, cell_item):
        self.progress['value'] = int(cell_num * 100 / self.amount_of_cells)
        self.label['text'] = f"Exporting...{cell_item}"
        # print(int(cell_num * 100 / self.amount_of_cells))
        self.update_idletasks()
        self.update()
        time.sleep(1/self.amount_of_cells)

    def bar_closing(self):
        self.destroy()


class MultiplierSyn(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.bit_depth = tk.IntVar()
        # self.B_depth = tk.IntVar()

        label = tk.Label(self, text="Multiplier Synthesis:")
        entry_bit_depth = tk.Entry(self, textvariable=self.bit_depth)
        # entry_B_depth = tk.Entry(self, textvariable=self.B_depth)
        btn = tk.Button(self, text="Apply", command=self.destroy)

        label.grid(row=0, columnspan=2)
        tk.Label(self, text="Digits Bit Depth:").grid(row=1, column=0)
        # tk.Label(self, text="B (bit depth):").grid(row=2, column=0)
        entry_bit_depth.grid(row=1, column=1)
        # entry_B_depth.grid(row=2, column=1)
        btn.grid(row=3, columnspan=2)

    def open(self):
        self.grab_set()
        self.wait_window()
        bit_depth = self.bit_depth.get()
        # B = self.B_depth.get()
        return bit_depth



# --- TPULSE Function Implementation ---
def calculate_tpulse_voltage(t, VL, VH, TD, TR, TF, TPW, TPER, N):
    """
    Calculates the voltage at time t based on TPULSE parameters.
    Assumes all time parameters are in seconds. N is the number of pulses (1-based).
    """
    if TR <= 0: TR = 1e-15 # Avoid division by zero, make rise instant
    if TF <= 0: TF = 1e-15 # Avoid division by zero, make fall instant
    if TPER <= 0: # Handle non-periodic case (or N=1)
        if t < TD:
            return VL
        elif TD <= t < (TD + TR):
            return VL + (VH - VL) / TR * (t - TD)
        elif (TD + TR) <= t < (TD + TPW - TF):
            return VH
        elif (TD + TPW - TF) <= t < (TD + TPW):
            return VH - (VH - VL) / TF * (t - (TD + TPW - TF))
        else: # t >= TD + TPW
            return VL
    else: # Periodic case
        if t < TD:
            return VL
        elif t >= (TD + N * TPER): # After the last specified pulse period ends
            return VL
        else:
            # Determine which pulse period 't' falls into (or if it's after the last pulse but within N*TPER)
            # Effective time within a single period
            t_eff = (t - TD) % TPER
            # Check if t is within the pulse part of the cycle for the *current* effective period
            # This check ensures we don't apply the pulse shape outside the N*TPER duration
            pulse_index = math.floor((t - TD) / TPER) # 0-based index of the pulse

            if pulse_index < N : # Only apply pulse shape if within the N pulses
                # Re-evaluate based on t_eff within one period structure
                # Note: TD is effectively 0 for t_eff calculation due to modulo
                if 0 <= t_eff < TR:
                    return VL + (VH - VL) / TR * t_eff
                elif TR <= t_eff < (TPW - TF):
                    return VH
                elif (TPW - TF) <= t_eff < TPW:
                    return VH - (VH - VL) / TF * (t_eff - (TPW - TF))
                elif TPW <= t_eff < TPER:
                    return VL
                else: # Should not happen if TPER > TPW
                    return VL
            else: # After the Nth pulse starts, but before TD + N*TPER
                return VL


# --- PWL Point Generation ---
def generate_pwl_points(VL, VH, TD, TR, TF, TPW, TPER, N):
    """
    Generates critical (time, voltage) points for SPICE PWL definition.
    Assumes all time parameters are in seconds.
    Returns a list of (t, v) tuples.
    """
    points = []
    # Ensure edges are sharp if TR/TF are very small
    epsilon = 1e-15 # A very small time offset if needed, but direct points usually work

    # Start condition
    points.append((0.0, VL))
    if TD > epsilon: # Add point just before first rise if TD > 0
        points.append((TD - epsilon, VL))
        points.append((TD, VL))

    for k in range(int(N)):
        t_base = TD + k * TPER

        # Start of rise
        if TR > epsilon:
            points.append((t_base + epsilon, VL)) # Point just before rise starts (if not at TD)
            points.append((t_base, VL))           # Ensure point at exact start time
            points.append((t_base + TR - epsilon, VH)) # Point just before rise ends
            points.append((t_base + TR, VH))         # Point exactly at end of rise
        else: # Instantaneous rise
            points.append((t_base + epsilon, VH))
            points.append((t_base, VH))


        # Start of fall
        t_fall_start = t_base + TPW - TF
        if TF > epsilon:
            points.append((t_fall_start - epsilon, VH)) # Point just before fall starts
            points.append((t_fall_start, VH))         # Point exactly at start of fall
            points.append((t_base + TPW - epsilon, VL)) # Point just before fall ends
            points.append((t_base + TPW, VL))         # Point exactly at end of fall
        else: # Instantaneous fall
            points.append((t_fall_start - epsilon, VH))
            points.append((t_fall_start, VL)) # Instant drop


        # End of period (hold VL) only if periodic
        if TPER > 0:
            t_period_end = t_base + TPER
            points.append((t_period_end - epsilon, VL))
            points.append((t_period_end, VL))

    # Add a final point to ensure the signal stays low after the last pulse
    final_time = TD + N * TPER + (TPER if TPER > 0 else TPW) # Go one cycle/pulse width further
    points.append((final_time, VL))

    # Sort points by time and remove duplicates
    # Using a dict preserves order while removing duplicates based on the key (time)
    # Filter out numerically very close time points that might cause issues
    unique_points = []
    last_t = -float('inf')
    min_dt = 1e-18 # Minimum time difference to consider points distinct

    # Sort first
    points.sort(key=lambda x: x[0])

    for t, v in points:
        if not unique_points or abs(t - last_t) > min_dt:
            unique_points.append((t, v))
            last_t = t
        elif abs(v - unique_points[-1][1]) > 1e-9: # Keep point if voltage changes significantly at ~same time
            unique_points.append((t, v))
            last_t = t


    # Ensure the very first point is exactly (0, VL) if TD >= 0
    if not unique_points or unique_points[0][0] > epsilon:
        unique_points.insert(0, (0.0, VL))
    elif unique_points[0][0] < epsilon and unique_points[0][1] != VL:
        unique_points[0] = (0.0, VL) # Correct first point if needed


    # Filter redundant points (where voltage doesn't change)
    final_points = []
    if not unique_points:
        return [(0.0, VL)]

    final_points.append(unique_points[0])
    for i in range(1, len(unique_points)):
        # Keep point if time changed OR if voltage changed (for vertical steps)
        if abs(unique_points[i][0] - final_points[-1][0]) > min_dt or \
           abs(unique_points[i][1] - final_points[-1][1]) > 1e-9:
            final_points.append(unique_points[i])

    # Ensure last point exists and defines final state
    if not final_points or final_points[-1][0] < final_time - TPER/2:
        final_points.append( (final_time, VL) )


    return final_points


# --- Main GUI Class ---
class SRAMParametrize(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("SRAM Parameters & PWL Export")
        self.parent = parent # Keep track of parent window

        # --- Data Storage ---
        self.calculation_mode = tk.StringVar(value="Parametrize")
        self.params = { # User inputs for parameterization
            "t_WL": tk.DoubleVar(value=100), # ps
            "t_WR": tk.DoubleVar(value=100), # ps
            "t_PC": tk.DoubleVar(value=100), # ps
            "t_OUT": tk.DoubleVar(value=500), # ps
            "R_L_OUT": tk.DoubleVar(value=10000), # Ohm
            "C_L_OUT": tk.DoubleVar(value=10)      # fF
        }
        self.max_widths = { # User inputs for maximum widths
            "t_WL": tk.DoubleVar(value=1.0), # um
            "t_WR": tk.DoubleVar(value=1.0), # um
            "t_PC": tk.DoubleVar(value=1.0), # um
            "t_OUT": tk.DoubleVar(value=1.0)  # um
        }
        self.constants = { # Fixed constants, but user-editable
            "TS": tk.DoubleVar(value=0.1),   # ns
            "min_t_per": tk.DoubleVar(value=1.0), # ns
            "min_t_pw": tk.DoubleVar(value=0.4), # ns
            "t_d_DC": tk.DoubleVar(value=200), # ps
            "t_latch": tk.DoubleVar(value=350), # ps
            "VH": tk.DoubleVar(value=1.8),   # V
            "VL": tk.DoubleVar(value=0.0),    # V
            "pause": tk.DoubleVar(value=5.0)  
        }
        # To store calculated signal parameters (TD, TR, etc.)
        self.signal_params_write = {}
        self.signal_params_read = {}
        # To store calculated cycle times
        self.calculated_times = {
            "t_WC": tk.StringVar(value="t_WC: N/A"),
            "t_RC": tk.StringVar(value="t_RC: N/A"),
            "t_A": tk.StringVar(value="t_A: N/A")
        }

        # --- GUI Elements ---
        # Frames for organization
        mode_frame = ttk.Frame(self, padding="5")
        param_frame = ttk.LabelFrame(self, text="Parameters", padding="10")
        const_frame = ttk.LabelFrame(self, text="Constants", padding="10")
        control_frame = ttk.Frame(self, padding="5")
        output_frame = ttk.LabelFrame(self, text="Calculated Times", padding="5")
        image_frame = ttk.Frame(self, padding="5")

        # Grid layout for main frames
        mode_frame.grid(row=0, column=0, sticky="ew", padx=5, pady=2)
        param_frame.grid(row=1, column=0, sticky="nsew", padx=5, pady=5)
        const_frame.grid(row=2, column=0, sticky="nsew", padx=5, pady=5)
        control_frame.grid(row=3, column=0, sticky="ew", padx=5, pady=2)
        output_frame.grid(row=4, column=0, sticky="ew", padx=5, pady=5)
        image_frame.grid(row=0, column=1, rowspan=5, sticky="nsew", padx=5, pady=5)

        self.grid_columnconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1) # Allow image frame to resize
        self.grid_rowconfigure(1, weight=1)
        self.grid_rowconfigure(2, weight=1)


        # --- Mode Selection ---
        self.precalculate_rb = ttk.Radiobutton(
            mode_frame, text="Precalculate", variable=self.calculation_mode, value="Precalculate", command=self.toggle_entries)
        self.parametrize_rb = ttk.Radiobutton(
            mode_frame, text="Parametrize", variable=self.calculation_mode, value="Parametrize", command=self.toggle_entries)
        self.precalculate_rb.pack(side=tk.LEFT, padx=5)
        self.parametrize_rb.pack(side=tk.LEFT, padx=5)


        # --- Parameter Inputs ---
        self.entries = {}
        self.max_width_entries = {}
        param_labels = {
            "t_WL": "t_WL_param [ps]:", "t_WR": "t_WR_param [ps]:", "t_PC": "t_PC_param [ps]:",
            "t_OUT": "t_OUT_param [ps]:", "R_L_OUT": "R_L_OUT [Ohm]:", "C_L_OUT": "C_L_OUT [fF]:"
        }
        param_row = 0
        for param_name, param_var in self.params.items():
            # Label and Entry for parameter
            ttk.Label(param_frame, text=param_labels[param_name]).grid(row=param_row, column=0, sticky=tk.W, padx=5, pady=2)
            entry = ttk.Entry(param_frame, textvariable=param_var, width=10)
            entry.grid(row=param_row, column=1, sticky=tk.EW, padx=5, pady=2)
            self.entries[param_name] = entry

            # Max width fields only for timing parameters
            if param_name in self.max_widths:
                max_label_text = f"MAX(W_{param_name.replace('t_', '')}) [μm]:"
                ttk.Label(param_frame, text=max_label_text).grid(row=param_row, column=2, sticky=tk.W, padx=5, pady=2)
                max_entry = ttk.Entry(param_frame, textvariable=self.max_widths[param_name], width=10)
                max_entry.grid(row=param_row, column=3, sticky=tk.EW, padx=5, pady=2)
                self.max_width_entries[param_name] = max_entry
            param_row += 1
        param_frame.grid_columnconfigure(1, weight=1)
        param_frame.grid_columnconfigure(3, weight=1)


        # --- Constant Inputs ---
        self.const_entries = {}
        const_labels = {
            "TS": "TS [ns]:", "min_t_per": "min_t_per [ns]:", "min_t_pw": "min_t_pw [ns]:",
            "t_d_DC": "t_d_DC [ps]:", "t_latch": "t_latch [ps]:", "VH": "VH [V]:", "VL": "VL [V]:",
            "pause": "Pause between WR/RD [ns]:"
        }
        
        const_row = 0
        for const_name, const_var in self.constants.items():
            ttk.Label(const_frame, text=const_labels[const_name]).grid(row=const_row, column=0, sticky=tk.W, padx=5, pady=2)
            entry = ttk.Entry(const_frame, textvariable=const_var, width=10)
            entry.grid(row=const_row, column=1, sticky=tk.EW, padx=5, pady=2)
            self.const_entries[const_name] = entry
            const_row += 1
        const_frame.grid_columnconfigure(1, weight=1)


        # --- Control Buttons ---
        self.apply_btn = ttk.Button(control_frame, text='Apply Settings', command=self.destroy) # Closes window, parent retrieves data
        self.calc_export_btn = ttk.Button(control_frame, text='Calculate & Export PWL', command=self.run_calculation_and_pwl_export)
        self.export_excel_btn = ttk.Button(control_frame, text='Export Waveforms to Excel', command=self.export_excel_func)

        self.apply_btn.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5, pady=5)
        self.calc_export_btn.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5, pady=5)
        self.export_excel_btn.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5, pady=5)


        # --- Calculated Times Display ---
        self.t_wc_label = ttk.Label(output_frame, textvariable=self.calculated_times["t_WC"])
        self.t_rc_label = ttk.Label(output_frame, textvariable=self.calculated_times["t_RC"])
        self.t_a_label = ttk.Label(output_frame, textvariable=self.calculated_times["t_A"])
        self.t_wc_label.pack(side=tk.LEFT, padx=10)
        self.t_rc_label.pack(side=tk.LEFT, padx=10)
        self.t_a_label.pack(side=tk.LEFT, padx=10)


        # --- Timing Diagram Image ---
        self.timing_img = None # Placeholder
        self.time_panel = None
        try:
            img = Image.open("TimingDiagramm_new.png")
            self.timing_img = ImageTk.PhotoImage(img)
            self.time_panel = tk.Label(image_frame, image=self.timing_img)
            self.time_panel.pack(fill="both", expand=True)
        except FileNotFoundError:
            ttk.Label(image_frame, text="TimingDiagramm_new.png not found.").pack()
            #print("Warning: TimingDiagramm_new.png not found.")
        except Exception as e:
            ttk.Label(image_frame, text=f"Error loading image:\n{e}").pack()
            #print(f"Error loading image: {e}")


        # --- Initial State ---
        self.toggle_entries()
        self.protocol("WM_DELETE_WINDOW", self.destroy) # Ensure closing window works like Apply


    def toggle_entries(self):
        """Enable/disable entries based on calculation mode."""
        mode = self.calculation_mode.get()
        param_state = 'normal' if mode == "Parametrize" else 'disabled'
        const_state = 'normal'  # Constants always editable
        export_state = 'normal' if mode == "Parametrize" else 'disabled'
    
        for key, entry in self.entries.items():
            # В режиме Precalculate — R_L_OUT и C_L_OUT остаются активными
            if mode == "Precalculate" and key in ["R_L_OUT", "C_L_OUT"]:
                entry.config(state="normal")
            else:
                entry.config(state=param_state)
    
        for entry in self.max_width_entries.values():
            entry.config(state=param_state)
        for entry in self.const_entries.values():
            entry.config(state=const_state)
    
        self.calc_export_btn.config(state=export_state)
        self.export_excel_btn.config(state=export_state)


    def _get_inputs_as_seconds(self):
        """ Safely retrieves all inputs and converts time units to seconds, load to F. """
        try:
            inputs = {}
            # Parameters (time in ps -> s)
            inputs['t_WL'] = self.params['t_WL'].get()
            inputs['t_WR'] = self.params['t_WR'].get()
            inputs['t_PC'] = self.params['t_PC'].get()
            inputs['t_OUT'] = self.params['t_OUT'].get() 
            # Parameters (load)
            inputs['R_L_OUT'] = self.params['R_L_OUT'].get() # Ohms
            inputs['C_L_OUT'] = self.params['C_L_OUT'].get() # fF

            # Constants (time conversion)
            inputs['TS'] = self.constants['TS'].get() * 1e-9          # ns -> s
            inputs['min_t_per'] = self.constants['min_t_per'].get() * 1e-9 # ns -> s
            inputs['min_t_pw'] = self.constants['min_t_pw'].get() * 1e-9  # ns -> s
            inputs['t_d_DC'] = self.constants['t_d_DC'].get() * 1e-12    # ps -> s
            inputs['t_latch'] = self.constants['t_latch'].get() * 1e-12 # ps -> s
            # Constants (voltage)
            inputs['VH'] = self.constants['VH'].get() # V
            inputs['VL'] = self.constants['VL'].get() # V

            # Validation
            if inputs['TS'] <= 0 or inputs['min_t_per'] <= 0 or inputs['min_t_pw'] <= 0:
                raise ValueError("TS, min_t_per, and min_t_pw must be positive.")
            if inputs['VH'] <= inputs['VL']:
                raise ValueError("VH must be greater than VL.")

            return inputs

        except (tk.TclError, ValueError) as e:
            messagebox.showerror("Input Error", f"Invalid numeric input detected.\nPlease check values.\nError: {e}")
            return None


    def _calculate_timing_params(self):
        """ Calculates all intermediate and final signal parameters based on inputs. """
        inputs = self._get_inputs_as_seconds()
        if inputs is None:
            return False # Indicate failure

        # --- Preliminary Calculations ---
        t_WL = inputs['t_WL']* 1e-12
        t_WR = inputs['t_WR']* 1e-12
        t_PC = inputs['t_PC']* 1e-12
        t_OUT = inputs['t_OUT']* 1e-12
        TS = inputs['TS']
        min_t_per = inputs['min_t_per']
        min_t_pw = inputs['min_t_pw']
        t_d_DC = inputs['t_d_DC']
        t_latch = inputs['t_latch']
        VH = inputs['VH']
        VL = inputs['VL']

        # Write cycle calculations
        t_hd_WR_A = t_PC + TS
        t_hd_CSY_WR = t_WL + TS
        t_pw_CSY_wr = t_WL + t_latch + TS + min_t_pw # Renamed to avoid clash with signal name CSY
        t_su_WR_CSY = t_WR + TS
        t_WC = t_d_DC + t_su_WR_CSY + t_pw_CSY_wr + t_hd_CSY_WR + t_hd_WR_A
        TPER_WR_base = builtins.max(1.5 * (t_WC + TS), min_t_per) # Calculate common period for write cycle

        # Read cycle calculations
        t_pw_RD_sig = 1.5 * (t_OUT + min_t_pw + TS) # Renamed to avoid clash with signal name RD
        t_su_CSY_RD = t_WL + t_PC + TS
        t_RC = t_d_DC + t_su_CSY_RD + t_pw_RD_sig + t_PC
        TPER_RD_base = builtins.max(1.5 * (t_RC + TS), min_t_per) # Calculate common period for read cycle

        # Access time calculation
        t_A = t_d_DC + t_WL + t_su_CSY_RD + t_OUT

        # Store calculated cycle times for display (convert back to ns for readability)
        self.calculated_times["t_WC"].set(f"t_WC: {t_WC * 1e9:.2f} ns")
        self.calculated_times["t_RC"].set(f"t_RC: {t_RC * 1e9:.2f} ns")
        self.calculated_times["t_A"].set(f"t_A: {t_A * 1e9:.2f} ns")


        # --- 4.1) Write Mode Signal Parameters ---
        self.signal_params_write = {}
        TD_A_WR = 0.1e-9 # 1 ns

        # ADDR (Write)
        self.signal_params_write['ADDR'] = {
            'VL': VL, 'VH': VH, 'TD': TD_A_WR, 'TR': TS, 'TF': TS,
            'TPW': t_WC + TS, 'TPER': TPER_WR_base, 'N': 1
        }
        # DIN (Write)
        self.signal_params_write['DIN'] = {
            'VL': VL, 'VH': VH, 'TD': TD_A_WR, 'TR': TS, 'TF': TS,
            'TPW': t_WC + TS, 'TPER': TPER_WR_base, 'N': 1
        }
        # WR (Write)
        TD_WR_WR = TD_A_WR + t_d_DC
        self.signal_params_write['WR'] = {
            'VL': VL, 'VH': VH, 'TD': TD_WR_WR, 'TR': TS, 'TF': TS,
            'TPW': t_su_WR_CSY + t_pw_CSY_wr + t_hd_CSY_WR,
            'TPER': TPER_WR_base, 'N': 1
        }
        # CSY (Write)
        TD_CSY_WR = TD_WR_WR + t_su_WR_CSY
        self.signal_params_write['CSY'] = {
            'VL': VL, 'VH': VH, 'TD': TD_CSY_WR, 'TR': TS, 'TF': TS,
            'TPW': t_pw_CSY_wr, 'TPER': TPER_WR_base, 'N': 1
        }


        # --- 4.2) Read Mode Signal Parameters ---
        self.signal_params_read = {}
        TD_A_RD = 0.1e-9 # 1 ns

        # ADDR (Read)
        self.signal_params_read['ADDR'] = {
            'VL': VL, 'VH': VH, 'TD': TD_A_RD, 'TR': TS, 'TF': TS,
            'TPW': t_RC + TS, 'TPER': TPER_RD_base, 'N': 1
        }
        # CSX (Read)
        self.signal_params_read['CSX'] = {
            'VL': VL, 'VH': VH, 'TD': TD_A_RD, 'TR': TS, 'TF': TS,
            'TPW': t_RC + TS, 'TPER': TPER_RD_base, 'N': 1
        }
        # CSY (Read)
        TD_CSY_RD = TD_A_RD + t_d_DC
        self.signal_params_read['CSY'] = {
            'VL': VL, 'VH': VH, 'TD': TD_CSY_RD, 'TR': TS, 'TF': TS,
            'TPW': t_su_CSY_RD + t_pw_RD_sig + min_t_pw, 'TPER': TPER_RD_base, 'N': 1
        }
        # RD (Read)
        TD_RD_RD = TD_CSY_RD + t_su_CSY_RD
        self.signal_params_read['RD'] = {
            'VL': VL, 'VH': VH, 'TD': TD_RD_RD, 'TR': TS, 'TF': TS,
            'TPW': t_pw_RD_sig, 'TPER': TPER_RD_base, 'N': 1
        }

        return True # Indicate success
    
    def safe_asksave_topmost(title="Save as", defaultextension=".txt"):
        root = tk.Tk()
        root.withdraw()  # Спрятать основное окно
        root.attributes('-topmost', True)  # Сделать всегда наверху (topmost)
        filename = filedialog.asksaveasfilename(
            parent=root,
            title=title,
            defaultextension=defaultextension,
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")]
        )
        root.destroy()  # Уничтожить временный root
        return filename
    
    def compress_pwl_points(self, points):
        if not points:
            return []
    
        compressed = [points[0]]
        for i in range(1, len(points) - 1):
            v_prev = points[i - 1][1]
            v_curr = points[i][1]
            v_next = points[i + 1][1]
    
            if not (v_prev == v_curr == v_next):
                compressed.append(points[i])
    
        compressed.append(points[-1])
        return compressed
    
    # --- PWL Export ---
    def run_calculation_and_pwl_export(self):
        """ Calculate params and export PWL files for both modes with auto-generated filenames. """
        if self.calculation_mode.get() != "Parametrize":
            messagebox.showwarning("Mode Error", "PWL Export only available in Parametrize mode.", parent=self)
            return
    
        if not self._calculate_timing_params():
            return  # Calculation failed
    
        # --- Ask for base filename once ---
        base_path = self.safe_asksave_topmost("Select base name for PWL export files")
        if not base_path:
            messagebox.showinfo("Cancelled", "PWL export cancelled.", parent=self)
            return
    
        base_name, _ = os.path.splitext(base_path)
        filepath_write = base_name + "_write.txt"
        filepath_read = base_name + "_read.txt"
        filepath_combined = base_name + "_combined.txt"
    
        # --- WRITE Mode ---
        with open(filepath_write, "w") as f:
            for signal_name in ["ADDR", "DIN", "WR", "CSY"]:
                params = self.signal_params_write[signal_name]
                points = generate_pwl_points(**params)
                points = self.compress_pwl_points(points)  # <--- добавлена фильтрация
                pwl_data_str = " ".join(f"{t:.6e} {v:.6f}" for t, v in points)
                f.write(f"{signal_name}:PWL({pwl_data_str})\n")
        #print(f"Write mode PWL data exported to {filepath_write}")

        # --- READ Mode ---
        with open(filepath_read, "w") as f:
            for signal_name in ["ADDR", "CSX", "CSY", "RD"]:
                params = self.signal_params_read[signal_name]
                points = generate_pwl_points(**params)
                points = self.compress_pwl_points(points)  # <--- добавлена фильтрация
                pwl_data_str = " ".join(f"{t:.6e} {v:.6f}" for t, v in points)
                f.write(f"{signal_name}:PWL({pwl_data_str})\n")
        #print(f"Read mode PWL data exported to {filepath_read}")

        # --- COMBINED Mode ---
        vl_default = float(self.constants['VL'].get())
        time_step = 0.5 * self.constants['TS'].get() * 1e-9

        t_end_wr = builtins.max(float(p['TD']) + float(p['TPER']) * float(p['N'])
                       for p in self.signal_params_write.values())
        t_end_rd = builtins.max(float(p['TD']) + float(p['TPER']) * float(p['N'])
                       for p in self.signal_params_read.values())
        pause_time = float(self.constants['pause'].get()) * 1e-9
        total_pause = t_end_wr + pause_time

        t_wr = np.arange(0, t_end_wr, time_step)
        t_pause = np.arange(t_end_wr, total_pause, time_step)
        t_rd_shifted = np.arange(total_pause, total_pause + t_end_rd, time_step)
        time_combined = np.concatenate((t_wr, t_pause, t_rd_shifted))

        all_signals = set(self.signal_params_write.keys()).union(self.signal_params_read.keys())
        combined_signals = {}

        for sig in sorted(all_signals):
            p_wr = self.signal_params_write.get(sig)
            p_rd = self.signal_params_read.get(sig)

            v_wr = [calculate_tpulse_voltage(t, **p_wr) if p_wr else vl_default for t in t_wr]
            v_pause = [v_wr[-1] if v_wr else vl_default] * len(t_pause)
            v_rd = [calculate_tpulse_voltage(t - total_pause, **p_rd) if p_rd else vl_default for t in t_rd_shifted]

            combined_signals[sig] = v_wr + v_pause + v_rd

        with open(filepath_combined, "w") as f:
            for sig, voltages in combined_signals.items():
                pwl_points = list(zip(time_combined, voltages))
                print(pwl_points)
                pwl_points = self.compress_pwl_points(pwl_points)
                pwl_str = " ".join(f"{t:.6e} {v:.3f}" for t, v in pwl_points)
                f.write(f"{sig}:PWL({pwl_str})\n")
                
        #print(f"Combined PWL exported to {filepath_combined}")

        # --- Summary message ---
        messagebox.showinfo(
            "Success",
            f"PWL files exported successfully:\n\n"
            f"➤ Write:    {os.path.basename(filepath_write)}\n"
            f"➤ Read:     {os.path.basename(filepath_read)}\n"
            f"➤ Combined: {os.path.basename(filepath_combined)}",
            parent=self
        )

        # --- Excel Export --- 
    def export_excel_func(self):
        """ Calculates params and exports densely sampled waveforms to Excel. """
        if self.calculation_mode.get() != "Parametrize":
            messagebox.showwarning("Mode Error", "Excel Export only available in Parametrize mode.", parent=self)
            return
    
        # Проверка расчета
        if not self._calculate_timing_params():
            return  # Calculation failed
    
        filepath_excel = filedialog.asksaveasfilename(
            parent=self,
            title="Save Waveforms to Excel File",
            defaultextension=".xlsx",
            filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")]
        )
        if not filepath_excel:
            messagebox.showinfo("Cancelled", "Excel export cancelled.", parent=self)
            return
    
        # Сбор всех сигналов
        all_signals = {f"{name}_WR": params for name, params in self.signal_params_write.items()}
        all_signals.update({f"{name}_RD": params for name, params in self.signal_params_read.items()})
    
        if not all_signals:
            messagebox.showerror("Error", "No signal parameters calculated.", parent=self)
            return
    
        # --- Расчет временного окна и шага ---
        max_time = 0.0
        min_step = float('inf')
    
        for params in all_signals.values():
            end_time = float(params['TD']) + float(params['N']) * float(params['TPER'])
            tper_val = float(params.get('TPER', params.get('TPW', 1e-9)))
            max_time = builtins.max(max_time, end_time + tper_val)
    
            # Получаем TS (в секундах)
            ts_param = float(self.constants['TS'].get()) * 1e-9
            tr = float(params['TR'])
            tf = float(params['TF'])
            step_basis = builtins.min(tr, tf, ts_param) if tr > 0 and tf > 0 else ts_param
            min_step = builtins.min(min_step, step_basis)
    
        # Расчет шага времени
        time_step = builtins.max(min_step / 10.0, 10e-15)
        num_points = int(max_time / time_step) + 1
    
        # Лимит на количество точек
        max_points = 100
        if num_points > max_points:
            time_step = max_time / max_points
            num_points = max_points
            print(f"Warning: Limiting Excel points to {max_points}. Time step adjusted to {time_step:.2e} s")
    
        # Генерация вектора времени
        time_vector = np.linspace(0, max_time, num_points)
    
        # --- Формирование Excel-данных ---
        excel_data = {"Time (s)": time_vector}
        #print(f"Generating {num_points} data points for Excel export...")
    
        for signal_name, params in all_signals.items():
            try:
                voltages = [float(calculate_tpulse_voltage(t, **params)) for t in time_vector]
            except Exception as e:
                messagebox.showerror("Data Error", f"Error calculating voltage for signal '{signal_name}':\n{e}", parent=self)
                return
            excel_data[signal_name + " (V)"] = voltages
    
        #print("Data generation complete.")
    
        # --- Экспорт Excel ---
        try:
            df = pd.DataFrame(excel_data)
            #print("Writing to Excel file...")
            df.to_excel(filepath_excel, index=False, engine='openpyxl')
            #print(f"Waveform data successfully exported to {filepath_excel}")
            messagebox.showinfo("Success", f"Waveform data exported to:\n{os.path.basename(filepath_excel)}", parent=self)
        except ImportError:
            messagebox.showerror("Import Error", "The 'openpyxl' library is required to write Excel files.\nPlease install it using: pip install openpyxl", parent=self)
        except Exception as e:
            messagebox.showerror("Excel Export Error", f"An error occurred during Excel export:\n{e}", parent=self)
            #print(f"Excel Export Error: {e}")
        
        # --- ДОПОЛНИТЕЛЬНЫЙ ФАЙЛ: Комбинированная временная ось (WR + RD) ---
        try:
            #print("\nGenerating combined WR+PAUSE+RD waveform...")
            
            vl_default = float(self.constants['VL'].get())
    
            # 1. Вычисляем длительность WR и RD
            t_end_wr = builtins.max(
                float(p['TD']) + float(p['TPER']) * float(p['N'])
                for p in self.signal_params_write.values()
            )
            t_end_rd = builtins.max(
                float(p['TD']) + float(p['TPER']) * float(p['N'])
                for p in self.signal_params_read.values()
            )
    
            pause_time = float(self.constants['pause'].get()) * 1e-9  # ns → s
            total_pause = t_end_wr + pause_time
    
            # 2. Генерируем временные оси с шагом time_step
            t_wr = np.arange(0, t_end_wr, time_step)
            t_pause = np.arange(t_end_wr, total_pause, time_step)
            t_rd_shifted = np.arange(total_pause, total_pause + t_end_rd, time_step)
            time_combined = np.concatenate((t_wr, t_pause, t_rd_shifted))
    
            # 3. Генерация сигналов, сдвигаем RD на total_pause
            all_signal_keys = set(self.signal_params_write.keys()).union(self.signal_params_read.keys())
            combined_signals = {}
    
            for sig in sorted(all_signal_keys):
                p_wr = self.signal_params_write.get(sig)
                p_rd = self.signal_params_read.get(sig)
    
                # WRITE часть
                v_wr = [calculate_tpulse_voltage(t, **p_wr) if p_wr else vl_default for t in t_wr]
                # PAUSE: держим последний уровень WR, или VL
                v_pause = [v_wr[-1] if v_wr else vl_default] * len(t_pause)
                # READ часть - сдвигаем время на -total_pause для расчёта
                v_rd = [calculate_tpulse_voltage(t - total_pause, **p_rd) if p_rd else vl_default for t in t_rd_shifted]
    
                combined_signals[sig] = v_wr + v_pause + v_rd
    
            # 4. Сбор данных
            combined_data = {"Time": np.round(time_combined, 14)}
            for sig, vlist in combined_signals.items():
                combined_data[f"{sig}"] = vlist
    
            df_combo = pd.DataFrame(combined_data)
    
            # 5. Сохраняем файл рядом
            base, ext = os.path.splitext(filepath_excel)
            combined_path = base + "_combined.xlsx"
            df_combo.to_excel(combined_path, index=False, engine="openpyxl")
            #print(f"Combined WR+RD waveform exported to {combined_path}")
    
        except Exception as e:
            #print(f"Error creating combined Excel: {e}")
            messagebox.showerror("Export Error", f"Failed to create combined Excel file:\n{e}", parent=self) 
        

    # --- Apply Settings (Original Functionality) ---
    def apply_settings(self):
        """ Returns the selected parameters and maximum widths when the window is closed. """
        self.grab_set() # Make window modal
        self.wait_window() # Wait until window is destroyed (closed or Apply button)

        # Get results based on the mode selected when the window was closed/applied
        if self.calculation_mode.get() == "Precalculate":
            # In Precalculate, we only care about load R and C
            results = {
                'None': None, # Keep this structure as per original example?
                'R_L_OUT': self.params['R_L_OUT'].get(),
                'C_L_OUT': self.params['C_L_OUT'].get()
            }
            # Max widths are probably irrelevant in precalculate mode, return empty or zero dict
            max_widths_results = {}
            # Or return the values entered, even if disabled?
            # max_widths_results = {f'MAX(W_{key.replace("t_", "")})': self.max_widths[key].get()
            #                       for key in self.max_widths}

        elif self.calculation_mode.get() == "Parametrize":
            try:
                results = {
                    't_WL': self.params['t_WL'].get(), # ps
                    't_WR': self.params['t_WR'].get(), # ps
                    't_PC': self.params['t_PC'].get(), # ps
                    't_OUT': self.params['t_OUT'].get(), # ps
                    'R_L_OUT': self.params['R_L_OUT'].get(), # Ohm
                    'C_L_OUT': self.params['C_L_OUT'].get() # fF
                }
                max_widths_results = {f'MAX(W_{key.replace("t_", "")})': (self.max_widths[key].get() * 1e3) for key in self.max_widths}
            except (tk.TclError, ValueError):
                messagebox.showerror("Apply Error", "Invalid numeric input detected. Cannot apply settings.")
                # Return default/empty values or re-raise?
                return {}, {} # Return empty dicts on error
        else: # Should not happen
            results = {}
            max_widths_results = {}
        
        print("SRAM param start with:", results, max_widths_results)
        return results, max_widths_results

class CellSyn(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.columns = tk.IntVar()
        self.rows = tk.IntVar()

        label = tk.Label(self, text="Cell Array Synthesis:")
        entry_columns = tk.Entry(self, textvariable=self.columns)
        entry_rows = tk.Entry(self, textvariable=self.rows)
        btn = tk.Button(self, text="Apply", command=self.destroy)

        label.grid(row=0, columnspan=2)
        tk.Label(self, text="M (rows):").grid(row=1, column=0)
        tk.Label(self, text="N (columns):").grid(row=2, column=0)
        entry_columns.grid(row=1, column=1)
        entry_rows.grid(row=2, column=1)
        btn.grid(row=3, columnspan=2)

    def open(self):
        self.grab_set()
        self.wait_window()
        columns = self.columns.get()
        rows = self.rows.get()
        return [columns, rows]


class AreaParam(tk.Toplevel):
    def __init__(self, parent, area_type):
        super().__init__(parent)
        self.width = tk.IntVar()
        self.length = tk.IntVar()
        self.area_type = area_type

        label = tk.Label(self, text="Create element: " + area_type.lower())
        entry_name = tk.Entry(self, textvariable=self.width)
        entry_pass = tk.Entry(self, textvariable=self.length)
        btn = tk.Button(self, text="Apply", command=self.destroy)

        label.grid(row=0, columnspan=2)
        tk.Label(self, text="Channel length:").grid(row=1, column=0)
        tk.Label(self, text="Channel width:").grid(row=2, column=0)
        entry_name.grid(row=1, column=1)
        entry_pass.grid(row=2, column=1)
        tk.Label(self, text="lambda").grid(row=1, column=2)
        tk.Label(self, text="lambda").grid(row=2, column=2)
        btn.grid(row=3, columnspan=2)

    def open(self):
        self.grab_set()
        self.wait_window()
        width = self.width.get()
        length = self.length.get()
        return Element(width, length, self.area_type)


class LoadRC(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        # only for demonstratioin we can set C_L manually
        self.C_L = tk.IntVar()  # default fF
        self.R_L = tk.IntVar()  # default Ohm
        self.choose_mode = tk.IntVar()  # if 1 then do Auto.calc

        if self.C_L.get() == 0:
            self.C_L.set(100)
        if self.R_L.get() == 0:
            self.R_L.set(100)

        label = tk.Label(self, text="Enter load values:")
        label.grid(row=0, columnspan=2)

        entry_c_l = tk.Entry(self, textvariable=self.C_L)
        entry_r_l = tk.Entry(self, textvariable=self.R_L)

        btn = tk.Button(self, text="Apply", command=self.destroy)
        mode_btn = tk.Button(self, text="Auto calc.",
                             command=self.choose_mode_func)

        tk.Label(self, text="C_L:").grid(row=2, column=0)
        entry_c_l.grid(row=2, column=1)
        tk.Label(self, text="fF").grid(row=2, column=2)

        tk.Label(self, text="R_L:").grid(row=3, column=0)
        entry_r_l.grid(row=3, column=1)
        tk.Label(self, text="Ohm").grid(row=3, column=2)

        btn.grid(row=4, columnspan=3, sticky="nswe")
        mode_btn.grid(row=5, columnspan=3, sticky="nswe")

    def open(self):
        self.grab_set()
        self.wait_window()
        c_l = self.C_L.get()
        r_l = self.R_L.get()
        mode = self.choose_mode.get()
        return [c_l, r_l, mode]

    def choose_mode_func(self):
        self.choose_mode.set(1)
        self.destroy()


class PCParam(tk.Toplevel):
    pc_blocks = precharges

    def __init__(self, parent):
        super().__init__(parent)
        self.time = tk.DoubleVar()
        self.eq_mos_scale = tk.DoubleVar()

        # only for demonstratioin we set R_L and C_L manually
        self.C_L = tk.IntVar()  # default fF
        self.R_L = tk.IntVar()  # default Ohm
        self.choose_mode = tk.IntVar()  # if 1 then do Auto.calc

        if self.C_L.get() == 0:
            self.C_L.set(100)
        if self.R_L.get() == 0:
            self.R_L.set(100)

        if int(self.eq_mos_scale.get()) == 0:
            self.eq_mos_scale.set(1)

        label = tk.Label(self, text="Enter precharge time and s-factor:")
        label.grid(row=0, columnspan=2)

        entry_time = tk.Entry(self, textvariable=self.time)
        entry_s = tk.Entry(self, textvariable=self.eq_mos_scale)
        entry_c_l = tk.Entry(self, textvariable=self.C_L)
        entry_r_l = tk.Entry(self, textvariable=self.R_L)

        btn = tk.Button(self, text="Apply", command=self.destroy)
        mode_btn = tk.Button(self, text="Auto calc.",
                             command=self.choose_mode_func)

        self.pc_block = tk.StringVar()
        self.pc_block.set(self.pc_blocks[0])
        pc_block_label = tk.Label(self, text="Choose PC block")
        pc_block_option = tk.OptionMenu(self, self.pc_block, *self.pc_blocks)

        tk.Label(self, text="t_PC:").grid(row=1, column=0)
        entry_time.grid(row=1, column=1)
        tk.Label(self, text="ps").grid(row=1, column=2)

        tk.Label(self, text="s-factor:").grid(row=2, column=0)
        entry_s.grid(row=2, column=1)

        pc_block_label.grid(sticky=tk.W, row=3, column=0)
        pc_block_option.grid(row=3, column=1)

        tk.Label(self, text="C_L:").grid(row=6, column=0)
        entry_c_l.grid(row=6, column=1)
        tk.Label(self, text="fF").grid(row=6, column=2)

        tk.Label(self, text="R_L:").grid(row=7, column=0)
        entry_r_l.grid(row=7, column=1)
        tk.Label(self, text="Ohm").grid(row=7, column=2)

        btn.grid(row=8, columnspan=3, sticky="nswe")
        mode_btn.grid(row=9, columnspan=3, sticky="nswe")

    def open(self):
        self.grab_set()
        self.wait_window()
        time = self.time.get()
        eq_mos_scale = self.eq_mos_scale.get()
        pc_block = self.pc_block.get()
        c_l = self.C_L.get()
        r_l = self.R_L.get()
        mode = self.choose_mode.get()
        return [time, eq_mos_scale, pc_block, c_l, r_l, mode]

    def choose_mode_func(self):
        self.choose_mode.set(1)
        self.destroy()


class PULSEYParam(tk.Toplevel):
    pulse_blocks = y_pulses

    def __init__(self, parent):
        super().__init__(parent)
        self.time = tk.DoubleVar()
        # only for demonstratioin we set C_L and R_L manually
        self.C_L = tk.IntVar()  # default fF
        self.R_L = tk.IntVar()  # default Ohm
        self.choose_mode = tk.IntVar()  # if 1 then do Auto.calc

        if self.C_L.get() == 0:
            self.C_L.set(100)
        if self.R_L.get() == 0:
            self.R_L.set(100)

        label = tk.Label(self, text="Enter WL access time:")
        label.grid(row=0, columnspan=2)

        entry_time = tk.Entry(self, textvariable=self.time)
        entry_c_l = tk.Entry(self, textvariable=self.C_L)
        entry_r_l = tk.Entry(self, textvariable=self.R_L)

        btn = tk.Button(self, text="Apply", command=self.destroy)
        mode_btn = tk.Button(self, text="Auto calc.",
                             command=self.choose_mode_func)

        self.pulse_block = tk.StringVar()
        self.pulse_block.set(self.pulse_blocks[0])
        pulse_block_label = tk.Label(self, text="Choose Y PULSE block")
        pulse_block_option = tk.OptionMenu(
            self, self.pulse_block, *self.pulse_blocks)

        tk.Label(self, text="t_WL:").grid(row=1, column=0)
        entry_time.grid(row=1, column=1)
        tk.Label(self, text="ps").grid(row=1, column=2)

        pulse_block_label.grid(sticky=tk.W, row=2, column=0)
        pulse_block_option.grid(row=2, column=1)

        tk.Label(self, text="C_L:").grid(row=4, column=0)
        entry_c_l.grid(row=4, column=1)
        tk.Label(self, text="fF").grid(row=4, column=2)

        tk.Label(self, text="R_L:").grid(row=5, column=0)
        entry_r_l.grid(row=5, column=1)
        tk.Label(self, text="Ohm").grid(row=5, column=2)

        btn.grid(row=6, columnspan=3, sticky="nswe")
        mode_btn.grid(row=7, columnspan=3, sticky="nswe")

    def open(self):
        self.grab_set()
        self.wait_window()
        time = self.time.get()
        pulse_block = self.pulse_block.get()
        c_l = self.C_L.get()
        r_l = self.R_L.get()
        mode = self.choose_mode.get()
        return [time, pulse_block, c_l, r_l, mode]

    def choose_mode_func(self):
        self.choose_mode.set(1)
        self.destroy()


class PULSEXParam(tk.Toplevel):
    pulse_blocks = x_pulses

    def __init__(self, parent):
        super().__init__(parent)
        self.time = tk.DoubleVar()
        # only for demonstratioin we set C_L and R_L manually
        self.C_L = tk.IntVar()  # default fF
        self.R_L = tk.IntVar()  # default Ohm
        self.choose_mode = tk.IntVar()  # if 1 then do Auto.calc

        if self.C_L.get() == 0:
            self.C_L.set(100)
        if self.R_L.get() == 0:
            self.R_L.set(100)

        label = tk.Label(self, text="Enter BUFFER access time:")
        label.grid(row=0, columnspan=2)

        entry_time = tk.Entry(self, textvariable=self.time)
        entry_c_l = tk.Entry(self, textvariable=self.C_L)
        entry_r_l = tk.Entry(self, textvariable=self.R_L)

        btn = tk.Button(self, text="Apply", command=self.destroy)
        mode_btn = tk.Button(self, text="Auto calc.",
                             command=self.choose_mode_func)

        self.pulse_block = tk.StringVar()
        self.pulse_block.set(self.pulse_blocks[0])
        pulse_block_label = tk.Label(self, text="Choose X PULSE block")
        pulse_block_option = tk.OptionMenu(
            self, self.pulse_block, *self.pulse_blocks)

        tk.Label(self, text="t_gate:").grid(row=1, column=0)
        entry_time.grid(row=1, column=1)
        tk.Label(self, text="ps").grid(row=1, column=2)

        pulse_block_label.grid(sticky=tk.W, row=2, column=0)
        pulse_block_option.grid(row=2, column=1)

        tk.Label(self, text="C_L:").grid(row=4, column=0)
        entry_c_l.grid(row=4, column=1)
        tk.Label(self, text="fF").grid(row=4, column=2)

        tk.Label(self, text="R_L:").grid(row=5, column=0)
        entry_r_l.grid(row=5, column=1)
        tk.Label(self, text="Ohm").grid(row=5, column=2)

        btn.grid(row=6, columnspan=3, sticky="nswe")
        mode_btn.grid(row=7, columnspan=3, sticky="nswe")

    def open(self):
        self.grab_set()
        self.wait_window()
        time = self.time.get()
        pulse_block = self.pulse_block.get()
        c_l = self.C_L.get()
        r_l = self.R_L.get()
        mode = self.choose_mode.get()
        return [time, pulse_block, c_l, r_l, mode]

    def choose_mode_func(self):
        self.choose_mode.set(1)
        self.destroy()


class WRParam(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.time = tk.DoubleVar()
        self.choose_mode = tk.IntVar()  # if 1 then do Auto.calc
        # only for demonstratioin we set R_L and C_L manually
        self.R_L = tk.IntVar()  # default Ohm
        self.C_L = tk.IntVar()  # default fF

        if self.R_L.get() == 0:
            self.R_L.set(100)

        if self.C_L.get() == 0:
            self.C_L.set(100)

        label = tk.Label(self, text="Enter write signal time:")
        label.grid(row=0, columnspan=2)

        entry_time = tk.Entry(self, textvariable=self.time)
        entry_r_l = tk.Entry(self, textvariable=self.R_L)
        entry_c_l = tk.Entry(self, textvariable=self.C_L)

        btn = tk.Button(self, text="Apply", command=self.destroy)
        mode_btn = tk.Button(self, text="Auto calc.",
                             command=self.choose_mode_func)

        tk.Label(self, text="t_WR:").grid(row=1, column=0)
        entry_time.grid(row=1, column=1)
        tk.Label(self, text="ps").grid(row=1, column=2)

        tk.Label(self, text="R_L:").grid(row=5, column=0)
        entry_r_l.grid(row=5, column=1)
        tk.Label(self, text="Ohm").grid(row=5, column=2)

        tk.Label(self, text="C_L:").grid(row=4, column=0)
        entry_c_l.grid(row=4, column=1)
        tk.Label(self, text="fF").grid(row=4, column=2)

        btn.grid(row=6, columnspan=3, sticky="nswe")
        mode_btn.grid(row=7, columnspan=3, sticky="nswe")

    def open(self):
        self.grab_set()
        self.wait_window()
        time = self.time.get()
        c_l = self.C_L.get()
        r_l = self.R_L.get()
        mode = self.choose_mode.get()
        return [time, c_l, r_l, mode]

    def choose_mode_func(self):
        self.choose_mode.set(1)
        self.destroy()


class OUTParam(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.time = tk.DoubleVar()
        # only for demonstratioin we set R_L and C_L manually
        self.R_L = tk.IntVar()  # default Ohm
        self.C_L = tk.IntVar()  # default fF

        if self.R_L.get() == 0:
            self.R_L.set(100)

        if self.C_L.get() == 0:
            self.C_L.set(100)

        label = tk.Label(self, text="Enter OUT_BLOCK delay time:")
        label.grid(row=0, columnspan=2)

        entry_time = tk.Entry(self, textvariable=self.time)
        entry_r_l = tk.Entry(self, textvariable=self.R_L)
        entry_c_l = tk.Entry(self, textvariable=self.C_L)

        btn = tk.Button(self, text="Apply", command=self.destroy)

        tk.Label(self, text="t_OUT:").grid(row=1, column=0)
        entry_time.grid(row=1, column=1)
        tk.Label(self, text="ps").grid(row=1, column=2)

        tk.Label(self, text="R_L:").grid(row=2, column=0)
        entry_r_l.grid(row=2, column=1)
        tk.Label(self, text="Ohm").grid(row=2, column=2)

        tk.Label(self, text="C_L:").grid(row=3, column=0)
        entry_c_l.grid(row=3, column=1)
        tk.Label(self, text="fF").grid(row=3, column=2)

        btn.grid(row=4, columnspan=3, sticky="nswe")

    def open(self):
        self.grab_set()
        self.wait_window()
        time = self.time.get()
        c_l = self.C_L.get()
        r_l = self.R_L.get()
        return [time, c_l, r_l]


class CropParam(tk.Toplevel):

    def __init__(self, parent):
        super().__init__(parent)
        self.delta = tk.IntVar()
        self.increase_flag = False
        self.decrease_flag = False
        label = tk.Label(self, text="Let modify")
        entry_value = tk.Entry(self, textvariable=self.delta)
        btn_increase = tk.Button(self, text="increase", command=self.increase)
        btn_decrease = tk.Button(self, text="decrease", command=self.decrease)

        label.grid(row=0, columnspan=2)
        tk.Label(self, text="Delta:").grid(row=1, column=0)
        entry_value.grid(row=1, column=1)
        tk.Label(self, text="lambda").grid(row=1, column=2)
        btn_increase.grid(row=2, columnspan=3, sticky="nswe")
        btn_decrease.grid(row=3, columnspan=3, sticky="nswe")

    def increase(self):
        self.increase_flag = True
        self.decrease_flag = False
        self.destroy()

    def decrease(self):
        self.increase_flag = False
        self.decrease_flag = True
        self.destroy()

    def open(self):
        self.grab_set()
        self.wait_window()
        if self.increase_flag == True and self.decrease_flag == False:
            delta = self.delta.get()
        elif self.increase_flag == False and self.decrease_flag == True:
            delta = -self.delta.get()
        self.increase_flag = False
        self.decrease_flag = False

        return delta


class PULSEXSyn(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.columns = tk.IntVar()

        label = tk.Label(self, text="Entry amount of columns:")
        entry_value = tk.Entry(self, textvariable=self.columns)
        btn = tk.Button(self, text="Apply", command=self.destroy)

        label.grid(row=0, columnspan=2)
        tk.Label(self, text="N:").grid(row=1, column=0)
        entry_value.grid(row=1, column=1)
        btn.grid(row=3, columnspan=2)

    def open(self):
        self.grab_set()
        self.wait_window()
        columns = math.ceil(self.columns.get()/2)
        return columns


class PULSEYSyn(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.rows = tk.IntVar()

        label = tk.Label(self, text="Entry amount of rows:")
        entry_value = tk.Entry(self, textvariable=self.rows)
        btn = tk.Button(self, text="Apply", command=self.destroy)

        label.grid(row=0, columnspan=2)
        tk.Label(self, text="M:").grid(row=1, column=0)
        entry_value.grid(row=1, column=1)
        btn.grid(row=3, columnspan=2)

    def open(self):
        self.grab_set()
        self.wait_window()
        rows = math.ceil(self.rows.get()/2)
        return rows


class PCRowSyn(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.columns = tk.IntVar()

        label = tk.Label(self, text="Entry amount of columns:")
        entry_value = tk.Entry(self, textvariable=self.columns)
        btn = tk.Button(self, text="Apply", command=self.destroy)

        label.grid(row=0, columnspan=2)
        tk.Label(self, text="N:").grid(row=1, column=0)
        entry_value.grid(row=1, column=1)
        btn.grid(row=3, columnspan=2)

    def open(self):
        self.grab_set()
        self.wait_window()
        columns = self.columns.get()
        return columns


class MultiplyingFunc(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.news_amount = tk.IntVar()

        label = tk.Label(self, text="Enter amount of multiplying blocks:")
        label.grid(row=0, columnspan=2)

        entry_amount = tk.Entry(self, textvariable=self.news_amount)

        btn = tk.Button(self, text="Apply", command=self.destroy)

        self.axis = tk.StringVar()
        axis_label = tk.Label(self, text="Choose an axis:")
        self.axis.set('R')
        axis_option = tk.OptionMenu(self, self.axis, *('L', 'R', 'U', 'D'))

        tk.Label(self, text="Amount:").grid(row=1, column=0)
        entry_amount.grid(row=1, column=1)

        axis_label.grid(sticky=tk.W, row=3, column=0)
        axis_option.grid(row=3, column=1)

        btn.grid(row=7, columnspan=2)

    def open(self):
        self.grab_set()
        self.wait_window()
        amount = self.news_amount.get()
        axis = self.axis.get()
        return [axis, amount]


'''
class MatrixDCSyn(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.i = tk.IntVar()

        label = tk.Label(self, text="Entry amount of inputs:")
        entry_value = tk.Entry(self, textvariable=self.i)
        btn = tk.Button(self, text="Apply", command=self.destroy)

        label.grid(row=0, columnspan=2)
        tk.Label(self, text="Bit Depth(I):").grid(row=1, column=0)
        entry_value.grid(row=1, column=1)
        btn.grid(row=3, columnspan=2)

    def open(self):
        self.grab_set()
        self.wait_window()
        i = self.i.get()
        return i
'''


class BuffRowSyn(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.columns = tk.IntVar()

        label = tk.Label(self, text="Entry amount of columns:")
        entry_value = tk.Entry(self, textvariable=self.columns)
        btn = tk.Button(self, text="Apply", command=self.destroy)

        label.grid(row=0, columnspan=2)
        tk.Label(self, text="N:").grid(row=1, column=0)
        entry_value.grid(row=1, column=1)
        btn.grid(row=3, columnspan=2)

    def open(self):
        self.grab_set()
        self.wait_window()
        columns = self.columns.get()
        return columns


class ReadCIF_MW():
    def __init__(self, path, name):  # , Lambda):
        self.name = name
        self.path = path
        # self.Lambda = Lambda
        # print(self.name, self.path )

        file = open(self.path, "r")
        self.lines = file.readlines()
        # print(self.lines)
        file.close()

    def getCoords(self):
        blocks = {}
        paths = {f'{self.name}': f"{self.path}"}

        blocks[self.name] = {}
        for p in paths.keys():
            coords = self.getArea()
            for i in range(len(top_area)):
                blocks[p][top_area[i]] = coords[i]
        # print(blocks[f'{self.name}'])
        return blocks[f'{self.name}']

    def getArea(self):
        n = len(top_area)
        amountArea = [0]*n
        coordArea = [0]*n
        zoom_coords = []
        read_flag = False

        for line in self.lines:
            # \  - экранирование метасимволов
            line = re.split(",|_| |;", line.strip())

            if line[-1] == '':
                line.pop()
            # print(line)
            if len(line) != 0:
                if line[0] == 'DS':
                    read_flag = True
                elif line[0] == 'DF':
                    read_flag = False

                if line[0] == 'L' and read_flag == True:
                    self.box = line[-1]
                    # print(self.box)

                if line[0] == 'P' and read_flag == True:
                    for i in range(n):
                        if self.box == top_area[i] and read_flag == True:
                            amountArea[i] += 1
                        # print(self.box)
                    # if self.box == cif_areas_mw['OP']:
                    # find self.Lambda coords and convert to int
                    zoom_coords = list(map(int, line[1:]))
                    '''
                    for d in range(len(zoom_coords)):
                        zoom_coords[d] /= self.Lambda
                    '''
                    # zoom_x0, zoom_y0 = math.floor(zoom_coords[-2]-(zoom_coords[0]/2)), math.floor(zoom_coords[-1]-(zoom_coords[1]/2))
                    zoom_x0, zoom_y0 = zoom_coords[0], zoom_coords[-1]
                    # zoom_x1, zoom_y1 = zoom_coords[2], zoom_coords[3]
                    zoom_dx, zoom_dy = zoom_coords[2] - \
                        zoom_coords[0], -(zoom_coords[-1] - zoom_coords[1])
                    zoom_coords = [zoom_x0, zoom_y0,
                                   zoom_dx, zoom_dy]  # -zoom_dy/2
                    # print('zoom_coords',zoom_coords)
        for i in range(n):
            for j in range(amountArea[i]):
                coordArea[i] = [0] * (j+1)
        # print(coordArea)

        for i in range(n):
            count = 0
            while count < amountArea[i]:
                for line in self.lines:
                    # \  - экранирование метасимволов
                    line = re.split(",|_| |;", line.strip())
                    if line[-1] == '':
                        line.pop()
                    if len(line) != 0:
                        if line[0] == 'DS':
                            read_flag = True
                        elif line[0] == 'DF':
                            read_flag = False

                        if line[0] == 'L' and read_flag == True:
                            self.box = line[-1]

                        if line[0] == 'P' and read_flag == True:

                            if self.box == top_area[i]:
                                # print(line)
                                coord_list = list(
                                    map(int, line[1:]))  # str->int
                                '''
                                for d in range(len(coord_list)):
                                    coord_list[d] /= self.Lambda
                                '''
                                # print('before', coord_list)
                                # ---------CIF to MSK----------
                                dx, dy = coord_list[2] - coord_list[0], - \
                                    (coord_list[-1] - coord_list[1])
                                x0, y0 = coord_list[0], coord_list[-1]
                                # x1, y1 = coord_list[2], coord_list[3]
                                coord_list = [x0, y0, dx, dy]
                                # ------------------------------
                                # print('after', coord_list)

                                for z in range(2):
                                    if zoom_coords[z] < 0:
                                        coord_list[z] += abs(zoom_coords[z])

                                    elif zoom_coords[z] > 0:
                                        coord_list[z] -= abs(zoom_coords[z])

                                if self.box != 'OP':
                                    coord_list[1] = zoom_coords[3] - \
                                        coord_list[1]

                                coordArea[i][count] = coord_list
                                count += 1
                                # print('normalized',coord_list)
        return coordArea


class ReadTXT_Foundry():
    def __init__(self, path, name):
        self.name = name
        self.path = path
        file = open(self.path, "r")
        self.lines = file.readlines()
        file.close()

    def getParams(self):
        CAPs = {
            'SRAM': {'WL': None, 'BL': None, 'NBL': None},
            'BUFFER': {'CmnBL': None, 'CmnNBL': None},
            'BTMPC': {'BL': None, 'NBL': None}
        }
        RESs = {
            'SRAM': {'WL': None, 'BL': None, 'NBL': None},
            'BUFFER': {'CmnBL': None, 'CmnNBL': None},
            'BTMPC': {'BL': None, 'NBL': None}
        }
        for line in self.lines:
            line = line.strip()

            # ------------get lambda--------
            if line.find('GridUnit') != -1 and line.find('*') == -1:
                # \  - экранирование метасимволов
                getLine = re.split(' ', line.strip())
                GridUnit = int(getLine[-1])

            for block in CAPs.keys():  # ------------get CAPs--------
                for bus in CAPs[block].keys():
                    if line.find(bus) != -1 and line.find(block) != -1 and line.find('*') == -1 and line.find('CAP') != -1:
                        # \  - экранирование метасимволов
                        getLine = re.split(' ', line.strip())
                        CAPs[block][bus] = float(getLine[-1])
            for block in RESs.keys():  # ------------get RESs--------
                for bus in RESs[block].keys():
                    if line.find(bus) != -1 and line.find(block) != -1 and line.find('*') == -1 and line.find('RES') != -1:
                        # \  - экранирование метасимволов
                        getLine = re.split(' ', line.strip())
                        RESs[block][bus] = float(getLine[-1])
        return GridUnit, CAPs, RESs


class ReadTXT_MW():

    def __init__(self, path, name):
        self.name = name
        self.path = path
        file = open(self.path, "r")
        self.lines = file.readlines()
        file.close()

    def getParams(self):
        parameters = {}
        for i in range(len(mos_models)):
            parameters[mos_models[i]] = {'NMOS': {}, 'PMOS': {}}
            if mos_models[i] == 'Level1':
                for j in range(len(level_1_params)):
                    parameters[mos_models[i]]['NMOS'][level_1_params[j]] = {}
                    parameters[mos_models[i]]['PMOS'][level_1_params[j]] = {}

        # print(parameters)
        CAPs = {
            'SRAM': {'WL': None, 'BL': None},
            'BUFFER': {'CmnBL': None, 'CmnNBL': None},
            'BTMPC': {'BL': None}
        }
        for line in self.lines:
            line = line.strip()
            # print(line)

            # ------------get lambda--------
            if line.find('lambda') != -1 and line.find('r') == -1:
                # \  - экранирование метасимволов
                getLine = re.split("=| |\//", line.strip())
                Lambda = float(getLine[3])

            for block in CAPs.keys():  # ------------get CAPs--------
                for bus in CAPs[block].keys():
                    if line.find(f'{block}_{bus}_CAP') != -1 and line.find('r') == -1:
                        # \  - экранирование метасимволов
                        getLine = re.split("=| |\//", line.strip())
                        CAPs[block][bus] = float(getLine[-1])
        # ------------get DRC params--------

        # --------------get spice params------------

        return Lambda, CAPs  # , parameters
        # print(parameters)

    def getCoords(self):
        blocks = {}
        paths = {f'{self.name}': f"{self.path}"}

        blocks[self.name] = {}

        for p in paths.keys():
            coords = self.getArea()
            for i in range(len(top_area['Microwind65'])):
                blocks[p][top_area['Microwind65'][i]] = coords[i]
        return blocks[f'{self.name}']

    def getRC(self):
        zero_caps = {}
        a_params = {}
        for line in self.lines:
            line = line.strip()
            if line.find('CAP') != -1:
                # \  - экранирование метасимволов
                line = re.split("\(|,|\)", line.strip())
                zero_caps[line[-2]] = float(line[1])
                probe = line[2:-2]
                for v in range(len(line[2:-2])):
                    probe[v] = float(line[2:-2][v])
                a_params[line[-2]] = probe
        return zero_caps, a_params

    def getArea(self):
        self.getRC()

        coord_dict = {layer: [] for layer in top_area['Microwind65']}
        x_shift, y_shift = 0, 0

        for row in self.lines:
            line = re.split("\(|,|\)", row.strip())
            if line[-2] in coord_dict.keys():
                layer_coords = list(map(int, line[1:5]))
                if line[-2] == 'OP':
                    x_shift, y_shift = -layer_coords[0], -layer_coords[1]
                shifted_coords = [layer_coords[0] + x_shift,
                                  layer_coords[1] + y_shift, layer_coords[2], layer_coords[3]]
                coord_dict[line[-2]].append(shifted_coords)
                # print(line)

        op_coords = coord_dict['OP'][0]
        # print(coord_dict)
        for layer in coord_dict.keys():
            if layer != 'OP' and coord_dict[layer]:
                # print(layer)
                for i in range(len(coord_dict[layer])):
                    coord_dict[layer][i] = [coord_dict[layer][i][0], coord_dict[layer][i]
                                            [1] - op_coords[3], coord_dict[layer][i][2], coord_dict[layer][i][3]]
                    coord_dict[layer][i] = [coord_dict[layer][i][0], coord_dict[layer][i][1] + 2 * (
                        op_coords[1] - coord_dict[layer][i][1]) - coord_dict[layer][i][3], coord_dict[layer][i][2], coord_dict[layer][i][3]]
        coord_list = list(coord_dict.values())
        # print(coord_list)

        return coord_list


class ReadTXT_SW:
    def __init__(self, path, name):
        self.name = name
        self.path = path
        with open(self.path, "r") as file:
            self.lines = file.readlines()

    def getCoords(self):
        coords = self.getArea()
        return {layer: coords[i] for i, layer in enumerate(top_area['SkyWater130'])}

    def getArea(self):
        coord_dict = {layer: [] for layer in top_area['SkyWater130']}
        layer_name = None

        for row in self.lines:
            line = row.strip().split()
            if len(line) > 2 and line[1] in coord_dict:
                layer_name = line[1]

            if layer_name and line[0] == 'rect':
                x1, y1, x2, y2 = map(int, line[1:])
                inserting_coords = [x1, y1, x2 - x1, y2 - y1]
                coord_dict[layer_name].append(inserting_coords)

            elif 'OP' in row:
                x1, y1, x2, y2 = map(int, line[2:6])
                coord_dict['OP'].append([x1, y1, x2, y2])

        if not coord_dict['OP']:
            raise ValueError("No OP coordinates found.")

        op_x1, op_y1, op_x2, op_y2 = coord_dict['OP'][0]
        op_height = op_y2 - op_y1

        for layer, coords in coord_dict.items():
            if layer == 'OP':
                continue
            for i in range(len(coords)):
                x, y, w, h = coords[i]
                y -= op_y2
                y = y + 2 * (op_y1 - y) - h
                coords[i] = [x, y, w, h]

        return list(coord_dict.values())


#class ReadTXT_SW():

    #def __init__(self, path, name):
        #self.name = name
        #self.path = path
        #file = open(self.path, "r")
        #self.lines = file.readlines()
        #file.close()

    #def getCoords(self):
        #blocks = {}
        #paths = {f'{self.name}': f"{self.path}"}

        #blocks[self.name] = {}

        #for p in paths.keys():
            #coords = self.getArea()
            #for i in range(len(top_area['SkyWater130'])):
                #blocks[p][top_area['SkyWater130'][i]] = coords[i]
        #return blocks[f'{self.name}']

    #def getArea(self):
        #coord_dict = {layer: [] for layer in top_area['SkyWater130']}
        #layer_name = None

        #for row in self.lines:
            #line = re.split(" ", row.strip())
            #if (len(line) > 2) and (line[1] in top_area['SkyWater130']):
                #layer_name = line[1]

            #if layer_name is not None and line[0] == 'rect':
                #original_coords = list(map(int, line[1:]))
                #inserting_coords = [original_coords[0], original_coords[1], original_coords[2] -
                                    #original_coords[0], original_coords[3] - original_coords[1]]
                #if layer_name == 'comment':
                    #coord_dict['OP'].append(inserting_coords)
                #else:
                    #coord_dict[layer_name].append(inserting_coords)

            #if row.find('OP') != -1:
                #original_coords = list(map(int, line[2:6]))
                #coord_dict['OP'].append(original_coords)

        #op_coords = coord_dict['OP'][0]
        #for layer in coord_dict.keys():
            #if layer != 'OP' and coord_dict[layer]:
                #for i in range(len(coord_dict[layer])):
                    #coord_dict[layer][i] = [coord_dict[layer][i][0], coord_dict[layer][i]
                                            #[1] - op_coords[3], coord_dict[layer][i][2], coord_dict[layer][i][3]]
                    #coord_dict[layer][i] = [coord_dict[layer][i][0], coord_dict[layer][i][1] + 2 * (
                        #op_coords[1] - coord_dict[layer][i][1]) - coord_dict[layer][i][3], coord_dict[layer][i][2], coord_dict[layer][i][3]]
        #coord_list = list(coord_dict.values())

        #return coord_list


class ResizingCanvas(tk.Canvas):
    def __init__(self, parent, **kwargs):
        tk.Canvas.__init__(self, parent, **kwargs)
        self.bind("<Configure>", self.on_resize)
        self.height = self.winfo_reqheight()
        self.width = self.winfo_reqwidth()

    def on_resize(self, event):
        # determine the ratio of old width/height to new width/height
        scale = float(event.height)/self.height
        self.width = event.width
        self.height = event.height
        # resize the canvas
        self.config(width=self.width, height=self.height)
        # rescale all the objects tagged with the "all" tag
        # self.scale("all",0,0,wscale,hscale)
        self.scale("all", 0, 0, scale, scale)


class App(ttk.Frame):
    foundrys = ['SkyWater130', 'Microwind65']

    def __init__(self, mainframe, folder):

        ttk.Frame.__init__(self, master=mainframe)

        self.filefolder = folder
        self.master.title("TopoPlot")
        self.master.iconbitmap(r'nano.ico')
        # self.win_width = self.master.winfo_screenwidth()
        # self.win_height = self.master.winfo_screenheight()
        # self.master.geometry("%dx%d" % (self.win_width, self.win_height))
        self.master.state('zoomed')
        # print(self.win_width, self.win_height)
        # ---------creaing menu-----------
        menubar = tk.Menu(self)
        menu_f = tk.Menu(menubar, tearoff=0)  # file
        edit_f = tk.Menu(menubar, tearoff=0)
        synt_f = tk.Menu(menubar, tearoff=0)
        param_f = tk.Menu(menubar, tearoff=0)
        info_f = tk.Menu(menubar, tearoff=0)
        # layers_f = tk.Menu(menubar,tearoff=0)
        export_f = tk.Menu(menubar, tearoff=0)

        menubar.add_cascade(label="File", menu=menu_f)  # Top Line
        menu_f.add_command(label="Open..", command=self.open_file)
        menu_f.add_command(label="Delete all", command=self.close_file)
        menu_f.add_command(label="Select foundry", command=self.getFoundry)
        menu_f.add_command(label="Insert", command=self.insert_file)
        # menu_f.add_command(label="Options", command=self.options_frame)
        menu_f.add_command(label="Layers", command=self.layers_menu)
        menu_f.add_command(label="Blocks", command=self.blocks_menu)
        # menu_f.add_command(label="Export2TXT", command=self.export_txt)
        # menu_f.add_command(label="Export2CIF", command=self.export_cif)

        menubar.add_cascade(label="Edit", menu=edit_f)  # Top Line
        edit_f.add_command(label="Vertical flip", command=self.ver_flip)
        edit_f.add_command(label="Horizontal flip", command=self.hor_flip)
        edit_f.add_command(label="CW rotate", command=self.cw_rot)
        edit_f.add_command(label="CCW rotate", command=self.ccw_rot)
        edit_f.add_command(label="Delete selected", command=self.bound_del)
        edit_f.add_command(label="Multiply selected",
                           command=self.MultiplyBounded)

        menubar.add_cascade(label="Synthesis", menu=synt_f)  # Top Line
        synt_f.add_command(label="PC row", command=self.PCRowAccess)
        synt_f.add_command(label="Y Pulse coloumn",
                           command=self.PulseColoumnAccess)
        synt_f.add_command(label="Y Decoder", command=self.YDCAccess)
        synt_f.add_command(label="X Pulse row", command=self.PulseRowAccess)
        synt_f.add_command(label="X Decoder", command=self.XDCAccess)
        synt_f.add_command(label="X Connect", command=self.XCONNECTAccess)
        synt_f.add_command(label="Cell array", command=self.CellAccess)
        synt_f.add_command(label="Buffer row", command=self.BuffRowAccess)
        # synt_f.add_separator()
        # synt_f.add_command(label="NEW_NANDs_DC", command=self.NewDCAccess)
        synt_f.add_separator()
        synt_f.add_command(label="Full SRAM", command=self.synAccess)
        synt_f.add_separator()
        synt_f.add_command(label="Multiplier", command=self.MultiAccess)

        menubar.add_cascade(label="Parametrize", menu=param_f)
        param_f.add_command(label="PC blocks",
                            command=self.PCParametrizeAccessCMD)
        param_f.add_command(label="Y Pulse blocks",
                            command=self.PulseYParametrizeAccessCMD)
        param_f.add_command(label="Write Device block",
                            command=self.WRParametrizeAccessCMD)
        param_f.add_command(label="Out Device block",
                            command=self.OUTParametrizeAccessCMD)
        param_f.add_separator()
        param_f.add_command(label="Full SRAM",
                            command=self.SRAMParametrizeAccess)

        menubar.add_cascade(label="Export", menu=export_f)  # Top Line
        export_f.add_command(label="Export2TXT", command=self.export_txt)
        export_f.add_command(label="Export2CIF(One Cell)",
                             command=self.export_cif)
        export_f.add_command(label="Export2CIF(Cells Hierarchy)",
                             command=self.export_cif_hierarchy)
        export_f.add_command(label="Export2GDS", command=self.export_gds)
        export_f.add_command(label="Export2MAG(One Cell)",
                             command=self.export_mag)

        menubar.add_cascade(label="About", menu=info_f)  # Top Line
        info_f.add_command(label="Manual", command=self.info)

        self.master.config(menu=menubar)  # adding menu to window
        # задаю количество областей одинакового типа для последующего образения через тэги
        self.num_of_blocks = {}
        self.j = {f'{tech}': {f'{areatype}': 0 for areatype in area_props[tech].keys(
        )} for tech in ('SkyWater130', 'Microwind65')}
        # self.j_new = {}
        # self.j_shifted = {}

        # self.j_new[areatype] = 0
        # self.j_shifted[areatype] = 0

        self.amount_of_line = 0
        self.drag_process = 0
        self.point_1 = [0, 0]
        self.point_2 = [0, 0]
        self.block_item = None

        self.delta_value = None
        self.line_start = None
        self.models = mos_models
        # self.options_frame()
        # self.layers_menu()
        # self.blocks_menu()
        # --------------------------------

        # --------------------------------
        # width = self.width, height = self.height, bg="white")
        self.canvas = tk.Canvas(self.master, bg="white")
        self.canvas.pack(side=tk.BOTTOM, fill=tk.BOTH, expand=True)
        self.prev_canvas = self.canvas.find_all()  # save previous state from canvas
        self.canvas.update()                      # update canvas
        # -----------------------------------------------------------------
        self.info_txt = tk.Text(self.master, height=1)
        self.info_txt.pack(side=tk.BOTTOM, fill=tk.X)
        # -----------------------------------------------------------------
        self.history = []
        self.rectangles = {}
        for key in rec_keys:
            self.rectangles[key] = []
        # self.rectangles = {
            # 'rec_tag': [],
            # 'rec_coord': [],
            # 'rec_outline': [],
            # 'rec_fill': [],
            # 'rec_border': []
        # }
        self.motion_flag = False
        self.press_flag = False
        # --------------------------------

        self.canvas.bind("<ButtonPress-2>", self.move_from_by_mouse)
        self.canvas.bind("<B2-Motion>",     self.move_to_by_mouse)

        self.canvas.bind_all("<KeyPress-Up>", self.move_canvas)
        self.canvas.bind_all("<KeyPress-Down>", self.move_canvas)
        self.canvas.bind_all("<KeyPress-Left>", self.move_canvas)
        self.canvas.bind_all("<KeyPress-Right>", self.move_canvas)

        self.canvas.bind("<MouseWheel>", self.wheel)

        self.delta = 0.8
        self.scale = 1.0
        self.count = 0
        # ----------------------
        self.PC_count_flag = 0
        self.PCblock = None
        self.PCParametrizeFlag = False
        self.PC_previos_mos = ['None']
        # ----------------------
        self.PULSEY_count_flag = 0
        self.PULSEYblock = None
        self.PULSEYParametrizeFlag = False
        self.PULSEY_previos_mos = ['None']
        self.delta_of_PULSEYs = {k: [] for k in ['DN', 'DP']}
        # ----------------------
        self.PULSEX_count_flag = 0
        self.PULSEXblock = None
        self.PULSEXParametrizeFlag = False
        self.PULSEX_previos_mos = ['None']
        self.delta_of_PULSEXs = {k: [] for k in ['DN', 'DP']}
        # ----------------------
        self.WR_count_flag = 0
        self.WRblock = None
        self.WRParametrizeFlag = False
        self.delta_of_WRs = {k: [] for k in ['DN_5', 'DP_3', 'DN_6', 'DP_5']}
        # ----------------------
        self.OUT_count_flag = 0
        self.OUTblock = None
        self.OUTParametrizeFlag = False
        # self.delta_of_OUTs = {k:[] for k in ['DN_5', 'DP_3', 'DN_6', 'DP_5']}
        # ----------------------

        self.wheel_count = self.count
        self.insertAccess = 0
        self.multiplyAccess = 0
        self.CellAccess = 0
        self.synthesisAcces = 0
        self.y_decoder_access = 0
        self.PulseY = 0
        self.x_decoder_access = 0
        self.PulseX = 0
        self.x_connect_access = 0
        self.mult_access = 0
        '''
        self.contact_blocks = [None, None]
        self.push_k = 0
        '''
        self.canvas.bind("<ButtonPress-3>", self.button_press)
        self.canvas.bind("<Button3-Motion>", self.button_motion)
        self.canvas.bind("<ButtonRelease-3>", self.button_release)

        self.canvas.bind("<Double-2>", self.choose_object)
        self.canvas.bind("<Button-1>", self.MUX)
        self.canvas.bind("<Control-ButtonPress-3>", self.dragMove)
        # self.btn_param = tk.Button(self.master, text = "Parametrize", command = self.let_param).pack(padx = 10, pady = 10)
        self.master.bind("<Control-u>", self.undo)
        self.canvas.update()
        # -----------------------------------------------------------------
        self.nmos_flag = tk.IntVar()
        self.pmos_flag = tk.IntVar()
        image = Image.open(r"NMOS.png")
        image = image.resize((25, 25), Image.Resampling.LANCZOS)
        self.nmos_ico = ImageTk.PhotoImage(image)
        image = Image.open(r"PMOS.png")
        image = image.resize((25, 25), Image.Resampling.LANCZOS)
        self.pmos_ico = ImageTk.PhotoImage(image)
        self.btn_nmos = tk.Checkbutton(self.master, image=self.nmos_ico, onvalue=1, offvalue=0, variable=self.nmos_flag, indicatoron=False, command=self.open_window_n).pack(side=tk.LEFT, padx=10, pady=10)
        self.btn_pmos = tk.Checkbutton(self.master, image=self.pmos_ico, onvalue=1, offvalue=0, variable=self.pmos_flag, indicatoron=False, command=self.open_window_p).pack(side=tk.LEFT, padx=10, pady=10)

        # self.btn_nmos.grid(row = 0, column = 0)
        # self.btn_pmos.grid(row = 0, column = 1)

        # -----------------------------------------------------------------
        image = Image.open(r"shapes_img.png")
        image = image.resize((25, 25), Image.Resampling.LANCZOS)
        self.shapes_ico = ImageTk.PhotoImage(image)

        self.shapes_flag = tk.IntVar()
        self.btn_shape = tk.Checkbutton(self.master, image=self.shapes_ico, onvalue=1, offvalue=0, variable=self.shapes_flag, indicatoron=False).pack(side=tk.LEFT, padx=10, pady=10)  # , command=self.shapes_access
        # -----------------------------------------------------------------
        image = Image.open(r"horizontal.png")
        image = image.resize((25, 25), Image.Resampling.LANCZOS)
        self.hor_ico = ImageTk.PhotoImage(image)

        self.hor_flag = tk.IntVar()
        self.btn_hor = tk.Checkbutton(self.master, image=self.hor_ico, onvalue=1, offvalue=0, variable=self.hor_flag, indicatoron=False).pack(side=tk.LEFT, padx=10, pady=10)  # , command=self.hor_access
        # -----------------------------------------------------------------
        image = Image.open(r"vertical.png")
        image = image.resize((25, 25), Image.Resampling.LANCZOS)
        self.ver_ico = ImageTk.PhotoImage(image)

        self.ver_flag = tk.IntVar()
        self.btn_ver = tk.Checkbutton(self.master, image=self.ver_ico, onvalue=1, offvalue=0, variable=self.ver_flag, indicatoron=False).pack(side=tk.LEFT, padx=10, pady=10)  # , command=self.ver_access
        # -----------------------------------------------------------------
        image = Image.open(r"del_img.png")
        image = image.resize((25, 25), Image.Resampling.LANCZOS)
        self.del_ico = ImageTk.PhotoImage(image)

        self.del_flag = tk.IntVar()
        self.btn_del = tk.Checkbutton(self.master, image=self.del_ico, onvalue=1, offvalue=0, variable=self.del_flag, indicatoron=False).pack(side=tk.LEFT, padx=10, pady=10)  # , command=self.delete_acces
        # -----------------------------------------------------------------
        image = Image.open(r"cut_img.png")
        image = image.resize((25, 25), Image.Resampling.LANCZOS)
        self.crop_ico = ImageTk.PhotoImage(image)
        self.btn_crop = tk.Button(self.master, image=self.crop_ico, command=self.crop).pack(side=tk.LEFT, padx=10, pady=10)  # text = "CROP"
        # -----------------------------------------------------------------
        image = Image.open(r"bound_img.png")
        image = image.resize((25, 25), Image.Resampling.LANCZOS)
        self.bounding_rect_ico = ImageTk.PhotoImage(image)

        self.bound_flag = tk.IntVar()
        self.btn_bounding_rect = tk.Checkbutton(self.master, image=self.bounding_rect_ico, onvalue=1, offvalue=0, variable=self.bound_flag, indicatoron=False, command=self.bound_acces).pack(side=tk.LEFT, padx=10, pady=10)
        # -----------------------------------------------------------------
        image = Image.open(r"drag_img.png")
        image = image.resize((25, 25), Image.Resampling.LANCZOS)
        self.drag_ico = ImageTk.PhotoImage(image)

        self.drag_flag = tk.IntVar()
        self.btn_drag = tk.Checkbutton(self.master, image=self.drag_ico, onvalue=1, offvalue=0, variable=self.drag_flag, indicatoron=False, command=self.drag_on).pack(side=tk.LEFT, padx=10, pady=10)
        # -----------------------------------------------------------------
        image = Image.open(r"labeling.png")
        image = image.resize((25, 25), Image.Resampling.LANCZOS)
        self.labeling_ico = ImageTk.PhotoImage(image)

        self.labeling_flag = tk.IntVar()
        #self.btn_labeling = tk.Checkbutton(self.master, image=self.labeling_ico, onvalue=1, offvalue=0, variable=self.labeling_flag, indicatoron=False, command=self.label_on).pack(side=tk.LEFT, padx=10, pady=10)
        # -----------------------------------------------------------------    
        self.GridLambda = tk.IntVar()
        tk.Label(self.master, text="GridUnit:").pack(
            side=tk.LEFT, padx=10, pady=10)
        self.entry_tech = tk.Entry(self.master, textvariable=self.GridLambda)
        self.entry_tech.pack(side=tk.LEFT, padx=1, pady=10)
        tk.Label(self.master, text="U").pack(side=tk.LEFT, padx=1, pady=10)
        # -----------------------------------------------------------------
        tk.Label(self.master, text="Foundry:").pack(side=tk.LEFT, padx=10, pady=10)
        self.foundry = tk.StringVar()
        self.foundry.set(self.foundrys[0])
        # foundry_option = tk.OptionMenu(self.master, self.foundry, *self.foundrys)
        # foundry_option.pack(side = tk.LEFT, padx=10, pady=10)
        self.foundry_version = tk.Entry(self.master, textvariable=self.foundry, background='lightgray')
        self.foundry_version.pack(side=tk.LEFT, padx=10, pady=10)
        # -----------------------------------------------------------------
        # print(self.j)
        # -----------------------------------------------------------------
        self.canvas.update()

    def layers_menu(self):
        self.layers_window = tk.Toplevel()
        self.layers_window.wm_attributes('-topmost', True)
        self.layers_window.title('TopoPlot: Layers')
        self.layers_window.iconbitmap(r'nano.ico')
        x0, y0 = 1300, 100
        dx, dy = 150, 900
        self.layers_window.geometry(f"{dx}x{dy}+{x0}+{y0}")
        self.checkbuttons_variables = {
            layer: tk.BooleanVar() for layer in top_area[self.foundry.get()]}
        self.rb_state = tk.StringVar()
        for c in range(2):
            self.columnconfigure(index=c, weight=1)
        for r in range(len(top_area[self.foundry.get()])):
            self.rowconfigure(index=r, weight=1)

        for i, layer in enumerate(top_area[self.foundry.get()]):

            self.rb = tk.Radiobutton(self.layers_window, text=layer, value=layer,
                                     variable=self.rb_state, command=self.layers_window_get_area, indicatoron=False)
            self.rb.grid(row=i, column=0, padx=5, pady=5, sticky='nsew')
            # self.radiobuttons[layer] = self.rb

            self.cb = tk.Checkbutton(self.layers_window, onvalue=1, offvalue=0,
                                     variable=self.checkbuttons_variables[layer], command=self.layer_vision)  # , command = self.visibility)
            self.cb.grid(row=i, column=1, padx=5, pady=5, sticky='nsew')
            # self.checkbuttons[layer] = self.cb
        for layer in top_area[self.foundry.get()]:
            self.checkbuttons_variables[layer].set(1)

        self.rb_state.set('OP')
        self.layers_shadow_access = tk.IntVar(value=1)

        enable_all_button = tk.Button(
            self.layers_window, text="Enable all", command=self.enable_all_layers)
        enable_all_button.grid(
            row=len(top_area[self.foundry.get()]), column=0, columnspan=2, sticky='swse')

        disable_all_button = tk.Button(
            self.layers_window, text="Disable all", command=self.disable_all_layers)
        disable_all_button.grid(row=len(
            top_area[self.foundry.get()]) + 1, column=0, columnspan=2, sticky='swse')

        shadowed_all_button = tk.Checkbutton(
            self.layers_window, text="Shadowed?", onvalue=1, offvalue=0, variable=self.layers_shadow_access)
        shadowed_all_button.grid(row=len(
            top_area[self.foundry.get()]) + 2, column=0, columnspan=2, sticky='swse')

    def enable_all_layers(self):
        for layer in top_area[self.foundry.get()]:
            self.checkbuttons_variables[layer].set(1)
        self.layer_vision()

    def disable_all_layers(self):
        for layer in top_area[self.foundry.get()]:
            self.checkbuttons_variables[layer].set(0)
        self.layer_vision()

    def layers_window_get_area(self):
        return self.rb_state.get()

    def layer_vision(self):
        choosed_layers = {}
        for layer in top_area[self.foundry.get()]:
            choosed_layers[layer] = self.checkbuttons_variables[layer].get()
        for item in self.canvas.find_all():
            item_tag_num = self.canvas.itemcget(item, "tags")
            item_tag = re.split("_", item_tag_num.strip())[-2]
            if choosed_layers[item_tag]:
                self.canvas.itemconfig(item, state=tk.NORMAL)
                self.canvas.itemconfig(item, fill=fills[self.foundry.get(
                )][top_area[self.foundry.get()].index(item_tag)])
            else:
                if self.layers_shadow_access.get() == 1:
                    self.canvas.itemconfig(item, fill='')
                else:
                    self.canvas.itemconfig(item, state=tk.HIDDEN)

    def blocks_menu(self):
        self.blocks_window = tk.Toplevel()
        self.blocks_window.wm_attributes('-topmost', True)
        self.blocks_window.title('TopoPlot: Blocks')
        self.blocks_window.iconbitmap(r'nano.ico')
        x0, y0 = 100, 100
        dx, dy = 150, 650
        self.blocks_window.geometry(f"{dx}x{dy}+{x0}+{y0}")
        self.blocks_checkbuttons_variables = {
            block: tk.BooleanVar() for block in blocks}

        for c in range(2):
            self.columnconfigure(index=c, weight=1)
        for r in range(len(blocks)):
            self.rowconfigure(index=r, weight=1)

        for i, block in enumerate(blocks):

            self.cb = tk.Checkbutton(self.blocks_window, text=block, onvalue=1, offvalue=0,
                                     variable=self.blocks_checkbuttons_variables[block], command=self.blocks_vision)  # , command = self.visibility)
            self.cb.grid(row=i, column=1, padx=5, pady=3, sticky='w')
            # self.checkbuttons[layer] = self.cb
        for block in blocks:
            self.blocks_checkbuttons_variables[block].set(1)

        enable_all_button = tk.Button(
            self.blocks_window, text="Enable all", command=self.enable_all_blocks)
        enable_all_button.grid(row=len(blocks), column=0,
                               columnspan=2, sticky='swse')

        disable_all_button = tk.Button(
            self.blocks_window, text="Disable all", command=self.disable_all_blocks)
        disable_all_button.grid(row=len(blocks) + 1,
                                column=0, columnspan=2, sticky='swse')

    def enable_all_blocks(self):
        for block in blocks:
            self.blocks_checkbuttons_variables[block].set(1)
        self.blocks_vision()

    def disable_all_blocks(self):
        for block in blocks:
            self.blocks_checkbuttons_variables[block].set(0)
        self.blocks_vision()

    def blocks_vision(self):
        choosed_blocks = {}
        for block in blocks:
            choosed_blocks[block] = self.blocks_checkbuttons_variables[block].get()
        for item in self.canvas.find_all():
            item_tag_num = self.canvas.itemcget(item, "tags")
            item_tag = re.split("_", item_tag_num.strip())
            # print(item_tag)
            if choosed_blocks[item_tag[0]]:
                self.canvas.itemconfig(item, state=tk.NORMAL)
                # self.canvas.itemconfig(item, fill = fills[blocks.index(item_tag)])
            else:
                self.canvas.itemconfig(item, state=tk.HIDDEN)

    def options_frame(self):
        self.form = LineForm(self.master, self.models)
        self.form.wm_attributes('-topmost', True)
        self.form.resizable(False, False)
        self.form.title('TopoPlot: Options')
        # self.form.pack(side=tk.LEFT, padx=10, pady=10)
        x = 1100
        y = 150
        # self.form.geometry(f"{width}x{height}+{x}+{y}")
        self.form.geometry(f"+{x}+{y}")

    def create_rec_with_mem(self, x1, y1, x2, y2, **kwargs):
        rec_coords = (x1, y1, x2, y2)
        params = {}
        for key in ("outline", "fill", "dash", "tags"):
            if key in kwargs.keys():
                value = kwargs[key]
            else:
                value = ''
            params[key] = value
        params = (rec_coords, *(list(params.values())))
        # -----expanding with saving in "mem"-------------------------
        self.insert_to_mem(params)
        # -------------------------------------------------------
        current_shape = self.canvas.create_rectangle(*rec_coords, **kwargs)
        return current_shape

    def undo(self, event):
        # self.GridUnits = self.form.get_tech()
        self.GridUnits = self.GridLambda.get()
        if self.GridUnits == 0:
            messagebox.showerror("Error", "Choose foundry, please")
        else:
            self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
            if self.history:
                moment = self.history.pop()
                rec_tag = self.rectangles['rec_tag'].pop()
                rec_coords = self.rectangles['rec_coord'].pop()
                rec_outline = self.rectangles['rec_outline'].pop()
                rec_fill = self.rectangles['rec_fill'].pop()
                rec_border = self.rectangles['rec_border'].pop()

                if moment == 'M':
                    prev_moment = self.history.pop()
                    prev_tag = self.rectangles['rec_tag'].pop()
                    prev_coords = self.rectangles['rec_coord'].pop()
                    prev_outline = self.rectangles['rec_outline'].pop()
                    prev_fill = self.rectangles['rec_fill'].pop()
                    prev_border = self.rectangles['rec_border'].pop()

                if (moment == 'C') or (moment == 'M' and prev_moment == 'P'):
                    for item in self.canvas.find_all():
                        if self.canvas.gettags(item)[0] == rec_tag:
                            self.canvas.delete(item)
                    if (moment == 'M' and prev_moment == 'P'):
                        self.canvas.create_rectangle(
                            *prev_coords, outline=prev_outline, fill=prev_fill, dash=prev_border, tags=prev_tag)

                elif moment == 'D':
                    self.canvas.create_rectangle(
                        *rec_coords, outline=rec_outline, fill=rec_fill, dash=rec_border, tags=rec_tag)
                    self.insert_to_mem(
                        (rec_coords, rec_outline, rec_fill, rec_border, rec_tag))

    def insert_to_mem(self, shape_params):
        param = {k: v for k, v in zip(rec_keys, shape_params)}
        for key in rec_keys:
            self.rectangles[key].append(param[key])

        if self.motion_flag:
            self.history.append('M')
        else:
            if self.press_flag:
                self.history.append('P')
            else:
                self.history.append('C')

    def delete_from_mem(self, item):
        self.rectangles['rec_coord'].append(tuple(self.canvas.coords(item)))
        self.rectangles['rec_tag'].append(self.canvas.itemcget(item, "tags"))
        self.rectangles['rec_outline'].append(
            self.canvas.itemcget(item, "outline"))
        self.rectangles['rec_fill'].append(self.canvas.itemcget(item, "fill"))
        self.rectangles['rec_border'].append(
            self.canvas.itemcget(item, "dash"))
        self.canvas.delete(item)
        self.history.append('D')

    def PCParametrizeAccessCMD(self):
        self.PCParametrizeAccess("sample", None, 100000)

    def PCParametrizeAccess(self, mode, data, width_limit):
        precharges.clear()
        for fig in self.canvas.find_all():
            figure = self.canvas.gettags(fig)[0]
            figure = re.split("_", figure.strip())
            if len(figure) != 2:
                if figure[2] == 'OP' and figure[0] == 'PC':
                    precharges.append(figure[0] + '_' + figure[1])

        if mode == "sample":
            window = PCParam(self.master)
            window.wm_attributes('-topmost', True)
            window.resizable(False, False)
            window.title('TopoPlot: PC params defining')
            window.iconbitmap(r'nano.ico')
            self.PC_param = window.open()

        elif mode == "block":
            self.PC_param = [data, 1, 'PC_1_OP_0']

        self.PCblock = self.PC_param[2]
        self.scale_eq_mos = self.PC_param[1]
        target_t_pc = self.PC_param[0]  # ps

        if target_t_pc == 0:
            messagebox.showerror("Error", "Enter a not zero time, please")
        else:
            sram_ops = {}
            pc_ops = {}
            C_L = None
            R_L = None
            if self.PC_param[-1] == 1:
                # ----- auto searching and calculating loaded capacitance -----
                for fig in self.canvas.find_all():
                    figure_tag = self.canvas.itemcget(fig, "tags")
                    figure = re.split("_", figure_tag.strip())
                    if figure[2] == 'OP':
                        if figure[0] == 'SRAM':
                            sram_ops[figure_tag] = self.canvas.coords(
                                figure_tag)
                        if figure[0] == 'PC' and figure[1] == '0':
                            pc_ops[figure_tag] = self.canvas.coords(figure_tag)
                if sram_ops:
                    k = 0
                    for sram_fig in sram_ops.keys():
                        for pc_fig in pc_ops.keys():
                            if pc_ops[pc_fig][0] >= sram_ops[sram_fig][0] and pc_ops[pc_fig][2] <= sram_ops[sram_fig][2]:
                                k += 1
                    if k == self.rows:
                        C_L = self.rows * \
                            self.CAPs['SRAM']['BL'] + self.CAPs['BTMPC']['BL']
                        R_L = self.rows * \
                            self.RESs['SRAM']['BL'] + self.RESs['BTMPC']['BL']
                    # print(k, C_L)
                else:
                    messagebox.showerror("Error", "unfound SRAM blocks")
            else:
                # manually get
                C_L = self.PC_param[-3]  # in fF
                R_L = self.PC_param[-2]  # in fF

            if C_L or R_L is not None:
                if self.foundry.get() == 'Microwind65':
                    psi = -0.523907542722564
                    hi = -14.024147928286363
                    teta = 2870.751343922466
                    ksi = -13411.995312062532
                    self.W_P_PC = (teta * C_L + ksi) / \
                        (target_t_pc - psi * C_L - hi)

                elif self.foundry.get() == 'SkyWater130':
                    approx_coeffs = {
                        'p00': {
                            'a': -2.7831218672705364e-11,
                            'b': 2.830723592706642e-10,
                            'c': -1.0598363731957857e-09,
                            'd': 1.653671173982053e-09,
                            'e': 7.810938236315294e-10
                        },
                        'p10': {
                            'a': -1.859669414420993e-14,
                            'b': 1.6310095708766159e-13,
                            'c': -3.4513111803815646e-13,
                            'd': -6.818949830243888e-13,
                            'e': -5.365486475283143e-13
                        },
                        'p01': {
                            'a': -5806.833265182063,
                            'b': 64505.84839166264,
                            'c': -252827.359901273,
                            'd': 374094.2124197386,
                            'e': -87658.93516957371
                        },
                        'p20': {
                            'a': -0.001992670912447105,
                            'b': 0.021889249301619784,
                            'c': -0.08864218220534521,
                            'd': 0.17314122155133527,
                            'e': 0.35419158236450005
                        },
                        'p11': {
                            'a': 0.005089582546052044,
                            'b': -0.04986886008071882,
                            'c': 0.17535115752896696,
                            'd': -0.2062507620718014,
                            'e': 1.5669598259967379
                        },
                        'p02': {
                            'a': -0.0018860537083543543,
                            'b': 0.022516922317391243,
                            'c': -0.10591802516680568,
                            'd': 0.20680443684308691,
                            'e': 0.9493162647663554
                        }
                    }
                    # Извлечение списков коэффициентов
                    coefficients = {key: [value for value in coeffs.values(
                    )] for key, coeffs in approx_coeffs.items()}

                    def t_pc(W_P, R_L, C_L):
                        p00 = polyval(coefficients['p00'], W_P)
                        p10 = polyval(coefficients['p10'], W_P)
                        p01 = polyval(coefficients['p01'], W_P)
                        p20 = polyval(coefficients['p20'], W_P)
                        p11 = polyval(coefficients['p11'], W_P)
                        p02 = polyval(coefficients['p02'], W_P)

                        return p00 + p10 * R_L ** p20 + p01 * C_L ** p02 + p11 * R_L * C_L

                    def equation(W_P, R_L, C_L, target_t_pc):
                        return t_pc(W_P, R_L, C_L) - target_t_pc

                    def solve_W_P(R_L, C_L, target_t_pc, initial_guess=1):
                        # Try using fsolve with a provided Jacobian
                        # return fsolve(equation, initial_guess, args=(R_L, C_L, target_t_pc), fprime=jacobian)

                        # Alternatively, try using root with a different method
                        result = sci_root(equation, initial_guess, args=(
                            R_L, C_L, target_t_pc), method='lm')
                        return result.x

                    self.W_P_PC = solve_W_P(
                        R_L, C_L*1e-15, target_t_pc*1e-12)[0] * 1e3  # um -> nm

                self.PCblock = re.split("_", self.PCblock.strip())
                self.PCblock = self.PCblock[1]
                # -------------calc. prev. info. about width------------------
                self.prev_Wp_PC = self.findPC(self.PCblock)
                self.width_PC_EQ = self.findPC_EQ(self.PCblock)
                print('self.prev_Wp_PC:', self.prev_Wp_PC,
                      '\t', 'self.W_P_PC:', self.W_P_PC)
                # ------------------------------------------------------------
                p_width_thresh = {'SkyWater130': 800.0, 'Microwind65': 135.0}
                if self.W_P_PC <= p_width_thresh[self.foundry.get()] and self.scale_eq_mos == 1:
                    messagebox.showerror("Error", "Enter a smaller t_PC, please")
                elif width_limit != None:
                    if self.W_P_PC >= width_limit:
                        messagebox.showerror("Error", "Enter a smaller MAX_W_P_PC, or increase t_PC please")
                    # self.delta_value = self.param[0]
                    # self.delta_value = (self.W_P_PC - self.prev_Wp_PC)*self.scale**self.wheel_count
                    # print('delta_pc:', self.delta_value)
                    self.PCParametrizeFlag = True
                    self.PC_previos_mos = ['None']
                    self.delta_of_PCs = [None, None, None]
                    self.PCParametrize()

    def PULSEY_CO_adding(self, direct):
        """"""
        # print('direct:', direct)
        if direct == 'for':
            CO_amount, PULSEY_amount = 0, 0
            diff_areas = ['DN', 'DP']
            diff_coords = [self.canvas.coords(self.canvas.itemcget(
                self.canvas.find_withtag(f'PULSEY_0_{area}_0'), "tags")) for area in diff_areas]
            diff_aimed_coords = {k: v for k, v in zip(diff_areas, diff_coords)}
            CO_aimed_coords = {k: [] for k in diff_areas}
            for fig in self.canvas.find_all():
                fig_tag = self.canvas.itemcget(fig, 'tags')
                figure = re.split("_", fig_tag.strip())
                if figure[0] == 'PULSEY':
                    if figure[-2] == 'OP':
                        PULSEY_amount += 1
                    if figure[1] == '0':
                        if figure[-2] == 'OP':
                            PULSEY_OP_dy = self.canvas.coords(
                                fig_tag)[3] - self.canvas.coords(fig_tag)[1]
                        elif figure[-2] == 'CO':
                            CO_amount += 1
                            co_coord = self.canvas.coords(fig_tag)
                            for area in diff_areas:
                                access = [None, None]
                                for i in range(2):
                                    if co_coord[i] >= diff_aimed_coords[area][i] and co_coord[i + 2] <= diff_aimed_coords[area][i + 2]:
                                        access[i] = True
                                    else:
                                        access[i] = False
                                if access[0] == True and access[-1] == True:
                                    CO_aimed_coords[area].append(co_coord)
            # -------получаем только ординаты--------------------
            odd_indexes = {k: [] for k in diff_areas}
            for area in diff_areas:
                for sublist in CO_aimed_coords[area]:
                    odd_sublist = sublist[1::2]
                    odd_indexes[area].append(odd_sublist)

            g = 3*self.Lambda
            a = 2*self.Lambda
            c = self.Lambda
            # --------форимруем новые координаты 'CO'--------
            new_co_coords = {k: [] for k in diff_areas}
            trig_lines = {k: [] for k in diff_areas}
            N = {k: [] for k in diff_areas}
            delta_trig = 2 * g - c
            for area in diff_areas:
                trig_lines[area] = diff_aimed_coords[area][2] - self.Lambda
                N[area] = int(abs(self.delta_of_PULSEYs[area])/delta_trig)
            if abs(diff_aimed_coords['DN'][2] - diff_aimed_coords['DN'][0]) > (a + g):
                for m in range(PULSEY_amount):
                    for area in self.delta_of_PULSEYs:
                        for j in range(len(odd_indexes[area])):
                            for i in range(N[area]):
                                x_0 = trig_lines[area] - ((i + 1) * g + i * a)
                                y_0 = odd_indexes[area][j][1] + \
                                    PULSEY_OP_dy * m - a
                                x_1 = x_0 + a
                                y_1 = y_0 + a
                                new_co_coords[area].append(
                                    [x_0, y_0, x_1, y_1])
                                self.create_rec_with_mem(
                                    *new_co_coords[area][-1], outline='black', fill='black', dash='', tags=f"PULSEY_{m}_CO_{CO_amount}")
                                CO_amount += 1
            # print('-------------------------------')
            # print('diff_aimed_coords:', diff_aimed_coords)
            # print('CO_aimed_coords:', CO_aimed_coords)
            # print('CO_amount:', CO_amount, '\t', 'PULSEY_amount:', PULSEY_amount)
            # print('odd_indexes:', odd_indexes)
            # print('trig_lines:', trig_lines)
            # print('N:', N)
            # print('new_co_coords:', new_co_coords)
            # print('-------------------------------')
        if direct == 'back':
            for fig in self.canvas.find_all():
                fig_tag = self.canvas.itemcget(fig, 'tags')
                figure = re.split("_", fig_tag.strip())
                if figure[0] == 'PULSEY' and figure[-2] == 'CO' and int(figure[-1]) >= 14:
                   self.delete_from_mem(fig)
            # self.PULSEY_CO_adding('for')

    def WR_CO_adding(self, direct):
        # print('direct:', direct)
        # print('delta_of_WRs:', self.delta_of_WRs)
        if direct == 'for':
            CO_amount = 0
            diff_areas = ['DN_5', 'DP_3', 'DN_6', 'DP_5']
            diff_coords = [self.canvas.coords(self.canvas.itemcget(
                self.canvas.find_withtag(f'WRITE_0_{area}'), "tags")) for area in diff_areas]
            diff_aimed_coords = {k: v for k, v in zip(diff_areas, diff_coords)}
            CO_aimed_coords = {k: [] for k in diff_areas}
            for fig in self.canvas.find_all():
                fig_tag = self.canvas.itemcget(fig, 'tags')
                figure = re.split("_", fig_tag.strip())
                # print(figure)
                if figure[0] == 'WRITE':
                    if figure[-2] == 'CO':
                        CO_amount += 1
                        co_coord = self.canvas.coords(fig_tag)
                        for area in diff_areas:
                            access = [None, None]
                            for i in range(2):
                                if co_coord[i] >= diff_aimed_coords[area][i] and co_coord[i + 2] <= diff_aimed_coords[area][i + 2]:
                                    access[i] = True
                                else:
                                    access[i] = False
                                if access[0] == True and access[-1] == True:
                                    CO_aimed_coords[area].append(co_coord)
            # -------получаем только ординаты--------------------
            odd_indexes = {k: [] for k in diff_areas}
            for area in diff_areas:
                for sublist in CO_aimed_coords[area]:
                    odd_sublist = sublist[1::2]
                    odd_indexes[area].append(odd_sublist)

            g = 3*self.Lambda
            a = 2*self.Lambda
            c = self.Lambda
            # --------форимруем новые координаты 'CO'--------
            new_co_coords = {k: [] for k in diff_areas}
            trig_lines = {k: [] for k in diff_areas}
            N = {k: [] for k in diff_areas}
            delta_trig = 2 * g - c
            # print(self.delta_of_WRs)
            for area in diff_areas:
                # print(self.delta_of_WRs[area])
                trig_lines[area] = diff_aimed_coords[area][2] - self.Lambda
                # print('before:', N[area])
                N[area] = int(abs(self.delta_of_WRs[area])/delta_trig)
                # print('after:', N[area])
            # print('-------------------------------')
            # print('diff_aimed_coords:', diff_aimed_coords)
            # print('CO_aimed_coords:', CO_aimed_coords)
            # print('CO_amount:', CO_amount)
            # print('odd_indexes:', odd_indexes)
            # print('trig_lines:', trig_lines)
            # print('N:', N)
            # print('delta_of_WRs:', self.delta_of_WRs)
            # print('-------------------------------')

            if abs(diff_aimed_coords['DN_5'][2] - diff_aimed_coords['DN_5'][0]) > 2 * g:
                for area in self.delta_of_WRs:
                    for j in range(len(odd_indexes[area])):
                        for i in range(N[area]):
                            x_0 = trig_lines[area] - ((i + 1) * g + i * a)
                            y_0 = odd_indexes[area][j][1] - a
                            x_1 = x_0 + a
                            y_1 = y_0 + a
                            new_co_coords[area].append([x_0, y_0, x_1, y_1])
                            self.create_rec_with_mem(*new_co_coords[area][-1], outline='black', fill='black', dash='', tags=f"WRITE_{0}_CO_{CO_amount}")
                            CO_amount += 1
            print('-------------------------------')
            print('diff_aimed_coords:', diff_aimed_coords)
            print('CO_aimed_coords:', CO_aimed_coords)
            print('CO_amount:', CO_amount)
            print('odd_indexes:', odd_indexes)
            print('trig_lines:', trig_lines)
            print('N:', N)
            print('new_co_coords:', new_co_coords)
            print('-------------------------------')
        if direct == 'back':
            for fig in self.canvas.find_all():
                fig_tag = self.canvas.itemcget(fig, 'tags')
                figure = re.split("_", fig_tag.strip())
                if figure[0] == 'WRITE' and figure[-2] == 'CO' and int(figure[-1]) > 58:
                    self.delete_from_mem(fig)
            self.WR_CO_adding('for')

    def PC_CO_adding(self, direct):
        if direct == 'for':
            CO_amount, PC_amount = 0, 0
            CO_aimed_coords = []
            DP_aimed_coords = [None, None, None]
            for fig in self.canvas.find_all():
                fig_tag = self.canvas.itemcget(fig, 'tags')
                figure = re.split("_", fig_tag.strip())
                if figure[0] == 'PC':
                    if figure[-2] == 'OP':
                        PC_amount += 1
                    if figure[1] == '0':
                        if figure[-2] == 'CO':
                            CO_amount += 1
                            if figure[-1] != '2' and figure[-1] != '3' and figure[-1] != '7':
                                CO_aimed_coords.append(
                                    self.canvas.coords(fig_tag))
                        elif figure[-2] == 'DP':
                            DP_aimed_coords[int(figure[-1])
                                            ] = self.canvas.coords(fig_tag)
                        elif figure[-2] == 'OP':
                            PC_OP_dx = self.canvas.coords(
                                fig_tag)[2] - self.canvas.coords(fig_tag)[0]

            # -------получаем только иксы--------------------
            even_indexes = []
            for sublist in CO_aimed_coords:
                even_sublist = sublist[::2]
                even_indexes.append(even_sublist)
            # --------избавляемся от дубликатов---------------
            even_indexes = list(set(map(tuple, even_indexes)))
            even_indexes = [list(x) for x in even_indexes]
            # ------------------------------------------------
            g = 3*self.Lambda
            a = 2*self.Lambda
            c = self.Lambda
            new_co_coords = []
            trig_lines = [None for i in range(len(DP_aimed_coords))]
            N = [None for i in range(len(DP_aimed_coords))]
            delta_trig = 2 * g - c
            for i in range(len(DP_aimed_coords)):
                trig_lines[i] = DP_aimed_coords[i][1] + self.Lambda  # - a
                N[i] = int(abs(self.delta_of_PCs[i])/delta_trig)
            for m in range(PC_amount):
                for k in range(len(self.delta_of_PCs)):
                    if abs(DP_aimed_coords[0][3] - DP_aimed_coords[0][1]) < (2 * (g + a) - 1):
                        N[k] = 1
                    for j in range(len(even_indexes)):
                        for i in range(N[k]):
                            x_0 = even_indexes[j][0] + PC_OP_dx * m
                            y_0 = trig_lines[k] + (i+1)*g + i*a
                            x_1 = x_0 + a
                            y_1 = y_0 - a
                            new_co_coords.append([x_0, y_0, x_1, y_1])
                            self.create_rec_with_mem(*new_co_coords[-1], outline='black', fill='black', dash='', tags=f"PC_{m}_CO_{CO_amount}")
                            CO_amount += 1

        if direct == 'back':
            for fig in self.canvas.find_all():
                fig_tag = self.canvas.itemcget(fig, 'tags')
                figure = re.split("_", fig_tag.strip())
                if figure[0] == 'PC' and figure[-2] == 'CO' and int(figure[-1]) >= 9:
                    self.delete_from_mem(fig)
                   # self.canvas.delete(fig)
            self.PC_CO_adding('for')

    def PCParametrize(self):
        self.ver_flag.set(0)
        self.PC_count_flag += 1
        if self.foundry.get() == 'SkyWater130':
            max_pc_count = 3
            pmos_tag = 'pmos'
            self.eq_mos_num = '0'
            cnt_tag = self.PC_count_flag - 1
        elif self.foundry.get() == 'Microwind65':
            pmos_tag = 'DP'
            max_pc_count = 4
            self.eq_mos_num = '1'
            cnt_tag = self.PC_count_flag

        if self.PC_count_flag == max_pc_count:
            self.delta_value = None
            self.PCParametrizeFlag = False
            self.PC_count_flag = 0
            if self.foundry.get() == 'Microwind65':
                self.PC_CO_adding(self.direction)
            self.hor_flag.set(0)
        else:
            self.hor_flag.set(1)
            for fig in self.canvas.find_all():
                # figure = self.canvas.gettags(fig)[0]
                figure = self.canvas.itemcget(fig, "tags")
                figure = re.split("_", figure.strip())
                if len(figure) == 4:
                    if figure[2] == pmos_tag and figure[0] == 'PC' and figure[1] == f'{self.PCblock}' and figure[3] == f'{cnt_tag}':
                        fig_tag = self.canvas.itemcget(fig, "tags")
                        if (fig_tag not in self.PC_previos_mos) or (self.PC_previos_mos[0] == 'None'):
                            print('PC_previos_mos before', self.PC_previos_mos)
                            self.PC_previos_mos.append(fig_tag)
                            try:
                                self.PC_previos_mos.remove('None')
                            except:
                                pass
                            print('PC_previos_mos after', self.PC_previos_mos)
                            fig_coords = self.canvas.coords(fig_tag)
                            # print(figure, fig_coords)
                            sechenie_coords[0] = fig_coords[0]
                            if self.foundry.get() == 'SkyWater130':
                                sechenie_coords[1] = (fig_coords[1]+fig_coords[3])/2 - (fig_coords[1]+fig_coords[3])/500
                            elif self.foundry.get() == 'Microwind65':
                                sechenie_coords[1] = (fig_coords[1]+fig_coords[3])/2
                            sechenie_coords[2] = fig_coords[2]
                            sechenie_coords[3] = sechenie_coords[1]
                            line = (sechenie_coords[0], sechenie_coords[1], sechenie_coords[2], sechenie_coords[3])
                            self.canvas.create_line(*line, fill='black', width=5, tags="Sechenie")
                            self.canvas.update()
                            self.amount_of_line += 1
                            self.after(500)
                            if figure[3] == self.eq_mos_num:
                                if self.scale_eq_mos != 1:
                                    self.delta_value = ((self.scale_eq_mos - 1) * (
                                        self.prev_Wp_PC + self.delta_value) + self.delta_value)*self.scale**self.wheel_count
                                else:
                                    self.delta_value = (self.W_P_PC - self.prev_Wp_PC)*self.scale**self.wheel_count
                            # elif figure[3] == '0':
                            #    self.prev_width = self.prev_Wp_PC
                            else:
                                self.delta_value = (self.W_P_PC - self.prev_Wp_PC)*self.scale**self.wheel_count
                            # print('let_cut')
                            # print('PC_delta', self.delta_value)
                            self.delta_of_PCs[int(figure[3])] = self.delta_value
                            print('delta_value:', self.delta_value)
                            print('fig_tag:', fig_tag)
                            self.pc_param_crop(fig, fig_coords, fig_tag)
                            if self.delta_value > 0:
                                self.direction = 'for'
                            else:
                                self.direction = 'back'
                            self.after(500, self.PCParametrize)

    def PulseYParametrizeAccessCMD(self):
        self.PulseYParametrizeAccess("sample", None, 100000)

    def PulseYParametrizeAccess(self, mode, data, width_limit):
        y_pulses.clear()
        for fig in self.canvas.find_all():
            figure = self.canvas.gettags(fig)[0]
            figure = re.split("_", figure.strip())
            if len(figure) != 2:
                if figure[2] == 'OP' and figure[0] == 'PULSEY':
                    y_pulses.append(figure[0] + '_' + figure[1])

        if mode == "sample":
            window = PULSEYParam(self.master)
            window.wm_attributes('-topmost', True)
            window.resizable(False, False)
            window.title('TopoPlot: PulseY params defining')
            window.iconbitmap(r'nano.ico')
            self.Y_PULSE_param = window.open()
        elif mode == "block":
            self.Y_PULSE_param = [data, 'PULSEY_1_OP_0', 1]

        self.PULSEYblock = self.Y_PULSE_param[1]
        self.PULSEYblock = re.split("_", self.PULSEYblock.strip())
        self.PULSEYblock = self.PULSEYblock[1]

        # print(self.CAPs)
        t_wl = self.Y_PULSE_param[0]
        if t_wl == 0:
            messagebox.showerror("Error", "Enter a not zero time, please")
        else:
            sram_ops = {}
            pulsey_ops = {}
            C_L = None
            R_L = None
            if self.Y_PULSE_param[-1] == 1:
                # ----- auto searching and calculating loaded capacitance -----
                for fig in self.canvas.find_all():
                    figure_tag = self.canvas.itemcget(fig, "tags")
                    figure = re.split("_", figure_tag.strip())
                    if figure[2] == 'OP':
                        if figure[0] == 'SRAM':
                            sram_ops[figure_tag] = self.canvas.coords(
                                figure_tag)
                        if figure[0] == 'PULSEY' and figure[1] == '1':
                            pulsey_ops[figure_tag] = self.canvas.coords(
                                figure_tag)
                if sram_ops:
                    k = 0
                    # print('pulsey_ops:', pulsey_ops)
                    for sram_fig in sram_ops.keys():
                        for pulsey_fig in pulsey_ops.keys():
                            if pulsey_ops[pulsey_fig][1] <= sram_ops[sram_fig][1] and pulsey_ops[pulsey_fig][3] >= sram_ops[sram_fig][3]:
                                k += 1
                    k /= 2
                    # print(k)
                    if k == self.columns:
                        C_L = k * self.CAPs['SRAM']['WL']
                        R_L = k * self.RESs['SRAM']['WL']
                else:
                    messagebox.showerror("Error", "unfound SRAM blocks")
            else:
                # manually get
                C_L = self.Y_PULSE_param[2]  # in fF
                R_L = self.Y_PULSE_param[3]  # in Ohm

            if C_L or R_L is not None:
                # -------------calc. prev. info. about width------------------
                self.prev_Wp_PULSEY = self.findPULSEY(self.PULSEYblock)
                print('prev_Wp_PULSEY:', self.prev_Wp_PULSEY)
                # ------------------------------------------------------------
                # -------------calc. needed width of mos------------------
                if self.foundry.get() == 'Microwind65':
                    eps = 31.586890862289795
                    gamma = 2.439060312177068
                    psi = 468.4958662237838
                    hi = 275.5145468405586
                    ksi = -0.07379516441290791
                    tetta = -1.0091467946225567
                    k_opt = 3
                    self.W_P_PULSEY = k_opt * \
                        exp(C_L * log((t_wl - eps) / (gamma * (psi * C_L + hi))
                                      ) / (ksi + tetta * C_L))  # needed width
                elif self.foundry.get() == 'SkyWater130':
                    approx_coeffs = {
                        'p00': {'a': 6.405850769305928e-11, 'b': 0.6011232697841825, 'c': 6.198013650820446e-11},
                        'p10': {'a': 2.0192613832182125e-13, 'b': 0.7793608865087375, 'c': -1.7502205627912913e-13},
                        'p01': {'a': 6396.111800718637, 'b': 0.12050598828545535, 'c': 2624.5068106702, 'd': -0.9970333859034737},
                        'p20': {'a': 7.59787580934806e-17, 'b': 1.0302452639569297, 'c': 3.4058821358456948, 'd': -0.25361053220508106},
                        'p11': {'a': 0.2595041672037046, 'b': 0.6453333146676379, 'c': 1.179441681452691},
                        'p02': {'a': 0.0, 'b': 0.0}
                    }

                    def t_calc(W_N, R_L, C_L):
                        p00 = approx_coeffs['p00']['a'] * \
                            W_N ** approx_coeffs['p00']['b'] + \
                            approx_coeffs['p00']['c']
                        p10 = approx_coeffs['p10']['a'] * \
                            exp(-approx_coeffs['p10']['b'] *
                                W_N) + approx_coeffs['p10']['c']
                        p01 = approx_coeffs['p01']['a'] * W_N ** approx_coeffs['p01']['d'] + \
                            approx_coeffs['p01']['b'] / W_N * \
                            approx_coeffs['p01']['c'] ** arctan(W_N)
                        p20 = approx_coeffs['p20']['a'] * W_N ** approx_coeffs['p20']['b'] * arctan(
                            approx_coeffs['p20']['c'] / W_N + approx_coeffs['p20']['d'])
                        p11 = approx_coeffs['p11']['a'] * \
                            W_N ** approx_coeffs['p11']['b'] + \
                            approx_coeffs['p11']['c']
                        p02 = approx_coeffs['p02']['a'] * \
                            W_N + approx_coeffs['p02']['b']
                        return p00 + p10 * R_L + p01 * C_L + p20 * R_L ** 2 + p11 * R_L * C_L + p02 * C_L ** 2

                    def equation(W_N, R_L, C_L, target_t_wl):
                        return t_calc(W_N, R_L, C_L) - target_t_wl

                    def solve_W_N(R_L, C_L, target_t_wl, initial_guess=1):
                        # Alternatively, try using root with a different method
                        result = sci_root(equation, initial_guess, args=(
                            R_L, C_L, target_t_wl), method='lm')
                        return result.x

                    W_N_PULSEY = solve_W_N(
                        R_L, C_L*1e-15, t_wl*1e-12)[0] * 1e3  # um -> nm
                    k_opt = 4
                    self.W_P_PULSEY = k_opt * W_N_PULSEY  # needed width
                print('t_wl:', t_wl, 'C_L:', C_L)
                print('W_P_PULSEY:', self.W_P_PULSEY)
                # ------------------------------------------------------------

                p_width_thresh = {'SkyWater130': 2800.0, 'Microwind65': 420.0}
                print('pulsey width_limit:', width_limit)
                if self.W_P_PULSEY <= p_width_thresh[self.foundry.get()]:
                    messagebox.showerror("Error", "Enter a smaller t_WL, please")
                elif  width_limit != None :
                    if width_limit <= self.W_P_PULSEY:
                        messagebox.showerror("Error", "Enter a smaller MAX_W_P_PULSEY, or increase t_WL please")
                    # self.delta_value = self.Y_PULSE_param[0]
                    self.delta_value = (
                        self.W_P_PULSEY - self.prev_Wp_PULSEY)*self.scale**self.wheel_count
                    # print('delta_pulse:', self.delta_value)
                    self.PULSEYParametrizeFlag = True
                    self.PULSEY_previos_mos = ['None']
                    self.PulseYParametrize()

    def PulseYParametrize(self):
        self.PULSEY_count_flag += 1
        self.hor_flag.set(0)
        if self.PULSEY_count_flag == 3:
            self.ver_flag.set(0)
        else:
            self.ver_flag.set(1)

        if self.PULSEY_count_flag == 3:
            self.delta_value = None
            self.PULSEYParametrizeFlag = False
            self.PULSEY_count_flag = 0
            # self.PULSEY_CO_adding(self.direction)

        if self.foundry.get() == 'Microwind65':
            nmos_tag = 'DN'
            pmos_tag = 'DP'
            k_opt = 3
        elif self.foundry.get() == 'SkyWater130':
            nmos_tag = 'nmos'
            pmos_tag = 'pmos'
            k_opt = 4

        if self.PULSEY_count_flag != 3:
            for fig in self.canvas.find_all():
                figure = self.canvas.itemcget(fig, "tags")
                figure = re.split("_", figure.strip())
                if len(figure) == 4:
                    # print(figure)
                    if (figure[2] == pmos_tag or figure[2] == nmos_tag) and figure[0] == 'PULSEY' and figure[1] == f'{self.PULSEYblock}' and figure[3] == '0':
                        fig_tag = self.canvas.itemcget(fig, "tags")
                        if (fig_tag not in self.PULSEY_previos_mos) or (self.PULSEY_previos_mos[0] == 'None'):
                            # print(self.previos_mos)
                            self.PULSEY_previos_mos.append(fig_tag)
                            try:
                                self.PULSEY_previos_mos.remove('None')
                            except:
                                pass
                            fig_coords = self.canvas.coords(fig_tag)
                            # print(figure, fig_coords)
                            sechenie_coords[0] = (
                                fig_coords[0]+fig_coords[2])/2
                            sechenie_coords[1] = fig_coords[1]
                            sechenie_coords[2] = (
                                fig_coords[0]+fig_coords[2])/2
                            sechenie_coords[3] = fig_coords[3]
                            line = (
                                sechenie_coords[0], sechenie_coords[1], sechenie_coords[2], sechenie_coords[3])
                            self.canvas.create_line(
                                *line, fill='black', width=5, tags="Sechenie")
                            self.canvas.update()
                            self.amount_of_line += 1
                            self.after(500)
                            if figure[2] == nmos_tag:
                                self.delta_value = (
                                    (self.W_P_PULSEY - self.prev_Wp_PULSEY) / k_opt) * self.scale ** self.wheel_count
                            elif figure[2] == pmos_tag:
                                self.delta_value = (
                                    (self.W_P_PULSEY - self.prev_Wp_PULSEY)) * self.scale ** self.wheel_count
                            # print('PULSE_delta', self.delta_value)
                            # print('let_cut')
                            self.delta_of_PULSEYs[f'{figure[2]}'] = self.delta_value
                            self.pulsey_param_crop(fig, fig_coords, fig_tag)
                            if self.delta_value > 0:
                                self.direction = 'for'
                            else:
                                self.direction = 'back'
                            self.after(500, self.PulseYParametrize)
# ------------------------------------------------------------------------------------------------------

    def PulseXParametrizeAccess(self):
        x_pulses.clear()
        for fig in self.canvas.find_all():
            figure = self.canvas.gettags(fig)[0]
            figure = re.split("_", figure.strip())
            if len(figure) != 2:
                if figure[2] == 'OP' and figure[0] == 'PULSEX':
                    x_pulses.append(figure[0] + '_' + figure[1])

        window = PULSEXParam(self.master)
        window.wm_attributes('-topmost', True)
        window.resizable(False, False)
        window.title('TopoPlot: PulseX params defining')
        window.iconbitmap(r'nano.ico')

        self.X_PULSE_param = window.open()
        self.PULSEXblock = self.X_PULSE_param[1]
        self.PULSEXblock = re.split("_", self.PULSEXblock.strip())
        self.PULSEXblock = self.PULSEXblock[1]

        # print(self.CAPs)
        t_gate = self.X_PULSE_param[0]
        if t_gate == 0:
            messagebox.showerror("Error", "Enter a not zero time, please")
        else:
            buffer_ops = {}
            pulsex_ops = {}
            C_L = None
            if self.X_PULSE_param[-1] == 1:
                # ----- auto searching and calculating loaded capacitance -----
                for fig in self.canvas.find_all():
                    figure_tag = self.canvas.itemcget(fig, "tags")
                    figure = re.split("_", figure_tag.strip())
                    if figure[2] == 'OP':
                        if figure[0] == 'BUFFER':
                            buffer_ops[figure_tag] = self.canvas.coords(
                                figure_tag)
                        if figure[0] == 'PULSEX' and figure[1] == '1':
                            pulsex_ops[figure_tag] = self.canvas.coords(
                                figure_tag)
                if buffer_ops:
                    C_L = self.CAPs['BUFFER']['EN'] + \
                        self.CAPs['XCON'][f'{self.columns}']
                else:
                    messagebox.showerror("Error", "unfound BUFFER blocks")
            else:
                # manually get
                C_L = self.X_PULSE_param[2]  # in fF

            if C_L is not None:
                # -------------calc. prev. info. about width------------------
                self.prev_Wp_PULSEX = self.findPULSEX(self.PULSEXblock)
                print('prev_Wp_PULSEX:', self.prev_Wp_PULSEX)
                # ------------------------------------------------------------
                # -------------calc. needed width of mos------------------
                if self.foundry.get() == 'Microwind65':
                    eps = 31.586890862289795
                    gamma = 2.439060312177068
                    psi = 468.4958662237838
                    hi = 275.5145468405586
                    ksi = -0.07379516441290791
                    tetta = -1.0091467946225567
                    k_opt = 3
                    self.W_P_PULSEX = k_opt * \
                        exp(C_L * log((t_gate - eps) / (gamma * (psi * C_L + hi))
                                      ) / (ksi + tetta * C_L))  # needed width
                elif self.foundry.get() == 'SkyWater130':
                    # alpha = 3145.879446025862
                    # betta = -0.992757623400862
                    gamma = 0.009434662853398779
                    sigma = 233.05233199842826
                    psi = 329624.2645862433
                    hi = -18471664.83676183
                    tetta = -0.9911202119363789
                    ksi = 9.565068771082172
                    k_opt = 3
                    self.W_P_PULSEX = k_opt * \
                        exp(C_L * log((t_gate - sigma) /
                            (gamma * (psi * C_L + hi)))/(ksi + tetta * C_L))

                print('t_gate:', t_gate, 'C_L:', C_L)
                print('W_P_PULSEX:', self.W_P_PULSEX)
                # ------------------------------------------------------------

                p_width_thresh = {'SkyWater130': 2100.0, 'Microwind65': 420.0}

                if self.W_P_PULSEX <= p_width_thresh[self.foundry.get()]:
                    messagebox.showerror(
                        "Error", "Enter a smaller time, please")
                else:
                    # self.delta_value = self.Y_PULSE_param[0]
                    self.delta_value = (
                        self.W_P_PULSEX - self.prev_Wp_PULSEX)*self.scale**self.wheel_count
                    # print('delta_pulse:', self.delta_value)
                    self.PULSEXParametrizeFlag = True
                    self.PULSEX_previos_mos = ['None']
                    self.PulseXParametrize()

    def PulseXParametrize(self):
        self.PULSEX_count_flag += 1
        self.ver_flag.set(0)
        if self.PULSEX_count_flag == 3:
            self.hor_flag.set(0)
        else:
            self.hor_flag.set(1)

        if self.PULSEX_count_flag == 3:
            self.delta_value = None
            self.PULSEXParametrizeFlag = False
            self.PULSEX_count_flag = 0
            # self.PULSEY_CO_adding(self.direction)

        if self.foundry.get() == 'Microwind65':
            nmos_tag = 'DN'
            pmos_tag = 'DP'
            k_opt = 3
        elif self.foundry.get() == 'SkyWater130':
            nmos_tag = 'nmos'
            pmos_tag = 'pmos'
            k_opt = 3

        if self.PULSEX_count_flag != 3:
            for fig in self.canvas.find_all():
                figure = self.canvas.itemcget(fig, "tags")
                figure = re.split("_", figure.strip())
                if len(figure) == 4:
                    # print(figure)
                    if (figure[2] == pmos_tag or figure[2] == nmos_tag) and figure[0] == 'PULSEX' and figure[1] == f'{self.PULSEXblock}' and figure[3] == '0':
                        fig_tag = self.canvas.itemcget(fig, "tags")
                        if (fig_tag not in self.PULSEX_previos_mos) or (self.PULSEX_previos_mos[0] == 'None'):
                            # print(self.previos_mos)
                            self.PULSEX_previos_mos.append(fig_tag)
                            try:
                                self.PULSEX_previos_mos.remove('None')
                            except:
                                pass
                            fig_coords = self.canvas.coords(fig_tag)
                            # print(figure, fig_coords)
                            sechenie_coords[0] = fig_coords[0]
                            sechenie_coords[1] = (
                                fig_coords[1] + fig_coords[3]) / 2
                            sechenie_coords[2] = fig_coords[2]
                            sechenie_coords[3] = (
                                fig_coords[1] + fig_coords[3]) / 2
                            line = (
                                sechenie_coords[0], sechenie_coords[1], sechenie_coords[2], sechenie_coords[3])
                            self.canvas.create_line(
                                *line, fill='black', width=5, tags="Sechenie")
                            self.canvas.update()
                            self.amount_of_line += 1
                            self.after(500)
                            if figure[2] == nmos_tag:
                                self.delta_value = (
                                    (self.W_P_PULSEX - self.prev_Wp_PULSEX) / k_opt) * self.scale ** self.wheel_count
                            elif figure[2] == pmos_tag:
                                self.delta_value = (
                                    (self.W_P_PULSEX - self.prev_Wp_PULSEX)) * self.scale ** self.wheel_count
                            # print('PULSE_delta', self.delta_value)
                            # print('let_cut')
                            self.delta_of_PULSEXs[f'{figure[2]}'] = self.delta_value
                            self.pulsex_param_crop(fig, fig_coords, fig_tag)
                            if self.delta_value > 0:
                                self.direction = 'for'
                            else:
                                self.direction = 'back'
                            self.after(500, self.PulseXParametrize)
# -----------------------------------------------------------------------------------------

    def WRITE_calculate(self, obj, mode):

        W_N = self.findWRinv()

        if mode == "sample":
            window = LoadRC(self.master)
            window.wm_attributes('-topmost', True)
            window.resizable(False, False)
            window.title('TopoPlot: RC params defining')
            window.iconbitmap(r'nano.ico')
            rc = window.open()
        elif mode == "block":
            rc = [None, None, 1]
        C_L = None
        R_L = None
        buffer_ops = {}
        if rc[-1] == 1:
            # ----- auto searching and calculationg loaded capacitance -----
            write_ops = self.canvas.coords(
                f'{obj[0]}_{obj[1]}_{obj[2]}_{obj[3]}')
            print(write_ops)
            for fig in self.canvas.find_all():
                figure_tag = self.canvas.itemcget(fig, "tags")
                figure = re.split("_", figure_tag.strip())
                if figure[2] == 'OP':
                    if figure[0] == 'BUFFER':
                        buffer_ops[figure_tag] = self.canvas.coords(figure_tag)
            print(buffer_ops)
            if buffer_ops:
                k = 0
                for buffer_fig in buffer_ops.keys():
                    if write_ops[1] >= buffer_ops[buffer_fig][1] and write_ops[3] <= buffer_ops[buffer_fig][3]:
                        k += 1
                if k == self.columns:
                    C_L = k * self.CAPs['BUFFER']['CmnBL']
                    R_L = k * self.RESs['BUFFER']['CmnBL']
            else:
                messagebox.showerror("Error", "unfound BUFFER blocks")
        else:
            C_L = rc[0]  # in fF
            R_L = rc[1]  # in Ohm

        if C_L or R_L is not None:
            if self.foundry.get() == 'Microwind65':
                # manually get
                psi = 533.7668239899014
                hi = -1519.8823716321156
                K1 = [-4.6528982162245226e-07, 0.00010839141477943026, -
                      0.009607763085440644, 0.39807504131384225, 26.337584174861526]
                K2 = [8.569422422756487e-11, -1.3759109609572283e-07,
                      8.050026767038944e-05, -0.033493175629653024, 35.640390977559804]

                if C_L <= 80:
                    B = K1[0] * C_L ** 4 + K1[1] * C_L ** 3 + \
                        K1[2] * C_L ** 2 + K1[3] * C_L + K1[4]
                else:
                    B = K2[0] * C_L ** 4 + K2[1] * C_L ** 3 + \
                        K2[2] * C_L ** 2 + K2[3] * C_L + K2[4]

                A = psi * C_L + hi

                t_wr = A / W_N + B

            elif self.foundry.get() == 'SkyWater130':
                approx_coeffs = {
                    'p00': {'a': 1.604860384960851e-10, 'b': 0.25048057717263195, 'c': -2.3283468806116447e-11},
                    'p10': {'a': 2.0455892280445003e-13, 'b': 1.2498580005170306, 'c': -1.5264871992401587e-13},
                    'p01': {'a': 4827.83338991393, 'b': 0.028837087444793706, 'c': 7228.879008406911, 'd': -0.9054244063438566},
                    'p20': {'a': 9.446995190910371e-17, 'b': 1.0896335678313898, 'c': 2.318376274772542, 'd': -0.26518503443034286},
                    'p11': {'a': 0.5281505122263599, 'b': 0.384362468925356, 'c': 1.0561919366487627},
                    'p02': {'a': 0.0, 'b': 0.0}
                }

                def t_calc(W_N, R_L, C_L):
                    p00 = approx_coeffs['p00']['a'] * \
                        W_N ** approx_coeffs['p00']['b'] + \
                        approx_coeffs['p00']['c']
                    p10 = approx_coeffs['p10']['a'] * \
                        exp(-approx_coeffs['p10']['b'] *
                            W_N) + approx_coeffs['p10']['c']
                    p01 = approx_coeffs['p01']['a'] * W_N ** approx_coeffs['p01']['d'] + \
                        approx_coeffs['p01']['b'] / W_N * \
                        approx_coeffs['p01']['c'] ** arctan(W_N)
                    p20 = approx_coeffs['p20']['a'] * W_N ** approx_coeffs['p20']['b'] * arctan(
                        approx_coeffs['p20']['c'] / W_N + approx_coeffs['p20']['d'])
                    p11 = approx_coeffs['p11']['a'] * \
                        W_N ** approx_coeffs['p11']['b'] + \
                        approx_coeffs['p11']['c']
                    p02 = approx_coeffs['p02']['a'] * \
                        W_N + approx_coeffs['p02']['b']
                    return p00 + p10 * R_L + p01 * C_L + p20 * R_L ** 2 + p11 * R_L * C_L + p02 * C_L ** 2

                t_wr = t_calc(W_N*1e-3, R_L, C_L*1e-15) * \
                    1e12  # convert sec -> picosec

            print(W_N, '\t', t_wr, '\t', C_L, '\t', R_L)

            return t_wr

    def WRParametrizeAccessCMD(self):
        self.WRParametrizeAccess("sample", None, 100000)

    def WRParametrizeAccess(self, mode, data, width_limit):
        if mode == "sample":
            window = WRParam(self.master)
            window.wm_attributes('-topmost', True)
            window.resizable(False, False)
            window.title('TopoPlot: Write Block params defining')
            window.iconbitmap(r'nano.ico')
            self.WR_param = window.open()

        elif mode == "block":
            self.WR_param = [data, 0, 1]

        t_wr = self.WR_param[0]  # ps
        if t_wr == 0:
            messagebox.showerror("Error", "Enter a not zero time, please")
        else:
            buffer_ops = {}
            write_ops = {}
            C_L = None
            R_L = None
            if self.WR_param[-1] == 1:
                # ----- auto searching and calculating loaded capacitance -----
                for fig in self.canvas.find_all():
                    figure_tag = self.canvas.itemcget(fig, "tags")
                    figure = re.split("_", figure_tag.strip())
                    if figure[2] == 'OP':
                        if figure[0] == 'BUFFER':
                            buffer_ops[figure_tag] = self.canvas.coords(
                                figure_tag)
                        if figure[0] == 'WRITE' and figure[1] == '1':
                            write_ops[figure_tag] = self.canvas.coords(
                                figure_tag)
                if buffer_ops:
                    k = 0
                    for buffer_fig in buffer_ops.keys():
                        for write_fig in write_ops.keys():
                            if write_ops[write_fig][1] >= buffer_ops[buffer_fig][1] and write_ops[write_fig][3] <= buffer_ops[buffer_fig][3]:
                                k += 1
                    if k == self.columns:
                        C_L = k * self.CAPs['BUFFER']['CmnBL']
                        R_L = k * self.RESs['BUFFER']['CmnBL']
                else:
                    messagebox.showerror("Error", "unfound BUFFER blocks")
            else:
                # manually get
                C_L = self.WR_param[1]  # in fF
                R_L = self.WR_param[2]  # in fF

        if C_L or R_L is not None:
            if self.foundry.get() == 'Microwind65':
                psi = 533.7668239899014
                hi = -1519.8823716321156
                K1 = [-4.6528982162245226e-07, 0.00010839141477943026, -
                      0.009607763085440644, 0.39807504131384225, 26.337584174861526]
                K2 = [8.569422422756487e-11, -1.3759109609572283e-07,
                      8.050026767038944e-05, -0.033493175629653024, 35.640390977559804]

                if C_L <= 80:
                    B = K1[0] * C_L ** 4 + K1[1] * C_L ** 3 + \
                        K1[2] * C_L ** 2 + K1[3] * C_L + K1[4]
                else:
                    B = K2[0] * C_L ** 4 + K2[1] * C_L ** 3 + \
                        K2[2] * C_L ** 2 + K2[3] * C_L + K2[4]

                A = psi * C_L + hi

                self.W_N_WR_inv = A / (t_wr - B)

            elif self.foundry.get() == 'SkyWater130':
                approx_coeffs = {
                    'p00': {'a': 1.604860384960851e-10, 'b': 0.25048057717263195, 'c': -2.3283468806116447e-11},
                    'p10': {'a': 2.0455892280445003e-13, 'b': 1.2498580005170306, 'c': -1.5264871992401587e-13},
                    'p01': {'a': 4827.83338991393, 'b': 0.028837087444793706, 'c': 7228.879008406911, 'd': -0.9054244063438566},
                    'p20': {'a': 9.446995190910371e-17, 'b': 1.0896335678313898, 'c': 2.318376274772542, 'd': -0.26518503443034286},
                    'p11': {'a': 0.5281505122263599, 'b': 0.384362468925356, 'c': 1.0561919366487627},
                    'p02': {'a': 0.0, 'b': 0.0}
                }

                def t_calc(W_N, R_L, C_L):
                    p00 = approx_coeffs['p00']['a'] * \
                        W_N ** approx_coeffs['p00']['b'] + \
                        approx_coeffs['p00']['c']
                    p10 = approx_coeffs['p10']['a'] * \
                        exp(-approx_coeffs['p10']['b'] *
                            W_N) + approx_coeffs['p10']['c']
                    p01 = approx_coeffs['p01']['a'] * W_N ** approx_coeffs['p01']['d'] + \
                        approx_coeffs['p01']['b'] / W_N * \
                        approx_coeffs['p01']['c'] ** arctan(W_N)
                    p20 = approx_coeffs['p20']['a'] * W_N ** approx_coeffs['p20']['b'] * arctan(
                        approx_coeffs['p20']['c'] / W_N + approx_coeffs['p20']['d'])
                    p11 = approx_coeffs['p11']['a'] * \
                        W_N ** approx_coeffs['p11']['b'] + \
                        approx_coeffs['p11']['c']
                    p02 = approx_coeffs['p02']['a'] * \
                        W_N + approx_coeffs['p02']['b']
                    return p00 + p10 * R_L + p01 * C_L + p20 * R_L ** 2 + p11 * R_L * C_L + p02 * C_L ** 2

                def equation(W_N, R_L, C_L, target_t):
                    return t_calc(W_N, R_L, C_L) - target_t

                def solve_W_N(R_L, C_L, target_t, initial_guess=1):
                    # Alternatively, try using root with a different method
                    result = sci_root(equation, initial_guess, args=(
                        R_L, C_L, target_t), method='lm')
                    return result.x

                self.W_N_WR_inv = solve_W_N(
                    R_L, C_L*1e-15, t_wr*1e-12)[0] * 1e3  # um -> nm

            # -------------calc. prev. info. about width------------------
            self.prev_WRn_width = self.findWRinv()
            # ------------------------------------------------------------
            # print(self.prev_WRn_width,'\t', self.W_N_WR_inv, '\t', k, '\t', C_L)
            print('prev_WRn_width:', self.prev_WRn_width, '\t',
                  'new_WRn_width:', self.W_N_WR_inv, '\t', C_L)
            print('write width limit', width_limit)
            n_width_thresh = {'SkyWater130': 700.0, 'Microwind65': 60.0}
            if self.W_N_WR_inv <= n_width_thresh[self.foundry.get()]:
                messagebox.showerror("Error", "Enter a smaller t_WR, please")
            elif width_limit != None :
                if self.W_N_WR_inv >= width_limit:
                    messagebox.showerror("Error", "Enter a smaller MAX_W_N_WR_inv, or increase t_WR, please")
                # self.delta_value = self.Y_PULSE_param[0]
                self.delta_value = (self.W_N_WR_inv - self.prev_WRn_width)*self.scale**self.wheel_count
                # print('delta_pulse:', self.delta_value)
                self.WRParametrizeFlag = True
                self.WR_previos_mos = ['None']
                self.WRParametrize()

    def WRParametrize(self):

        if self.foundry.get() == 'SkyWater130':
            pmos_tag = 'pmos'
            nmos_tag = 'nmos'
            pmos_num = '6'
            nmos_num = '8'

        elif self.foundry.get() == 'Microwind65':
            pmos_tag = 'DP'
            nmos_tag = 'DN'
            pmos_num = '3'
            nmos_num = '5'

        self.WR_count_flag += 1
        self.hor_flag.set(0)
        if self.WR_count_flag == 3:
            self.ver_flag.set(0)
        else:
            self.ver_flag.set(1)

        if self.WR_count_flag == 3:
            self.delta_value = None
            self.WRParametrizeFlag = False
            self.WR_count_flag = 0
            if self.foundry.get() == 'Microwind65':
                self.WR_CO_adding(self.direction)

        if self.WR_count_flag != 3:
            for fig in self.canvas.find_all():
                figure = self.canvas.itemcget(fig, "tags")
                figure = re.split("_", figure.strip())
                if len(figure) != 2:
                    if figure[0] == 'WRITE' and ((figure[-2] == pmos_tag and figure[-1] == pmos_num) | (figure[-2] == nmos_tag and figure[-1] == nmos_num)):
                        fig_tag = self.canvas.itemcget(fig, "tags")
                        if (fig_tag not in self.WR_previos_mos) or (self.WR_previos_mos[0] == 'None'):
                            # print(self.previos_mos)
                            # print('\n', 'fig_tag:', fig_tag)
                            self.WR_previos_mos.append(fig_tag)
                            try:
                                self.WR_previos_mos.remove('None')
                            except:
                                pass
                            fig_coords = self.canvas.coords(fig_tag)
                            # print(figure, fig_coords)
                            sechenie_coords[0] = (fig_coords[0]+fig_coords[2])/2 + (fig_coords[0]+fig_coords[2])/500
                            sechenie_coords[1] = fig_coords[1]
                            sechenie_coords[2] = sechenie_coords[0]
                            sechenie_coords[3] = fig_coords[3]
                            line = (
                                sechenie_coords[0], sechenie_coords[1], sechenie_coords[2], sechenie_coords[3])
                            self.canvas.create_line(
                                *line, fill='black', width=5, tags="Sechenie")
                            self.canvas.update()
                            self.amount_of_line += 1
                            self.after(500)
                            if figure[2] == nmos_tag:
                                self.delta_value = (
                                    (self.W_N_WR_inv - self.prev_WRn_width)) * self.scale ** self.wheel_count
                                self.delta_of_WRs[f'{figure[2]}_5'] = self.delta_value
                                self.delta_of_WRs[f'{figure[2]}_6'] = self.delta_value
                            elif figure[2] == pmos_tag:
                                self.delta_value = (
                                    (self.W_N_WR_inv - self.prev_WRn_width) * 3) * self.scale ** self.wheel_count
                                self.delta_of_WRs[f'{figure[2]}_3'] = self.delta_value
                                self.delta_of_WRs[f'{figure[2]}_5'] = self.delta_value

                            self.wr_param_crop(fig, fig_coords, fig_tag)
                            if self.delta_value > 0:
                                self.direction = 'for'
                            else:
                                self.direction = 'back'
                            self.after(500, self.WRParametrize)

    def OUTParametrizeAccessCMD(self):
        self.OUTParametrizeAccess("sample", None, None, 100000)

    def OUTParametrizeAccess(self, mode, data, loads, width_limit):
        if mode == "sample":
            window = OUTParam(self.master)
            window.wm_attributes('-topmost', True)
            window.resizable(False, False)
            window.title('TopoPlot: OUT Block params defining')
            window.iconbitmap(r'nano.ico')
            self.OUT_param = window.open()
        elif mode == "block":
            self.OUT_param = [data, *loads, 1]

        t_dout = self.OUT_param[0]  # ps
        if t_dout == 0:
            messagebox.showerror("Error", "Enter a not zero time, please")
        else:
            C_L = self.OUT_param[1]  # in fF
            R_L = self.OUT_param[2]  # in Ohm

        if C_L or R_L is not None:
            if self.foundry.get() == 'Microwind65':
                messagebox.showerror("Error", "Model is not definded yet")

            elif self.foundry.get() == 'SkyWater130':

                interpolation_data_file = "interpolation_spline_coeffs.txt"
                self.spline_coeffs_data = self.load_spline_interpolation_data_simple(interpolation_data_file)

                # Проверка загрузки данных
                param_names = ['p00', 'p10', 'p01', 'p20', 'p11', 'p02']
                loaded_keys = set(self.spline_coeffs_data.keys())
                if not all(name in loaded_keys for name in param_names):
                    missing_keys = [
                        name for name in param_names if name not in loaded_keys]
                    self.spline_coeffs_data = {}
                    messagebox.showerror(
                        "Error", f"Failed to load all necessary interpolation data. Missing: {', '.join(missing_keys)}")
                    return None

                # Функция интерполяции t_out
                def calculate_tdout_from_Wn(W_N_microns, R_L_ohm, C_L_fF):
                    spline_coeffs = {
                        'p00': self.spline_coeffs_data['p00'](C_L_fF).item(),
                        'p10': self.spline_coeffs_data['p10'](C_L_fF).item(),
                        'p01': self.spline_coeffs_data['p01'](C_L_fF).item(),
                        'p20': self.spline_coeffs_data['p20'](C_L_fF).item(),
                        'p11': self.spline_coeffs_data['p11'](C_L_fF).item(),
                        'p02': self.spline_coeffs_data['p02'](C_L_fF).item()
                    }

                    calculated_time_sec = spline_coeffs['p00'] + spline_coeffs['p10'] / W_N_microns ** spline_coeffs['p20'] + \
                        spline_coeffs['p01'] * R_L_ohm ** spline_coeffs['p02'] + \
                        spline_coeffs['p11'] / W_N_microns * R_L_ohm
                    return calculated_time_sec

                def equation(W_N, R_L, C_L, target_t_out):
                    return calculate_tdout_from_Wn(W_N, R_L, C_L) - target_t_out

                def solve_W_N(R_L, C_L, target_t_out, initial_guess=1):
                    # Alternatively, try using root with a different method
                    result = sci_root(equation, initial_guess, args=(
                        R_L, C_L, target_t_out), method='lm')
                    return result.x

                self.new_OUTWn_width = solve_W_N(
                    R_L, C_L*1e-15, t_dout*1e-12)[0] * 1e3  # um -> nm

            # -------------calc. prev. info. about width------------------
            self.prev_OUTWn_width = self.findOUTWn()
            # ------------------------------------------------------------
            print('prev_OUTWn_width:', self.prev_OUTWn_width, '\t',
                  'new_OUTWn_width:', self.new_OUTWn_width, '\t', C_L)

            n_width_thresh = {'SkyWater130': 700.0, 'Microwind65': 60.0}
            if self.new_OUTWn_width <= n_width_thresh[self.foundry.get()]:
                messagebox.showerror("Error", "Enter a smaller t_OUT, please")
            elif width_limit != None :
                if width_limit <= self.new_OUTWn_width:
                    messagebox.showerror("Error", "Enter a smaller MAX_OUTWn_width, or increase t_OUT, please")
                # self.delta_value = self.Y_PULSE_param[0]
                self.delta_value = (
                    self.new_OUTWn_width - self.prev_OUTWn_width)*self.scale**self.wheel_count
                # print('delta_pulse:', self.delta_value)
                self.OUTParametrizeFlag = True
                self.OUT_previos_mos = ['None']
                self.OUTParametrize()

    def OUTParametrize(self):

        if self.foundry.get() == 'SkyWater130':
            pmos_tag = 'pmos'
            nmos_tag = 'nmos'
            pmos_num = '0'
            nmos_num = '0'

        elif self.foundry.get() == 'Microwind65':
            pmos_tag = 'DP'
            nmos_tag = 'DN'
            pmos_num = '3'
            nmos_num = '5'

        self.OUT_count_flag += 1
        self.hor_flag.set(0)
        if self.OUT_count_flag == 3:
            self.ver_flag.set(0)
        else:
            self.ver_flag.set(1)

        if self.OUT_count_flag == 3:
            self.delta_value = None
            self.OUTParametrizeFlag = False
            self.OUT_count_flag = 0

        if self.OUT_count_flag != 3:
            for fig in self.canvas.find_all():
                figure = self.canvas.itemcget(fig, "tags")
                figure = re.split("_", figure.strip())
                if len(figure) != 2:
                    if figure[0] == 'OUT' and ((figure[-2] == pmos_tag and figure[-1] == pmos_num) | (figure[-2] == nmos_tag and figure[-1] == nmos_num)):
                        fig_tag = self.canvas.itemcget(fig, "tags")
                        if (fig_tag not in self.OUT_previos_mos) or (self.OUT_previos_mos[0] == 'None'):
                            # print(self.previos_mos)
                            # print('\n', 'fig_tag:', fig_tag)
                            self.OUT_previos_mos.append(fig_tag)
                            try:
                                self.OUT_previos_mos.remove('None')
                            except:
                                pass
                            fig_coords = self.canvas.coords(fig_tag)
                            # print(figure, fig_coords)
                            if figure[-2] == pmos_tag:
                                sechenie_coords[0] = (fig_coords[0]+fig_coords[2])/2 - (fig_coords[0]+fig_coords[2])/500
                            elif figure[-2] == nmos_tag:
                                sechenie_coords[0] = (fig_coords[0]+fig_coords[2])/2 + (fig_coords[0]+fig_coords[2])/500
                            sechenie_coords[1] = fig_coords[1]
                            sechenie_coords[2] = sechenie_coords[0]
                            sechenie_coords[3] = fig_coords[3]
                            line = (
                                sechenie_coords[0], sechenie_coords[1], sechenie_coords[2], sechenie_coords[3])
                            self.canvas.create_line(
                                *line, fill='black', width=5, tags="Sechenie")
                            self.canvas.update()
                            self.amount_of_line += 1
                            self.after(500)
                            if figure[2] == nmos_tag or figure[2] == pmos_tag:
                                self.delta_value = (self.new_OUTWn_width - self.prev_OUTWn_width) * self.scale ** self.wheel_count
                            self.out_param_crop(fig, fig_coords, fig_tag)
                            if self.delta_value > 0:
                                self.direction = 'for'
                            else:
                                self.direction = 'back'
                            self.after(500, self.OUTParametrize)

    def SRAMParametrizeAccess(self):
        # layout_items = {f'{self.canvas.itemcget(fig,"tags")}': self.canvas.coords(self.canvas.itemcget(fig,"tags")) for fig in self.canvas.find_all()}
        window = SRAMParametrize(self.master)
        window.wm_attributes('-topmost', True)
        window.state('zoomed')
        # window.resizable(False, False)
        window.title('TopoPlot: SRAM Full Parametrize')
        window.iconbitmap(r'nano.ico')

        param_results, widths_limits = window.apply_settings()
        loads = (param_results['C_L_OUT'], param_results['R_L_OUT'])
        print('loads:', loads)
        if None in param_results.values():
            ''' ---- precharge block finding and calculation ---- '''
            t_PC = self.PC_calculate(['PC', '1', 'OP', '0'], "block")
            ''' ------------------------------------------------- '''            
            ''' ---- write block finding and calculation -------- '''
            t_WR = self.WRITE_calculate(['WRITE', '1', 'OP', '0'], "block")
            ''' ------------------------------------------------- '''
            ''' ---- pulsey block finding and calculation ------- '''
            t_WL = self.PULSEY_calculate(['PULSEY', '1', 'OP', '0'], "block")
            ''' ------------------------------------------------- '''
            ''' ---- out block finding and calculation ---------- '''
            t_OUT = self.OUT_calculate(['OUT', '1', 'OP', '0'], "block", loads)
            ''' ------------------------------------------------- '''
            messagebox.showinfo("Calculation results", f"t_WR = {t_WR} ps\nt_WL = {t_WL} ps\nt_PC = {t_PC} ps\nt_OUT = {t_OUT} ps")
        else:
            # print(param_results)
            ''' ---- precharge block finding and parametrize ---- '''
            if param_results['t_PC'] != 0:
                self.PCParametrizeAccess("block", param_results['t_PC'], widths_limits['MAX(W_PC)'])
                self.after(500)
            ''' ------------------------------------------------- '''             
            ''' ---- write block finding and parametrize -------- '''
            if param_results['t_WR'] != 0:
                self.WRParametrizeAccess("block", param_results['t_WR'], widths_limits['MAX(W_WR)'])
                self.after(500)
            ''' ------------------------------------------------- '''
            ''' ---- pulsey block finding and parametrize ------- '''
            if param_results['t_WL'] != 0:
                self.PulseYParametrizeAccess("block", param_results['t_WL'], widths_limits['MAX(W_WL)'])
                self.after(500)
            ''' ------------------------------------------------- '''
            ''' ---- out block finding and parametrize ---------- '''
            if param_results['t_OUT'] != 0:
                self.OUTParametrizeAccess("block", param_results['t_OUT'], loads, widths_limits['MAX(W_OUT)'])
                self.after(500)
            ''' ------------------------------------------------- '''
        window.mainloop()

    def getFoundry(self):
        filepath = filedialog.askopenfilename(filetypes=[(
            "txt file", ".txt")], defaultextension=".txt", initialdir=self.filefolder + '\rules')
        filename = os.path.basename(filepath)[:-4]
        GridUnit, self.CAPs, self.RESs = ReadTXT_Foundry(
            path=filepath, name=filename).getParams()
        # print(GridUnit)
        # print(self.CAPs)
        f = self.foundry_version
        f.delete(0, tk.END)
        f.insert(0, filename)

        e = self.entry_tech
        e.delete(0, tk.END)
        e.insert(0, GridUnit)

    def open_file(self):
        # self.GridUnits = self.form.get_tech()
        self.GridUnits = self.GridLambda.get()
        if self.GridUnits == 0:
            messagebox.showerror("Error", "Choose foundry, please")
        else:
            self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
            r = self.Lambda/2

            self.w, self.h = 750, 750
            self.canvas.delete('all')
            # self.grid_flag.set(0)
            self.canvas.configure(width=self.w, height=self.h)
            filepath = filedialog.askopenfilename(filetypes=[(
                "TXT file", ".txt"), ("CIF file", ".cif"), ("MSK file", ".MSK")], initialdir=self.filefolder)
            filename = os.path.basename(filepath)[:-4]
            extension = os.path.basename(filepath)[-3:]

            if extension == 'txt' or extension == 'TXT' or extension == 'msk' or extension == 'MSK':
                device_coords = ReadTXT_MW(
                    path=filepath, name=filename).getCoords()
            elif extension == 'cif' or extension == 'CIF':
                # , Lambda = self.Lambda
                device_coords = ReadCIF_MW(path=filepath, name=filename).getCoords()

            self.insert_item = re.split("_", filename.strip())
            self.insert_item = self.insert_item[0]
            if not self.canvas.find_all():
                self.num_of_blocks[self.insert_item] = 0
            else:
                self.num_of_blocks[self.insert_item] += 1

            '''self.window = device_coords['OP'][0]'''

            '''
            self.width = plus_size + self.window[2]*self.Lambda
            self.height = plus_size + self.window[3]*self.Lambda
            self.canvas.configure(width=self.width,height=self.height)
            '''
            for j in range(len(top_area[self.foundry.get()])):
                rec = device_coords.get(top_area[self.foundry.get()][j])
                color = colors[self.foundry.get()][j]
                bordertype = borders[self.foundry.get()][j]
                filling = fills[self.foundry.get()][j]
                if type(rec) is list:
                    for i in range(len(rec)):
                        if device_coords['OP'] != 0:
                            if j != (len(top_area[self.foundry.get()])-1):
                                koeff = 1
                            else:
                                koeff = -1
                        else:
                            koeff = -1

                        rec_coord = (math.ceil(rec[i][0]*self.Lambda), math.ceil(rec[i][1]*self.Lambda), math.ceil(
                            (rec[i][0]+rec[i][2])*self.Lambda), math.ceil((rec[i][1]-koeff*rec[i][3])*self.Lambda))
                        if device_coords['OP'] == 0:
                            rec_coord = self.mirror_shape(rec_coord, 0, 0, 'X')
                        # print(top_area[j],rec_coord, color, bordertype, filling)
                        if j == len(top_area[self.foundry.get()])-1:
                            for m in (0, 2):
                                for n in (1, 3):
                                    self.canvas.create_oval(rec_coord[m]-r, rec_coord[n]-r, rec_coord[m]+r, rec_coord[n]+r, fill='', activefill='black', outline= 'black', tags = 'corner'+f'{m}'+f'{n}'+'_'+f'{j}')
                        self.create_rec_with_mem(*rec_coord, outline=color, fill=filling, dash=bordertype, tags=f'{self.insert_item}_{self.num_of_blocks[self.insert_item]}_{top_area[self.foundry.get()][j]}_{i}')
                        # print(rec_coord)
                        # self.canvas.update()

    def export_gds(self):

        export_path = filedialog.asksaveasfilename(filetypes=[(
            "GDS file", ".gds")], defaultextension=".txt", initialdir=self.filefolder)
        name = os.path.basename(export_path)[:-4]

        layout = db.Layout()
        # Create Cell obj
        cell_obj = layout.create_cell(f"{name}")
        self.bound_coords = self.canvas.bbox('all')
        if export_path:
            op_item = None
            # ----------------------------------------------------
            for item in self.canvas.find_all():
                fig = re.split("_", self.canvas.gettags(item)[0].strip())
                if fig[-2] == 'OP':
                    op_item = item
            try:
                self.op_coords = self.canvas.coords(op_item)
            except:
                self.op_coords = self.bound_coords

            y_median = (self.op_coords[1]+self.op_coords[3])/2
            # ----------------------------------------------------
            item_num = 0
            previos_tag = None
            num_of_all_items = len(self.canvas.find_all())
            window = ProgressBarWindow(self.master, num_of_all_items)
            window.wm_attributes('-topmost', True)
            window.resizable(False, False)
            window.title('TopoPlot: Progress Bar')
            for item in self.canvas.find_all():
                item_num += 1
                numerical_tag = self.canvas.gettags(item)[0]
                numerical_tag = re.split("_", numerical_tag.strip())
                only_tag = numerical_tag[-2]
                old_coords = self.canvas.coords(item)

                if only_tag != previos_tag:  # and areas[item] != 0:
                    # layouts initialization

                    # new_file.writelines(f"L {lyp_codes_mw[only_tag]};\n")
                    previos_tag = only_tag

                k = 0
                for i in range(2):
                    if old_coords[i] >= self.bound_coords[i] and old_coords[i+2] <= self.bound_coords[i+2]:
                        k += 1
                if k == 2:
                    self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
                    new_coords = (old_coords[0]/self.Lambda, (y_median+(y_median-old_coords[1]))/self.Lambda,
                                  old_coords[2]/self.Lambda, (y_median+(y_median-old_coords[3]))/self.Lambda)
                    # new_coords = (old_coords[0]/self.Lambda, old_coords[1]/self.Lambda, old_coords[2]/self.Lambda, old_coords[3]/self.Lambda)
                    coord = list(map(int, new_coords))
                    # self.canvas.coords(item, *new_coords)
                length, width = abs(coord[2]-coord[0]), abs(coord[3]-coord[1])
                '''in POLYGON style'''
                X1, Y1 = coord[0], coord[1]
                X2, Y1 = coord[0]+length, coord[1]
                X2, Y2 = coord[0]+length, coord[1]-width
                X1, Y2 = coord[0], coord[1]-width
                points = [
                    db.DPoint(X1, Y1),
                    db.DPoint(X2, Y1),
                    db.DPoint(X2, Y2),
                    db.DPoint(X1, Y2)
                ]
                # db.LayerInfo(f"{lyp_codes_mw[only_tag]}",0)
                if self.foundry.get() == 'Microwind65':
                    cell_obj.shapes(layout.layer(db.LayerInfo(gds_codes_mw[only_tag], 0))).insert(
                        db.DPolygon(points))
                elif self.foundry.get() == 'SkyWater130':
                    cell_obj.shapes(layout.layer(db.LayerInfo(
                        lyp_codes_sw['gds'][only_tag], 0))).insert(db.DPolygon(points))
                # new_file.writelines(f"P {X1},{Y1} {X2},{Y1} {X2},{Y2} {X1},{Y2};\n")

                window.bar(item_num, self.canvas.gettags(item)[0])
            window.bar_closing()
        layout.write(f"{export_path}")

    def export_cif_hierarchy(self):
        amount_of_cells = 0
        export_path = filedialog.asksaveasfilename(filetypes=[(
            "CIF file", ".cif")], defaultextension=".txt", initialdir=self.filefolder)
        name = os.path.basename(export_path)[:-4]
        # ----------cell blocks counting-----------
        for item in self.canvas.find_all():
            fig = re.split("_", self.canvas.gettags(item)[0].strip())
            if fig[-2] == 'OP':
                amount_of_cells += 1
        # print("amount_of_cells:", amount_of_cells)
        # -----------------------------------------
        with open(f'{export_path}', 'w') as new_file:
            new_file.writelines("(CIF file written  by TopoPlot);\n")
            new_file.close()
        '''
        with open(f'{export_path}', 'w') as new_file:
            new_file.writelines("DS 1 3 2;\n");
            new_file.writelines(f"9 {name};\n");
            new_file.close()
        '''
        tag_list = ['None']*amount_of_cells
        op_cells_coords_list = ['None']*amount_of_cells

        for cell_id in range(1, amount_of_cells + 1):
            for item in self.canvas.find_all():
                fig = re.split("_", self.canvas.gettags(item)[0].strip())
                # print(fig)
                if len(fig) == 4:
                    cell_tag = f"{fig[0]}_{fig[1]}"
                elif len(fig) == 5:
                    cell_tag = f"{fig[0]}_{fig[1]}_{fig[2]}"
                elif len(fig) == 6:
                    cell_tag = f"{fig[0]}_{fig[1]}_{fig[2]}_{fig[3]}"
                # print(fig, ' ', cell_tag)
                # and f"{cell-1}" == fig[-3] :
                if fig[-2] == 'OP' and (cell_tag not in tag_list):
                    tag_list[cell_id-1] = cell_tag
                    # print('after:',tag_list)
        # print(tag_list)
        # creating progressbar window
        window = ProgressBarWindow(self.master, amount_of_cells)
        window.wm_attributes('-topmost', True)
        window.resizable(False, False)
        window.title('TopoPlot: Progress Bar')
        if export_path:
            with open(f'{export_path}', 'a') as new_file:
                self.bound_coords = self.canvas.bbox('all')
                # ----------------------------------------------------
                for cell in range(1, amount_of_cells+1):
                    # print('cell:', cell)
                    # print('before:',tag_list)
                    op_item = None
                    for item in self.canvas.find_all():
                        fig = re.split(
                            "_", self.canvas.gettags(item)[0].strip())
                        '''
                        if len(fig) == 4:
                            cell_tag = f"{fig[0]}_{fig[1]}"
                        elif len(fig) == 5:
                            cell_tag = f"{fig[0]}_{fig[1]}_{fig[2]}"
                        #print(fig, ' ', cell_tag)
                        '''
                        if fig[-2] == 'OP':  # and f"{cell-1}" == fig[-3]:# (cell_tag not in tag_list) :
                            op_item = item
                            # tag_list[cell-1] = cell_tag
                            # print('after:',tag_list)
                    # cell_obj = re.split("_", self.canvas.gettags(op_item)[0].strip())
                    # print(tag_list)
                    new_file.writelines(f"DS {cell} 3 2;\n")
                    new_file.writelines(f"9 {tag_list[cell-1]};\n")
                    # print(tag_list[cell-1])
                    try:
                        self.op_coords = self.canvas.coords(op_item)
                    except:
                        self.op_coords = self.bound_coords

                    # if op_item is None:
                    #    self.create_rec_with_mem(*self.op_coords, outline='black', fill = '', dash = '-', tags = 'OP_BB')

                    y_median = (self.op_coords[1]+self.op_coords[3])/2
                    # ----------------------------------------------------
                    previos_tag = None
                    for item in self.canvas.find_all():
                        numerical_tag = re.split(
                            "_", self.canvas.gettags(item)[0].strip())
                        if (tag_list[cell-1] == f"{numerical_tag[0]}_{numerical_tag[1]}" or tag_list[cell-1] == f"{numerical_tag[0]}_{numerical_tag[1]}_{numerical_tag[2]}" or tag_list[cell-1] == f"{numerical_tag[0]}_{numerical_tag[1]}_{numerical_tag[2]}_{numerical_tag[3]}"):
                            only_tag = numerical_tag[-2]
                            old_coords = self.canvas.coords(item)

                            # and areas[item] != 0:
                            if only_tag != previos_tag:
                                if self.foundry.get() == 'Microwind65':
                                    new_file.writelines(
                                        f"L {lyp_codes_mw[only_tag]};\n")
                                elif self.foundry.get() == 'SkyWater130':
                                    new_file.writelines(
                                        f"L {lyp_codes_sw['cif'][only_tag]};\n")
                                previos_tag = only_tag

                            k = 0
                            for i in range(2):
                                if old_coords[i] >= self.bound_coords[i] and old_coords[i+2] <= self.bound_coords[i+2]:
                                    k += 1
                            if k == 2:
                                self.Lambda = (self.GridUnits) * \
                                    self.scale**self.wheel_count
                                new_coords = (old_coords[0]/self.Lambda, (y_median+(y_median-old_coords[1]))/self.Lambda,
                                              old_coords[2]/self.Lambda, (y_median+(y_median-old_coords[3]))/self.Lambda)
                                # new_coords = (old_coords[0]/self.Lambda, old_coords[1]/self.Lambda, old_coords[2]/self.Lambda, old_coords[3]/self.Lambda)
                                coord = list(map(int, new_coords))
                                # self.canvas.coords(item, *new_coords)
                            length, width = abs(
                                coord[2]-coord[0]), abs(coord[3]-coord[1])
                            # op_cells_coords_list[cell-1] = (coord[0], coord[1], length, width)
                            '''in BOX style'''
                            # x_center, y_center = math.ceil(coord[0]+length/2), math.ceil(coord[1]-width/2)
                            # new_file.writelines(f"B {length} {width} {x_center},{y_center};\n")
                            '''in POLYGON style'''
                            X1, Y1 = coord[0], coord[1]
                            X2, Y1 = coord[0]+length, coord[1]
                            X2, Y2 = coord[0]+length, coord[1]-width
                            X1, Y2 = coord[0], coord[1]-width
                            new_file.writelines(
                                f"P {X1},{Y1} {X2},{Y1} {X2},{Y2} {X1},{Y2};\n")
                    new_file.writelines("DF;\n")
                    # increasing in progressbar window
                    window.bar(cell, tag_list[cell-1])
                new_file.writelines(f"DS {amount_of_cells+1} 3 2;\n")
                new_file.writelines(f"9 {name};\n")
                for cell_id in range(amount_of_cells):
                    new_file.writelines(f"C{cell_id+1} R1,0 T0,0;\n")
                new_file.writelines("DF;\n")
                new_file.writelines("E\n")
                new_file.close()
                window.bar_closing()

    def export_cif(self):
        export_path = filedialog.asksaveasfilename(filetypes=[(
            "CIF file", ".cif")], defaultextension=".txt", initialdir=self.filefolder)
        name = os.path.basename(export_path)[:-4]
        # open (export_path, 'w').close()

        if export_path:
            with open(f'{export_path}', 'w') as new_file:
                new_file.writelines("DS 1 3 2;\n")
                new_file.writelines(f"9 {name};\n")
                new_file.close()
            op_item = None
            with open(f'{export_path}', 'a') as new_file:
                self.bound_coords = self.canvas.bbox('all')
                # ----------------------------------------------------
                for item in self.canvas.find_all():
                    fig = re.split("_", self.canvas.gettags(item)[0].strip())
                    if fig[-2] == 'OP':
                        op_item = item
                try:
                    self.op_coords = self.canvas.coords(op_item)
                except:
                    self.op_coords = self.bound_coords

                if op_item is None:
                    self.create_rec_with_mem(*self.op_coords, outline='black', fill='', dash='-', tags='OP_BB')

                y_median = (self.op_coords[1]+self.op_coords[3])/2
                # ----------------------------------------------------
                item_num = 0
                previos_tag = None
                num_of_all_items = len(self.canvas.find_all())
                window = ProgressBarWindow(self.master, num_of_all_items)
                window.wm_attributes('-topmost', True)
                window.resizable(False, False)
                window.title('TopoPlot: Progress Bar')
                for item in self.canvas.find_all():
                    item_num += 1
                    numerical_tag = self.canvas.gettags(item)[0]
                    numerical_tag = re.split("_", numerical_tag.strip())
                    only_tag = numerical_tag[-2]
                    old_coords = self.canvas.coords(item)

                    if only_tag != previos_tag:  # and areas[item] != 0:
                        if self.foundry.get() == 'Microwind65':
                            new_file.writelines(
                                f"L {lyp_codes_mw[only_tag]};\n")
                        elif self.foundry.get() == 'SkyWater130':
                            new_file.writelines(
                                f"L {lyp_codes_sw['cif'][only_tag]};\n")

                        previos_tag = only_tag

                    k = 0
                    for i in range(2):
                        if old_coords[i] >= self.bound_coords[i] and old_coords[i+2] <= self.bound_coords[i+2]:
                            k += 1
                    if k == 2:
                        self.Lambda = (self.GridUnits) * \
                            self.scale**self.wheel_count
                        new_coords = (old_coords[0]/self.Lambda, (y_median+(y_median-old_coords[1]))/self.Lambda,
                                      old_coords[2]/self.Lambda, (y_median+(y_median-old_coords[3]))/self.Lambda)
                        # new_coords = (old_coords[0]/self.Lambda, old_coords[1]/self.Lambda, old_coords[2]/self.Lambda, old_coords[3]/self.Lambda)
                        coord = list(map(int, new_coords))
                        # self.canvas.coords(item, *new_coords)
                    length, width = abs(
                        coord[2]-coord[0]), abs(coord[3]-coord[1])
                    '''in BOX style'''
                    # x_center, y_center = math.ceil(coord[0]+length/2), math.ceil(coord[1]-width/2)
                    # new_file.writelines(f"B {length} {width} {x_center},{y_center};\n")
                    '''in POLYGON style'''
                    X1, Y1 = coord[0], coord[1]
                    X2, Y1 = coord[0]+length, coord[1]
                    X2, Y2 = coord[0]+length, coord[1]-width
                    X1, Y2 = coord[0], coord[1]-width
                    new_file.writelines(
                        f"P {X1},{Y1} {X2},{Y1} {X2},{Y2} {X1},{Y2};\n")
                    window.bar(item_num, self.canvas.gettags(item)[0])
                new_file.writelines("DF;\n")
                new_file.writelines("E\n")
                new_file.close()
                window.bar_closing()

# =============================================================================
#     def export_mag(self):
#         export_path = filedialog.asksaveasfilename(
#             filetypes=[("MAG file", ".mag")],
#             defaultextension=".mag",initialdir=self.filefolder)
#         open (export_path, 'w').close()
#         op_item = None
#         all_items = self.canvas.find_all()
#         window = ProgressBarWindow(self.master, len(all_items))
#         window.wm_attributes('-topmost', True)
#         window.resizable(False, False)
#         window.title('TopoPlot: Progress Bar')
#         if export_path:
#             self.bound_coords = self.canvas.bbox('all')
#
#             for item in all_items:
#                 fig = re.split("_", self.canvas.gettags(item)[0].strip())
#                 if fig[-2] == 'OP':
#                     op_item = item
#             try:
#                 self.op_coords = self.canvas.coords(op_item)
#             except:
#                 self.op_coords = self.bound_coords
#
#             if op_item is None:
#                 self.create_rec_with_mem(*self.op_coords, outline='black', fill = '', dash = '-', tags = 'OP_BB')
#
#             y_median = (self.op_coords[1]+self.op_coords[3])/2
#             items_dict = {layer: [] for layer in top_area['SkyWater130']}
#
#             for num, item in enumerate(all_items):
#                 numerical_tag = self.canvas.gettags(item)[0]
#                 numerical_tag = re.split("_", numerical_tag.strip())
#                 only_tag = numerical_tag[-2]
#                 old_coords = self.canvas.coords(item)
#                 k = 0
#                 for i in range(2):
#                     if old_coords[i] >= self.bound_coords[i] and old_coords[i+2] <= self.bound_coords[i+2]:
#                         k += 1
#                 if k == 2:
#                     self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
#                     #new_coords = [old_coords[0]/self.Lambda, old_coords[1]/self.Lambda, old_coords[2]/self.Lambda, old_coords[3]/self.Lambda]
#                     new_coords = [old_coords[0]/self.Lambda, (y_median+(y_median-old_coords[3]))/self.Lambda, old_coords[2]/self.Lambda, (y_median+(y_median-old_coords[1]))/self.Lambda]
#                     new_coords = [int(coord + 0.5) if coord > 0 else int(coord - 0.5) for coord in new_coords]
#                     items_dict[only_tag].append(new_coords)
#
#             new_items_dict = {k:v for k,v in items_dict.items() if v}
#             num = 0
#             with open(f'{export_path}', 'a') as new_file:
#                 new_file.writelines("magic\ntech sky130A\ntimestamp 1737276349\n")
#                 for layer, rects in new_items_dict.items():
#                     #if layer != 'OP':
#                     if layer == 'OP':
#                         new_file.writelines(f"<< comment >>\n")
#                     else:
#                         new_file.writelines(f"<< {layer} >>\n")
#                     for rect in rects:
#                         num += 1
#                         new_file.writelines(f"rect {rect[0]} {rect[1]} {rect[2]} {rect[3]}\n")
#                         window.bar(num, f"{layer}_{num}")
#                 #new_file.writelines("<< labels >>\n")
#                 #for i, op_rects in enumerate(new_items_dict['OP']):
#                     #new_file.writelines(f"rlabel space {op_rects[0]} {op_rects[1]} {op_rects[2]} {op_rects[3]} {i + 1} OP\n")
#                 new_file.writelines("<< end >>")
#                 new_file.close()
#             window.bar_closing()
# =============================================================================
    def export_mag(self):
        export_path = filedialog.asksaveasfilename(
            filetypes=[("MAG file", ".mag")],
            defaultextension=".mag", initialdir=self.filefolder)
        if not export_path:
            return

        op_item = None
        all_items = self.canvas.find_all()
        window = ProgressBarWindow(self.master, len(all_items))
        window.wm_attributes('-topmost', True)
        window.resizable(False, False)
        window.title('TopoPlot: Progress Bar')

        self.bound_coords = self.canvas.bbox('all')

        # Поиск OP элемента
        for item in all_items:
            fig = self.canvas.gettags(item)
            if not fig:
                continue
            fig = re.split("_", fig[0].strip())
            if fig[-2] == 'OP':
                op_item = item
                break  # Предполагаем, что нужен только первый OP

        try:
            self.op_coords = self.canvas.coords(op_item)
        except Exception:
            self.op_coords = self.bound_coords

        if op_item is None:
            self.create_rec_with_mem(
                *self.op_coords, outline='black', fill='', dash='-', tags='OP_BB')

        y_median = (self.op_coords[1] + self.op_coords[3]) / 2
        items_dict = {layer: [] for layer in top_area['SkyWater130']}

        # --- Собираем прямоугольники по слоям ---
        for num, item in enumerate(all_items):
            tags = self.canvas.gettags(item)
            if not tags:
                continue
            numerical_tag = re.split("_", tags[0].strip())
            only_tag = numerical_tag[-2]
            old_coords = self.canvas.coords(item)
            k = 0
            for i in range(2):
                if old_coords[i] >= self.bound_coords[i] and old_coords[i+2] <= self.bound_coords[i+2]:
                    k += 1
            if k == 2:
                Lambda = self.GridUnits * self.scale ** self.wheel_count
                y0 = (y_median + (y_median - old_coords[3])) / Lambda
                y1 = (y_median + (y_median - old_coords[1])) / Lambda
                new_coords = [
                    int(old_coords[0] / Lambda + 0.5) if old_coords[0] > 0 else int(
                        old_coords[0] / Lambda - 0.5),
                    int(y0 + 0.5) if y0 > 0 else int(y0 - 0.5),
                    int(old_coords[2] / Lambda + 0.5) if old_coords[2] > 0 else int(
                        old_coords[2] / Lambda - 0.5),
                    int(y1 + 0.5) if y1 > 0 else int(y1 - 0.5)
                ]
                items_dict[only_tag].append(new_coords)

        new_items_dict = {k: v for k, v in items_dict.items() if v}

        # --- Буферизация строк для записи ---
        lines = []
        lines.append("magic\ntech sky130A\ntimestamp 1737276349\n")
        num = 0
        for layer, rects in new_items_dict.items():
            if layer == 'OP':
                lines.append("<< comment >>\n")
            else:
                lines.append(f"<< {layer} >>\n")
            for rect in rects:
                num += 1
                lines.append(f"rect {rect[0]} {rect[1]} {rect[2]} {rect[3]}\n")
                if num % 100 == 0:  # Обновляем прогрессбар реже
                    window.bar(num, f"{layer}_{num}")

        lines.append("<< end >>")

        # --- Быстрая запись всего файла за 1 раз ---
        with open(export_path, 'w', encoding='utf-8') as new_file:
            new_file.writelines(lines)

        window.bar_closing()

    def export_txt(self):
        export_path = filedialog.asksaveasfilename(
            filetypes=[("TXT file", ".txt")],
            defaultextension=".txt", initialdir=self.filefolder)
        open(export_path, 'w').close()
        op_item = None
        num_of_all_items = len(self.canvas.find_all())
        window = ProgressBarWindow(self.master, num_of_all_items)
        window.wm_attributes('-topmost', True)
        window.resizable(False, False)
        window.title('TopoPlot: Progress Bar')
        if export_path:
            self.bound_coords = self.canvas.bbox('all')

            for item in self.canvas.find_all():
                fig = re.split("_", self.canvas.gettags(item)[0].strip())
                if fig[-2] == 'OP':
                    op_item = item
            try:
                self.op_coords = self.canvas.coords(op_item)
            except:
                self.op_coords = self.bound_coords

            if op_item is None:
                self.create_rec_with_mem(*self.op_coords, outline='black', fill='', dash='-', tags='OP_BB')

            y_median = (self.op_coords[1]+self.op_coords[3])/2

            item_num = 0
            for item in self.canvas.find_all():
                item_num += 1
                numerical_tag = self.canvas.gettags(item)[0]
                numerical_tag = re.split("_", numerical_tag.strip())
                only_tag = numerical_tag[-2]
                old_coords = self.canvas.coords(item)
                k = 0
                for i in range(2):
                    if old_coords[i] >= self.bound_coords[i] and old_coords[i+2] <= self.bound_coords[i+2]:
                        k += 1
                if k == 2:
                    self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
                    new_coords = [old_coords[0]/self.Lambda, (y_median+(y_median-old_coords[1]))/self.Lambda,
                                  old_coords[2]/self.Lambda, (y_median+(y_median-old_coords[3]))/self.Lambda]
                    new_coords = [
                        int(coord + 0.5) if coord > 0 else int(coord - 0.5) for coord in new_coords]

                new_coords[3] = new_coords[3]-new_coords[1]
                new_coords[2] = new_coords[2]-new_coords[0]
                with open(f'{export_path}', 'a') as new_file:
                    new_file.writelines(
                        f"REC({new_coords[0]},{new_coords[1]},{new_coords[2]},{new_coords[3]},{only_tag})\n")
                    window.bar(item_num, self.canvas.gettags(item)[0])
                    new_file.close()
            window.bar_closing()

    def insert_file(self):
        # self.w, self.h = 500, 500
        # self.canvas.configure(width=self.w,height=self.h)
        self.insertAccess = 1
        self.multiplyAccess = 0
        self.synthesisAcces = 0
        self.y_decoder_access = 0
        filepath = filedialog.askopenfilename(filetypes=[("TXT file", ".txt"), ("CIF file", ".cif"), (
            "MSK file", ".MSK"), ("MAG file", ".mag")], initialdir=self.filefolder)
        filename = os.path.basename(filepath)[:-4]
        extension = os.path.basename(filepath)[-3:]
        if extension == 'txt' or extension == 'TXT' or extension == 'msk' or extension == 'MSK':
            self.device_coords = ReadTXT_MW(
                path=filepath, name=filename).getCoords()
        elif extension == 'cif' or extension == 'CIF':
            self.device_coords = ReadCIF_MW(
                path=filepath, name=filename).getCoords()
        elif extension == 'mag' or extension == 'MAG':
            self.device_coords = ReadTXT_SW(
                path=filepath, name=filename).getCoords()

        # print('inserting: ', self.device_coords)

        self.insert_item = re.split("_", filename.strip())
        self.insert_item = self.insert_item[0]

        no_update = False

        for fig in self.canvas.find_all():
            figure = self.canvas.gettags(fig)[0]
            figure = re.split("_", figure.strip())
            figure = figure[0]
            if figure == self.insert_item:
                no_update = True
            else:
                pass

        if not self.canvas.find_all() or no_update == False:
            self.num_of_blocks[self.insert_item] = 0
        else:
            self.num_of_blocks[self.insert_item] += 1

        # self.previos_item = self.insert_item
        # print(self.num_of_blocks)

    def let_insert(self, event):
        if self.insertAccess == 0 and (self.multiplyAccess == 1 or self.synthesisAcces == 1 or self.y_decoder_access == 1):
            pass
        elif self.insertAccess == 1:
            self.insertAccess = 0
            self.multiplyAccess = 0
            self.synthesisAcces = 0
            self.y_decoder_access = 0
            self.GridUnits = self.GridLambda.get()
            # self.GridUnits = self.form.get_tech()
            if self.GridUnits == 0:
                messagebox.showerror("Error", "Choose foundry, please")
            elif self.GridUnits != 0 and self.drag_flag.get() == 0:
                x = self.canvas.canvasx(event.x)
                y = self.canvas.canvasy(event.y)
                self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
                # self.points_coord = self.device_coords['OP'][0]
                # print(self.points_coord)
                for j in range(len(top_area[self.foundry.get()])):
                    rec = self.device_coords.get(
                        top_area[self.foundry.get()][j])
                    color = colors[self.foundry.get()][j]
                    bordertype = borders[self.foundry.get()][j]
                    filling = fills[self.foundry.get()][j]
                    if type(rec) is list:
                        for i in range(len(rec)):

                            rec_coord = (x + rec[i][0] * self.Lambda, y + rec[i][1] * self.Lambda, x + (
                                rec[i][0] + rec[i][2]) * self.Lambda, y + (rec[i][1] + rec[i][3]) * self.Lambda)

                            if self.device_coords['OP'] == 0:
                                rec_coord = self.mirror_shape(
                                    rec_coord, x, y, 'X')
                            # export_rec_coords = (x+rec[i][0], y+rec[i][1],x+(rec[i][0]+rec[i][2]),y+(rec[i][1]-koeff*rec[i][3]))
                            self.create_rec_with_mem(*rec_coord, outline=color, fill=filling, dash=bordertype, tags=f'{self.insert_item}_{self.num_of_blocks[self.insert_item]}_{top_area[self.foundry.get()][j]}_{i}')
                            # self.canvas.update()

    def close_file(self):
        self.canvas.delete('all')
        for i in range(len(sechenie_coords)):
            sechenie_coords[i] = None
        self.num_of_blocks = {}
        self.j[self.foundry.get()] = {}
        # self.j_new = {}
        # self.j_shifted = {}
        for areatype in area_props[self.foundry.get()].keys():
            self.j[self.foundry.get()][areatype] = 0
            # self.j_new[areatype] = 0
            # self.j_shifted[areatype] = 0

        self.amount_of_line = 0
        self.drag_process = 0
        self.point_1 = [0, 0]
        self.point_2 = [0, 0]
        self.block_item = None

        self.PCParametrizeFlag = False
        self.PULSEYParametrizeFlag = False

        self.delta_value = None
        self.line_start = None
        self.PC_previos_mos = ['None']
        self.PULSEY_previos_mos = ['None']

        # self.grid_flag.set(0)
        # self.wheel_count = 0
        # self.scale = 1.0

        self.delta = 0.8
        self.scale = 1.0
        self.count = 0
        # ----------------------
        self.PC_count_flag = 0
        self.PCblock = None
        # ----------------------
        self.PULSEY_count_flag = 0
        self.PULSEYblock = None
        # ----------------------
        self.WR_count_flag = 0
        self.WRblock = None
        # ----------------------
        self.wheel_count = self.count
        self.insertAccess = 0
        self.multiplyAccess = 0
        self.CellAccess = 0
        self.synthesisAcces = 0
        self.y_decoder_access = 0
        self.PulseY = 0
        self.x_decoder_access = 0
        self.PulseX = 0
        self.x_connect_access = 0
        # self.canvas.destroy()
        self.canvas.update()  # self.canvas.configure(width = self.width, height = self.height)

    def move_canvas(self, event):
        self.speed = 10
        if event.keysym == 'Left':
            self.dir_x, self.dir_y = 1, 0

        if event.keysym == 'Right':
            self.dir_x, self.dir_y = -1, 0

        if event.keysym == 'Up':
            self.dir_x, self.dir_y = 0, 1

        if event.keysym == 'Down':
            self.dir_x, self.dir_y = 0, -1
        try:
            self.pos_x += self.dir_x * self.speed
            self.pos_y += self.dir_y * self.speed
        except:
            self.pos_x = self.dir_x * self.speed
            self.pos_y = self.dir_y * self.speed

        self.canvas.scan_dragto(self.pos_x, self.pos_y, gain=1)

    def move_from_by_mouse(self, event):
        ''' Remember previous coordinates for scrolling with the mouse '''
        self.canvas.scan_mark(event.x, event.y)

    def move_to_by_mouse(self, event):
        ''' Drag (move) canvas to the new position '''
        self.canvas.scan_dragto(event.x, event.y, gain=1)
        self.pos_x = event.x
        self.pos_y = event.y

    def wheel(self, event):
        ''' Zoom with mouse wheel '''

        self.scale = 1.0

        if event.delta == -120:
            self.scale *= self.delta
            self.count += 1

        if event.delta == 120:
            self.scale /= self.delta
            self.count -= 1
        if self.scale != 1.0:
            sign = -1 if self.scale > 1 else 1
            self.wheel_count = sign*self.count
            # print("scale:",self.scale,"wheel_count:",self.wheel_count, "count:", self.count)

            # Rescale all canvas objects
            self.wheel_x = self.canvas.canvasx(event.x)
            self.wheel_y = self.canvas.canvasy(event.y)
            self.canvas.scale('all', self.wheel_x,
                              self.wheel_y, self.scale, self.scale)

    def open_window_n(self):
        if self.nmos_flag.get() != 0:
            window = AreaParam(self.master, area_types[0])
            window.title('TopoPlot: NMOS creating')
            window.wm_attributes('-topmost', True)
            window.iconbitmap(r'nano.ico')
            window.resizable(False, False)
            Element = window.open()
            for i in range(len(list_of_el)):
                list_of_el[i] = Element[-1-i]

    def open_window_p(self):
        if self.pmos_flag.get() != 0:
            window = AreaParam(self.master, area_types[1])
            window.title('TopoPlot: PMOS creating')
            window.wm_attributes('-topmost', True)
            window.iconbitmap(r'nano.ico')
            window.resizable(False, False)
            Element = window.open()
            for i in range(len(list_of_el)):
                list_of_el[i] = Element[-1-i]

    def create_mos(self, event):
        if self.nmos_flag.get() == 1 or self.pmos_flag.get() == 1:
            self.nmos_flag.set(0)
            self.pmos_flag.set(0)
            self.GridUnits = self.GridLambda.get()
            # self.GridUnits = self.form.get_tech()
            if self.GridUnits == 0:
                messagebox.showerror("Error", "Choose foundry, please")
            else:
                # print(self.scale, self.wheel_count)
                self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
                x_init = self.canvas.canvasx(event.x)
                y_init = self.canvas.canvasy(event.y)
                type_of_mos = list_of_el[0]
                w_me = 4*self.Lambda  # the width of me1 is 4 lambda
                w_mos = list_of_el[1]*self.Lambda
                l_mos = list_of_el[2]*self.Lambda
                a_contact = 2*self.Lambda

                if list_of_el[1] >= 5:
                    amount_of_contact = math.floor(list_of_el[1]/5)
                elif list_of_el[1] == 4:
                    amount_of_contact = 1
                else:
                    amount_of_contact = 0

                # minimum length of diffusion area of mos is 12 lambda
                min_length = (list_of_el[2] + 10)*self.Lambda

                diff_area = (x_init, y_init, x_init +
                             min_length, y_init + w_mos)
                channel_area = (x_init + 5*self.Lambda, y_init - 3*self.Lambda,
                                x_init + 5*self.Lambda + l_mos, y_init + w_mos + 3*self.Lambda)
                well_area = (x_init - 3*self.Lambda, y_init - 3*self.Lambda, x_init +
                             min_length + 3*self.Lambda, y_init + w_mos + 3*self.Lambda)

                if type_of_mos == 'NMOS':
                    '''creating the diffusion area of mos'''
                    self.j[self.foundry.get()]['DN'] += 1
                    self.create_rec_with_mem(
                        *diff_area, outline='green', tags=f"DN_{self.j[self.foundry.get()]['DN']}")
                    '''creating the polySi area of mos'''
                    self.j[self.foundry.get()]['PO'] += 1
                    self.create_rec_with_mem(
                        *channel_area, outline='red', tags=f"PO_{self.j[self.foundry.get()]['PO']}")

                elif type_of_mos == 'PMOS':
                    '''creating the diffusion area of mos'''
                    self.j[self.foundry.get()]['DP'] += 1
                    self.create_rec_with_mem(
                        *diff_area, outline='brown', tags=f"DP_{self.j[self.foundry.get()]['DP']}")
                    '''creating the polySi area of mos'''
                    self.j[self.foundry.get()]['PO'] += 1
                    self.create_rec_with_mem(
                        *channel_area, outline='red', tags=f"PO_{self.j[self.foundry.get()]['PO']}")
                    self.j[self.foundry.get()]['NW'] += 1
                    self.create_rec_with_mem(
                        *well_area, outline='green', dash='-', tags=f"NW_{self.j[self.foundry.get()]['NW']}")

                # creating the first metall layer
                self.j[self.foundry.get()]['ME'] += 1
                me1_area_left = (x_init, y_init, x_init + w_me, y_init + w_mos)
                self.create_rec_with_mem(
                    *me1_area_left, outline='blue', tags=f"ME_{self.j[self.foundry.get()]['ME']}")

                self.j[self.foundry.get()]['ME'] += 1
                me1_area_right = (x_init+l_mos+6*self.Lambda, y_init,
                                  x_init+l_mos+w_me+6*self.Lambda, y_init + w_mos)
                self.create_rec_with_mem(
                    *me1_area_right, outline='blue', tags=f"ME_{self.j[self.foundry.get()]['ME']}")

                # creating the contact areas
                for i in range(amount_of_contact):
                    self.j[self.foundry.get()]['CO'] += 1

                    contact_area_left = (x_init + 1*self.Lambda, y_init + (1+5*i)*self.Lambda,
                                         x_init + 1*self.Lambda + a_contact, y_init + (1+5*i)*self.Lambda + a_contact)
                    self.create_rec_with_mem(
                        *contact_area_left, outline='black', tags=f"CO_{self.j[self.foundry.get()]['CO'] + i}")

                    contact_area_right = (x_init+l_mos+7*self.Lambda, y_init + (1+5*i)*self.Lambda,
                                          x_init+l_mos+7*self.Lambda+a_contact, y_init + (1+5*i)*self.Lambda + a_contact)
                    self.create_rec_with_mem(
                        *contact_area_right, outline='black', tags=f"CO_{self.j[self.foundry.get()]['CO'] + i + 1}")
                self.j[self.foundry.get()]['CO'] += amount_of_contact

    def findOUTWn(self):
        if self.foundry.get() == 'SkyWater130':
            mos_tag = 'nmos'
            mos_num = '0'
        elif self.foundry.get() == 'Microwind65':
            mos_tag = 'DN'
            mos_num = '5'
        for fig in self.canvas.find_all():
            figure = self.canvas.gettags(fig)[0]
            figure = re.split("_", figure.strip())
            if len(figure) != 2:
                if figure[-2] == mos_tag and figure[0] == 'OUT' and figure[-1] == mos_num:
                    fig_tag = self.canvas.itemcget(fig, "tags")
                    fig_coords = self.canvas.coords(fig_tag)
                    width = (fig_coords[2]-fig_coords[0]) / \
                        (self.scale**self.wheel_count)
        print(width, 'nm')
        return width

    def findWRinv(self):
        if self.foundry.get() == 'SkyWater130':
            mos_tag = 'nmos'
            mos_num = ['4', '8']
        elif self.foundry.get() == 'Microwind65':
            mos_tag = 'DN'
            mos_num = ['5', '6']
        for fig in self.canvas.find_all():
            figure = self.canvas.gettags(fig)[0]
            figure = re.split("_", figure.strip())
            if len(figure) != 2:
                if figure[-2] == mos_tag and figure[0] == 'WRITE' and (figure[-1] == mos_num[0] or figure[-1] == mos_num[1]):
                    fig_tag = self.canvas.itemcget(fig, "tags")
                    fig_coords = self.canvas.coords(fig_tag)
                    width = (fig_coords[2]-fig_coords[0]) / \
                        (self.scale**self.wheel_count)
        print(width, 'nm')
        return width

    def findPULSEY(self, PULSEYblock):
        if self.foundry.get() == 'SkyWater130':
            mos_tag = 'pmos'
        elif self.foundry.get() == 'Microwind65':
            mos_tag = 'DP'
        for fig in self.canvas.find_all():
            figure = self.canvas.gettags(fig)[0]
            figure = re.split("_", figure.strip())
            if len(figure) != 2:
                if figure[0] == 'PULSEY' and figure[1] == f'{PULSEYblock}' and figure[-2] == mos_tag and figure[-1] == '0':
                    fig_tag = self.canvas.itemcget(fig, "tags")
                    fig_coords = self.canvas.coords(fig_tag)
                    width = (fig_coords[2]-fig_coords[0]) / \
                        (self.scale**self.wheel_count)
        return width

    def findPULSEX(self, PULSEXblock):
        if self.foundry.get() == 'SkyWater130':
            mos_tag = 'pmos'
        elif self.foundry.get() == 'Microwind65':
            mos_tag = 'DP'
        for fig in self.canvas.find_all():
            figure = self.canvas.gettags(fig)[0]
            figure = re.split("_", figure.strip())
            if len(figure) != 2:
                if figure[0] == 'PULSEX' and figure[1] == f'{PULSEXblock}' and figure[2] == mos_tag and figure[3] == '0':
                    fig_tag = self.canvas.itemcget(fig, "tags")
                    fig_coords = self.canvas.coords(fig_tag)
                    width = (fig_coords[3]-fig_coords[1]) / \
                        (self.scale**self.wheel_count)
        print(width)
        return width

    def findPC(self, PCblock):
        if self.foundry.get() == 'SkyWater130':
            mos_tag = 'pmos'
        elif self.foundry.get() == 'Microwind65':
            mos_tag = 'DP'
        for fig in self.canvas.find_all():
            figure = self.canvas.gettags(fig)[0]
            figure = re.split("_", figure.strip())
            if len(figure) != 2:
                if figure[2] == mos_tag and figure[0] == 'PC' and figure[1] == f'{PCblock}' and figure[3] == '1':
                    fig_tag = self.canvas.itemcget(fig, "tags")
                    fig_coords = self.canvas.coords(fig_tag)
                    width = (fig_coords[3]-fig_coords[1]) / (self.scale**self.wheel_count)
        print(width, 'nm')
        return width

    def findPC_EQ(self, PCblock):
        if self.foundry.get() == 'SkyWater130':
            mos_tag = 'pmos'
            mos_num = '0'
        elif self.foundry.get() == 'Microwind65':
            mos_tag = 'DP'
            mos_num = '1'
        for fig in self.canvas.find_all():
            figure = self.canvas.gettags(fig)[0]
            figure = re.split("_", figure.strip())
            if len(figure) != 2:
                if figure[2] == mos_tag and figure[0] == 'PC' and figure[1] == f'{PCblock}' and figure[3] == mos_num:
                    fig_tag = self.canvas.itemcget(fig, "tags")
                    fig_coords = self.canvas.coords(fig_tag)
                    width = (fig_coords[3]-fig_coords[1]) / \
                        (self.scale**self.wheel_count)
        print(width, 'nm')
        return width
        # print(widths, 'nm')

    # двойным нажатием на колесико мыши получаем тэг объекта и его координаты
    def choose_object(self, event):
        self.GridUnits = self.GridLambda.get()
        # self.GridUnits = self.form.get_tech()
        if self.GridUnits == 0:
            messagebox.showerror("Error", "Choose foundry, please")
        else:
            self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
            item = self.canvas.find_withtag(tk.CURRENT)
            tag = self.canvas.gettags(item)[0]
            print(tag)
            figure = re.split("_", tag.strip())
            print(figure)
            coord = self.canvas.coords(item)
            value = None
            mode = "sample"
            if figure[0] == 'PC' and figure[2] == 'OP':
                value = self.PC_calculate(figure, mode)
            elif figure[0] == 'PULSEY' and figure[2] == 'OP':
                value = self.PULSEY_calculate(figure, mode)
            elif figure[0] == 'PULSEX' and figure[2] == 'OP':
                value = self.PULSEX_calculate(figure, mode)
            elif figure[0] == 'WRITE' and figure[2] == 'OP':
                value = self.WRITE_calculate(figure, mode)
            elif figure[0] == 'OUT' and figure[2] == 'OP':
                value = self.OUT_calculate(figure, mode, None)
            if value:
                # self.form.let_write_1([tag, [coord[0], coord[1], (coord[2] - coord[0]) // self.Lambda, (coord[3] - coord[1]) // self.Lambda], value])

                self.info_txt.delete('1.0', END)  # remove the previous content
                self.info_txt.insert(
                    tk.END, f'Type of area: {tag}\tCoords of (x0, y0): {coord[0], coord[1]}\tLength, Width (lambda):{(coord[2] - coord[0]) // self.Lambda, (coord[3] - coord[1]) // self.Lambda}\tBlock parameters: t = {value} ps')
            else:
                # self.form.let_write_2([tag, [coord[0], coord[1], (coord[2] - coord[0]) // self.Lambda, (coord[3] - coord[1]) // self.Lambda]])

                self.info_txt.delete('1.0', END)  # remove the previous content
                self.info_txt.insert(
                    tk.END, f'Type of area: {tag}\tCoords of (x0, y0): {coord[0], coord[1]}\tLength, Width (lambda):{(coord[2] - coord[0]) // self.Lambda, (coord[3] - coord[1]) // self.Lambda}')
        # print('history:', self.history, '\t', 'rectangles:', self.rectangles, '\n')
        # print("tag of object:", tag)
        # print("coords of object", coord)

    def load_spline_interpolation_data_simple(self, filename):
        spline_funcs = {}
        current_param_name = None
        current_x_values = []
        current_y_values = []

        try:
            with open(filename, 'r', encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line or line.startswith('#'):
                        continue

                    # Если строка не содержит запятой, считаем, что это имя коэффициента
                    if ',' not in line:
                        # Обрабатываем данные предыдущего блока, если они есть
                        if current_param_name and len(current_x_values) >= 2 and len(current_x_values) == len(current_y_values):
                            try:
                                spline_funcs[current_param_name] = CubicSpline(
                                    current_x_values, current_y_values)
                                # print(f"  Spline created for {current_param_name}")
                            except Exception as e:
                                print(
                                    f"  Ошибка при создании сплайна для '{current_param_name}': {e}. Пропуск.")
                        elif current_param_name:
                            print(
                                f"  Предупреждение: Недостаточно валидных точек ({len(current_x_values)}) или несовпадение X/Y для сплайна '{current_param_name}'. Пропуск.")

                        # Начинаем новый блок
                        current_param_name = line
                        current_x_values = []
                        current_y_values = []
                    else:
                        # Если строка содержит запятую, считаем, что это пара точка x,y
                        if current_param_name is None:
                            print(
                                f"Предупреждение: Точка найдена ({line}) до определения имени коэффициента. Пропуск.")
                            continue
                        try:
                            # Split only on the first comma
                            x_str, y_str = line.split(',', 1)
                            x_val = float(x_str.strip())
                            y_val = float(y_str.strip())
                            current_x_values.append(x_val)
                            current_y_values.append(y_val)
                        except ValueError as e:
                            print(
                                f"  Предупреждение: Неверный формат числа в строке '{line}' для коэффициента '{current_param_name}': {e}. Пропуск точки.")
                        except Exception as e:
                            print(
                                f"  Неожиданная ошибка парсинга точки в строке '{line}' для коэффициента '{current_param_name}': {e}. Пропуск точки.")

            # Обрабатываем последний блок после окончания файла
            if current_param_name and len(current_x_values) >= 2 and len(current_x_values) == len(current_y_values):
                try:
                    spline_funcs[current_param_name] = CubicSpline(
                        current_x_values, current_y_values)
                    # print(f"  Spline created for {current_param_name}")
                except Exception as e:
                    print(
                        f"  Ошибка при создании сплайна для '{current_param_name}': {e}. Пропуск.")
            elif current_param_name:
                print(
                    f"  Предупреждение: Недостаточно валидных точек ({len(current_x_values)}) или несовпадение X/Y для последнего сплайна '{current_param_name}'. Пропуск.")

        except FileNotFoundError:
            print(
                f"Ошибка загрузки сплайн-данных: Файл '{filename}' не найден.")
        except Exception as e:
            print(
                f"Неожиданная ошибка при загрузке сплайн-данных из '{filename}': {e}")

        print(
            f"Загружены сплайн-функции для коэффициентов: {list(spline_funcs.keys())}")
        return spline_funcs

    def OUT_calculate(self, obj, mode, loads):

        W_N = self.findOUTWn()  # in nm
        if mode == "sample":
            window = LoadRC(self.master)
            window.wm_attributes('-topmost', True)
            window.resizable(False, False)
            window.title('TopoPlot: params defining')
            window.iconbitmap(r'nano.ico')
            rc = window.open()
        elif mode == "block":
            rc = loads

        # --- Конец новой функции load_spline_interpolation_data_simple ---

        C_L = rc[0]  # in fF
        R_L = rc[1]  # in Ohm

        if C_L or R_L is not None:
            if self.foundry.get() == 'Microwind65':
                messagebox.showerror("Error", "undefinded model yet  ")

            elif self.foundry.get() == 'SkyWater130':
                # --- ЗАГРУЗКА СПЛАЙНОВ (СЮДА), ИСПОЛЬЗУЯ ПРОСТОЙ МЕТОД ---
                # Загружаем данные сплайнов, если они еще не загружены
                interpolation_data_file = "interpolation_spline_coeffs.txt"
                self.spline_coeffs_data = self.load_spline_interpolation_data_simple(
                    interpolation_data_file)

                # Проверяем, удалось ли загрузить данные для всех ожидаемых коэффициентов
                param_names = ['p00', 'p10', 'p01', 'p20', 'p11', 'p02']
                loaded_keys = set(self.spline_coeffs_data.keys())
                if not all(name in loaded_keys for name in param_names):
                    missing_keys = [
                        name for name in param_names if name not in loaded_keys]
                    self.spline_coeffs_data = {}  # Сбрасываем, если загрузка не полная
                    messagebox.showerror(
                        "Error", f"Failed to load all necessary interpolation data. Missing: {', '.join(missing_keys)}")
                    return None  # Возвращаем None, если загрузка не удалась

                # --- Определение функции t_out на основе загруженных сплайнов ---
                def calculate_tdout_from_Wn(W_N_microns, R_L_ohm, C_L_fF):
                    spline_coeffs = {
                        'p00': self.spline_coeffs_data['p00'](C_L_fF).item(),
                        'p10': self.spline_coeffs_data['p10'](C_L_fF).item(),
                        'p01': self.spline_coeffs_data['p01'](C_L_fF).item(),
                        'p20': self.spline_coeffs_data['p20'](C_L_fF).item(),
                        'p11': self.spline_coeffs_data['p11'](C_L_fF).item(),
                        'p02': self.spline_coeffs_data['p02'](C_L_fF).item()
                    }

                    calculated_time_sec = spline_coeffs['p00'] + spline_coeffs['p10'] / W_N_microns ** spline_coeffs['p20'] + spline_coeffs['p01'] * R_L_ohm ** spline_coeffs['p02'] + spline_coeffs['p11'] / W_N_microns * R_L_ohm
                    return calculated_time_sec

                t_dout = calculate_tdout_from_Wn(W_N*1e-3, R_L, C_L * 1e-15)*1e12

            print(f"W_N={W_N:.4g} nm\t t_dout={t_dout:.4g} ps\t C_L={C_L:.4g} fF\t R_L={R_L:.4g} Ohm")

            return t_dout

    def PC_calculate(self, obj, mode):

        W_P = self.findPC(obj[1])
        W_P_EQ = self.findPC_EQ(obj[1])
        s = W_P_EQ/W_P
        if mode == "sample":
            window = LoadRC(self.master)
            window.wm_attributes('-topmost', True)
            window.resizable(False, False)
            window.title('TopoPlot: params defining')
            window.iconbitmap(r'nano.ico')
            rc = window.open()
        elif mode == "block":
            rc = [0, 0, 1]
        sram_ops = {}
        C_L = None
        R_L = None
        if rc[-1] == 1:
            # ----- auto searching and calculationg loaded capacitance -----
            pc_ops = self.canvas.coords(f'{obj[0]}_{obj[1]}_{obj[2]}_{obj[3]}')
            for fig in self.canvas.find_all():
                figure_tag = self.canvas.itemcget(fig, "tags")
                figure = re.split("_", figure_tag.strip())
                if figure[2] == 'OP':
                    if figure[0] == 'SRAM':
                        sram_ops[figure_tag] = self.canvas.coords(figure_tag)

            if sram_ops:
                k = 0
                # print(sram_ops, '\n', pc_ops)
                for sram_fig in sram_ops.keys():
                    if pc_ops[0] >= sram_ops[sram_fig][0] and pc_ops[2] <= sram_ops[sram_fig][2]:
                        k += 1
                # print(k)
                if k == self.rows:
                    C_L = self.rows * self.CAPs['SRAM']['BL'] + self.CAPs['BTMPC']['BL']
                    R_L = self.rows * self.RESs['SRAM']['BL'] + self.RESs['BTMPC']['BL']
            else:
                messagebox.showerror("Error", "unfound SRAM blocks")
        else:
            C_L = rc[0]  # in fF
            R_L = rc[1]  # in Ohm

        if C_L or R_L is not None:
            if self.foundry.get() == 'Microwind65':
                psi = -0.523907542722564
                hi = -14.024147928286363
                teta = 2870.751343922466
                ksi = -13411.99531206253
                t_pc = psi * C_L + hi + (teta * C_L + ksi) / W_P

            elif self.foundry.get() == 'SkyWater130':
                approx_coeffs = {
                    'p00': {
                        'a': -2.7831218672705364e-11,
                        'b': 2.830723592706642e-10,
                        'c': -1.0598363731957857e-09,
                        'd': 1.653671173982053e-09,
                        'e': 7.810938236315294e-10
                    },
                    'p10': {
                        'a': -1.859669414420993e-14,
                        'b': 1.6310095708766159e-13,
                        'c': -3.4513111803815646e-13,
                        'd': -6.818949830243888e-13,
                        'e': -5.365486475283143e-13
                    },
                    'p01': {
                        'a': -5806.833265182063,
                        'b': 64505.84839166264,
                        'c': -252827.359901273,
                        'd': 374094.2124197386,
                        'e': -87658.93516957371
                    },
                    'p20': {
                        'a': -0.001992670912447105,
                        'b': 0.021889249301619784,
                        'c': -0.08864218220534521,
                        'd': 0.17314122155133527,
                        'e': 0.35419158236450005
                    },
                    'p11': {
                        'a': 0.005089582546052044,
                        'b': -0.04986886008071882,
                        'c': 0.17535115752896696,
                        'd': -0.2062507620718014,
                        'e': 1.5669598259967379
                    },
                    'p02': {
                        'a': -0.0018860537083543543,
                        'b': 0.022516922317391243,
                        'c': -0.10591802516680568,
                        'd': 0.20680443684308691,
                        'e': 0.9493162647663554
                    }
                }
                # Извлечение списков коэффициентов
                coefficients = {key: [value for value in coeffs.values()] for key, coeffs in approx_coeffs.items()}

                def t_pc(W_P, R_L, C_L):
                    p00 = polyval(coefficients['p00'], W_P)
                    p10 = polyval(coefficients['p10'], W_P)
                    p01 = polyval(coefficients['p01'], W_P)
                    p20 = polyval(coefficients['p20'], W_P)
                    p11 = polyval(coefficients['p11'], W_P)
                    p02 = polyval(coefficients['p02'], W_P)

                    return p00 + p10 * R_L ** p20 + p01 * C_L ** p02 + p11 * R_L * C_L

                tpc = t_pc(W_P*1e-3, R_L, C_L*1e-15) * 1e12  # convert sec -> picosec

            print(W_P, '\t', tpc, '\t', C_L)
            return tpc

    def PULSEY_calculate(self, obj, mode):
        W_N = self.findPULSEY(obj[1]) / 4

        if mode == "sample":
            window = LoadRC(self.master)
            window.wm_attributes('-topmost', True)
            window.resizable(False, False)
            window.title('TopoPlot: RC params defining')
            window.iconbitmap(r'nano.ico')
            rc = window.open()
        elif mode == "block":
            rc = [0, 0, 1]
        sram_ops = {}
        C_L = None
        R_L = None
        if rc[-1] == 1:
            # ----- auto searching and calculationg loaded capacitance -----
            pulsey_ops = self.canvas.coords(
                f'{obj[0]}_{obj[1]}_{obj[2]}_{obj[3]}')
            for fig in self.canvas.find_all():
                figure_tag = self.canvas.itemcget(fig, "tags")
                figure = re.split("_", figure_tag.strip())
                if figure[2] == 'OP':
                    if figure[0] == 'SRAM':
                        sram_ops[figure_tag] = self.canvas.coords(figure_tag)
            if sram_ops:
                k = 0
                for sram_fig in sram_ops.keys():
                    if pulsey_ops[1] <= sram_ops[sram_fig][1] and pulsey_ops[3] >= sram_ops[sram_fig][3]:
                        k += 1
                k /= 2
                if k == self.columns:
                    C_L = k * self.CAPs['SRAM']['WL']
                    R_L = k * self.RESs['SRAM']['WL']
            else:
                messagebox.showerror("Error", "unfound SRAM blocks")
        else:
            C_L = rc[0]  # in fF
            R_L = rc[1]  # in Ohm

        if C_L or R_L is not None:
            if self.foundry.get() == 'Microwind65':
                eps = 31.586890862289795
                gamma = 2.439060312177068
                psi = 468.4958662237838
                hi = 275.5145468405586
                ksi = -0.07379516441290791
                tetta = -1.0091467946225567
                t_wl = (eps + gamma * (psi * C_L + hi)
                        * W_N ** (tetta + ksi / C_L))

            elif self.foundry.get() == 'SkyWater130':
                approx_coeffs = {
                    'p00': {'a': 6.405850769305928e-11, 'b': 0.6011232697841825, 'c': 6.198013650820446e-11},
                    'p10': {'a': 2.0192613832182125e-13, 'b': 0.7793608865087375, 'c': -1.7502205627912913e-13},
                    'p01': {'a': 6396.111800718637, 'b': 0.12050598828545535, 'c': 2624.5068106702, 'd': -0.9970333859034737},
                    'p20': {'a': 7.59787580934806e-17, 'b': 1.0302452639569297, 'c': 3.4058821358456948, 'd': -0.25361053220508106},
                    'p11': {'a': 0.2595041672037046, 'b': 0.6453333146676379, 'c': 1.179441681452691},
                    'p02': {'a': 0.0, 'b': 0.0}
                }

                def t_calc(W_N, R_L, C_L):
                    p00 = approx_coeffs['p00']['a'] * \
                        W_N ** approx_coeffs['p00']['b'] + \
                        approx_coeffs['p00']['c']
                    p10 = approx_coeffs['p10']['a'] * \
                        exp(-approx_coeffs['p10']['b'] *
                            W_N) + approx_coeffs['p10']['c']
                    p01 = approx_coeffs['p01']['a'] * W_N ** approx_coeffs['p01']['d'] + \
                        approx_coeffs['p01']['b'] / W_N * \
                        approx_coeffs['p01']['c'] ** arctan(W_N)
                    p20 = approx_coeffs['p20']['a'] * W_N ** approx_coeffs['p20']['b'] * arctan(
                        approx_coeffs['p20']['c'] / W_N + approx_coeffs['p20']['d'])
                    p11 = approx_coeffs['p11']['a'] * \
                        W_N ** approx_coeffs['p11']['b'] + \
                        approx_coeffs['p11']['c']
                    p02 = approx_coeffs['p02']['a'] * \
                        W_N + approx_coeffs['p02']['b']
                    return p00 + p10 * R_L + p01 * C_L + p20 * R_L ** 2 + p11 * R_L * C_L + p02 * C_L ** 2

                t_wl = t_calc(W_N*1e-3, R_L, C_L*1e-15) * \
                    1e12  # convert sec -> picosec

            print(W_N, '\t', t_wl, '\t', C_L)

            return t_wl

    def PULSEX_calculate(self, obj, mode):
        W_N = self.findPULSEX(obj[1]) / 3
        if mode == "sample":
            window = LoadRC(self.master)
            window.wm_attributes('-topmost', True)
            window.resizable(False, False)
            window.title('TopoPlot: RC params defining')
            window.iconbitmap(r'nano.ico')
            rc = window.open()
        elif mode == "block":
            rc = [0, 0, 1]
        buffer_ops = {}
        C_L = None
        R_L = None
        if rc[-1] == 1:
            # ----- auto searching and calculationg loaded capacitance -----
            for fig in self.canvas.find_all():
                figure_tag = self.canvas.itemcget(fig, "tags")
                figure = re.split("_", figure_tag.strip())
                if figure[2] == 'OP':
                    if figure[0] == 'BUFFER':
                        buffer_ops[figure_tag] = self.canvas.coords(figure_tag)
            if buffer_ops:
                C_L = self.CAPs['BUFFER']['EN'] + \
                    self.CAPs['XCON'][f'{self.columns}']
                R_L = self.RESs['BUFFER']['EN'] + \
                    self.RESs['XCON'][f'{self.columns}']
            else:
                messagebox.showerror("Error", "unfound BUFFER blocks")
        else:
            C_L = rc[0]  # in fF
            R_L = rc[1]  # in Ohm

        if C_L or R_L is not None:
            if self.foundry.get() == 'Microwind65':
                eps = 31.586890862289795
                gamma = 2.439060312177068
                psi = 468.4958662237838
                hi = 275.5145468405586
                ksi = -0.07379516441290791
                tetta = -1.0091467946225567
                t_gate = (eps + gamma * (psi * C_L + hi)
                          * W_N ** (tetta + ksi / C_L))

            elif self.foundry.get() == 'SkyWater130':
                approx_coeffs = {
                    'p00': {'a': 6.137803487049536e-11, 'b': 0.6170809768144824, 'c': 6.559627535904883e-11},
                    'p10': {'a': 1.969996242228071e-13, 'b': 0.7750561269851095, 'c': -1.7510880145869427e-13},
                    'p01': {'a': 6248.060568392826, 'b': 0.11472125918006874, 'c': 2684.1610291561024, 'd': -0.9728239498980423},
                    'p20': {'a': 7.652214761349008e-17, 'b': 0.9850886548186326, 'c': 3.6114447960354688, 'd': -0.26294672366446226},
                    'p11': {'a': 0.25288909649681945, 'b': 0.6541260324965531, 'c': 1.190510007971873},
                    'p02': {'a': 2.1986885748796432e-16, 'b': 0.9999999999999997}
                }

                def t_calc(W_N, R_L, C_L):
                    p00 = approx_coeffs['p00']['a'] * \
                        W_N ** approx_coeffs['p00']['b'] + \
                        approx_coeffs['p00']['c']
                    p10 = approx_coeffs['p10']['a'] * \
                        exp(-approx_coeffs['p10']['b'] *
                            W_N) + approx_coeffs['p10']['c']
                    p01 = approx_coeffs['p01']['a'] * W_N ** approx_coeffs['p01']['d'] + \
                        approx_coeffs['p01']['b'] / W_N * \
                        approx_coeffs['p01']['c'] ** arctan(W_N)
                    p20 = approx_coeffs['p20']['a'] * W_N ** approx_coeffs['p20']['b'] * arctan(
                        approx_coeffs['p20']['c'] / W_N + approx_coeffs['p20']['d'])
                    p11 = approx_coeffs['p11']['a'] * \
                        W_N ** approx_coeffs['p11']['b'] + \
                        approx_coeffs['p11']['c']
                    p02 = approx_coeffs['p02']['a'] * \
                        W_N + approx_coeffs['p02']['b']
                    return p00 + p10 * R_L + p01 * C_L + p20 * R_L ** 2 + p11 * R_L * C_L + p02 * C_L ** 2

                t_gate = t_calc(W_N*1e-3, R_L, C_L*1e-15) * \
                    1e12  # convert sec -> picosec

            print(W_N, '\t', t_gate, '\t', C_L)

            return t_gate

    def info(self):
        messagebox.showinfo(
            "Information", "SCALING WINDOW: wheel range\nMOVE ALL ELEMENTS: wheel button press and move\nMOVE EACH ELEMENT: right button press and move\nGridUnit in [nm/lambda] for MagicVLSI \nGridUnit in [nm] for Microwind")
        '''
        print("amount:", len(self.canvas.find_all()))
        print("list_of_objects: ", list_of_objects)
        print("objects:", self.canvas.find_all())
        print("coords_of_objects: ", coords_of_objects)
        print("shifted_rect: ", shifted_rect)
        print("list_object_colors: ", list_object_colors)
        print("amount_of_line:", self.amount_of_line)
        print("sechenie_coords:", sechenie_coords)
        print("new_rect:", new_rect)
        '''

    def MultSyn(self, event):
        self.GridUnits = self.GridLambda.get()
        # self.GridUnits = self.form.get_tech()
        if self.GridUnits == 0:
            messagebox.showerror("Error", "Choose foundry, please")
        else:
            self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
            if self.mult_access == 0 and (self.insertAccess == 1 or self.multiplyAccess == 1 and self.synthesisAcces == 1):
                pass
            elif self.mult_access == 1:
                self.multiplyAccess = 0
                self.insertAccess = 0
                self.synthesisAcces = 0
                self.y_decoder_access = 0
                self.mult_access == 0
                x0 = self.canvas.canvasx(event.x)
                y0 = self.canvas.canvasy(event.y)
                bit_depth = self.MULT_bit_depth
                # print(x0, y0, self.MULT_bit_depth)
                '''pattern creating'''
                bus_PB = array(['PB'] * bit_depth)[:, newaxis]
                pattern_AC = array([[None] * bit_depth] * bit_depth)
                pattern_FAC = array([[None] * bit_depth] * bit_depth)
                pattern_BC = array([None] * bit_depth)[:, newaxis]
                pattern_FBC = array([None] * bit_depth)[:, newaxis]
                pattern_AND = array([None] * bit_depth)[:, newaxis]
                pattern_ANDT = array([None] * bit_depth)[:, newaxis]
                pattern_ADD = array([[None] * (bit_depth - 1)] * bit_depth)
                for i in range(bit_depth):
                    pattern_BC[i][0] = 'BC'
                    pattern_FBC[i][0] = 'FBC'
                    pattern_AND[i][0] = 'PAND'
                    pattern_ANDT[i][0] = 'PANDT'
                    # pattern_AND[i][0] = 'AND'
                    # pattern_ANDT[i][0] = 'ANDT'
                    for j in range(bit_depth):
                        if i == (bit_depth - 1) - j:
                            pattern_AC[i][j] = 'AC'
                            pattern_FAC[i][j] = 'FAC'
                        elif i < (bit_depth - 1) - j:
                            pattern_AC[i][j] = 'HCU'
                            pattern_FAC[i][j] = 'FHCU'
                        elif i > (bit_depth - 1) - j:
                            pattern_AC[i][j] = 'HCD'
                            pattern_FAC[i][j] = 'FHCD'
                        if j < bit_depth - 1:
                            if i == 0:
                                pattern_ADD[i][j] = 'HA'
                            elif i < bit_depth - 1:
                                pattern_ADD[i][j] = 'FA'
                            else:
                                if j == 0:
                                    pattern_ADD[i][j] = 'LHA'
                                else:
                                    pattern_ADD[i][j] = 'LFA'
                for i in range(bit_depth):
                    if i == 0:
                        full_pattern = hstack(
                            (bus_PB, pattern_FBC, pattern_FAC, pattern_AND))
                    else:
                        full_pattern = hstack(
                            (full_pattern, pattern_BC, pattern_AC, pattern_ANDT, pattern_ADD[:, i - 1][:, newaxis]))
                # table = tabulate(full_pattern, tablefmt="pretty")
                # print(table)

                bus_IN = array(['INB'] * bit_depth)[:,  newaxis]
                bus_FBC = array(['FCT'] * bit_depth)[:,  newaxis]
                bus_FBC[0][0] = 'FBL'
                bus_AND = array(['UTS'] * bit_depth)[:,  newaxis]
                bus_AND[0][0] = 'UT'
                bus_BC = array([[None] * (bit_depth - 1)] * bit_depth)
                bus_ANDT = array([[None] * (bit_depth - 1)] * bit_depth)
                bus_ADD = array([[None] * (bit_depth - 1)] * bit_depth)
                bus_OUT = array(
                    [[None] * (bit_depth ** 2 + 2 * bit_depth - 2)] * (bit_depth - 1))
                bus_AC = array([[[None] * bit_depth] * bit_depth] * bit_depth)
                for i in range(bit_depth):
                    for j in range(bit_depth - 1):
                        if i - j == 1:
                            bus_BC[i][j] = 'BCL'
                        elif i - j <= 0:
                            bus_BC[i][j] = 'BCCB'
                        elif i - j > 1:
                            bus_BC[i][j] = 'BCT'
                        if i - j >= 2 and j < bit_depth - 2:
                            bus_ANDT[i][j] = 'TUTS'
                            bus_ADD[i][j] = 'AUTS'
                        elif i - j < 2 and j < bit_depth - 2:
                            bus_ANDT[i][j] = 'TUT'
                            bus_ADD[i][j] = 'AUT'
                        else:
                            bus_ANDT[i][j] = 'TUTE'
                            if i == 0:
                                bus_ADD[i][j] = 'LAUTE'
                            else:
                                bus_ADD[i][j] = 'AUTE'

                    for j in range(bit_depth):
                        for k in range(bit_depth):
                            if i == j and i <= k:
                                bus_AC[k][i][j] = 'ACT'
                            elif i == j and i > k:
                                bus_AC[k][i][j] = 'HCHC'
                            elif i - j < 0 and i <= k:
                                bus_AC[k][i][j] = 'HCDC'
                            elif i - j < 0 and i > k:
                                bus_AC[k][i][j] = 'HCB'
                            elif i - j > 0 and i <= k:
                                bus_AC[k][i][j] = 'ET'
                            elif i - j > 0 and i > k:
                                bus_AC[k][i][j] = 'FCT'
                bus_FULL = hstack(
                    (bus_IN, bus_FBC, bus_AC[0], bus_AND[:, 0][:,  newaxis]))
                for i in range(bit_depth - 1):
                    bus_FULL = hstack(
                        (bus_FULL, bus_BC[:, i][:, newaxis], bus_AC[i+1], bus_ANDT[:, i][:, newaxis], bus_ADD[:, i][:, newaxis]))

                X_length = bit_depth ** 2 + 2 * bit_depth - 2

                pattern_ACE = array([['ACUOE'] * bit_depth] * (bit_depth - 1))
                for i in range(bit_depth - 1):
                    for j in range(X_length):
                        if j % (bit_depth + 3) == 0:
                            bus_OUT[i][j] = 'ADDUOT'
                            if j != 0 and i < j / (bit_depth + 3):
                                bus_OUT[i][j - 1] = 'ANDTUOT'
                                for k in range(bit_depth):
                                    bus_OUT[i][j - 1 - k - 1] = 'ACUOT'
                                if j < X_length - 1:
                                    bus_OUT[i][j + 1] = 'BCUOT'
                            if i < j / (bit_depth + 3):
                                bus_OUT[i][j] = 'ADDUOE'
                            if i == j / (bit_depth + 3):
                                bus_OUT[i][j] = 'ADDUOL'
                                for k in range(bit_depth + 2):
                                    if k == 0:
                                        item = 'ANDTUOE'
                                    elif k == bit_depth + 1:
                                        item = 'BCUOE'
                                    else:
                                        item = 'ACUOE'
                                    bus_OUT[i][j - k - 1] = item
                                bus_OUT[i][j + 1] = 'BCUOT'
                        if j == 0 and i != 0:
                            bus_OUT[i][j] = 'ANDUOT'
                        elif j == 0 and i == 0:
                            bus_OUT[i][j] = 'ANDUOL'
                for i in range(bit_depth - 2):
                    for j in range(X_length):
                        if bus_OUT[i][j] == 'BCUOE':
                            bus_OUT[i+1][j] = 'BCUOE'
                        if bus_OUT[i][j] == 'ACUOE':
                            bus_OUT[i+1][j] = 'ACUOE'
                        if bus_OUT[i][j] == 'ANDTUOE':
                            bus_OUT[i+1][j] = 'ANDTUOE'
                FULL_OUT = hstack((array(['PBUO'] * (bit_depth - 1))[:,  newaxis], array(
                    ['ACUOE'] * (bit_depth - 1))[:,  newaxis], pattern_ACE, bus_OUT))
                MB_OUT = hstack((transpose(array(['MBNADD'] * (bit_depth - 1))), transpose(array(
                    ['MBADD'] * bit_depth)), ['MBLADD'], array(['MBADDE'] * (bit_depth - 1))))[:, newaxis]
                FULL_scheme = transpose(
                    hstack((transpose(FULL_OUT), transpose(full_pattern), transpose(bus_FULL))))
                FULL_scheme = hstack((FULL_scheme, MB_OUT))
                # print(FULL_scheme )
                '''-------------------'''
                columns_amount = bit_depth ** 2 + 3 * bit_depth - 1
                delta_y_list = array(
                    [[None] * (columns_amount + 2)] * (3 * bit_depth - 1))
                delta_x_list = array(
                    [[None] * (columns_amount + 2)] * (3 * bit_depth - 1))
                for i in range(3 * bit_depth - 1):
                    for j in range(columns_amount + 2):
                        item = FULL_scheme[i][j]
                        if item is not None:
                            item_coords = self.MULT_objects_coords[item]['OP']
                            delta_y_list[i][j] = item_coords[0][3]
                            delta_x_list[i][j] = item_coords[0][2]
                        # print(f'{item}:', item_coords)
                y = y0
                for amount_y in range(3 * bit_depth - 1):
                    if amount_y != 0:
                        y = y + (delta_y_list[amount_y - 1][0]) * self.Lambda
                    x = x0
                    for amount_x in range(columns_amount + 2):
                        # print(f'({amount_y}, {amount_x}):{delta_y_list[amount_y][amount_x]}')
                        # print(f'current y:{y}')
                        if amount_x != 0:
                            x = x + \
                                delta_x_list[amount_y][amount_x -
                                                       1] * self.Lambda
                        item = FULL_scheme[amount_y][amount_x]
                        if item is not None:
                            # print(f'({amount_y}, {amount_x}):{block}')
                            self.device_coords = self.MULT_objects_coords[item]
                            self.insert_item = item
                            try:
                                self.num_of_blocks[self.insert_item] += 1
                            except:
                                self.num_of_blocks[self.insert_item] = 0

                            for j in range(len(top_area)):
                                rec = self.device_coords.get(top_area[j])
                                color = colors[j]
                                bordertype = borders[j]
                                filling = fills[j]
                                if type(rec) is list:
                                    for i in range(len(rec)):
                                        if j != (len(top_area)-1):
                                            koeff = 1
                                        else:
                                            koeff = -1

                                        x1 = x+rec[i][0]*self.Lambda
                                        x2 = x+(rec[i][0]+rec[i]
                                                [2])*self.Lambda
                                        y1 = y+rec[i][1]*self.Lambda
                                        y2 = y+(rec[i][1]-koeff *
                                                rec[i][3])*self.Lambda

                                        rec_coord = (x1, y1, x2, y2)

                                        self.create_rec_with_mem(*rec_coord, outline=color, fill=filling, dash=bordertype, tags= f'{self.insert_item}_{self.num_of_blocks[self.insert_item]}_{top_area[j]}_{i}')

    def Y_DC_Syn(self, event):
        self.GridUnits = self.GridLambda.get()
        # self.GridUnits = self.form.get_tech()
        if self.GridUnits == 0:
            messagebox.showerror("Error", "Choose foundry, please")
        else:
            self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
            if self.y_decoder_access == 0 and (self.insertAccess == 1 or self.multiplyAccess == 1 and self.synthesisAcces == 1):
                pass
            elif self.y_decoder_access == 1:
                self.multiplyAccess = 0
                self.insertAccess = 0
                self.synthesisAcces = 0
                self.y_decoder_access = 0
                x0 = self.canvas.canvasx(event.x)
                y0 = self.canvas.canvasy(event.y)
                coulumns_amount = 0
                for i in range(0, (self.YDC_inputs - 2), 1):
                    coulumns_amount = coulumns_amount + 2**i + 1

                decoder_matrix = [0]*coulumns_amount
                delta_y_matrix = [0]*coulumns_amount
                delta_x_matrix = [0]*coulumns_amount
                counter = 0
                self.stage_count = 0

                top_area_length = len(top_area['Microwind65'])

                # минус 2 поскольку нулевой stage это и есть базовый DC
                for stage in range(coulumns_amount, 0, -1):
                    if stage == coulumns_amount:
                        self.stage_count = (self.YDC_inputs - 2) - 1
                    stage_list = ['None']*(self.YDC_outputs//4+1)
                    delta_y_list = ['None']*(self.YDC_outputs//4+1)
                    delta_x_list = ['None']*(self.YDC_outputs//4+1)
                    amount_of_objects = (
                        2**(self.stage_count+1))//2  # (2**stage)//2
                    if counter == 0:
                        # base_nor
                        if self.YDC_inputs % 2 == 0 and (stage) % 2 == 0:
                            inv_block = 'Yforward_inv'
                            first_block = 'YNnands'
                            inverse_for_first = 'Ynands'
                        # base_nand
                        elif self.YDC_inputs % 2 != 0 and (stage) % 2 == 0:
                            inv_block = 'Ybackward_inv'
                            first_block = 'Ynors'
                            inverse_for_first = 'YNnors'
                        # base_nor
                        elif self.YDC_inputs % 2 == 0 and (stage) % 2 != 0:
                            inv_block = 'Ybackward_inv'
                            first_block = 'Ynors'
                            inverse_for_first = 'YNnors'
                        # base_nand
                        elif self.YDC_inputs % 2 != 0 and (stage) % 2 != 0:
                            inv_block = 'Yforward_inv'
                            first_block = 'YNnands'
                            inverse_for_first = 'Ynands'
                        stage_list[0] = inv_block
                        item_coords = self.YDC_objects_coords[inv_block]
                    else:
                        empty_block = 'Yempty'
                        stage_list[0] = empty_block
                        item_coords = self.YDC_objects_coords[empty_block]
                    # print('item_coords:', item_coords)
                    item_coords = item_coords.get(
                        top_area['Microwind65'][top_area_length-1])

                    delta_y_list[0] = item_coords[0][3]
                    delta_x_list[0] = item_coords[0][2]
                    for h in range(2*amount_of_objects):
                        if h < amount_of_objects:
                            if counter == 0:
                                stage_list[h+1] = first_block
                                item_coords = self.YDC_objects_coords[first_block]
                                item_coords = item_coords.get(
                                    top_area['Microwind65'][top_area_length-1])
                                delta_y_list[h+1] = item_coords[0][3]
                                delta_x_list[h+1] = item_coords[0][2]
                            else:
                                if counter == (h + 1):
                                    YT_block = 'YT'
                                    stage_list[h+1] = YT_block
                                    item_coords = self.YDC_objects_coords[YT_block]
                                    item_coords = item_coords.get(
                                        top_area['Microwind65'][top_area_length-1])
                                    delta_y_list[h+1] = item_coords[0][3]
                                    delta_x_list[h+1] = item_coords[0][2]
                                elif counter > (h + 1):
                                    YC_block = 'YC'
                                    stage_list[h+1] = YC_block
                                    item_coords = self.YDC_objects_coords[YC_block]
                                    item_coords = item_coords.get(
                                        top_area['Microwind65'][top_area_length-1])
                                    delta_y_list[h+1] = item_coords[0][3]
                                    delta_x_list[h+1] = item_coords[0][2]
                                elif counter < (h + 1):
                                    YH_block = 'YH'
                                    stage_list[h+1] = YH_block
                                    item_coords = self.YDC_objects_coords[YH_block]
                                    item_coords = item_coords.get(
                                        top_area['Microwind65'][top_area_length-1])
                                    delta_y_list[h+1] = item_coords[0][3]
                                    delta_x_list[h+1] = item_coords[0][2]
                        else:
                            if counter == 0:
                                stage_list[h+1] = inverse_for_first
                                item_coords = self.YDC_objects_coords[inverse_for_first]
                                item_coords = item_coords.get(
                                    top_area['Microwind65'][top_area_length-1])
                                delta_y_list[h+1] = item_coords[0][3]
                                delta_x_list[h+1] = item_coords[0][2]
                            else:
                                if counter == (h + 1) - amount_of_objects:
                                    YL_block = 'YL'
                                    stage_list[h+1] = YL_block
                                    item_coords = self.YDC_objects_coords[YL_block]
                                    item_coords = item_coords.get(
                                        top_area['Microwind65'][top_area_length-1])
                                    delta_y_list[h+1] = item_coords[0][3]
                                    delta_x_list[h+1] = item_coords[0][2]
                                elif counter > (h + 1) - amount_of_objects:
                                    YII_block = 'YII'
                                    stage_list[h+1] = YII_block
                                    item_coords = self.YDC_objects_coords[YII_block]
                                    item_coords = item_coords.get(
                                        top_area['Microwind65'][top_area_length-1])
                                    delta_y_list[h+1] = item_coords[0][3]
                                    delta_x_list[h+1] = item_coords[0][2]
                                elif counter < (h + 1) - amount_of_objects:
                                    YC_block = 'YC'
                                    stage_list[h+1] = YC_block
                                    item_coords = self.YDC_objects_coords[YC_block]
                                    item_coords = item_coords.get(
                                        top_area['Microwind65'][top_area_length-1])
                                    delta_y_list[h+1] = item_coords[0][3]
                                    delta_x_list[h+1] = item_coords[0][2]

                    decoder_matrix[stage-1] = stage_list
                    delta_y_matrix[stage-1] = delta_y_list
                    delta_x_matrix[stage-1] = delta_x_list
                    if counter < (2 ** self.stage_count):
                        counter += 1
                    else:
                        self.stage_count -= 1
                        counter = 0
                # print(decoder_matrix)#, '\n', delta_y_matrix, '\n', delta_x_matrix)
                y = y0
                self.other_delta_y = 0
                for amount_y in range(self.YDC_outputs//4+1):
                    if amount_y != 0:
                        # y + delta_y_matrix[self.YDC_inputs-3][amount_y] * self.Lambda
                        y = self.other_delta_y
                    x = x0
                    for amount_x in range(coulumns_amount - 1, -2, -1):
                        if amount_x == -1 and amount_y == 0:
                            if self.YDC_inputs % 2 == 0:
                                item = 'Ynor_base'
                            else:
                                item = 'Ynand_base'
                            self.device_coords = self.YDC_objects_coords[item]
                            self.insert_item = item
                            item_coords = self.YDC_objects_coords[item]['OP']
                            # item_coords = item_coords.get(top_area[len(top_area)-1])
                            x = x - item_coords[0][2] * self.Lambda
                            y = y0
                        elif amount_x >= 0:
                            item = decoder_matrix[amount_x][amount_y]
                            if item != 'None':
                                self.device_coords = self.YDC_objects_coords[item]
                                self.insert_item = item
                            try:
                                if amount_x != coulumns_amount-1:
                                    x = x - \
                                        delta_x_matrix[amount_x][amount_y] * \
                                        self.Lambda
                            except:
                                pass
                            if decoder_matrix[amount_x][amount_y] != decoder_matrix[amount_x-1][amount_y]:
                                # y = y + (delta_y_matrix[amount_x-1][amount_y] - delta_y_matrix[amount_x][amount_y]) * self.Lambda

                                if (item == 'Ynands' or item == 'Ynors'):
                                    y = y + \
                                        (delta_y_matrix[coulumns_amount-1][amount_y] -
                                         delta_y_matrix[amount_x][amount_y]) * self.Lambda
                                elif (item == 'YNnands' or item == 'YNnors'):
                                    y = y + \
                                        (delta_y_matrix[coulumns_amount-1][amount_y] -
                                         delta_y_matrix[amount_x][amount_y]) * self.Lambda

                            if item != decoder_matrix[amount_x-1][amount_y]:
                                self.other_delta_y = y + (self.device_coords.get(top_area['Microwind65'][top_area_length - 1])[
                                                          0][1]+self.device_coords.get(top_area['Microwind65'][top_area_length - 1])[0][3])*self.Lambda
                            # print(decoder_matrix[amount_x][amount_y])
                        if (amount_y == 0 and amount_x == -1) or amount_x >= 0:
                            try:
                                self.num_of_blocks[self.insert_item] += 1
                            except:
                                self.num_of_blocks[self.insert_item] = 0

                            for j in range(top_area_length):
                                rec = self.device_coords.get(
                                    top_area['Microwind65'][j])
                                color = colors['Microwind65'][j]
                                bordertype = borders['Microwind65'][j]
                                filling = fills['Microwind65'][j]
                                if type(rec) is list:
                                    for i in range(len(rec)):
                                        rec_coord = (x + rec[i][0] * self.Lambda, y + rec[i][1] * self.Lambda, x + (
                                            rec[i][0] + rec[i][2]) * self.Lambda, y + (rec[i][1] + rec[i][3]) * self.Lambda)
                                        self.create_rec_with_mem(*rec_coord, outline=color, fill=filling, dash=bordertype, tags=f'{self.insert_item}_{self.num_of_blocks[self.insert_item]}_{top_area["Microwind65"][j]}_{i}')
                                        # self.canvas.update()

    def X_Connect_MW(self, event):
        self.GridUnits = self.GridLambda.get()
        # self.GridUnits = self.form.get_tech()
        if self.GridUnits == 0:
            messagebox.showerror("Error", "Choose foundry, please")
        else:
            self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
            if self.x_connect_access == 0 and (self.insertAccess == 1 or self.multiplyAccess == 1 and self.synthesisAcces == 1):
                pass
            elif self.x_connect_access == 1 and self.XDC_outputs > 2:
                self.multiplyAccess = 0
                self.insertAccess = 0
                self.synthesisAcces = 0
                self.x_connect_access = 0
                x0 = self.canvas.canvasx(event.x)
                y0 = self.canvas.canvasy(event.y)

                '''pattern matrixes creating'''
                M = self.XDC_outputs
                MeB = zeros((M, M))
                M2B = zeros((M, M))
                V2P = zeros((M, M))
                for i in range(M):
                    for j in range(M):
                        if j >= i:
                            MeB[i][j] = 1
                        if j <= i:
                            M2B[i][j] = 1
                c = 0
                for i in range(M // 2):
                    for j in range(M // 2):
                        if i == j:
                            '''
                            V2P[i+c][j] = 1
                            if j > 0:
                                V2P[i+c-1][j] = 1
                                c += 1
                            else:
                                V2P[i+c+1][j] = 1
                            '''
                            V2P[i+c][j] = 1
                            V2P[i+c+1][j] = 1
                            c += 1

                print(MeB, '\n\n', M2B, '\n\n', V2P)

                '''get data about widths of Buffer and pulsex blocks'''
                filepath = self.filefolder+'\examples\BUFFER_block.txt'
                filename = os.path.basename(filepath)[:-4]
                buffer_coords = ReadTXT_MW(
                    path=filepath, name=filename).getCoords()
                buffer_width = buffer_coords['OP'][0][-2]*self.Lambda

                filepath = self.filefolder+'\examples\_PULSEX_block.txt'
                filename = os.path.basename(filepath)[:-4]
                pulsex_coords = ReadTXT_MW(
                    path=filepath, name=filename).getCoords()
                pulsex_width = pulsex_coords['OP'][0][-2]*self.Lambda

                self.device_coords = pulsex_coords
                self.insert_item = re.split("_", filename.strip())
                self.insert_item = self.insert_item[1]

                no_update = False
                for fig in self.canvas.find_all():
                    figure = self.canvas.gettags(fig)[0]
                    figure = re.split("_", figure.strip())
                    figure = figure[0]
                    if figure == self.insert_item:
                        no_update = True

                '''get data about scales of vdd_pulsex block'''
                filepath = self.filefolder+'\examples\_vddpulsex_block.txt'
                filename = os.path.basename(filepath)[:-4]
                vddpulsex_coords = ReadTXT_MW(
                    path=filepath, name=filename).getCoords()
                vddpulsex_width = vddpulsex_coords['OP'][0][-2]*self.Lambda

                '''------------'''
                M2_size = 4 * self.Lambda
                left_off_MeB = 9 * self.Lambda
                border_off_M3P = 7 * self.Lambda
                '''drawing patterns'''
                full_OP_coords = (
                    x0, y0, x0 + M * buffer_width, y0 + 2 * M * M2_size)
                self.create_rec_with_mem(
                    *full_OP_coords, outline='orange', tags=f"XCONNECT_OP_Connect")

                for i in range(M):
                    for j in range(M):
                        OP_coords_pulsex = (vddpulsex_width + x0 + j * pulsex_width, y0 + i * 2 * M2_size,
                                            vddpulsex_width + x0 + (j + 1) * pulsex_width, y0 + (i + 1) * 2 * M2_size)
                        if V2P[i][j] == 1:
                            self.create_rec_with_mem(
                                *OP_coords_pulsex, fill='', outline='black', tags=f"OP_PulseX_{i}_{j}")
                            if i % 2 == 0:
                                k = 0
                            else:
                                k = 1
                            V3_coords = (OP_coords_pulsex[2*k] + ((-1) ** k) * border_off_M3P - k * M2_size + self.Lambda, OP_coords_pulsex[2*k+1] + ((-1) ** k) * (M2_size / 2 + (
                                2*k+1)*self.Lambda), OP_coords_pulsex[2*k] + ((-1) ** k) * border_off_M3P + (1 - k) * M2_size - self.Lambda, OP_coords_pulsex[2*k+1] + ((-1) ** k) * (M2_size / 2 + (3-2*k) * self.Lambda))
                            self.create_rec_with_mem(*V3_coords, fill='', outline='gray', dash= '-.-', tags = f"XCONNECT_V2_PulseX")

                            M3_coords = (V3_coords[0] - self.Lambda, V3_coords[1] -
                                         self.Lambda, V3_coords[2] + self.Lambda, full_OP_coords[3])
                            self.create_rec_with_mem(*M3_coords, fill='', outline='#000068', dash='-.-', tags = f"XCONNECT_M3_PulseX")

                        OP_coords_buffer = [x0 + j * buffer_width, y0 + i * 2 * M2_size, x0 + (
                            j + 1) * buffer_width, y0 + (i + 1) * 2 * M2_size]
                        # self.create_rec_with_mem(*OP_coords_buffer, outline='black', tags = f"OP_Buffer_{i}_{j}")
                        if MeB[i][j] == 1:
                            ME_coords = (OP_coords_buffer[0] + left_off_MeB, OP_coords_buffer[1],
                                         OP_coords_buffer[0] + left_off_MeB + M2_size, OP_coords_buffer[3])
                            self.create_rec_with_mem(*ME_coords, fill='blue', outline='blue', tags=f"XCONNECT_ME_Buffer")  # , fill = 'blue'
                        if MeB[i][j] == 1 and M2B[i][j] == 1:
                            V2_coords = (ME_coords[0] + self.Lambda, OP_coords_buffer[1] + M2_size / 2 + self.Lambda,
                                         ME_coords[2] - self.Lambda, OP_coords_buffer[3] - M2_size / 2 - self.Lambda)
                            self.create_rec_with_mem(*V2_coords, fill='gray', outline='gray', dash='-.', tags= f"XCONNECT_VI_Buffer")

                            if i == 0:
                                M2_coords = (V3_coords[2] + self.Lambda, V3_coords[3] + self.Lambda,
                                             V2_coords[0] - self.Lambda, V2_coords[1] - self.Lambda)
                            else:
                                M2_coords = (V3_coords[0] - self.Lambda, V3_coords[1] - self.Lambda,
                                             V2_coords[2] + self.Lambda, V2_coords[3] + self.Lambda)

                            self.create_rec_with_mem(*M2_coords, fill='#00008B', outline='#00008B', dash='-.', tags = f"XCONNECT_M2_Buffer")

                '''creating power lines in XCONNECT_block'''
                vertical_vdd_coords = (x0 + vddpulsex_width - M2_size - 2 * self.Lambda, y0 + 3 * M2_size + 2 *
                                       self.Lambda, x0 + vddpulsex_width - 2 * self.Lambda, y0 + (full_OP_coords[3] - full_OP_coords[1]))
                self.create_rec_with_mem(*vertical_vdd_coords, fill='blue', outline='blue', dash='', tags = f"XCONNECT_ME_vdd")

                horizontal_vdd_coords = (x0, y0 + 3 * M2_size + 2 * self.Lambda, x0 +
                                         vddpulsex_width - 6 * self.Lambda, y0 + 4 * M2_size + 2 * self.Lambda)
                self.create_rec_with_mem(*horizontal_vdd_coords, fill='blue', outline='blue', dash= '', tags = f"XCONNECT_ME_vdd")
                vertical_vss_coords = (x0 + left_off_MeB, y0 + 2 * M2_size + 2 * self.Lambda,
                                       x0 + left_off_MeB + M2_size, y0 + (full_OP_coords[3] - full_OP_coords[1]))
                self.create_rec_with_mem(*vertical_vss_coords, fill='#00008B', outline='#00008B', dash='-.', tags = f"XCONNECT_M2_vss")

                horizontal_vss_coords = (
                    x0, y0 + 2 * M2_size + 2 * self.Lambda, x0 + left_off_MeB, y0 + 3 * M2_size + 2 * self.Lambda)
                self.create_rec_with_mem(*horizontal_vss_coords, fill='#00008B', outline='#00008B', dash='-.', tags = f"XCONNECT_M2_vss")

                vertical_sig_coords = (x0 + left_off_MeB + M2_size + self.Lambda, y0 + 4 * M2_size + 2 * self.Lambda,
                                       x0 + left_off_MeB + 2 * M2_size + self.Lambda, y0 + (full_OP_coords[3] - full_OP_coords[1]))
                self.create_rec_with_mem(*vertical_sig_coords, fill='', outline='#000068', dash='-.-', tags = f"XCONNECT_M3_sig")

                horizontal_sig_coords = (x0, y0 + 4 * M2_size + 2 * self.Lambda, x0 +
                                         left_off_MeB + M2_size + self.Lambda, y0 + 5 * M2_size + 2 * self.Lambda)
                self.create_rec_with_mem(*horizontal_sig_coords, fill='', outline='#000068', dash= '-.-', tags = f"XCONNECT_M3_sig")

    def SW_XCONNECT_for_full(self, x0, y0, columns):
        ''' get data and scales about of xconnect block '''

        filepath = self.filefolder + f'\examples\_xcon_{columns}.mag'
        filename = os.path.basename(filepath)[:-4]
        xcon_coords = ReadTXT_SW(path=filepath, name=filename).getCoords()
        xcon_insert_item = re.split("_", filename.strip())
        xcon_insert_item = xcon_insert_item[1]

        no_update = False
        for fig in self.canvas.find_all():
            figure = self.canvas.gettags(fig)[0]
            figure = re.split("_", figure.strip())
            figure = figure[0]
            if figure == xcon_insert_item:
                no_update = True
            else:
                self.num_of_blocks[xcon_insert_item] = 0

        if self.choosed_blocks['XCONNECT']:
            for j in range(len(top_area['SkyWater130'])):
                rec = xcon_coords.get(top_area['SkyWater130'][j])
                color = colors['SkyWater130'][j]
                bordertype = borders['SkyWater130'][j]
                filling = fills['SkyWater130'][j]
                if type(rec) is list:
                    for i in range(len(rec)):
                        rec_coord = (x0 + rec[i][0] * self.Lambda, y0 + rec[i][1] * self.Lambda, x0 + (
                            rec[i][0] + rec[i][2]) * self.Lambda, y0 + (rec[i][1] + rec[i][3]) * self.Lambda)
                        self.create_rec_with_mem(*rec_coord, outline=color, fill=filling, dash=bordertype, tags= f'{xcon_insert_item}_{self.num_of_blocks[xcon_insert_item]}_{top_area["SkyWater130"][j]}_{i}')

        y = y0 + (xcon_coords['OP'][0][3] -
                  xcon_coords['OP'][0][1]) * self.Lambda
        x = x0
        return x, y

    def X_Connect_SW(self, event):
        self.GridUnits = self.GridLambda.get()
        # self.GridUnits = self.form.get_tech()
        if self.GridUnits == 0:
            messagebox.showerror("Error", "Choose foundry, please")
        else:
            self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
            if self.x_connect_access == 0 and (self.insertAccess == 1 or self.multiplyAccess == 1 and self.synthesisAcces == 1):
                pass
            elif self.x_connect_access == 1 and self.XDC_outputs > 2:
                self.multiplyAccess = 0
                self.insertAccess = 0
                self.synthesisAcces = 0
                self.x_connect_access = 0
                x0 = self.canvas.canvasx(event.x)
                y0 = self.canvas.canvasy(event.y)

                '''pattern matrixes creating'''
                M = math.ceil(self.XDC_outputs)
                M1B = zeros((M, M))
                M2B = zeros((M, M))
                V2P = zeros((M, M))
                for i in range(M):
                    for j in range(M):
                        if j >= i:
                            M1B[i][j] = 1
                        if j <= i:
                            M2B[i][j] = 1
                c = 0
                for i in range(M // 2):
                    for j in range(M // 2):
                        if i == j:
                            V2P[i+c][j] = 1
                            V2P[i+c+1][j] = 1
                            c += 1
                # print('M1B:\n', M1B, '\n', 'M2B:\n', M2B, '\n', 'V2P:\n', V2P)

                '''get data about widths of Buffer and pulsex blocks'''
                filepath = self.filefolder+'\examples\BUFFER_block.mag'
                filename = os.path.basename(filepath)[:-4]
                buffer_coords = ReadTXT_SW(
                    path=filepath, name=filename).getCoords()
                buffer_width = buffer_coords['OP'][0][-2]*self.Lambda

                filepath = self.filefolder+'\examples\_PULSEX_block.mag'
                filename = os.path.basename(filepath)[:-4]
                pulsex_coords = ReadTXT_SW(
                    path=filepath, name=filename).getCoords()
                pulsex_width = pulsex_coords['OP'][0][-2]*self.Lambda

                '''get data about scales of vdd_pulsex block'''
                filepath = self.filefolder+'\examples\_vddpulsex_block.mag'
                filename = os.path.basename(filepath)[:-4]
                vddpulsex_coords = ReadTXT_SW(
                    path=filepath, name=filename).getCoords()
                vddpulsex_width = vddpulsex_coords['OP'][0][-2]*self.Lambda

                self.device_coords = pulsex_coords
                self.insert_item = re.split("_", filename.strip())
                self.insert_item = self.insert_item[1]

                no_update = False
                for fig in self.canvas.find_all():
                    figure = self.canvas.gettags(fig)[0]
                    figure = re.split("_", figure.strip())
                    figure = figure[0]
                    if figure == self.insert_item:
                        no_update = True

                '''------------'''
                Grid_Lambda = 5 * self.Lambda
                M2_OP_height = 16 * Grid_Lambda
                M1_OP_height = 16 * Grid_Lambda
                left_off_M1B = 94 * Grid_Lambda
                M1_width = 8 * Grid_Lambda
                M2_width = 8 * Grid_Lambda
                V1_size = 6 * Grid_Lambda
                VIALI_size = 4 * Grid_Lambda
                border_off_M2 = 12 * Grid_Lambda

                '''drawing patterns'''
                full_OP_coords = (x0, y0, x0 + M * buffer_width,
                                  y0 + M * 16 * Grid_Lambda)
                self.create_rec_with_mem(
                    *full_OP_coords, outline=lookup['SkyWater130']['comment']['color'], tags=f"XCONNECT_OP_Connect")

                for i in range(M):
                    for j in range(M):

                        OP_coords_pulsex = (vddpulsex_width + x0 + j * pulsex_width, y0 + i * M2_OP_height,
                                            vddpulsex_width + x0 + (j + 1) * pulsex_width, y0 + (i + 1) * M2_OP_height)
                        if V2P[i][j] == 1:
                            # self.create_rec_with_mem(*OP_coords_pulsex, fill = lookup['SkyWater130']['comment']['fill'], outline=lookup['SkyWater130']['comment']['color'], tags = f"OP_PulseX_{i}_{j}")

                            if i % 2 == 0:
                                k = 0
                            else:
                                k = 1
                            V2_coords = (
                                OP_coords_pulsex[2*k] + ((-1) ** k) *
                                border_off_M2 - k * M2_width + 2 * Grid_Lambda,
                                OP_coords_pulsex[2*k+1] + ((-1) ** k) * (
                                    M2_width / 2 + (2*k+1) * 2 * Grid_Lambda),
                                OP_coords_pulsex[2*k] + ((-1) ** k) * border_off_M2 + (
                                    1 - k) * M2_width - 2 * Grid_Lambda,
                                OP_coords_pulsex[2*k+1] + ((-1) ** k) * (
                                    M2_width / 2 + (3-2*k) * 2 * Grid_Lambda)
                            )
                            V2_coords = (
                                V2_coords[0] - Grid_Lambda,
                                V2_coords[1] - Grid_Lambda,
                                V2_coords[2] + Grid_Lambda,
                                V2_coords[3] + Grid_Lambda
                            )
                            self.create_rec_with_mem(*V2_coords, fill=lookup['SkyWater130']['via2']['fill'], outline=lookup['SkyWater130']['via2']['color'], dash= lookup['SkyWater130']['via2']['border'], tags = f"XCONNECT_via2_PulseX")

                            M2_coords = (V2_coords[0] - Grid_Lambda, V2_coords[1] -
                                         Grid_Lambda, V2_coords[2] + Grid_Lambda, full_OP_coords[3])
                            self.create_rec_with_mem(*M2_coords, fill=lookup['SkyWater130']['metal2']['fill'], outline=lookup['SkyWater130']['metal2']['color'], dash=lookup['SkyWater130']['metal2']['border'], tags = f"XCONNECT_metal2_PulseX")

                            dcx_connect_square = (
                                M2_coords[0], M2_coords[3] - M1_width, M2_coords[2], M2_coords[3])
                            self.create_rec_with_mem(*dcx_connect_square, fill=lookup['SkyWater130']['metal1']['fill'], outline=lookup['SkyWater130']['metal1']['color'], tags= f"XCONNECT_metal1_dcxconn")  # , fill = 'blue'
                            self.create_rec_with_mem(*dcx_connect_square, fill=lookup['SkyWater130']['locali']['fill'], outline=lookup['SkyWater130']['locali']['color'], dash= lookup['SkyWater130']['locali']['border'], tags = f"XCONNECT_locali_dcxconn")

                            dcx_connect_vias = (dcx_connect_square[0] + (M1_width - VIALI_size) / 2, dcx_connect_square[1] + (
                                M1_width - VIALI_size) / 2, dcx_connect_square[2] - (M1_width - VIALI_size) / 2, dcx_connect_square[3] - (M1_width - VIALI_size) / 2)
                            self.create_rec_with_mem(*dcx_connect_vias, fill=lookup['SkyWater130']['viali']['fill'], outline=lookup['SkyWater130']['viali']['color'], dash=lookup['SkyWater130']['viali']['border'], tags=f"XCONNECT_viali_dcxconn")
                            dcx_connect_vias1 = (dcx_connect_square[0] + (M2_width - V1_size) / 2, dcx_connect_square[1] + (
                                M2_width - V1_size) / 2, dcx_connect_square[2] - (M2_width - V1_size) / 2, dcx_connect_square[3] - (M2_width - V1_size) / 2)
                            self.create_rec_with_mem(*dcx_connect_vias1, fill=lookup['SkyWater130']['via1']['fill'], outline=lookup['SkyWater130']['via1']['color'], dash=lookup['SkyWater130']['via1']['border'], tags=f"XCONNECT_via1_dcxconn")

                        OP_coords_buffer = [x0 + j * buffer_width, y0 + i * M1_OP_height, x0 + (
                            j + 1) * buffer_width, y0 + (i + 1) * M1_OP_height]
                        # self.create_rec_with_mem(*OP_coords_buffer, outline=lookup['SkyWater130']['comment']['color'], tags = f"OP_Buffer_{i}_{j}")
                        if M1B[i][j] == 1:
                            M1_coords = (OP_coords_buffer[0] + left_off_M1B, OP_coords_buffer[1],
                                         OP_coords_buffer[0] + left_off_M1B + M1_width, OP_coords_buffer[3])
                            self.create_rec_with_mem(*M1_coords, fill=lookup['SkyWater130']['metal1']['fill'], outline=lookup['SkyWater130']['metal1']['color'], tags= f"XCONNECT_metal1_Buffer")  # , fill = 'blue'
                        if M1B[i][j] == 1 and M2B[i][j] == 1:
                            V1_coords = (M1_coords[0] + (M1_width - V1_size) / 2, OP_coords_buffer[1] + M1_OP_height / 2 - V1_size / 2,
                                         M1_coords[2] - (M1_width - V1_size) / 2, OP_coords_buffer[1] + M1_OP_height / 2 + V1_size / 2)
                            self.create_rec_with_mem(*V1_coords, fill=lookup['SkyWater130']['via1']['fill'], outline=lookup['SkyWater130']['via1']['color'], dash=lookup['SkyWater130']['via1']['border'], tags= f"XCONNECT_via1_Buffer")

                            self.create_rec_with_mem(*V1_coords, fill=lookup['SkyWater130']['via2']['fill'], outline=lookup['SkyWater130']['via2']['color'], dash=lookup['SkyWater130']['via2']['border'], tags= f"XCONNECT_via2_Buffer")

                            dop_M2_coords = (
                                V1_coords[0] - Grid_Lambda,
                                V1_coords[1] - Grid_Lambda,
                                V1_coords[2] + Grid_Lambda,
                                V1_coords[3] + Grid_Lambda
                            )
                            self.create_rec_with_mem(*dop_M2_coords, fill=lookup['SkyWater130']['metal2']['fill'], outline=lookup['SkyWater130']['metal2']['color'], dash=lookup['SkyWater130']['metal2']['border'], tags= f"XCONNECT_metal2_Buffer")
                            if j != 0:
                                M3_coords = (V2_coords[0] - Grid_Lambda, V2_coords[1] - Grid_Lambda,
                                             V1_coords[2] + Grid_Lambda, V1_coords[3] + Grid_Lambda)
                            else:
                                M3_coords = (
                                    dop_M2_coords[0], dop_M2_coords[1], M2_coords[2], dop_M2_coords[3])
                            self.create_rec_with_mem(*M3_coords, fill=lookup['SkyWater130']['metal3']['fill'], outline=lookup['SkyWater130']['metal3']['color'], dash=lookup['SkyWater130']['metal3']['border'], tags = f"XCONNECT_metal3_Buffer")

                '''creating power lines in XCONNECT_block'''
                vertical_vss_coords = (
                    x0 + 22 * Grid_Lambda - 8 * Grid_Lambda,
                    y0 + 34 * Grid_Lambda + 8 * Grid_Lambda,
                    x0 + 22 * Grid_Lambda,
                    y0 + (full_OP_coords[3] - full_OP_coords[1])
                )
                self.create_rec_with_mem(*vertical_vss_coords, fill=lookup['SkyWater130']['metal1']['fill'], outline=lookup['SkyWater130']['metal1']['color'], dash=lookup['SkyWater130']['metal1']['border'], tags = f"XCONNECT_metal1_vss")

                horizontal_vss_coords = (
                    x0,
                    y0 + 34 * Grid_Lambda,
                    x0 + 22 * Grid_Lambda,
                    y0 + 34 * Grid_Lambda + 8 * Grid_Lambda
                )
                self.create_rec_with_mem(*horizontal_vss_coords, fill=lookup['SkyWater130']['metal1']['fill'], outline=lookup['SkyWater130']['metal1']['color'], dash=lookup['SkyWater130']['metal1']['border'], tags = f"XCONNECT_metal1_vss")
                # -----------------------------------------------------
                vertical_vdd_coords = (
                    x0 + 38 * Grid_Lambda - 8 * Grid_Lambda,
                    y0 + 16 * Grid_Lambda + 8 * Grid_Lambda,
                    x0 + 38 * Grid_Lambda,
                    y0 + (full_OP_coords[3] - full_OP_coords[1])
                )
                self.create_rec_with_mem(*vertical_vdd_coords, fill=lookup['SkyWater130']['locali']['fill'], outline=lookup['SkyWater130']['locali']['color'], dash= lookup['SkyWater130']['locali']['border'], tags = f"XCONNECT_locali_vdd")

                horizontal_vdd_coords = (
                    x0,
                    y0 + 16 * Grid_Lambda,
                    x0 + 38 * Grid_Lambda,
                    y0 + 16 * Grid_Lambda + 8 * Grid_Lambda
                )
                self.create_rec_with_mem(*horizontal_vdd_coords, fill=lookup['SkyWater130']['locali']['fill'], outline=lookup['SkyWater130']['locali']['color'], dash=lookup['SkyWater130']['locali']['border'], tags = f"XCONNECT_locali_vdd")
                # -----------------------------------------------------
                # vertical_vdd_coords = (
                # x0 + 38 * Grid_Lambda + 8 * Grid_Lambda,
                # y0 + 16 * Grid_Lambda + 9 * Grid_Lambda + 8 * Grid_Lambda,
                # x0 + 38 * Grid_Lambda + 16 * Grid_Lambda,
                # y0 + (full_OP_coords[3] - full_OP_coords[1])
                # )
                # self.create_rec_with_mem(*vertical_vdd_coords, fill = lookup['SkyWater130']['metal1']['fill'], outline = lookup['SkyWater130']['metal1']['color'], dash = lookup['SkyWater130']['metal1']['border'], tags = f"XCONNECT_metal1_vdd")

                # horizontal_vdd_coords = (
                # x0,
                # y0 + 16 * Grid_Lambda + 9 * Grid_Lambda,
                # x0 + 38 * Grid_Lambda + 16 * Grid_Lambda,
                # y0 + 16 * Grid_Lambda + 9 * Grid_Lambda + 8 * Grid_Lambda
                # )
                # self.create_rec_with_mem(*horizontal_vdd_coords, fill = lookup['SkyWater130']['metal1']['fill'], outline = lookup['SkyWater130']['metal1']['color'], dash = lookup['SkyWater130']['metal1']['border'], tags = f"XCONNECT_metal1_sig")

    def X_DC_Syn(self, event):
        self.GridUnits = self.GridLambda.get()
        # self.GridUnits = self.form.get_tech()
        if self.GridUnits == 0:
            messagebox.showerror("Error", "Choose foundry, please")
        else:
            self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
            if self.x_decoder_access == 0 and (self.insertAccess == 1 or self.multiplyAccess == 1 and self.synthesisAcces == 1):
                pass
            elif self.x_decoder_access == 1:
                self.multiplyAccess = 0
                self.insertAccess = 0
                self.synthesisAcces = 0
                self.x_decoder_access = 0
                x0 = self.canvas.canvasx(event.x)
                y0 = self.canvas.canvasy(event.y)
                coulumns_amount = 0

                if self.XDC_outputs <= 4:
                    item = 'Xnand_base'
                    self.device_coords = self.XDC_objects_coords[item]
                    self.insert_item = item
                    x = x0
                    y = y0
                    try:
                        self.num_of_blocks[self.insert_item] += 1
                    except:
                        self.num_of_blocks[self.insert_item] = 0

                    for j in range(len(top_area)):
                        rec = self.device_coords.get(top_area[j])
                        color = colors[j]
                        bordertype = borders[j]
                        filling = fills[j]
                        if type(rec) is list:
                            for i in range(len(rec)):
                                if j != (len(top_area)-1):
                                    koeff = 1
                                else:
                                    koeff = -1

                                x1 = x+rec[i][0]*self.Lambda
                                x2 = x+(rec[i][0]+rec[i][2])*self.Lambda
                                y1 = y+rec[i][1]*self.Lambda
                                y2 = y+(rec[i][1]-koeff*rec[i][3])*self.Lambda

                                rec_coord = (x1, y1, x2, y2)

                                self.create_rec_with_mem(*rec_coord, outline=color, fill=filling, dash=bordertype, tags=f'{self.insert_item}_{self.num_of_blocks[self.insert_item]}_{top_area[j]}_{i}')

                for i in range(0, (self.XDC_inputs - 2), 1):
                    coulumns_amount = coulumns_amount + 2**i + 1

                decoder_matrix = [0]*coulumns_amount
                delta_y_matrix = [0]*coulumns_amount
                delta_x_matrix = [0]*coulumns_amount
                counter = 0
                self.stage_count = 0

                # минус 2 поскольку нулевой stage это и есть базовый DC
                for stage in range(coulumns_amount, 0, -1):
                    if stage == coulumns_amount:
                        self.stage_count = (self.XDC_inputs - 2) - 1
                    stage_list = [0]*(self.XDC_outputs//4+1)
                    delta_y_list = [0]*(self.XDC_outputs//4+1)
                    delta_x_list = [0]*(self.XDC_outputs//4+1)
                    amount_of_objects = (
                        2**(self.stage_count+1))//2  # (2**stage)//2
                    if counter == 0:
                        # base_nor
                        if self.XDC_inputs % 2 == 0 and (stage) % 2 == 0:
                            inv_block = 'Xforward_inv'
                            first_block = 'XNnands'
                            inverse_for_first = 'Xnands'
                        # base_nand
                        elif self.XDC_inputs % 2 != 0 and (stage) % 2 == 0:
                            inv_block = 'Xbackward_inv'
                            first_block = 'Xnors'
                            inverse_for_first = 'XNnors'
                        # base_nor
                        elif self.XDC_inputs % 2 == 0 and (stage) % 2 != 0:
                            inv_block = 'Xbackward_inv'
                            first_block = 'Xnors'
                            inverse_for_first = 'XNnors'
                        # base_nand
                        elif self.XDC_inputs % 2 != 0 and (stage) % 2 != 0:
                            inv_block = 'Xforward_inv'
                            first_block = 'XNnands'
                            inverse_for_first = 'Xnands'
                        stage_list[0] = inv_block
                        item_coords = self.XDC_objects_coords[inv_block]
                    else:
                        empty_block = 'Xempty'
                        stage_list[0] = empty_block
                        item_coords = self.XDC_objects_coords[empty_block]
                    item_coords = item_coords.get(top_area[len(top_area)-1])
                    delta_y_list[0] = item_coords[0][3]
                    delta_x_list[0] = item_coords[0][2]
                    for h in range(2*amount_of_objects):
                        if h < amount_of_objects:
                            if counter == 0:
                                stage_list[h+1] = first_block
                                item_coords = self.XDC_objects_coords[first_block]
                                item_coords = item_coords.get(
                                    top_area[len(top_area)-1])
                                delta_y_list[h+1] = item_coords[0][3]
                                delta_x_list[h+1] = item_coords[0][2]
                            else:
                                if counter == (h + 1):
                                    XT_block = 'XT'
                                    stage_list[h+1] = XT_block
                                    item_coords = self.XDC_objects_coords[XT_block]
                                    item_coords = item_coords.get(
                                        top_area[len(top_area)-1])
                                    delta_y_list[h+1] = item_coords[0][3]
                                    delta_x_list[h+1] = item_coords[0][2]
                                elif counter > (h + 1):
                                    XC_block = 'XC'
                                    stage_list[h+1] = XC_block
                                    item_coords = self.XDC_objects_coords[XC_block]
                                    item_coords = item_coords.get(
                                        top_area[len(top_area)-1])
                                    delta_y_list[h+1] = item_coords[0][3]
                                    delta_x_list[h+1] = item_coords[0][2]
                                elif counter < (h + 1):
                                    XH_block = 'XH'
                                    stage_list[h+1] = XH_block
                                    item_coords = self.XDC_objects_coords[XH_block]
                                    item_coords = item_coords.get(
                                        top_area[len(top_area)-1])
                                    delta_y_list[h+1] = item_coords[0][3]
                                    delta_x_list[h+1] = item_coords[0][2]
                        else:
                            if counter == 0:
                                stage_list[h+1] = inverse_for_first
                                item_coords = self.XDC_objects_coords[inverse_for_first]
                                item_coords = item_coords.get(
                                    top_area[len(top_area)-1])
                                delta_y_list[h+1] = item_coords[0][3]
                                delta_x_list[h+1] = item_coords[0][2]
                            else:
                                if counter == (h + 1) - amount_of_objects:
                                    XL_block = 'XL'
                                    stage_list[h+1] = XL_block
                                    item_coords = self.XDC_objects_coords[XL_block]
                                    item_coords = item_coords.get(
                                        top_area[len(top_area)-1])
                                    delta_y_list[h+1] = item_coords[0][3]
                                    delta_x_list[h+1] = item_coords[0][2]
                                elif counter > (h + 1) - amount_of_objects:
                                    XII_block = 'XII'
                                    stage_list[h+1] = XII_block
                                    item_coords = self.XDC_objects_coords[XII_block]
                                    item_coords = item_coords.get(
                                        top_area[len(top_area)-1])
                                    delta_y_list[h+1] = item_coords[0][3]
                                    delta_x_list[h+1] = item_coords[0][2]
                                elif counter < (h + 1) - amount_of_objects:
                                    XC_block = 'XC'
                                    stage_list[h+1] = XC_block
                                    item_coords = self.XDC_objects_coords[XC_block]
                                    item_coords = item_coords.get(
                                        top_area[len(top_area)-1])
                                    delta_y_list[h+1] = item_coords[0][3]
                                    delta_x_list[h+1] = item_coords[0][2]

                    decoder_matrix[stage-1] = stage_list
                    delta_y_matrix[stage-1] = delta_y_list
                    delta_x_matrix[stage-1] = delta_x_list
                    if counter < (2 ** self.stage_count):
                        counter += 1
                    else:
                        self.stage_count -= 1
                        counter = 0
                # print('before:', decoder_matrix, '\n', delta_x_matrix, '\n', delta_y_matrix)
                # -----------------------------------
                for i in range(len(decoder_matrix)):
                    decoder_matrix[i].reverse()
                decoder_matrix.reverse()
                # -----------------------------------
                for i in range(len(delta_y_matrix)):
                    delta_y_matrix[i].reverse()
                delta_y_matrix.reverse()
                # -----------------------------------
                for i in range(len(delta_x_matrix)):
                    delta_x_matrix[i].reverse()
                delta_x_matrix.reverse()
                # -----------------------------------
                transpose_decoder_matrix = []
                for i in range(len(decoder_matrix[0])):
                    row = []
                    for item in decoder_matrix:
                        row.append(item[i])
                    transpose_decoder_matrix.append(row)
                decoder_matrix = transpose_decoder_matrix
                # -----------------------------------
                transpose_delta_y_matrix = []
                for i in range(len(delta_y_matrix[0])):
                    row = []
                    for item in delta_y_matrix:
                        row.append(item[i])
                    transpose_delta_y_matrix.append(row)
                delta_y_matrix = transpose_delta_y_matrix
                # -----------------------------------
                transpose_delta_x_matrix = []
                for i in range(len(delta_x_matrix[0])):
                    row = []
                    for item in delta_x_matrix:
                        row.append(item[i])
                    transpose_delta_x_matrix.append(row)
                delta_x_matrix = transpose_delta_x_matrix
                # -----------------------------------
                # print('after:', decoder_matrix, '\n', delta_x_matrix, '\n', delta_y_matrix)
                y = y0
                self.other_delta_y = 0
                # self.other_delta_x = 0
                for amount_y in range(len(decoder_matrix[0])+1):
                    x = x0  # + self.other_delta_x
                    if amount_y == len(decoder_matrix[0]):
                        if self.XDC_inputs % 2 == 0:
                            item = 'Xnor_base'
                        else:
                            item = 'Xnand_base'
                        self.device_coords = self.XDC_objects_coords[item]
                        op_coords = self.device_coords.get('OP')[0]
                        # print('op_coords:', op_coords)
                        # print('empty_op_coords:', self.empty_op_coords)
                        self.insert_item = item
                        x = self.empty_op_coords[0] + \
                            (self.empty_op_coords[2] -
                             op_coords[2])*self.Lambda
                        y = self.other_delta_y
                        try:
                            self.num_of_blocks[self.insert_item] += 1
                        except:
                            self.num_of_blocks[self.insert_item] = 0

                        for j in range(len(top_area)):
                            rec = self.device_coords.get(top_area[j])
                            color = colors[j]
                            bordertype = borders[j]
                            filling = fills[j]
                            if type(rec) is list:
                                for i in range(len(rec)):
                                    if j != (len(top_area)-1):
                                        koeff = 1
                                    else:
                                        koeff = -1

                                    x1 = x+rec[i][0]*self.Lambda
                                    x2 = x+(rec[i][0]+rec[i][2])*self.Lambda
                                    y1 = y+rec[i][1]*self.Lambda
                                    y2 = y+(rec[i][1]-koeff *
                                            rec[i][3])*self.Lambda

                                    rec_coord = (x1, y1, x2, y2)

                                    self.create_rec_with_mem(*rec_coord, outline=color, fill=filling, dash=bordertype, tags=f'{self.insert_item}_{self.num_of_blocks[self.insert_item]}_{top_area[j]}_{i}')
                                    # self.canvas.update()
                    else:
                        for amount_x in range(len(decoder_matrix)):
                            item = decoder_matrix[amount_x][amount_y]

                            if item == 0 and amount_x == 0:
                                delta_x_matrix[amount_x][amount_y] = delta_x_matrix[amount_x][0]
                                delta_y_matrix[amount_x][amount_y] = delta_y_matrix[-1][amount_y]
                            elif item == 0 and amount_x != 0:
                                delta_x_matrix[amount_x][amount_y] += delta_x_matrix[amount_x-1][0]
                                delta_y_matrix[amount_x][amount_y] = delta_y_matrix[-1][amount_y]

                            if amount_y != 0:
                                # y + delta_y_matrix[amount_x][amount_y-1] * self.Lambda
                                y = self.other_delta_y
                            if amount_x != 0:
                                x = x + \
                                    delta_x_matrix[amount_x -
                                                   1][amount_y] * self.Lambda
                            if amount_x == len(decoder_matrix)-1:
                                self.other_delta_y = y + \
                                    delta_y_matrix[amount_x][amount_y] * \
                                    self.Lambda

                            if item != 0:
                                self.device_coords = self.XDC_objects_coords[item]
                                self.insert_item = item
                                if item == 'Xempty':
                                    self.empty_op_coords = [x, self.other_delta_y, self.device_coords.get(
                                        'OP')[0][2], self.device_coords.get('OP')[0][3]]

                                try:
                                    self.num_of_blocks[self.insert_item] += 1
                                except:
                                    self.num_of_blocks[self.insert_item] = 0

                                for j in range(len(top_area)):
                                    rec = self.device_coords.get(top_area[j])
                                    color = colors[j]
                                    bordertype = borders[j]
                                    filling = fills[j]
                                    if type(rec) is list:
                                        for i in range(len(rec)):
                                            if j != (len(top_area)-1):
                                                koeff = 1
                                            else:
                                                koeff = -1

                                            x1 = x+rec[i][0]*self.Lambda
                                            x2 = x+(rec[i][0]+rec[i]
                                                    [2])*self.Lambda
                                            y1 = y+rec[i][1]*self.Lambda
                                            y2 = y + \
                                                (rec[i][1]-koeff *
                                                 rec[i][3])*self.Lambda

                                            rec_coord = (x1, y1, x2, y2)

                                            self.create_rec_with_mem(*rec_coord, outline=color, fill=filling, dash=bordertype, tags=f'{self.insert_item}_{self.num_of_blocks[self.insert_item]}_{top_area[j]}_{i}')
                                            # self.canvas.update()

    def XCONNECT_for_full(self, x0, y0):
        '''pattern matrixes creating'''
        M = math.ceil(self.columns)
        MeB = zeros((M, M))
        M2B = zeros((M, M))
        V2P = zeros((M, M))
        for i in range(M):
            for j in range(M):
                if j >= i:
                    MeB[i][j] = 1
                if j <= i:
                    M2B[i][j] = 1
        c = 0
        for i in range(M // 2):
            for j in range(M // 2):
                if i == j:
                    V2P[i+c][j] = 1
                    V2P[i+c+1][j] = 1
                    c += 1

        '''get data about widths of Buffer and pulsex blocks'''
        filepath = self.filefolder+'\examples\BUFFER_block.txt'
        filename = os.path.basename(filepath)[:-4]
        buffer_coords = ReadTXT_MW(path=filepath, name=filename).getCoords()
        buffer_width = buffer_coords['OP'][0][-2]*self.Lambda

        filepath = self.filefolder+'\examples\_PULSEX_block.txt'
        filename = os.path.basename(filepath)[:-4]
        pulsex_coords = ReadTXT_MW(path=filepath, name=filename).getCoords()
        pulsex_width = pulsex_coords['OP'][0][-2]*self.Lambda

        self.device_coords = pulsex_coords
        self.insert_item = re.split("_", filename.strip())
        self.insert_item = self.insert_item[1]

        no_update = False
        for fig in self.canvas.find_all():
            figure = self.canvas.gettags(fig)[0]
            figure = re.split("_", figure.strip())
            figure = figure[0]
            if figure == self.insert_item:
                no_update = True

        delta = self.device_coords.get('OP')
        delta_x = delta[0][2]
        '''get data about scales of vdd_pulsex block'''
        filepath = self.filefolder+'\examples\_vddpulsex_block.txt'
        filename = os.path.basename(filepath)[:-4]
        vddpulsex_coords = ReadTXT_MW(path=filepath, name=filename).getCoords()
        vddpulsex_width = vddpulsex_coords['OP'][0][-2]*self.Lambda

        '''------------'''
        M2_size = 4 * self.Lambda
        left_off_MeB = 9 * self.Lambda
        border_off_M3P = 7 * self.Lambda
        '''drawing patterns'''
        full_OP_coords = (x0, y0, x0 + M * buffer_width, y0 + 2 * M * M2_size)
        if self.choosed_blocks['XCONNECT']:
            self.create_rec_with_mem(
                *full_OP_coords, outline='orange', tags=f"XCONNECT_OP_Connect")

        for i in range(M):
            for j in range(M):
                OP_coords_pulsex = (vddpulsex_width + x0 + j * pulsex_width, y0 + i * 2 * M2_size,
                                    vddpulsex_width + x0 + (j + 1) * pulsex_width, y0 + (i + 1) * 2 * M2_size)
                if V2P[i][j] == 1:
                    # self.create_rec_with_mem(*OP_coords_pulsex, fill ='', outline='black', tags = f"OP_PulseX_{i}_{j}")
                    if i % 2 == 0:
                        k = 0
                    else:
                        k = 1
                    V3_coords = (OP_coords_pulsex[2*k] + ((-1) ** k) * border_off_M3P - k * M2_size + self.Lambda, OP_coords_pulsex[2*k+1] + ((-1) ** k) * (M2_size / 2 + (2*k+1)*self.Lambda),
                                 OP_coords_pulsex[2*k] + ((-1) ** k) * border_off_M3P + (1 - k) * M2_size - self.Lambda, OP_coords_pulsex[2*k+1] + ((-1) ** k) * (M2_size / 2 + (3-2*k) * self.Lambda))

                    if self.choosed_blocks['XCONNECT']:
                        self.create_rec_with_mem(*V3_coords, fill='', outline='gray', dash= '-.-', tags = f"XCONNECT_V2_PulseX")

                    M3_coords = (V3_coords[0] - self.Lambda, V3_coords[1] -
                                 self.Lambda, V3_coords[2] + self.Lambda, full_OP_coords[3])

                    if self.choosed_blocks['XCONNECT']:
                        self.create_rec_with_mem(*M3_coords, fill='', outline='#000068', dash='-.-', tags = f"XCONNECT_M3_PulseX")

                OP_coords_buffer = [x0 + j * buffer_width, y0 + i * 2 * M2_size,
                                    x0 + (j + 1) * buffer_width, y0 + (i + 1) * 2 * M2_size]
                # self.create_rec_with_mem(*OP_coords_buffer, outline='black', tags = f"OP_Buffer_{i}_{j}")
                if MeB[i][j] == 1:
                    ME_coords = (OP_coords_buffer[0] + left_off_MeB, OP_coords_buffer[1],
                                 OP_coords_buffer[0] + left_off_MeB + M2_size, OP_coords_buffer[3])
                    if self.choosed_blocks['XCONNECT']:
                        self.create_rec_with_mem(*ME_coords, fill='blue', outline='blue', tags=f"XCONNECT_ME_Buffer")  # , fill = 'blue'
                if MeB[i][j] == 1 and M2B[i][j] == 1:
                    V2_coords = (ME_coords[0] + self.Lambda, OP_coords_buffer[1] + M2_size / 2 + self.Lambda,
                                 ME_coords[2] - self.Lambda, OP_coords_buffer[3] - M2_size / 2 - self.Lambda)
                    if self.choosed_blocks['XCONNECT']:
                        self.create_rec_with_mem(*V2_coords, fill='gray', outline='gray', dash='-.', tags= f"XCONNECT_VI_Buffer")

                    if i == 0:
                        M2_coords = (V3_coords[2] + self.Lambda, V3_coords[3] + self.Lambda,
                                     V2_coords[0] - self.Lambda, V2_coords[1] - self.Lambda)
                    else:
                        M2_coords = (V3_coords[0] - self.Lambda, V3_coords[1] - self.Lambda,
                                     V2_coords[2] + self.Lambda, V2_coords[3] + self.Lambda)
                    if self.choosed_blocks['XCONNECT']:
                        self.create_rec_with_mem(*M2_coords, fill='#00008B', outline='#00008B', dash='-.', tags = f"XCONNECT_M2_Buffer")

        '''creating power lines in XCONNECT_block'''
        vertical_vdd_coords = (x0 + vddpulsex_width - M2_size - 2 * self.Lambda, y0 + 3 * M2_size + 2 *
                               self.Lambda, x0 + vddpulsex_width - 2 * self.Lambda, y0 + (full_OP_coords[3] - full_OP_coords[1]))
        if self.choosed_blocks['XCONNECT']:
            self.create_rec_with_mem(*vertical_vdd_coords, fill='blue', outline='blue', dash='', tags = f"XCONNECT_ME_vdd")

        horizontal_vdd_coords = (x0, y0 + 3 * M2_size + 2 * self.Lambda, x0 +
                                 vddpulsex_width - 6 * self.Lambda, y0 + 4 * M2_size + 2 * self.Lambda)
        if self.choosed_blocks['XCONNECT']:
            self.create_rec_with_mem(*horizontal_vdd_coords, fill='blue', outline='blue', dash= '', tags = f"XCONNECT_ME_vdd")

        vertical_vss_coords = (x0 + left_off_MeB, y0 + 2 * M2_size + 2 * self.Lambda,
                               x0 + left_off_MeB + M2_size, y0 + (full_OP_coords[3] - full_OP_coords[1]))
        if self.choosed_blocks['XCONNECT']:
            self.create_rec_with_mem(*vertical_vss_coords, fill='#00008B', outline='#00008B', dash='-.', tags = f"XCONNECT_M2_vss")

        horizontal_vss_coords = (x0, y0 + 2 * M2_size + 2 * self.Lambda,
                                 x0 + left_off_MeB, y0 + 3 * M2_size + 2 * self.Lambda)
        if self.choosed_blocks['XCONNECT']:
            self.create_rec_with_mem(*horizontal_vss_coords, fill='#00008B', outline='#00008B', dash='-.', tags = f"XCONNECT_M2_vss")

        vertical_sig_coords = (x0 + left_off_MeB + M2_size + self.Lambda, y0 + 4 * M2_size + 2 * self.Lambda,
                               x0 + left_off_MeB + 2 * M2_size + self.Lambda, y0 + (full_OP_coords[3] - full_OP_coords[1]))
        if self.choosed_blocks['XCONNECT']:
            self.create_rec_with_mem(*vertical_sig_coords, fill='', outline='#000068', dash='-.-', tags = f"XCONNECT_M3_sig")

        horizontal_sig_coords = (x0, y0 + 4 * M2_size + 2 * self.Lambda, x0 +
                                 left_off_MeB + M2_size + self.Lambda, y0 + 5 * M2_size + 2 * self.Lambda)
        if self.choosed_blocks['XCONNECT']:
            self.create_rec_with_mem(*horizontal_sig_coords, fill='', outline='#000068', dash= '-.-', tags = f"XCONNECT_M3_sig")

        # delta_y = delta[0][3]
        y = y0 + (full_OP_coords[3] - full_OP_coords[1])
        x = x0 + vddpulsex_width
        if self.choosed_blocks['PULSEX']:
            for amount_x in range(M // 2):
                if amount_x != 0:
                    x = x + delta_x * self.Lambda
                if not self.canvas.find_all() or no_update == False:
                    self.num_of_blocks[self.insert_item] = 0
                else:
                    self.num_of_blocks[self.insert_item] += 1

                # xOP_1 = x + self.device_coords.get('OP')[0][0]*self.Lambda
                # xOP_2 = x + (self.device_coords.get('OP')[0][0]+self.device_coords.get('OP')[0][2])*self.Lambda

                for j in range(len(top_area)):
                    rec = self.device_coords.get(top_area['Microwind65'][j])
                    color = colors['Microwind65'][j]
                    bordertype = borders['Microwind65'][j]
                    filling = fills['Microwind65'][j]
                    if type(rec) is list:
                        for i in range(len(rec)):
                            rec_coord = (x + rec[i][0] * self.Lambda, y + rec[i][1] * self.Lambda, x + (
                                rec[i][0] + rec[i][2]) * self.Lambda, y + (rec[i][1] + rec[i][3]) * self.Lambda)

                            self.create_rec_with_mem(*rec_coord, outline=color, fill=filling, dash=bordertype, tags=f'{self.insert_item}_{self.num_of_blocks[self.insert_item]}_{top_area["Microwind65"][j]}_{i}')
                            self.canvas.update()
        return x0 + vddpulsex_width, y + (delta[0][-1] - delta[0][1]) * self.Lambda

    def XDC_for_full(self, x0, y0):
        coulumns_amount = 0
        self.XDC_inputs = self.columns

        if self.columns <= 4:
            item = 'Xnand_base'
            self.device_coords = self.XDC_objects_coords[item]
            self.insert_item = item
            x = x0
            y = y0
            try:
                self.num_of_blocks[self.insert_item] += 1
            except:
                self.num_of_blocks[self.insert_item] = 0

            for j in range(len(top_area)):
                rec = self.device_coords.get(top_area[j])
                color = colors[j]
                bordertype = borders[j]
                filling = fills[j]
                if type(rec) is list:
                    for i in range(len(rec)):
                        if j != (len(top_area)-1):
                            koeff = 1
                        else:
                            koeff = -1

                        x1 = x+rec[i][0]*self.Lambda
                        x2 = x+(rec[i][0]+rec[i][2])*self.Lambda
                        y1 = y+rec[i][1]*self.Lambda
                        y2 = y+(rec[i][1]-koeff*rec[i][3])*self.Lambda

                        rec_coord = (x1, y1, x2, y2)

                        self.create_rec_with_mem(*rec_coord, outline=color, fill=filling, dash=bordertype, tags=f'{self.insert_item}_{self.num_of_blocks[self.insert_item]}_{top_area[j]}_{i}')

        for i in range(0, (self.XDC_inputs - 2), 1):
            coulumns_amount = coulumns_amount + 2**i + 1

        decoder_matrix = [0]*coulumns_amount
        delta_y_matrix = [0]*coulumns_amount
        delta_x_matrix = [0]*coulumns_amount
        counter = 0
        self.stage_count = 0

        # минус 2 поскольку нулевой stage это и есть базовый DC
        for stage in range(coulumns_amount, 0, -1):
            if stage == coulumns_amount:
                self.stage_count = (self.XDC_inputs - 2) - 1
            stage_list = [0]*(self.columns//4+1)
            delta_y_list = [0]*(self.columns//4+1)
            delta_x_list = [0]*(self.columns//4+1)
            amount_of_objects = (2**(self.stage_count+1))//2  # (2**stage)//2
            if counter == 0:
                if self.XDC_inputs % 2 == 0 and (stage) % 2 == 0:   # base_nor
                    inv_block = 'Xforward_inv'
                    first_block = 'XNnands'
                    inverse_for_first = 'Xnands'
                # base_nand
                elif self.XDC_inputs % 2 != 0 and (stage) % 2 == 0:
                    inv_block = 'Xbackward_inv'
                    first_block = 'Xnors'
                    inverse_for_first = 'XNnors'
                elif self.XDC_inputs % 2 == 0 and (stage) % 2 != 0:  # base_nor
                    inv_block = 'Xbackward_inv'
                    first_block = 'Xnors'
                    inverse_for_first = 'XNnors'
                # base_nand
                elif self.XDC_inputs % 2 != 0 and (stage) % 2 != 0:
                    inv_block = 'Xforward_inv'
                    first_block = 'XNnands'
                    inverse_for_first = 'Xnands'
                stage_list[0] = inv_block
                item_coords = self.XDC_objects_coords[inv_block]
            else:
                empty_block = 'Xempty'
                stage_list[0] = empty_block
                item_coords = self.XDC_objects_coords[empty_block]
            item_coords = item_coords.get(top_area[len(top_area)-1])
            delta_y_list[0] = item_coords[0][3]
            delta_x_list[0] = item_coords[0][2]
            for h in range(2*amount_of_objects):
                if h < amount_of_objects:
                    if counter == 0:
                        stage_list[h+1] = first_block
                        item_coords = self.XDC_objects_coords[first_block]
                        item_coords = item_coords.get(
                            top_area[len(top_area)-1])
                        delta_y_list[h+1] = item_coords[0][3]
                        delta_x_list[h+1] = item_coords[0][2]
                    else:
                        if counter == (h + 1):
                            XT_block = 'XT'
                            stage_list[h+1] = XT_block
                            item_coords = self.XDC_objects_coords[XT_block]
                            item_coords = item_coords.get(
                                top_area[len(top_area)-1])
                            delta_y_list[h+1] = item_coords[0][3]
                            delta_x_list[h+1] = item_coords[0][2]
                        elif counter > (h + 1):
                            XC_block = 'XC'
                            stage_list[h+1] = XC_block
                            item_coords = self.XDC_objects_coords[XC_block]
                            item_coords = item_coords.get(
                                top_area[len(top_area)-1])
                            delta_y_list[h+1] = item_coords[0][3]
                            delta_x_list[h+1] = item_coords[0][2]
                        elif counter < (h + 1):
                            XH_block = 'XH'
                            stage_list[h+1] = XH_block
                            item_coords = self.XDC_objects_coords[XH_block]
                            item_coords = item_coords.get(
                                top_area[len(top_area)-1])
                            delta_y_list[h+1] = item_coords[0][3]
                            delta_x_list[h+1] = item_coords[0][2]
                else:
                    if counter == 0:
                        stage_list[h+1] = inverse_for_first
                        item_coords = self.XDC_objects_coords[inverse_for_first]
                        item_coords = item_coords.get(
                            top_area[len(top_area)-1])
                        delta_y_list[h+1] = item_coords[0][3]
                        delta_x_list[h+1] = item_coords[0][2]
                    else:
                        if counter == (h + 1) - amount_of_objects:
                            XL_block = 'XL'
                            stage_list[h+1] = XL_block
                            item_coords = self.XDC_objects_coords[XL_block]
                            item_coords = item_coords.get(
                                top_area[len(top_area)-1])
                            delta_y_list[h+1] = item_coords[0][3]
                            delta_x_list[h+1] = item_coords[0][2]
                        elif counter > (h + 1) - amount_of_objects:
                            XII_block = 'XII'
                            stage_list[h+1] = XII_block
                            item_coords = self.XDC_objects_coords[XII_block]
                            item_coords = item_coords.get(
                                top_area[len(top_area)-1])
                            delta_y_list[h+1] = item_coords[0][3]
                            delta_x_list[h+1] = item_coords[0][2]
                        elif counter < (h + 1) - amount_of_objects:
                            XC_block = 'XC'
                            stage_list[h+1] = XC_block
                            item_coords = self.XDC_objects_coords[XC_block]
                            item_coords = item_coords.get(
                                top_area[len(top_area)-1])
                            delta_y_list[h+1] = item_coords[0][3]
                            delta_x_list[h+1] = item_coords[0][2]

            decoder_matrix[stage-1] = stage_list
            delta_y_matrix[stage-1] = delta_y_list
            delta_x_matrix[stage-1] = delta_x_list
            if counter < (2 ** self.stage_count):
                counter += 1
            else:
                self.stage_count -= 1
                counter = 0
        # print('before:', decoder_matrix, '\n', delta_x_matrix, '\n', delta_y_matrix)
        # -----------------------------------
        for i in range(len(decoder_matrix)):
            decoder_matrix[i].reverse()
        decoder_matrix.reverse()
        # -----------------------------------
        for i in range(len(delta_y_matrix)):
            delta_y_matrix[i].reverse()
        delta_y_matrix.reverse()
        # -----------------------------------
        for i in range(len(delta_x_matrix)):
            delta_x_matrix[i].reverse()
        delta_x_matrix.reverse()
        # -----------------------------------
        transpose_decoder_matrix = []
        for i in range(len(decoder_matrix[0])):
            row = []
            for item in decoder_matrix:
                row.append(item[i])
            transpose_decoder_matrix.append(row)
        decoder_matrix = transpose_decoder_matrix
        # -----------------------------------
        transpose_delta_y_matrix = []
        for i in range(len(delta_y_matrix[0])):
            row = []
            for item in delta_y_matrix:
                row.append(item[i])
            transpose_delta_y_matrix.append(row)
        delta_y_matrix = transpose_delta_y_matrix
        # -----------------------------------
        transpose_delta_x_matrix = []
        for i in range(len(delta_x_matrix[0])):
            row = []
            for item in delta_x_matrix:
                row.append(item[i])
            transpose_delta_x_matrix.append(row)
        delta_x_matrix = transpose_delta_x_matrix
        # -----------------------------------
        # print('after:', decoder_matrix, '\n', delta_x_matrix, '\n', delta_y_matrix)
        y = y0
        self.other_delta_y = 0
        # self.other_delta_x = 0
        for amount_y in range(len(decoder_matrix[0])+1):
            x = x0  # + self.other_delta_x
            if amount_y == len(decoder_matrix[0]):
                if self.XDC_inputs % 2 == 0:
                    item = 'Xnor_base'
                else:
                    item = 'Xnand_base'
                self.device_coords = self.XDC_objects_coords[item]
                op_coords = self.device_coords.get('OP')[0]
                # print('op_coords:', op_coords)
                # print('empty_op_coords:', self.empty_op_coords)
                self.insert_item = item
                x = self.empty_op_coords[0] + \
                    (self.empty_op_coords[2] - op_coords[2])*self.Lambda
                y = self.other_delta_y
                try:
                    self.num_of_blocks[self.insert_item] += 1
                except:
                    self.num_of_blocks[self.insert_item] = 0

                for j in range(len(top_area)):
                    rec = self.device_coords.get(top_area[j])
                    color = colors[j]
                    bordertype = borders[j]
                    filling = fills[j]
                    if type(rec) is list:
                        for i in range(len(rec)):
                            if j != (len(top_area)-1):
                                koeff = 1
                            else:
                                koeff = -1

                            x1 = x+rec[i][0]*self.Lambda
                            x2 = x+(rec[i][0]+rec[i][2])*self.Lambda
                            y1 = y+rec[i][1]*self.Lambda
                            y2 = y+(rec[i][1]-koeff*rec[i][3])*self.Lambda

                            rec_coord = (x1, y1, x2, y2)

                            self.create_rec_with_mem(*rec_coord, outline=color, fill=filling, dash=bordertype, tags=f'{self.insert_item}_{self.num_of_blocks[self.insert_item]}_{top_area[j]}_{i}')
                            # self.canvas.update()
            else:
                for amount_x in range(len(decoder_matrix)):
                    item = decoder_matrix[amount_x][amount_y]

                    if item == 0 and amount_x == 0:
                        delta_x_matrix[amount_x][amount_y] = delta_x_matrix[amount_x][0]
                        delta_y_matrix[amount_x][amount_y] = delta_y_matrix[-1][amount_y]
                    elif item == 0 and amount_x != 0:
                        delta_x_matrix[amount_x][amount_y] += delta_x_matrix[amount_x-1][0]
                        delta_y_matrix[amount_x][amount_y] = delta_y_matrix[-1][amount_y]

                    if amount_y != 0:
                        # y + delta_y_matrix[amount_x][amount_y-1] * self.Lambda
                        y = self.other_delta_y
                    if amount_x != 0:
                        x = x + delta_x_matrix[amount_x -
                                               1][amount_y] * self.Lambda
                    if amount_x == len(decoder_matrix)-1:
                        self.other_delta_y = y + \
                            delta_y_matrix[amount_x][amount_y] * self.Lambda

                    if item != 0:
                        self.device_coords = self.XDC_objects_coords[item]
                        self.insert_item = item
                        if item == 'Xempty':
                            self.empty_op_coords = [x, self.other_delta_y, self.device_coords.get(
                                'OP')[0][2], self.device_coords.get('OP')[0][3]]

                        try:
                            self.num_of_blocks[self.insert_item] += 1
                        except:
                            self.num_of_blocks[self.insert_item] = 0

                        for j in range(len(top_area)):
                            rec = self.device_coords.get(top_area[j])
                            color = colors[j]
                            bordertype = borders[j]
                            filling = fills[j]
                            if type(rec) is list:
                                for i in range(len(rec)):
                                    if j != (len(top_area)-1):
                                        koeff = 1
                                    else:
                                        koeff = -1

                                    x1 = x+rec[i][0]*self.Lambda
                                    x2 = x+(rec[i][0]+rec[i][2])*self.Lambda
                                    y1 = y+rec[i][1]*self.Lambda
                                    y2 = y+(rec[i][1]-koeff *
                                            rec[i][3])*self.Lambda

                                    rec_coord = (x1, y1, x2, y2)

                                    self.create_rec_with_mem(*rec_coord, outline=color, fill=filling, dash=bordertype, tags=f'{self.insert_item}_{self.num_of_blocks[self.insert_item]}_{top_area[j]}_{i}')
                                    # self.canvas.update()

    def YDC_for_full_by_matrix(self, x0, y0):
        # x0 = self.canvas.canvasx(event.x) - 3*self.Lambda # добавка чтобы сместить начало рисования в NE точку OP
        # y0 = self.canvas.canvasy(event.y) + 32*self.Lambda
        x0 = x0 - 3*self.Lambda
        y0 = y0 + 31*self.Lambda

        I = int(math.log2(self.rows))
        M = 2**I  # amount of outputs
        w = 4*self.Lambda
        a = 4*self.Lambda
        b = 4*self.Lambda
        gap = 3*self.Lambda
        big_gap = 10*self.Lambda
        L = M*b+2*gap+(M-1)*big_gap
        nw_1_x = x0-gap-I*(w+3*a)-w
        nw_2_x = nw_1_x - 5*a - self.Lambda
        NW_1_x = x0+gap
        NW_2_x = nw_1_x
        NW_1_y = y0-2*gap-3*b
        NW_2_y = y0+L+M*b+gap
        '''---------------crossbar creating--------------'''
        '''OP layer creating'''

        OP_coords = (x0+gap, y0-7*b-gap-self.Lambda, NW_2_x -
                     gap-4*I*a-w-5*self.Lambda, y0+L+(M+1)*b)
        self.create_rec_with_mem(
            *OP_coords, outline='orange', tags=f"OP_layer")

        forward = [0]*M
        revers = [0]*M
        crossbar = [0]*M
        for i in range(M):
            decimal = i
            binary = ""
            while decimal > 0:
                remainder = decimal % 2
                binary = str(remainder) + binary
                decimal = decimal // 2
            forward[i] = list(binary.zfill(I))
        for i in range(M):
            revers[i] = forward[-i-1]
            # crossbar[i] = forward[i] + revers[i]
        revers = transpose(array(revers))
        forward = transpose(array(forward))
        crossbar = transpose(column_stack(
            (forward, revers)).reshape(-1, forward.shape[1]))

        # NDiff matrix creating
        crossbar = crossbar.astype('int')
        # one way using np.where, and taking the bitwise XOR of a given value when it is either 0 or 1
        me_crossbar = where((crossbar == 0) | (crossbar == 1), crossbar ^ 1, crossbar)
        ndiff_crossbar = crossbar
        s_array = zeros((M, 2*I+1))
        for j in range(2*I+1):
            if j == 0:
                s_array[:, j] = crossbar[:, j]
            elif j == 2*I:
                s_array[:, j] = crossbar[:, -1]
            else:
                s_array[:, j] = crossbar[:, j-1] | crossbar[:, j]
        # co_crossbar=np.where((crossbar==0)|(crossbar==1), crossbar^1, crossbar)
        n = 0
        for j in range(2*I+1):
            me_crossbar = insert(me_crossbar, n, ones(M), axis=1)
            ndiff_crossbar = insert(ndiff_crossbar, n, s_array[:, j], axis=1)
            n += 2
        # print(ndiff_crossbar)
        co_crossbar = zeros((M, 4*I+1))
        co_crossbar = co_crossbar.astype('int')
        for j in range(4*I+1):
            if j % 2 == 0:
                co_crossbar[:, j] = ndiff_crossbar[:, j]

        '''-----------------------------------------------'''
        for m in range(M):
            for n in range(2*I):
                if int(crossbar[m][-n-1]) == 1:
                    crossbar_cords = (x0-(n+1)*w-n*a, y0+gap+big_gap *
                                      m+m*b*2, x0-(n+1)*(w+a), y0+gap+big_gap*m+m*b*2+2*b)
                    self.create_rec_with_mem(
                        *crossbar_cords, outline='brown', fill='brown', tags=f"{m}_{n}_DP_cross")

        for m in range(M):
            for n in range(4*I+1):
                if int(ndiff_crossbar[m][-n-1]) == 1:
                    ndiff_crossbar_coords = (
                        NW_2_x-gap-n*w, y0+gap+big_gap*m+m*b*2, NW_2_x-gap-(n+1)*w, y0+gap+big_gap*m+m*b*2+2*b)
                    self.create_rec_with_mem(
                        *ndiff_crossbar_coords, outline='green', fill='green', tags=f"{m}_{n}_DN_cross")

        for m in range(M):
            for n in range(4*I+1):
                if int(me_crossbar[m][-n-1]) == 1:
                    me_crossbar_coords = (
                        NW_2_x-gap-n*w, y0+gap+big_gap*m+m*b*2, NW_2_x-gap-(n+1)*w, y0+gap+big_gap*m+m*b*2+b)
                    self.create_rec_with_mem(
                        *me_crossbar_coords, fill='blue', outline='blue', tags=f"{m}_{n}_ME_cross")

        for m in range(M):
            for n in range(4*I+1):
                if int(co_crossbar[m][-n-1]) == 1:
                    co_crossbar_coords = (NW_2_x-gap-n*w-self.Lambda, y0+gap+big_gap*m+m*b*2+self.Lambda,
                                          NW_2_x-gap-(n+1)*w+self.Lambda, y0+gap+big_gap*m+m*b*2+b-self.Lambda)
                    self.create_rec_with_mem(
                        *co_crossbar_coords, outline='black', fill='black', tags=f"{m}_{n}_CO_cross")

        '''main block of pdiff fingers'''
        for j in range(I+1):
            T_coords = (x0-j*(w+3*a), y0-b, x0-j*(w+3*a) -
                        w, y0+L+M*b)  # + 4*b - more pmos
            B_coords_T = (x0-j*(w+3*a)-self.Lambda, y0-gap, x0 -
                          j*(w+3*a)-w+self.Lambda, y0-self.Lambda)
            # T_coords = (-j*(w+3*a), 0, -j*(w+3*a)-w, L)
            self.create_rec_with_mem(
                *T_coords, outline='brown', fill='brown', tags=f"T_DP_{j}")
            self.create_rec_with_mem(
                *B_coords_T, outline='black', fill='black', tags=f"B_T_CO_{j}")
            for i in range(M+1):
                if j != I:
                    if i == 0:
                        C_coords = (x0-j*(w+3*a)-(w+a), y0-b,
                                    x0-j*(w+3*a)-(w+2*a), y0)
                        B_coords = (x0-j*(w+3*a)-(w+a)-self.Lambda, y0-b+self.Lambda,
                                    x0-j*(w+3*a)-(w+2*a)+self.Lambda, y0-self.Lambda)
                    else:
                        C_coords = (x0-j*(w+3*a)-(w+a), y0+gap+big_gap*(i-1)+2 *
                                    b*(i-1), x0-j*(w+3*a)-(w+2*a), y0+gap+big_gap*(i-1)+2*b*i)
                        B_coords = (x0-j*(w+3*a)-(w+a)-self.Lambda, y0+gap+big_gap*(i-1)+2*b*(i-1)+self.Lambda,
                                    x0-j*(w+3*a)-(w+2*a)+self.Lambda, y0+gap+(big_gap+2*b)*(i-1)+b-self.Lambda)
                    if i != 0:
                        C_color = 'brown'
                        area = 'DP'
                    else:
                        C_color = 'green'
                        area = 'DN'
                    self.create_rec_with_mem(
                        *C_coords, outline=C_color, fill=C_color, tags=f"{j}_{i}_{area}_C")
                    self.create_rec_with_mem(
                        *B_coords, outline='black', fill='black', tags=f"{j}_{i}_CO_B")

        for i in range(M):
            metal_outline = (nw_1_x-gap, y0+gap+big_gap*i+2 *
                             w*i, x0+gap, y0+gap+big_gap*i+2*w*i+w)
            self.create_rec_with_mem(
                *metal_outline, fill='blue', outline='blue', tags=f"metal_outline_ME_{i}")

        '''NWell creating'''
        NW_coords = (NW_1_x, NW_1_y, NW_2_x, NW_2_y)
        self.create_rec_with_mem(
            *NW_coords, outline='green', dash='--', tags=f"NW_area")

        '''NMOS polarization creating'''

        for i in range(M):

            polar_met = (NW_2_x-gap-4*I*a-w, y0+gap+big_gap*i+i*b*2,
                         NW_2_x-gap-4*I*a-w-5*self.Lambda, y0+gap+big_gap*i+i*b*2+w)

            polar_coords = (NW_2_x-gap-4*I*a-w-self.Lambda, y0+gap+big_gap*i +
                            i*b*2, NW_2_x-gap-4*I*a-w-5*self.Lambda, y0+gap+big_gap*i+i*b*2+w)

            cont_coords = (NW_2_x-gap-4*I*a-w-w/2, y0+gap+big_gap*i+i*b*2+self.Lambda,
                           NW_2_x-gap-4*I*a-w-4*self.Lambda, y0+gap+big_gap*i+i*b*2+w-self.Lambda)

            self.create_rec_with_mem(
                *polar_coords, outline='brown', fill='brown', tags=f"nmos_pol_DP_{i}")

            self.create_rec_with_mem(
                *cont_coords, outline='black', fill='black', tags=f"pol_cont_CO_{i}")

            self.create_rec_with_mem(
                *polar_met, outline='blue', tags=f"pol_ME_{i}")

        '''metal layers creating'''
        # m1_vss = (nw_1_x-2*a-gap, y0+gap, nw_1_x-3*a-gap, y0+L+(M-1)*b)
        # m1_vdd = (nw_1_x-gap-a, y0-b, x0, y0)
        # m_plus = (nw_1_x-gap-a, y0-7*b-gap-self.Lambda, nw_1_x-gap, y0)
        m1_vss = (NW_2_x-gap-4*I*a-5*self.Lambda, y0+gap,
                  NW_2_x-gap-4*I*a-5*self.Lambda-w, y0+L+(M-1)*b)
        m1_vdd = (nw_1_x, y0-b, x0, y0)
        m_plus = (x0-w/2, y0-7*b-gap-self.Lambda, x0-w/2+w, y0)
        metals = [m1_vdd, m_plus, m1_vss]
        for i in range(len(metals)):
            self.create_rec_with_mem(
                *metals[i], fill='blue', outline='blue', tags=f"vdd_ME_{i}")
        '''Poly-Si creating'''
        # NMOSes gate
        '''
        P_coords_1 = (nw_1_x-2*a, y0, nw_1_x-2*a-2*self.Lambda, y0+L+(M-1)*b)
        P_coords_2 = (nw_1_x-gap, y0-b, nw_1_x-a-2*gap, y0)
        P_coords = [P_coords_1, P_coords_2]
        cont_coords = (nw_1_x-gap-self.Lambda, y0-b+self.Lambda, nw_1_x-2*gap, y0-self.Lambda)
        for i in range(2):
            self.create_rec_with_mem(*P_coords[i], outline='red', fill = 'red', tags = f"PO_nmos")
        self.create_rec_with_mem(*cont_coords, outline='black', fill = 'black', tags = f"PO_CO_nmos")
        '''
        # between pdiff polysi
        for j in range(2*I):
            if j % 2 == 0:
                P_coords = (x0-5*self.Lambda - j*2*w, y0-4*b, x0 -
                            5*self.Lambda - j*2*w - w/2, y0+L+M*b)
                P_square_coords = (x0-5*self.Lambda - j*2*w, y0+j*w+(j+1)*(2*(b+gap)),
                                   x0-5*self.Lambda - j*2*w - w, y0+(j+1)*(w+(2*(b+gap))))
                # contacts for squared PO
                CO_square_coords = (x0-6*self.Lambda - j*2*w, y0+j*w+(j+1)*(2*(b+gap))+self.Lambda,
                                    x0-4*self.Lambda - j*2*w - w, y0+(j+1)*(w+(2*(b+gap)))-self.Lambda)

            else:
                P_coords = (x0-5*self.Lambda - j*2*w, y0-7*b, x0 -
                            5*self.Lambda - j*2*w - w/2, y0+L+M*b)
                P_square_coords = (x0-5*self.Lambda - j*2*w+w/2, y0+j*w+(j+1)*(
                    2*(b+gap)), x0-5*self.Lambda - j*2*w - w/2, y0+(j+1)*(w+(2*(b+gap))))
                # contacts for squared PO
                CO_square_coords = (x0-6*self.Lambda - j*2*w+w/2, y0+j*w+(j+1)*(2*(b+gap))+self.Lambda,
                                    x0-4*self.Lambda - j*2*w - w/2, y0+(j+1)*(w+(2*(b+gap)))-self.Lambda)

            self.create_rec_with_mem(
                *P_coords, outline='red', fill='red', tags=f"area_N_PO_{j}")
            self.create_rec_with_mem(
                *P_square_coords, outline='red', fill='red', tags=f"square_N_PO_{j}")
            self.create_rec_with_mem(
                *CO_square_coords, outline='black', fill='black', tags=f"square_N_CO_{j}")

        # between ndiff polysi
        for j in range(2*I):
            P_coords = (NW_2_x-gap-5*self.Lambda - j*2*w, y0,
                        NW_2_x-gap-5*self.Lambda - j*2*w - w/2, y0+L+M*b)
            P_square_coords = (NW_2_x-gap-5*self.Lambda - j*2*w+w/2, y0+j*w+(j+1)*(
                2*(b+gap)), NW_2_x-gap-5*self.Lambda - j*2*w - w/2, y0+(j+1)*(w+(2*(b+gap))))
            # contacts for squared PO
            CO_square_coords = (NW_2_x-gap-6*self.Lambda - j*2*w+w/2, y0+j*w+(j+1)*(2*(b+gap))+self.Lambda,
                                NW_2_x-gap-4*self.Lambda - j*2*w - w/2, y0+(j+1)*(w+(2*(b+gap)))-self.Lambda)

            self.create_rec_with_mem(
                *P_coords, outline='red', fill='red', tags=f"area_P_PO_{j}")
            self.create_rec_with_mem(
                *P_square_coords, outline='red', fill='red', tags=f"square_P_PO_{j}")
            self.create_rec_with_mem(
                *CO_square_coords, outline='black', fill='black', tags=f"square_P_CO_{j}")

        # metals creating between PO squares in P and N wells
        for j in range(2*I):
            if j % 2 == 0:
                ME_coords = (x0-5*self.Lambda - j*2*w, y0+j*w+(j+1)*(2*(b+gap)),
                             NW_2_x-gap-5*self.Lambda - j*2*w - w/2, y0+(j+1)*(w+(2*(b+gap))))
            else:
                ME_coords = (x0-5*self.Lambda - j*2*w+w/2, y0+j*w+(j+1)*(2*(b+gap)),
                             NW_2_x-gap-5*self.Lambda - j*2*w - w/2, y0+(j+1)*(w+(2*(b+gap))))
            self.create_rec_with_mem(*ME_coords, fill='blue', outline='blue', tags=f"between_po_squares_ME_{j}")

        '''--------------------Invertors creating-----------------'''
        # -----------PDiff creating----------
        for j in range(I):
            PDiff_cooords = (x0-j*(w+3*a)-(w+a), y0-3*b-gap,
                             x0-j*(w+3*a)-(w+4*a), y0-b-gap)
            self.create_rec_with_mem(*PDiff_cooords, outline='brown', fill='brown', tags=f"inv_DP_{j}")
            PDiff_pol = (x0-j*(w+3*a)-(w+3*a), y0-6*b-gap-b/2-self.Lambda,
                         x0-j*(w+3*a)-(w+4*a), y0-5*b-gap-b/2-self.Lambda)
            self.create_rec_with_mem(*PDiff_pol, outline='brown', fill='brown', tags=f"inv_pol_DP_{j}")
            PDiff_pol_CO = (x0-j*(w+3*a)-(w+3*a)-self.Lambda, y0-6 *
                            b-gap-b/2, x0-j*(w+3*a)-(w+4*a)+self.Lambda, y0-6*b-gap)
            self.create_rec_with_mem(*PDiff_pol_CO, outline='black', fill='black', tags=f"inv_DP_pol_CO_{j}")
            for v in range(2):
                PDiff_CO = (x0-j*(w+3*a)-(w+a)-self.Lambda-v*2*a, y0-2*b-gap+self.Lambda,
                            x0-j*(w+3*a)-(w+a)-self.Lambda-a/2-v*2*a, y0-b-gap-self.Lambda)
                self.create_rec_with_mem(*PDiff_CO, outline='black', fill='black', tags=f"inv_DP_CO_{j}{v}")
        # -----------NDiff creating----------
        for j in range(I):
            NDiff_coords = (x0-j*(w+3*a)-(w+a), y0-5*b-gap-b/2,
                            x0-j*(w+3*a)-(w+4*a), y0-4*b-gap-b/2)
            self.create_rec_with_mem(*NDiff_coords, outline='green', fill='green', tags=f"inv_DN_{j}")
            for v in range(2):
                NDiff_CO = (x0-j*(w+3*a)-(w+a)-self.Lambda-v*2*a, y0-5*b-gap-b/2+self.Lambda,
                            x0-j*(w+3*a)-(w+a)-self.Lambda-a/2-v*2*a, y0-4*b-gap-b/2-self.Lambda)
                self.create_rec_with_mem(*NDiff_CO, outline='black', fill='black', tags=f"inv_DN_CO_{j}{v}")

        # -----------POlySi creating----------
        for j in range(2*I):
            # polysi creating and metall on polysi creating
            if j % 2 == 0:
                PO_coords = (x0-5*self.Lambda - j*2*w, y0-5*b,
                             x0-5*self.Lambda - j*2*w-b, y0-4*b)
                PO_ME = (x0-5*self.Lambda - j*2*w, y0-5*b,
                         x0-5*self.Lambda - j*2*w-b, y0-4*b)
                PO_CO = (x0-6*self.Lambda - j*2*w, y0-5*b+self.Lambda,
                         x0-4*self.Lambda - j*2*w-b, y0-4*b-self.Lambda)
            else:
                PO_coords = (x0-5*self.Lambda - j*2*w+a, y0-8*b,
                             x0-5*self.Lambda - j*2*w, y0-7*b+b/2)
                PO_ME = (x0-5*self.Lambda - j*2*w+a, y0-8 *
                         b, x0-5*self.Lambda - j*2*w, y0-7*b)
                PO_CO = (x0-6*self.Lambda - j*2*w+a, y0-8*b+self.Lambda,
                         x0-4*self.Lambda - j*2*w, y0-7*b-self.Lambda)
            self.create_rec_with_mem(
                *PO_coords, outline='red', fill='red', tags=f"area_PO_{j}")
            self.create_rec_with_mem(
                *PO_ME, outline='blue', tags=f"area_PO_ME_{j}")
            self.create_rec_with_mem(
                *PO_CO, outline='black', fill='black', tags=f"area_PO_CO_{j}")
        # -----------MEtall creating----------
        ''''''
        for j in range(I):
            ME_coords = (x0-j*(w+3*a)-(w+a), y0-5*b-gap-b /
                         2, x0-j*(w+3*a)-(w+2*a), y0-b-gap)
            self.create_rec_with_mem(*ME_coords, fill='blue', outline='blue', tags= f"inv_ME_{j}")
        ''''''
        for j in range(1, I+1):
            ME_coords = [(x0-j*(w+3*a), y0-2*b-gap, x0-j*(w+3*a)-w, y0), (x0-j *
                                                                          (w+3*a), y0-6*b-gap-b/2-self.Lambda, x0-j*(w+3*a)-w, y0-4*b-gap-b/2)]
            for v in range(len(ME_coords)):
                self.create_rec_with_mem(*ME_coords[v], fill='blue', outline='blue', tags= f"inv_ME_{j}")
        # -----------VIa creating----------
        for j in range(I):
            VI_coords = (x0-j*(w+3*a)-(w+a)-self.Lambda-2*a, y0-5*b-gap-b/2+self.Lambda,
                         x0-j*(w+3*a)-(w+a)-self.Lambda-a/2-2*a, y0-4*b-gap-b/2-self.Lambda)
            self.create_rec_with_mem(*VI_coords, outline='gray', fill='gray', tags= f"inv_VI_{j}")
            ME2_coords = (x0-j*(w+3*a)-(w+a)-2*a, y0-5*b-gap-b/2,
                          x0-j*(w+3*a)-(w+a)-3*a, y0-4*b-gap-b/2)
            self.create_rec_with_mem(*ME2_coords, outline='#00008B', fill='#00008B', dash= '-.', tags = f"inv_M2_{j}")

        # -----------VI for vss creating----------
        VI_pol = (NW_2_x-gap-4*I*a-self.Lambda, y0+gap+self.Lambda,
                  NW_2_x-gap-4*I*a-w+self.Lambda, y0+(gap+w)-self.Lambda)
        self.create_rec_with_mem(*VI_pol, outline='gray', fill='gray', tags= "VI_pol")
        # -----------ME2 creating----------
        ME2_coords = (x0-(w+a), y0-5*b-gap, NW_2_x-gap-4*I*a-w, y0-4*b-gap)
        self.create_rec_with_mem(*ME2_coords, outline='#00008B', fill='#00008B', dash= '-.', tags = "M2_vss")
        ME2_coords = (NW_2_x-gap-4*I*a, y0-7*b-gap -
                      self.Lambda, NW_2_x-gap-4*I*a-w, y0+b+gap)
        self.create_rec_with_mem(*ME2_coords, outline='#00008B', fill='#00008B', dash= '-.', tags = "M2_vss")
        '''-------------------------------------------------------'''

    def YDC_for_full_by_blocks(self, x0, y0):
        self.YDC_inputs = int(math.log2(self.rows))
        self.YDC_outputs = self.rows
        coulumns_amount = 0
        for i in range(0, (self.YDC_inputs - 2), 1):
            coulumns_amount = coulumns_amount + 2**i + 1

        decoder_matrix = [0]*coulumns_amount
        delta_y_matrix = [0]*coulumns_amount
        delta_x_matrix = [0]*coulumns_amount
        counter = 0
        self.stage_count = 0

        # минус 2 поскольку нулевой stage это и есть базовый DC
        for stage in range(coulumns_amount, 0, -1):
            if stage == coulumns_amount:
                self.stage_count = (self.YDC_inputs - 2) - 1
            stage_list = ['None']*(self.YDC_outputs//4+1)
            delta_y_list = ['None']*(self.YDC_outputs//4+1)
            delta_x_list = ['None']*(self.YDC_outputs//4+1)
            amount_of_objects = (2**(self.stage_count+1))//2  # (2**stage)//2
            if counter == 0:
                if self.YDC_inputs % 2 == 0 and (stage) % 2 == 0:   # base_nor
                    inv_block = 'Yforward_inv'
                    first_block = 'YNnands'
                    inverse_for_first = 'Ynands'
                # base_nand
                elif self.YDC_inputs % 2 != 0 and (stage) % 2 == 0:
                    inv_block = 'Ybackward_inv'
                    first_block = 'Ynors'
                    inverse_for_first = 'YNnors'
                elif self.YDC_inputs % 2 == 0 and (stage) % 2 != 0:  # base_nor
                    inv_block = 'Ybackward_inv'
                    first_block = 'Ynors'
                    inverse_for_first = 'YNnors'
                # base_nand
                elif self.YDC_inputs % 2 != 0 and (stage) % 2 != 0:
                    inv_block = 'Yforward_inv'
                    first_block = 'YNnands'
                    inverse_for_first = 'Ynands'
                stage_list[0] = inv_block
                item_coords = self.YDC_objects_coords[inv_block]
            else:
                empty_block = 'Yempty'
                stage_list[0] = empty_block
                item_coords = self.YDC_objects_coords[empty_block]
            item_coords = item_coords.get(top_area[len(top_area)-1])
            delta_y_list[0] = item_coords[0][3]
            delta_x_list[0] = item_coords[0][2]
            for h in range(2*amount_of_objects):
                if h < amount_of_objects:
                    if counter == 0:
                        stage_list[h+1] = first_block
                        item_coords = self.YDC_objects_coords[first_block]
                        item_coords = item_coords.get(
                            top_area[len(top_area)-1])
                        delta_y_list[h+1] = item_coords[0][3]
                        delta_x_list[h+1] = item_coords[0][2]
                    else:
                        if counter == (h + 1):
                            YT_block = 'YT'
                            stage_list[h+1] = YT_block
                            item_coords = self.YDC_objects_coords[YT_block]
                            item_coords = item_coords.get(
                                top_area[len(top_area)-1])
                            delta_y_list[h+1] = item_coords[0][3]
                            delta_x_list[h+1] = item_coords[0][2]
                        elif counter > (h + 1):
                            YC_block = 'YC'
                            stage_list[h+1] = YC_block
                            item_coords = self.YDC_objects_coords[YC_block]
                            item_coords = item_coords.get(
                                top_area[len(top_area)-1])
                            delta_y_list[h+1] = item_coords[0][3]
                            delta_x_list[h+1] = item_coords[0][2]
                        elif counter < (h + 1):
                            YH_block = 'YH'
                            stage_list[h+1] = YH_block
                            item_coords = self.YDC_objects_coords[YH_block]
                            item_coords = item_coords.get(
                                top_area[len(top_area)-1])
                            delta_y_list[h+1] = item_coords[0][3]
                            delta_x_list[h+1] = item_coords[0][2]
                else:
                    if counter == 0:
                        stage_list[h+1] = inverse_for_first
                        item_coords = self.YDC_objects_coords[inverse_for_first]
                        item_coords = item_coords.get(
                            top_area[len(top_area)-1])
                        delta_y_list[h+1] = item_coords[0][3]
                        delta_x_list[h+1] = item_coords[0][2]
                    else:
                        if counter == (h + 1) - amount_of_objects:
                            YL_block = 'YL'
                            stage_list[h+1] = YL_block
                            item_coords = self.YDC_objects_coords[YL_block]
                            item_coords = item_coords.get(
                                top_area[len(top_area)-1])
                            delta_y_list[h+1] = item_coords[0][3]
                            delta_x_list[h+1] = item_coords[0][2]
                        elif counter > (h + 1) - amount_of_objects:
                            YII_block = 'YII'
                            stage_list[h+1] = YII_block
                            item_coords = self.YDC_objects_coords[YII_block]
                            item_coords = item_coords.get(
                                top_area[len(top_area)-1])
                            delta_y_list[h+1] = item_coords[0][3]
                            delta_x_list[h+1] = item_coords[0][2]
                        elif counter < (h + 1) - amount_of_objects:
                            YC_block = 'YC'
                            stage_list[h+1] = YC_block
                            item_coords = self.YDC_objects_coords[YC_block]
                            item_coords = item_coords.get(
                                top_area[len(top_area)-1])
                            delta_y_list[h+1] = item_coords[0][3]
                            delta_x_list[h+1] = item_coords[0][2]

            decoder_matrix[stage-1] = stage_list
            delta_y_matrix[stage-1] = delta_y_list
            delta_x_matrix[stage-1] = delta_x_list
            if counter < (2 ** self.stage_count):
                counter += 1
            else:
                self.stage_count -= 1
                counter = 0
        # print(decoder_matrix, '\n', delta_y_matrix, '\n', delta_x_matrix)
        y = y0
        self.other_delta_y = 0
        for amount_y in range(self.YDC_outputs//4+1):
            if amount_y != 0:
                # y + delta_y_matrix[self.YDC_inputs-3][amount_y] * self.Lambda
                y = self.other_delta_y
            x = x0
            for amount_x in range(coulumns_amount - 1, -2, -1):
                if amount_x == -1 and amount_y == 0:
                    if self.YDC_inputs % 2 == 0:
                        item = 'Ynor_base'
                    else:
                        item = 'Ynand_base'
                    self.device_coords = self.YDC_objects_coords[item]
                    self.insert_item = item
                    item_coords = self.YDC_objects_coords[item]
                    item_coords = item_coords.get(top_area[len(top_area)-1])
                    x = x - item_coords[0][2] * self.Lambda
                    y = y0
                elif amount_x >= 0:
                    item = decoder_matrix[amount_x][amount_y]
                    if item != 'None':
                        self.device_coords = self.YDC_objects_coords[item]
                        self.insert_item = item
                    try:
                        if amount_x != coulumns_amount-1:
                            x = x - \
                                delta_x_matrix[amount_x][amount_y] * \
                                self.Lambda
                    except:
                        pass
                    if decoder_matrix[amount_x][amount_y] != decoder_matrix[amount_x-1][amount_y]:
                        # y = y + (delta_y_matrix[amount_x-1][amount_y] - delta_y_matrix[amount_x][amount_y]) * self.Lambda

                        if (item == 'Ynands' or item == 'Ynors'):
                            y = y + (delta_y_matrix[coulumns_amount-1][amount_y] -
                                     delta_y_matrix[amount_x][amount_y]) * self.Lambda
                        elif (item == 'YNnands' or item == 'YNnors'):
                            y = y + (delta_y_matrix[coulumns_amount-1][amount_y] -
                                     delta_y_matrix[amount_x][amount_y]) * self.Lambda

                    if item != decoder_matrix[amount_x-1][amount_y]:
                        self.other_delta_y = y + (self.device_coords.get(top_area[len(top_area)-1])[
                                                  0][1]+self.device_coords.get(top_area[len(top_area)-1])[0][3])*self.Lambda
                    # print(decoder_matrix[amount_x][amount_y])
                if (amount_y == 0 and amount_x == -1) or amount_x >= 0:
                    try:
                        self.num_of_blocks[self.insert_item] += 1
                    except:
                        self.num_of_blocks[self.insert_item] = 0

                    for j in range(len(top_area)):
                        rec = self.device_coords.get(top_area[j])
                        color = colors[j]
                        bordertype = borders[j]
                        filling = fills[j]
                        if type(rec) is list:
                            for i in range(len(rec)):
                                if j != (len(top_area)-1):
                                    koeff = 1
                                else:
                                    koeff = -1

                                x1 = x+rec[i][0]*self.Lambda
                                x2 = x+(rec[i][0]+rec[i][2])*self.Lambda
                                y1 = y+rec[i][1]*self.Lambda
                                y2 = y+(rec[i][1]-koeff*rec[i][3])*self.Lambda

                                rec_coord = (x1, y1, x2, y2)

                                self.create_rec_with_mem(*rec_coord, outline=color, fill=filling, dash=bordertype, tags=f'{self.insert_item}_{self.num_of_blocks[self.insert_item]}_{top_area[j]}_{i}')
                                # self.canvas.update()

    def synthesis_MW(self, event):
        self.GridUnits = self.GridLambda.get()
        # self.GridUnits = self.form.get_tech()
        if self.GridUnits == 0:
            messagebox.showerror("Error", "Choose foundry, please")
        else:
            self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
            if self.synthesisAcces == 0 and (self.insertAccess == 1 or self.multiplyAccess == 1 or self.y_decoder_access == 1):
                pass
            elif self.synthesisAcces == 1:
                self.multiplyAccess = 0
                self.insertAccess = 0
                self.synthesisAcces = 0
                self.another_delta_y = 0
                self.y_decoder_access = 0
                x0 = 0  # self.canvas.canvasx(event.x)
                y0 = 0  # self.canvas.canvasy(event.y)
                amount_of_objects = 17
                # print(self.choosed_blocks)

                for l in range(-1, amount_of_objects):
                    # -----------PC_BLOCK SYNTHESIS-------------------------------

                    if l == -1:
                        # print(self.device_coords_PC)
                        delta = self.device_coords_PC.get(
                            top_area['Microwind65'][len(top_area['Microwind65'])-1])
                        rows = 1
                        columns = self.columns
                        self.ObjectCoords = self.device_coords_PC
                        insert_block = self.insert_item_PC
                        delta_x = delta[0][2]
                        delta_y = delta[0][3]
                    # -----------bottom_pc_empty_block SYNTHESIS-------------------------------
                    elif l == 0:
                        delta = self.device_coords_bottom_pc_empty.get(
                            top_area['Microwind65'][len(top_area['Microwind65'])-1])
                        rows = 1
                        columns = self.columns
                        self.ObjectCoords = self.device_coords_bottom_pc_empty
                        insert_block = self.insert_item_bottom_pc_empty
                        delta_x = delta[0][2]
                        delta_y = delta[0][3]
                    # -----------CELL_BLOCK SYNTHESIS-------------------------------
                    elif l == 1:
                        delta = self.device_coords_CELL.get('OP')
                        rows = self.rows
                        columns = self.columns
                        self.ObjectCoords = self.device_coords_CELL
                        insert_block = self.insert_item_CELL
                        delta_x = delta[0][2]
                        delta_y = delta[0][3]
                    # -----------BUFF_BLOCK SYNTHESIS-------------------------------
                    elif l == 2:
                        delta = self.device_coords_BUFF.get(
                            top_area['Microwind65'][len(top_area['Microwind65'])-1])
                        rows = 1
                        columns = self.columns
                        self.ObjectCoords = self.device_coords_BUFF
                        insert_block = self.insert_item_BUFF
                        delta_x = delta[0][2]
                        delta_y = delta[0][3]
                    # -----------PULSE_BLOCK SYNTHESIS-------------------------------
                    elif l == 3:
                        delta_pulsey = self.device_coords_pulsey.get(
                            top_area['Microwind65'][len(top_area['Microwind65'])-1])
                        rows = int(self.rows/2)
                        columns = 1
                        delta_x_pulsey = delta_pulsey[0][2]
                        delta_y_pulsey = delta_pulsey[0][3]
                        delta_y = 0
                        delta_x = 0
                    # -----------OUT_BLOCK SYNTHESIS-------------------------------
                    elif l == 4:
                        delta = self.device_coords_OUT.get(
                            top_area['Microwind65'][len(top_area['Microwind65'])-1])
                        rows = 1
                        columns = 1
                        self.ObjectCoords = self.device_coords_OUT
                        insert_block = self.insert_item_OUT
                        delta_x = delta[0][2]
                        delta_y = delta[0][3]
                    # -----------RSA_BLOCK SYNTHESIS-------------------------------
                    elif l == 5:
                        delta = self.device_coords_RSA.get(
                            top_area['Microwind65'][len(top_area['Microwind65'])-1])
                        rows = 1
                        columns = 1
                        self.ObjectCoords = self.device_coords_RSA
                        insert_block = self.insert_item_RSA
                        delta_x = delta[0][2]
                        delta_y = delta[0][3]
                    # -----------WR_BLOCK SYNTHESIS-------------------------------
                    elif l == 6:
                        delta = self.device_coords_WR.get(
                            top_area['Microwind65'][len(top_area['Microwind65'])-1])
                        rows = 1
                        columns = 1
                        self.ObjectCoords = self.device_coords_WR
                        insert_block = self.insert_item_WR
                        delta_x = delta[0][2]
                        delta_y = delta[0][3]
                    # -----------CTRL_BLOCK SYNTHESIS-------------------------------
                    elif l == 7:
                        delta = self.device_coords_CTRL.get(
                            top_area['Microwind65'][len(top_area['Microwind65'])-1])
                        rows = 1
                        columns = 1
                        self.ObjectCoords = self.device_coords_CTRL
                        insert_block = self.insert_item_CTRL
                        delta_x = delta[0][2]
                        delta_y = delta[0][3]
                    # -----------top_pulse_empty_block SYNTHESIS-------------------------------
                    elif l == 8:
                        delta = self.device_coords_top_pulse_empty.get(
                            top_area['Microwind65'][len(top_area['Microwind65'])-1])
                        rows = 1
                        columns = 1
                        self.ObjectCoords = self.device_coords_top_pulse_empty
                        insert_block = self.insert_item_top_pulse_empty
                        delta_x = delta[0][2]
                        delta_y = delta[0][3]
                    # -----------for_pc_ctrl_block SYNTHESIS-------------------------------
                    elif l == 9:
                        delta = self.device_coords_for_pc_ctrl.get(
                            top_area['Microwind65'][len(top_area['Microwind65'])-1])
                        rows = 1
                        columns = 1
                        self.ObjectCoords = self.device_coords_for_pc_ctrl
                        insert_block = self.insert_item_for_pc_ctrl
                        delta_x = delta[0][2]
                        delta_y = delta[0][3]
                    # -----------Y Decoder SYNTHESIS-------------------------------
                    elif l == 10:
                        axis = 'Y'
                        angle = 0
                        mirr_axis = None
                        I = int(math.log2(self.rows))
                        dop_shift = 0
                        self.compact_matrix_DC_MW(
                            self.pulse_x_for_ydc, self.pulse_y_for_ydc, self.Lambda, axis, angle, I, mirr_axis, dop_shift)
                        # self.YDC_for_full_by_matrix(self.pulse_x_for_ydc,self.pulse_y_for_ydc)
                        rows = 0
                        columns = 0

                        '''
                        self.YDC_for_full_by_blocks(self.pulse_x_for_ydc,self.pulse_y_for_ydc)
                        rows = 0
                        columns = 0
                        '''

                    # -----------Y_CONNECT SYNTHESIS-------------------------------
                    elif l == 11:
                        delta = self.device_coords_y_connect.get(
                            top_area['Microwind65'][len(top_area['Microwind65'])-1])
                        rows = 1
                        columns = 1
                        self.ObjectCoords = self.device_coords_y_connect
                        insert_block = self.insert_item_y_connect
                        delta_x = delta[0][2]
                        delta_y = delta[0][3]
                    # -----------X_CONNECT and PULSEX ROW SYNTHESIS---------------
                    elif l == 12:
                        pulsex_op_coords = self.XCONNECT_for_full(
                            x0, self.XCONNECT_y0)
                        rows = 0
                        columns = 0
                    # -----------X Decoder SYNTHESIS-------------------------------
                    elif l == 13:
                        x0_for_XDC = pulsex_op_coords[0]
                        y0_for_XDC = pulsex_op_coords[1]
                        axis = 'X'
                        angle = pi/2
                        mirr_axis = None
                        b = 4*self.Lambda
                        gap = 3*self.Lambda
                        I = int(math.log2(self.columns))
                        dop_shift = 0  # 27*self.Lambda
                        self.matrixDC(x0_for_XDC - 13*b/2 - 2*gap + b, y0_for_XDC,
                                      self.Lambda, axis, angle, I, mirr_axis, dop_shift)
                        rows = 0
                        columns = 0

                    # -----------_VddLine_block SYNTHESIS-------------------------------
                    elif l == 14:
                        delta = self.device_coords_vdd_line.get(
                            top_area['Microwind65'][len(top_area['Microwind65'])-1])
                        rows = self.rows
                        columns = 1
                        self.ObjectCoords = self.device_coords_vdd_line
                        insert_block = self.insert_item_vdd_line
                        delta_x = delta[0][2]
                        delta_y = delta[0][3]
                    # -----------_VddTop_block SYNTHESIS-------------------------------
                    elif l == 15:
                        delta = self.device_coords_vdd_top.get(
                            top_area['Microwind65'][len(top_area['Microwind65'])-1])
                        rows = 1
                        columns = 1
                        self.ObjectCoords = self.device_coords_vdd_top
                        insert_block = self.insert_item_vdd_top
                        delta_x = delta[0][2]
                        delta_y = delta[0][3]
                    # ----------- vdd_pulsex SYNTHESIS-------------------------------
                    elif l == 16:
                        delta = self.device_coords_vdd_pulsex.get(
                            top_area['Microwind65'][len(top_area['Microwind65'])-1])
                        rows = 1
                        columns = 1
                        self.ObjectCoords = self.device_coords_vdd_pulsex
                        insert_block = self.insert_item_vdd_pulsex
                        delta_x = delta[0][2]
                        delta_y = delta[0][3]
                    # ------------------------------------------------------------------
                    if l == 1:
                        self.PulseY_delta = self.another_delta_y
                        self.for_empty_top_pulse_y = self.PulseY_delta
                        self.vdd_lineY_delta = self.PulseY_delta
                    elif l == 2:
                        self.OUT_delta_y = self.another_delta_y
                        self.BUFF_y_end = self.another_delta_y + \
                            (delta[0][3] - delta[0][1])*self.Lambda
                        self.XCONNECT_y0 = self.BUFF_y_end
                        self.CTRL_delta_y = self.BUFF_y_end
                    elif l == 4:
                        self.RSA_delta_y = self.OUT_delta_y + \
                            (delta[0][3])*self.Lambda

                    if l == 3:
                        y = y0 + self.PulseY_delta
                    elif l == 4:
                        y = y0 + self.OUT_delta_y
                    elif l == 5:
                        y = y0 + self.RSA_delta_y
                    elif l == 6:
                        self.WR_delta_y = self.BUFF_y_end - \
                            (delta[0][3] - delta[0][1])*self.Lambda
                        y = y0 + self.WR_delta_y
                        self.for_y_connect_y = y
                    elif l == 7:
                        y = y0 + self.CTRL_delta_y
                    elif l == 8 or l == 15:
                        y = self.for_empty_top_pulse_y - delta_y * self.Lambda
                        self.pulse_y_for_ydc = y
                    elif l == 9:
                        y = y0
                    elif l == 11:
                        y = self.for_y_connect_y - delta_y * self.Lambda
                    elif l == 14:
                        y = y0 + self.vdd_lineY_delta
                    elif l == 16:
                        x = x0_for_XDC - delta_x * self.Lambda
                        y = y0_for_XDC - delta_y * self.Lambda
                    else:
                        y = y0 + self.another_delta_y

                    for amount_y in range(rows):

                        if l == 3:
                            # delta_y == delta_y_pulsey
                            self.ObjectCoords = self.device_coords_pulsey
                            self.insert_item = self.insert_item_pulsey
                            insert_block = self.insert_item_pulsey
                            delta = delta_pulsey

                        if amount_y != 0:
                            if l == 3:
                                delta_y = delta_y_pulsey
                            y = y + delta_y * self.Lambda

                        # yOP_1 = y + delta[0][1]*self.Lambda
                        yOP_2 = y + (delta[0][1]+delta[0][3])*self.Lambda

                        if amount_y == rows - 1 and l != 3:
                            self.another_delta_y = yOP_2

                        x = x0
                        if l == 1:
                            yOP_1 = y + delta[0][1]*self.Lambda
                            yOP_2 = y + (delta[0][1]+delta[0][3])*self.Lambda
                        for amount_x in range(columns):
                            if not self.canvas.find_all():
                                self.num_of_blocks[self.insert_item_PC] = 0
                                self.num_of_blocks[self.insert_item_bottom_pc_empty] = 0
                                self.num_of_blocks[self.insert_item_top_pulse_empty] = 0
                                self.num_of_blocks[self.insert_item_for_pc_ctrl] = 0
                                self.num_of_blocks[self.insert_item_CELL] = 0
                                self.num_of_blocks[self.insert_item_BUFF] = 0
                                self.num_of_blocks[self.insert_item_pulsey] = 0
                                self.num_of_blocks[self.insert_item_OUT] = 0
                                self.num_of_blocks[self.insert_item_RSA] = 0
                                self.num_of_blocks[self.insert_item_WR] = 0
                                self.num_of_blocks[self.insert_item_CTRL] = 0
                                self.num_of_blocks[self.insert_item_y_connect] = 0
                                self.num_of_blocks[self.insert_item_vdd_line] = 0
                                self.num_of_blocks[self.insert_item_vdd_top] = 0
                                self.num_of_blocks[self.insert_item_vdd_pulsex] = 0
                            else:
                                if l == -1 and self.choosed_blocks['PC']:
                                    self.num_of_blocks[self.insert_item_PC] += 1
                                elif l == 0 and self.choosed_blocks['bottomPC']:
                                    self.num_of_blocks[self.insert_item_bottom_pc_empty] += 1
                                elif l == 1 and self.choosed_blocks['SRAM']:
                                    self.num_of_blocks[self.insert_item_CELL] += 1
                                elif l == 2 and self.choosed_blocks['BUFFER']:
                                    self.num_of_blocks[self.insert_item_BUFF] += 1
                                elif l == 3 and self.choosed_blocks['PULSEY']:
                                    self.num_of_blocks[self.insert_item_pulsey] += 1
                                elif l == 4 and self.choosed_blocks['OUT']:
                                    self.num_of_blocks[self.insert_item_OUT] += 1
                                elif l == 5 and self.choosed_blocks['RSA']:
                                    self.num_of_blocks[self.insert_item_RSA] += 1
                                elif l == 6 and self.choosed_blocks['WRITE']:
                                    self.num_of_blocks[self.insert_item_WR] += 1
                                elif l == 7 and self.choosed_blocks['CONTROL']:
                                    self.num_of_blocks[self.insert_item_CTRL] += 1
                                elif l == 8 and self.choosed_blocks['topPULSE']:
                                    self.num_of_blocks[self.insert_item_top_pulse_empty] += 1
                                elif l == 9 and self.choosed_blocks['forPCctrl']:
                                    self.num_of_blocks[self.insert_item_for_pc_ctrl] += 1
                                elif l == 11 and self.choosed_blocks['YCONNECT']:
                                    self.num_of_blocks[self.insert_item_y_connect] += 1
                                elif l == 14 and self.choosed_blocks['VddLine']:
                                    self.num_of_blocks[self.insert_item_vdd_line] += 1
                                elif l == 15 and self.choosed_blocks['VddTop']:
                                    self.num_of_blocks[self.insert_item_vdd_top] += 1
                                elif l == 16 and self.choosed_blocks['vddpulsex']:
                                    self.num_of_blocks[self.insert_item_vdd_pulsex] += 1

                            # and l != 4:
                            if (amount_x != 0 and l != 3) or l == 6 or l == 7:
                                if l == 6 or l == 7:
                                    delta_x = -delta[0][2]
                                x = x + delta_x * self.Lambda
                                self.for_y_connect_x = x

                            elif l == 3:
                                delta_x = -delta_x_pulsey
                                x = x + delta_x * self.Lambda
                                self.for_empty_top_pulse_x = x

                            if l == 4 or l == 5 or l == 14 or l == 15:
                                x = self.OUT_delta_x
                            elif l == 8:
                                # by matrix
                                x = self.for_empty_top_pulse_x
                                self.pulse_x_for_ydc = self.for_empty_top_pulse_x
                                ''' #by blocks
                                x = self.for_empty_top_pulse_x
                                if int(math.log2(self.rows)) < 3:
                                    self.pulse_x_for_ydc = x
                                else:
                                    self.pulse_x_for_ydc = 2*x
                                '''
                            elif l == 9:
                                x = x0 - delta_x * self.Lambda

                            elif l == 11:
                                x = self.for_y_connect_x

                            # xOP_1 = x + delta[0][0]*self.Lambda
                            xOP_2 = x + (delta[0][0]+delta[0][2])*self.Lambda

                            if l == 2:
                                self.OUT_delta_x = xOP_2
                            if l == 1:
                                xOP_1 = x + delta[0][0]*self.Lambda
                                xOP_2 = x + \
                                    (delta[0][0]+delta[0][2])*self.Lambda

                            # print(insert_block)
                            if self.choosed_blocks[insert_block]:
                                # print(insert_block, self.choosed_blocks[insert_block])
                                for j in range(len(top_area['Microwind65'])):
                                    rec = self.ObjectCoords.get(
                                        top_area['Microwind65'][j])
                                    color = colors['Microwind65'][j]
                                    bordertype = borders['Microwind65'][j]
                                    filling = fills['Microwind65'][j]
                                    if type(rec) is list:
                                        for i in range(len(rec)):

                                            rec_coord = (x + rec[i][0] * self.Lambda, y + rec[i][1] * self.Lambda, x + (
                                                rec[i][0] + rec[i][2]) * self.Lambda, y + (rec[i][1] + rec[i][3]) * self.Lambda)

                                            if l == 1:
                                                if amount_x % 2 != 0:
                                                    rec_coord = self.mirror_shape(
                                                        rec_coord, (xOP_1 + xOP_2)/2, 0, 'Y')
                                                if amount_y % 2 != 0:
                                                    rec_coord = self.mirror_shape(
                                                        rec_coord, 0, (yOP_1 + yOP_2)/2, 'X')
                                            self.create_rec_with_mem(*rec_coord, outline=color, fill=filling, dash=bordertype, tags=f'{insert_block}_{self.num_of_blocks[insert_block]}_{top_area["Microwind65"][j]}_{i}')
                                            # self.canvas.update()

    def synthesis_SW(self, event):
        self.GridUnits = self.GridLambda.get()
        if self.GridUnits == 0:
            messagebox.showerror("Error", "Choose foundry, please")
            return
        
        self.Lambda = self.GridUnits * self.scale**self.wheel_count
        
        if self.synthesisAcces == 0 and (self.insertAccess == 1 or self.multiplyAccess == 1 or self.y_decoder_access == 1):
            return
        
        self.multiplyAccess = 0
        self.insertAccess = 0
        self.synthesisAcces = 0
        self.another_delta_y = 0
        self.y_decoder_access = 0
        x0 = 0
        y0 = 0
        
        # Предварительно определим все блоки и их параметры
        blocks_config = [
            # l=-1: PC_BLOCK
            {'delta': self.device_coords_PC['OP'], 'rows': 1, 'columns': self.columns, 
             'coords': self.device_coords_PC, 'insert_block': self.insert_item_PC, 'block_key': 'PC'},
            # l=0: bottom_pc_empty_block
            {'delta': self.device_coords_bottom_pc_empty['OP'], 'rows': 1, 'columns': self.columns, 
             'coords': self.device_coords_bottom_pc_empty, 'insert_block': self.insert_item_bottom_pc_empty, 'block_key': 'bottomPC'},
            # l=1: CELL_BLOCK
            {'delta': self.device_coords_CELL['OP'], 'rows': self.rows, 'columns': self.columns, 
             'coords': self.device_coords_CELL, 'insert_block': self.insert_item_CELL, 'block_key': 'SRAM'},
            # l=2: BUFF_BLOCK
            {'delta': self.device_coords_BUFF['OP'], 'rows': 1, 'columns': self.columns, 
             'coords': self.device_coords_BUFF, 'insert_block': self.insert_item_BUFF, 'block_key': 'BUFFER'},
            # l=3: PULSE_BLOCK
            {'delta': self.device_coords_pulsey['OP'], 'rows': int(self.rows/2), 'columns': 1, 
             'coords': self.device_coords_pulsey, 'insert_block': self.insert_item_pulsey, 'block_key': 'PULSEY'},
            # l=4: OUT_BLOCK
            {'delta': self.device_coords_OUT['OP'], 'rows': 1, 'columns': 1, 
             'coords': self.device_coords_OUT, 'insert_block': self.insert_item_OUT, 'block_key': 'OUT'},
            # l=5: RSA_BLOCK
            {'delta': self.device_coords_RSA['OP'], 'rows': 1, 'columns': 1, 
             'coords': self.device_coords_RSA, 'insert_block': self.insert_item_RSA, 'block_key': 'RSA'},
            # l=6: WR_BLOCK
            {'delta': self.device_coords_WR['OP'], 'rows': 1, 'columns': 1, 
             'coords': self.device_coords_WR, 'insert_block': self.insert_item_WR, 'block_key': 'WRITE'},
            # l=7: CTRL_BLOCK
            {'delta': self.device_coords_CTRL['OP'], 'rows': 1, 'columns': 1, 
             'coords': self.device_coords_CTRL, 'insert_block': self.insert_item_CTRL, 'block_key': 'CONTROL'},
            # l=8: top_pulse_empty_block
            {'delta': self.device_coords_top_pulse_empty['OP'], 'rows': 1, 'columns': 1, 
             'coords': self.device_coords_top_pulse_empty, 'insert_block': self.insert_item_top_pulse_empty, 'block_key': 'topPULSE'},
            # l=9: for_pc_ctrl_block
            {'delta': self.device_coords_for_pc_ctrl['OP'], 'rows': 1, 'columns': 1, 
             'coords': self.device_coords_for_pc_ctrl, 'insert_block': self.insert_item_for_pc_ctrl, 'block_key': 'forPCctrl'},
            # l=10: Y Decoder (специальный случай)
            {'rows': 0, 'columns': 0, 'block_key': 'DCY'},
            # l=11: X_CONNECT and PULSEX ROW (специальный случай)
            {'rows': 0, 'columns': 0},
            # l=12: X Decoder (специальный случай)
            {'rows': 0, 'columns': 0, 'block_key': 'DCX'},
            # l=13: VddLine_block
            {'delta': self.device_coords_vdd_line['OP'], 'rows': self.rows, 'columns': 1, 
             'coords': self.device_coords_vdd_line, 'insert_block': self.insert_item_vdd_line, 'block_key': 'VddLine'},
            # l=14: VddTop_block
            {'delta': self.device_coords_vdd_top['OP'], 'rows': 1, 'columns': 1, 
             'coords': self.device_coords_vdd_top, 'insert_block': self.insert_item_vdd_top, 'block_key': 'VddTop'},
        ]
        
        # Инициализация счетчиков блоков, если холст пуст
        if not self.canvas.find_all():
            for block in blocks_config:
                if 'insert_block' in block:
                    self.num_of_blocks[block['insert_block']] = 0
        
        # Обработка каждого блока
        for l, block in enumerate(blocks_config, -1):
            if l > 14:  # Защита от выхода за пределы списка
                break
                
            # Специальные случаи
            if l == 10:  # Y Decoder
                if self.choosed_blocks['DCY']:
                    axis = 'Y'
                    angle = 0
                    mirr_axis = None
                    I = int(math.log2(self.rows))
                    dop_shift = 0
                    self.compact_matrix_DC_SW(self.pulse_x_for_ydc, self.pulse_y_for_ydc, self.Lambda, axis, angle, I, mirr_axis, dop_shift)
                continue
                
            elif l == 11:  # X_CONNECT and PULSEX ROW
                xcon_op_coords = self.SW_XCONNECT_for_full(x0, self.XCONNECT_y0, self.columns)
                continue
                
            elif l == 12:  # X Decoder
                if self.choosed_blocks['DCX']:
                    x0_for_XDC = xcon_op_coords[0]
                    y0_for_XDC = xcon_op_coords[1]
                    axis = 'X'
                    angle = pi/2
                    mirr_axis = None
                    I = int(math.log2(self.columns))
                    dop_shift = 0
                    self.compact_matrix_DC_SW(x0_for_XDC, y0_for_XDC, self.Lambda, axis, angle, I, mirr_axis, dop_shift)
                continue
                
            # Получение параметров текущего блока
            delta = block['delta']
            rows = block['rows']
            columns = block['columns']
            
            if 'coords' in block:
                self.ObjectCoords = block['coords']
            
            if 'insert_block' in block:
                insert_block = block['insert_block']
            
            delta_x = delta[0][2]
            delta_y = delta[0][3]
            
            # Специальная обработка для PULSE_BLOCK
            if l == 3:
                delta_pulsey = delta
                delta_x_pulsey = delta_pulsey[0][2]
                delta_y_pulsey = delta_pulsey[0][3]
            
            # Обновление координат в зависимости от блока
            if l == 1:
                self.PulseY_delta = self.another_delta_y
                self.for_empty_top_pulse_y = self.PulseY_delta
                self.vdd_lineY_delta = self.PulseY_delta
            elif l == 2:
                self.OUT_delta_y = self.another_delta_y
                self.BUFF_y_end = self.another_delta_y + (delta[0][3] - delta[0][1])*self.Lambda
                self.XCONNECT_y0 = self.BUFF_y_end
                self.CTRL_delta_y = self.BUFF_y_end
            elif l == 4:
                self.RSA_delta_y = self.OUT_delta_y + (delta[0][3])*self.Lambda
            
            # Определение начальной координаты y
            if l == 3:
                y = y0 + self.PulseY_delta
            elif l == 4:
                y = y0 + self.OUT_delta_y
            elif l == 5:
                y = y0 + self.RSA_delta_y
            elif l == 6:
                self.WR_delta_y = self.BUFF_y_end - (delta[0][3] - delta[0][1])*self.Lambda
                y = y0 + self.WR_delta_y
            elif l == 7:
                y = y0 + self.CTRL_delta_y
            elif l == 8 or l == 14:
                y = self.for_empty_top_pulse_y - delta_y * self.Lambda
                self.pulse_y_for_ydc = y
            elif l == 9:
                y = y0
            elif l == 13:
                y = y0 + self.vdd_lineY_delta
            else:
                y = y0 + self.another_delta_y
            
            # Обработка строк
            for amount_y in range(rows):
                if l == 3:
                    self.ObjectCoords = self.device_coords_pulsey
                    insert_block = self.insert_item_pulsey
                    delta = delta_pulsey
                
                if amount_y != 0:
                    if l == 3:
                        delta_y = delta_y_pulsey
                    y = y + delta_y * self.Lambda
                
                yOP_2 = y + (delta[0][1]+delta[0][3])*self.Lambda
                if amount_y == rows - 1 and l != 3:
                    self.another_delta_y = yOP_2
                
                x = x0
                if l == 1:
                    yOP_1 = y + delta[0][1]*self.Lambda
                    yOP_2 = y + (delta[0][1]+delta[0][3])*self.Lambda
                
                # Обработка столбцов
                for amount_x in range(columns):
                    # Увеличение счетчика блоков
                    if 'insert_block' in block and 'block_key' in block and self.choosed_blocks[block['block_key']]:
                        self.num_of_blocks[insert_block] += 1
                    
                    # Обновление координаты x
                    if (amount_x != 0 and l != 3) or l == 6 or l == 7:
                        if l == 6 or l == 7:
                            delta_x = -delta[0][2]
                        x = x + delta_x * self.Lambda
                    elif l == 3:
                        delta_x = -delta_x_pulsey
                        x = x + delta_x * self.Lambda
                        self.for_empty_top_pulse_x = x
                    
                    if l == 4 or l == 5 or l == 13 or l == 14:
                        x = self.OUT_delta_x
                    elif l == 8:
                        x = self.for_empty_top_pulse_x
                        self.pulse_x_for_ydc = self.for_empty_top_pulse_x
                    elif l == 9:
                        x = x0 - delta_x * self.Lambda
                    
                    xOP_2 = x + (delta[0][0]+delta[0][2])*self.Lambda
                    if l == 2:
                        self.OUT_delta_x = xOP_2
                    if l == 1:
                        xOP_1 = x + delta[0][0]*self.Lambda
                        xOP_2 = x + (delta[0][0]+delta[0][2])*self.Lambda
                    
                    # Отрисовка блока, если он выбран
                    if 'block_key' in block and 'insert_block' in block and self.choosed_blocks[block['block_key']]:
                        for j, layer in enumerate(top_area['SkyWater130']):
                            rec = self.ObjectCoords.get(layer)
                            color = colors['SkyWater130'][j]
                            bordertype = borders['SkyWater130'][j]
                            filling = fills['SkyWater130'][j]
                            
                            if isinstance(rec, list):
                                for i, r in enumerate(rec):
                                    rec_coord = (
                                        x + r[0] * self.Lambda, 
                                        y + r[1] * self.Lambda, 
                                        x + (r[0] + r[2]) * self.Lambda, 
                                        y + (r[1] + r[3]) * self.Lambda
                                    )
                                    
                                    if l == 1:
                                        if amount_x % 2 != 0:
                                            rec_coord = self.mirror_shape(rec_coord, (xOP_1 + xOP_2)/2, 0, 'Y')
                                        if amount_y % 2 != 0:
                                            rec_coord = self.mirror_shape(rec_coord, 0, (yOP_1 + yOP_2)/2, 'X')
                                    
                                    self.create_rec_with_mem(
                                        *rec_coord, 
                                        outline=color, 
                                        fill=filling, 
                                        dash=bordertype, 
                                        tags=f'{insert_block}_{self.num_of_blocks[insert_block]}_{layer}_{i}'
                                    )


    #def synthesis_SW(self, event):
        #self.GridUnits = self.GridLambda.get()
        #if self.GridUnits == 0:
            #messagebox.showerror("Error", "Choose foundry, please")
        #else:
            #self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
            #if self.synthesisAcces == 0 and (self.insertAccess == 1 or self.multiplyAccess == 1 or self.y_decoder_access == 1):
                #pass
            #elif self.synthesisAcces == 1:
                #self.multiplyAccess = 0
                #self.insertAccess = 0
                #self.synthesisAcces = 0
                #self.another_delta_y = 0
                #self.y_decoder_access = 0
                #x0 = 0  # self.canvas.canvasx(event.x)
                #y0 = 0  # self.canvas.canvasy(event.y)
                #amount_of_objects = 15
                #for l in range(-1, amount_of_objects):
                    ## -----------PC_BLOCK SYNTHESIS-------------------------------
                    #if l == -1:
                        #delta = self.device_coords_PC['OP']
                        #rows = 1
                        #columns = self.columns
                        #self.ObjectCoords = self.device_coords_PC
                        #insert_block = self.insert_item_PC
                        #delta_x = delta[0][2]
                        #delta_y = delta[0][3]
                    ## -----------bottom_pc_empty_block SYNTHESIS-------------------------------
                    #elif l == 0:
                        #delta = self.device_coords_bottom_pc_empty['OP']
                        #rows = 1
                        #columns = self.columns
                        #self.ObjectCoords = self.device_coords_bottom_pc_empty
                        #insert_block = self.insert_item_bottom_pc_empty
                        #delta_x = delta[0][2]
                        #delta_y = delta[0][3]
                    ## -----------CELL_BLOCK SYNTHESIS-------------------------------
                    #elif l == 1:
                        #delta = self.device_coords_CELL['OP']
                        #rows = self.rows
                        #columns = self.columns
                        #self.ObjectCoords = self.device_coords_CELL
                        #insert_block = self.insert_item_CELL
                        #delta_x = delta[0][2]
                        #delta_y = delta[0][3]
                    ## -----------BUFF_BLOCK SYNTHESIS-------------------------------
                    #elif l == 2:
                        #delta = self.device_coords_BUFF['OP']
                        #rows = 1
                        #columns = self.columns
                        #self.ObjectCoords = self.device_coords_BUFF
                        #insert_block = self.insert_item_BUFF
                        #delta_x = delta[0][2]
                        #delta_y = delta[0][3]
                    ## -----------PULSE_BLOCK SYNTHESIS-------------------------------
                    #elif l == 3:
                        #delta_pulsey = self.device_coords_pulsey['OP']
                        #rows = int(self.rows/2)
                        #columns = 1
                        #delta_x_pulsey = delta_pulsey[0][2]
                        #delta_y_pulsey = delta_pulsey[0][3]
                        #delta_y = 0
                        #delta_x = 0
                    ## -----------OUT_BLOCK SYNTHESIS-------------------------------
                    #elif l == 4:
                        #delta = self.device_coords_OUT['OP']
                        #rows = 1
                        #columns = 1
                        #self.ObjectCoords = self.device_coords_OUT
                        #insert_block = self.insert_item_OUT
                        #delta_x = delta[0][2]
                        #delta_y = delta[0][3]
                    ## -----------RSA_BLOCK SYNTHESIS-------------------------------
                    #elif l == 5:
                        #delta = self.device_coords_RSA['OP']
                        #rows = 1
                        #columns = 1
                        #self.ObjectCoords = self.device_coords_RSA
                        #insert_block = self.insert_item_RSA
                        #delta_x = delta[0][2]
                        #delta_y = delta[0][3]
                    ## -----------WR_BLOCK SYNTHESIS-------------------------------
                    #elif l == 6:
                        #delta = self.device_coords_WR['OP']
                        #rows = 1
                        #columns = 1
                        #self.ObjectCoords = self.device_coords_WR
                        #insert_block = self.insert_item_WR
                        #delta_x = delta[0][2]
                        #delta_y = delta[0][3]
                    ## -----------CTRL_BLOCK SYNTHESIS-------------------------------
                    #elif l == 7:
                        #delta = self.device_coords_CTRL['OP']
                        #rows = 1
                        #columns = 1
                        #self.ObjectCoords = self.device_coords_CTRL
                        #insert_block = self.insert_item_CTRL
                        #delta_x = delta[0][2]
                        #delta_y = delta[0][3]
                    ## -----------top_pulse_empty_block SYNTHESIS-------------------------------
                    #elif l == 8:
                        #delta = self.device_coords_top_pulse_empty['OP']
                        #rows = 1
                        #columns = 1
                        #self.ObjectCoords = self.device_coords_top_pulse_empty
                        #insert_block = self.insert_item_top_pulse_empty
                        #delta_x = delta[0][2]
                        #delta_y = delta[0][3]
                    ## -----------for_pc_ctrl_block SYNTHESIS-------------------------------
                    #elif l == 9:
                        #delta = self.device_coords_for_pc_ctrl['OP']
                        #rows = 1
                        #columns = 1
                        #self.ObjectCoords = self.device_coords_for_pc_ctrl
                        #insert_block = self.insert_item_for_pc_ctrl
                        #delta_x = delta[0][2]
                        #delta_y = delta[0][3]
                    ## -----------Y Decoder SYNTHESIS-------------------------------
                    #elif l == 10:
                        #axis = 'Y'
                        #angle = 0
                        #mirr_axis = None
                        #I = int(math.log2(self.rows))
                        #dop_shift = 0
                        #if self.choosed_blocks['DCY']:
                            #self.compact_matrix_DC_SW(
                                #self.pulse_x_for_ydc, self.pulse_y_for_ydc, self.Lambda, axis, angle, I, mirr_axis, dop_shift)
                        #rows = 0
                        #columns = 0
                    ## -----------X_CONNECT and PULSEX ROW SYNTHESIS---------------
                    #elif l == 11:
                        #xcon_op_coords = self.SW_XCONNECT_for_full(x0, self.XCONNECT_y0, self.columns)
                        #rows = 0
                        #columns = 0
                    ## -----------X Decoder SYNTHESIS-------------------------------
                    #elif l == 12:
                        #x0_for_XDC = xcon_op_coords[0]
                        #y0_for_XDC = xcon_op_coords[1]
                        #axis = 'X'
                        #angle = pi/2
                        #mirr_axis = None
                        #I = int(math.log2(self.columns))
                        #dop_shift = 0 
                        #if self.choosed_blocks['DCX']:
                            #self.compact_matrix_DC_SW(x0_for_XDC, y0_for_XDC, self.Lambda, axis, angle, I, mirr_axis, dop_shift)
                        #rows = 0
                        #columns = 0
                    ## -----------_VddLine_block SYNTHESIS-------------------------------
                    #elif l == 13:
                        #delta = self.device_coords_vdd_line['OP']
                        #rows = self.rows
                        #columns = 1
                        #self.ObjectCoords = self.device_coords_vdd_line
                        #insert_block = self.insert_item_vdd_line
                        #delta_x = delta[0][2]
                        #delta_y = delta[0][3]
                    ## -----------_VddTop_block SYNTHESIS-------------------------------
                    #elif l == 14:
                        #delta = self.device_coords_vdd_top['OP']
                        #rows = 1
                        #columns = 1
                        #self.ObjectCoords = self.device_coords_vdd_top
                        #insert_block = self.insert_item_vdd_top
                        #delta_x = delta[0][2]
                        #delta_y = delta[0][3]
                    #if l == 1:
                        #self.PulseY_delta = self.another_delta_y
                        #self.for_empty_top_pulse_y = self.PulseY_delta
                        #self.vdd_lineY_delta = self.PulseY_delta
                    #elif l == 2:
                        #self.OUT_delta_y = self.another_delta_y
                        #self.BUFF_y_end = self.another_delta_y + (delta[0][3] - delta[0][1])*self.Lambda
                        #self.XCONNECT_y0 = self.BUFF_y_end
                        #self.CTRL_delta_y = self.BUFF_y_end
                    #elif l == 4:
                        #self.RSA_delta_y = self.OUT_delta_y + (delta[0][3])*self.Lambda
                    #if l == 3:
                        #y = y0 + self.PulseY_delta
                    #elif l == 4:
                        #y = y0 + self.OUT_delta_y
                    #elif l == 5:
                        #y = y0 + self.RSA_delta_y
                    #elif l == 6:
                        #self.WR_delta_y = self.BUFF_y_end - (delta[0][3] - delta[0][1])*self.Lambda
                        #y = y0 + self.WR_delta_y
                    #elif l == 7:
                        #y = y0 + self.CTRL_delta_y
                    #elif l == 8 or l == 14:
                        #y = self.for_empty_top_pulse_y - delta_y * self.Lambda
                        #self.pulse_y_for_ydc = y
                    #elif l == 9:
                        #y = y0
                    #elif l == 13:
                        #y = y0 + self.vdd_lineY_delta
                    #else:
                        #y = y0 + self.another_delta_y
                    #for amount_y in range(rows):
                        #if l == 3:
                            #self.ObjectCoords = self.device_coords_pulsey
                            #self.insert_item = self.insert_item_pulsey
                            #insert_block = self.insert_item_pulsey
                            #delta = delta_pulsey
                        #if amount_y != 0:
                            #if l == 3:
                                #delta_y = delta_y_pulsey
                            #y = y + delta_y * self.Lambda

                        #yOP_2 = y + (delta[0][1]+delta[0][3])*self.Lambda
                        #if amount_y == rows - 1 and l != 3:
                            #self.another_delta_y = yOP_2
                        #x = x0
                        #if l == 1:
                            #yOP_1 = y + delta[0][1]*self.Lambda
                            #yOP_2 = y + (delta[0][1]+delta[0][3])*self.Lambda
                        #for amount_x in range(columns):
                            #if not self.canvas.find_all():
                                #self.num_of_blocks[self.insert_item_PC] = 0
                                #self.num_of_blocks[self.insert_item_bottom_pc_empty] = 0
                                #self.num_of_blocks[self.insert_item_top_pulse_empty] = 0
                                #self.num_of_blocks[self.insert_item_for_pc_ctrl] = 0
                                #self.num_of_blocks[self.insert_item_CELL] = 0
                                #self.num_of_blocks[self.insert_item_BUFF] = 0
                                #self.num_of_blocks[self.insert_item_pulsey] = 0
                                #self.num_of_blocks[self.insert_item_OUT] = 0
                                #self.num_of_blocks[self.insert_item_RSA] = 0
                                #self.num_of_blocks[self.insert_item_WR] = 0
                                #self.num_of_blocks[self.insert_item_CTRL] = 0
                                #self.num_of_blocks[self.insert_item_vdd_line] = 0
                                #self.num_of_blocks[self.insert_item_vdd_top] = 0
                            #else:
                                #if l == -1 and self.choosed_blocks['PC']:
                                    #self.num_of_blocks[self.insert_item_PC] += 1
                                #elif l == 0 and self.choosed_blocks['bottomPC']:
                                    #self.num_of_blocks[self.insert_item_bottom_pc_empty] += 1
                                #elif l == 1 and self.choosed_blocks['SRAM']:
                                    #self.num_of_blocks[self.insert_item_CELL] += 1
                                #elif l == 2 and self.choosed_blocks['BUFFER']:
                                    #self.num_of_blocks[self.insert_item_BUFF] += 1
                                #elif l == 3 and self.choosed_blocks['PULSEY']:
                                    #self.num_of_blocks[self.insert_item_pulsey] += 1
                                #elif l == 4 and self.choosed_blocks['OUT']:
                                    #self.num_of_blocks[self.insert_item_OUT] += 1
                                #elif l == 5 and self.choosed_blocks['RSA']:
                                    #self.num_of_blocks[self.insert_item_RSA] += 1
                                #elif l == 6 and self.choosed_blocks['WRITE']:
                                    #self.num_of_blocks[self.insert_item_WR] += 1
                                #elif l == 7 and self.choosed_blocks['CONTROL']:
                                    #self.num_of_blocks[self.insert_item_CTRL] += 1
                                #elif l == 8 and self.choosed_blocks['topPULSE']:
                                    #self.num_of_blocks[self.insert_item_top_pulse_empty] += 1
                                #elif l == 9 and self.choosed_blocks['forPCctrl']:
                                    #self.num_of_blocks[self.insert_item_for_pc_ctrl] += 1
                                #elif l == 13 and self.choosed_blocks['VddLine']:
                                    #self.num_of_blocks[self.insert_item_vdd_line] += 1
                                #elif l == 14 and self.choosed_blocks['VddTop']:
                                    #self.num_of_blocks[self.insert_item_vdd_top] += 1

                            #if (amount_x != 0 and l != 3) or l == 6 or l == 7:
                                #if l == 6 or l == 7:
                                    #delta_x = -delta[0][2]
                                #x = x + delta_x * self.Lambda
                            #elif l == 3:
                                #delta_x = -delta_x_pulsey
                                #x = x + delta_x * self.Lambda
                                #self.for_empty_top_pulse_x = x
                            #if l == 4 or l == 5 or l == 13 or l == 14:
                                #x = self.OUT_delta_x
                            #elif l == 8:
                                #x = self.for_empty_top_pulse_x
                                #self.pulse_x_for_ydc = self.for_empty_top_pulse_x
                            #elif l == 9:
                                #x = x0 - delta_x * self.Lambda
                            #xOP_2 = x + (delta[0][0]+delta[0][2])*self.Lambda
                            #if l == 2:
                                #self.OUT_delta_x = xOP_2
                            #if l == 1:
                                #xOP_1 = x + delta[0][0]*self.Lambda
                                #xOP_2 = x + (delta[0][0]+delta[0][2])*self.Lambda

                            #if self.choosed_blocks[insert_block]:
                                #for j in range(len(top_area['SkyWater130'])):
                                    #rec = self.ObjectCoords.get(
                                        #top_area['SkyWater130'][j])
                                    #color = colors['SkyWater130'][j]
                                    #bordertype = borders['SkyWater130'][j]
                                    #filling = fills['SkyWater130'][j]
                                    #if type(rec) is list:
                                        #for i in range(len(rec)):
                                            #rec_coord = (x + rec[i][0] * self.Lambda, y + rec[i][1] * self.Lambda, x + (rec[i][0] + rec[i][2]) * self.Lambda, y + (rec[i][1] + rec[i][3]) * self.Lambda)
                                            #if l == 1:
                                                #if amount_x % 2 != 0:
                                                    #rec_coord = self.mirror_shape(
                                                        #rec_coord, (xOP_1 + xOP_2)/2, 0, 'Y')
                                                #if amount_y % 2 != 0:
                                                    #rec_coord = self.mirror_shape(
                                                        #rec_coord, 0, (yOP_1 + yOP_2)/2, 'X')
                                            #self.create_rec_with_mem(*rec_coord, outline=color, fill=filling, dash=bordertype, tags=f'{insert_block}_{self.num_of_blocks[insert_block]}_{top_area["SkyWater130"][j]}_{i}')
                                            ## self.canvas.update()


    


    def MultiplyBounded(self):
        window = MultiplyingFunc(self.master)
        window.wm_attributes('-topmost', True)
        window.resizable(False, False)
        window.title('TopoPlot: Let Multiplying')
        self.mult_param = window.open()
        self.bound_coords = self.canvas.coords('bound_rect')
        self.canvas.delete('bound_rect')
        self.bound_flag.set(0)
        op_flag = False
        for item in self.canvas.find_all():
            fig = re.split("_", self.canvas.gettags(item)[0].strip())
            # print('fig:', fig)
            if len(fig) >= 4:
                if fig[2] == 'OP' and self.canvas.coords(item)[0] > self.bound_coords[0] and self.canvas.coords(item)[2] < self.bound_coords[2] and self.canvas.coords(item)[1] > self.bound_coords[1] and self.canvas.coords(item)[3] < self.bound_coords[3]:
                    op_item = item
                    op_flag = True
        if not op_flag:
            self.op_coords = self.bound_coords
        else:
            self.op_coords = self.canvas.coords(op_item)
        # try:
            # self.op_coords = self.canvas.coords(op_item)
        # except:
            # self.op_coords = self.bound_coords
        # print('self.op_coords:', self.op_coords)
        # self.delete_from_mem(self.canvas.find_withtag('bound_rect'))
        for item in self.canvas.find_all():
            init_tag = self.canvas.itemcget(item, "tags")
            init_outline = self.canvas.itemcget(item, "outline")
            init_fill = self.canvas.itemcget(item, "fill")
            init_dash = self.canvas.itemcget(item, "dash")
            init_obj = self.canvas.coords(item)
            # print('init_obj:', init_obj)
            fig = re.split("_", self.canvas.gettags(item)[0].strip())
            # print(fig)
            if fig[0] != 'bound' and fig[0] != 'Sechenie' and init_obj[0] > self.bound_coords[0] and init_obj[2] < self.bound_coords[2] and init_obj[1] > self.bound_coords[1] and init_obj[3] < self.bound_coords[3]:
                if self.mult_param[0] == 'R':
                    dx = self.op_coords[2] - self.op_coords[0]
                    dy = 0
                elif self.mult_param[0] == 'L':
                    dx = -(self.op_coords[2] - self.op_coords[0])
                    dy = 0
                elif self.mult_param[0] == 'D':
                    dx = 0
                    dy = self.op_coords[3] - self.op_coords[1]
                elif self.mult_param[0] == 'U':
                    dx = 0
                    dy = -(self.op_coords[3] - self.op_coords[1])
                for count in range(self.mult_param[1]):
                    added_obj = (init_obj[0] + dx * (count + 1), init_obj[1] + dy * (
                        count + 1), init_obj[2] + dx * (count + 1), init_obj[3] + dy * (count + 1))
                    self.create_rec_with_mem(*added_obj, outline=init_outline, fill=init_fill, dash= init_dash, tags = init_tag)

    def multiply(self, event):
        # self.GridUnits = self.form.get_tech()
        self.GridUnits = self.GridLambda.get()
        if self.GridUnits == 0:
            messagebox.showerror("Error", "Choose foundry, please")
        else:
            self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
            if self.multiplyAccess == 0 and (self.synthesisAcces == 1 or self.insertAccess == 1 or self.y_decoder_access == 1):
                pass
            elif self.multiplyAccess == 1:
                self.multiplyAccess = 0
                self.insertAccess = 0
                self.y_decoder_access = 0
                self.synthesisAcces = 0
                x0 = self.canvas.canvasx(event.x)
                y0 = self.canvas.canvasy(event.y)

                if self.PulseY != 1 and self.PulseX != 1:
                    delta = self.device_coords.get('OP')
                    delta_x = delta[0][2]
                    delta_y = delta[0][3]
                elif self.PulseY == 1:
                    delta_pulsey = self.device_coords_pulsey.get('OP')
                    delta_x_pulsey = delta_pulsey[0][2]
                    delta_y_pulsey = delta_pulsey[0][3]
                    delta_y = 0
                    delta_x = 0
                elif self.PulseX == 1:
                    delta_pulsex = self.device_coords_pulsex.get('OP')
                    delta_x_pulsex = delta_pulsex[0][2]
                    delta_y_pulsex = delta_pulsex[0][3]
                    delta_y = 0
                    delta_x = 0

                if self.CellAccess == 0:
                    rows = 1
                else:
                    rows = self.rows
                    # self.CellAccess = 0
                # print(self.CellAccess)
                y = y0

                for amount_y in range(rows):
                    # print('\n',delta_x_pulsey, delta_y_pulsey)
                    if self.PulseY == 1:
                        self.device_coords = self.device_coords_pulsey
                        self.insert_item = self.insert_item_pulsey
                    elif self.PulseX == 1:
                        self.device_coords = self.device_coords_pulsex
                        self.insert_item = self.insert_item_pulsex

                    # print(self.device_coords)

                    if amount_y != 0:
                        if self.PulseY == 1:
                            delta_y = delta_y_pulsey
                        elif self.PulseX == 1:
                            delta_y = delta_y_pulsex
                        y = y + delta_y * self.Lambda
                    # print('amount_y: ', amount_y, '\ty: ', y, '\tdelta_y: ', delta_y, '\tdelta_y_pulsey: ', delta_y_pulsey, '\tLambda: ', self.Lambda)
                    if self.CellAccess != 0:
                        yOP_1 = y + \
                            self.device_coords.get('OP')[0][1]*self.Lambda
                        yOP_2 = y + \
                            (self.device_coords.get('OP')[
                             0][1]+self.device_coords.get('OP')[0][3])*self.Lambda

                    x = x0
                    for amount_x in range(self.columns):
                        # print('init:', x, y)

                        # print(amount_x, amount_y, self.insert_item, self.device_coords)
                        '''
                        for thing in self.canvas.find_all():
                            thing_tag = self.canvas.gettags()[0]
                            thing = re.split("_", thing_tag.strip())
                            if self.insert_item != thing:
                                self.num_of_blocks[self.insert_item] = 0
                            else:
                                self.num_of_blocks[self.insert_item] += 1
                        '''

                        if not self.canvas.find_all():  # or no_update == False:
                            self.num_of_blocks[self.insert_item] = 0
                        else:
                            self.num_of_blocks[self.insert_item] += 1

                        if amount_x != 0:
                            if self.PulseY == 1:
                                delta_x = delta_x_pulsey
                            elif self.PulseX == 1:
                                delta_x = delta_x_pulsex
                            x = x + delta_x * self.Lambda

                        if self.CellAccess != 0:
                            xOP_1 = x + \
                                self.device_coords.get('OP')[0][0]*self.Lambda
                            xOP_2 = x + \
                                (self.device_coords.get('OP')[
                                 0][0]+self.device_coords.get('OP')[0][2])*self.Lambda

                        # if self.foundry.get() == 'Microwind65':
                            # layers_num = len(top_area[self.foundry.get()])
                        # elif self.foundry.get() == 'SkyWater130':
                            # layers_num = len(top_area[self.foundry.get()]) - 1

                        for j in range(len(top_area[self.foundry.get()])):
                            # print(x, y)
                            rec = self.device_coords.get(
                                top_area[self.foundry.get()][j])
                            color = colors[self.foundry.get()][j]
                            bordertype = borders[self.foundry.get()][j]
                            filling = fills[self.foundry.get()][j]
                            if type(rec) is list:
                                for i in range(len(rec)):
                                    rec_coord = (x + rec[i][0] * self.Lambda, y + rec[i][1] * self.Lambda, x + (
                                        rec[i][0] + rec[i][2]) * self.Lambda, y + (rec[i][1] + rec[i][3]) * self.Lambda)

                                    # print(rec_coord)
                                    if self.CellAccess != 0:
                                        if amount_x % 2 != 0:
                                            rec_coord = self.mirror_shape(
                                                rec_coord, (xOP_1 + xOP_2)/2, 0, 'Y')
                                        if amount_y % 2 != 0:
                                            rec_coord = self.mirror_shape(
                                                rec_coord, 0, (yOP_1 + yOP_2)/2, 'X')
                                    self.create_rec_with_mem(*rec_coord, outline=color, fill=filling, dash=bordertype, tags=f'{self.insert_item}_{self.num_of_blocks[self.insert_item]}_{top_area[self.foundry.get()][j]}_{i}')
                                    self.canvas.update()
                self.PulseY = 0
                self.PulseX = 0
                self.CellAccess = 0

    def MultiAccess(self):
        self.multiplyAccess = 0
        self.y_decoder_access = 0
        self.insertAccess = 0
        self.synthesisAcces = 0
        self.CellAccess = 0
        self.mult_access = 1
        window = MultiplierSyn(self.master)
        window.wm_attributes('-topmost', True)
        window.resizable(False, False)
        window.title('TopoPlot: Multiplier synthesis')
        window.iconbitmap(r'nano.ico')
        # params = window.open()
        self.MULT_bit_depth = window.open()
        # self.B_depth = params[1]
        # print(self.A, self.B)
        self.MULT_objects_coords = MultObjectItems_MW.device_coords['MULT']
        # print(self.MULT_objects_coords)

    def CellAccess(self):
        self.multiplyAccess = 1
        self.y_decoder_access = 0
        self.insertAccess = 0
        self.synthesisAcces = 0
        self.CellAccess = 1
        window = CellSyn(self.master)
        window.wm_attributes('-topmost', True)
        window.iconbitmap(r'nano.ico')
        window.resizable(False, False)
        window.title('TopoPlot: SRAM matrix creating')

        params = window.open()
        self.rows = params[0]
        self.columns = params[1]
        # print(self.columns, self.rows)
        if self.foundry.get() == 'Microwind65':
            filepath = self.filefolder+'\examples\SRAM_cell.txt'
            filename = os.path.basename(filepath)[:-4]
            self.device_coords = ReadTXT_MW(
                path=filepath, name=filename).getCoords()
        elif self.foundry.get() == 'SkyWater130':
            filepath = self.filefolder+'\examples\SRAM_cell.mag'
            filename = os.path.basename(filepath)[:-4]
            self.device_coords = ReadTXT_SW(
                path=filepath, name=filename).getCoords()

        self.insert_item = re.split("_", filename.strip())
        self.insert_item = self.insert_item[0]

        no_update = False

        for fig in self.canvas.find_all():
            figure = self.canvas.gettags(fig)[0]
            figure = re.split("_", figure.strip())
            figure = figure[0]
            if figure == self.insert_item:
                no_update = True
            else:
                pass

        if not self.canvas.find_all() or no_update == False:
            self.num_of_blocks[self.insert_item] = 0
        else:
            self.num_of_blocks[self.insert_item] += 1

    def BuffRowAccess(self):
        self.multiplyAccess = 1
        self.insertAccess = 0
        self.synthesisAcces = 0
        self.y_decoder_access = 0
        window = BuffRowSyn(self.master)
        window.title('TopoPlot: Buffer blocks Row')
        window.wm_attributes('-topmost', True)
        window.iconbitmap(r'nano.ico')
        window.resizable(False, False)
        self.columns = window.open()

        if self.foundry.get() == 'Microwind65':
            filepath = self.filefolder+'\examples\BUFFER_block.txt'
            filename = os.path.basename(filepath)[:-4]
            self.device_coords = ReadTXT_MW(
                path=filepath, name=filename).getCoords()
        elif self.foundry.get() == 'SkyWater130':
            filepath = self.filefolder+'\examples\BUFFER_block.mag'
            filename = os.path.basename(filepath)[:-4]
            self.device_coords = ReadTXT_SW(
                path=filepath, name=filename).getCoords()

        self.insert_item = re.split("_", filename.strip())
        self.insert_item = self.insert_item[0]

        no_update = False

        for fig in self.canvas.find_all():
            figure = self.canvas.gettags(fig)[0]
            figure = re.split("_", figure.strip())
            figure = figure[0]
            if figure == self.insert_item:
                no_update = True
            else:
                pass

        if not self.canvas.find_all() or no_update == False:
            self.num_of_blocks[self.insert_item] = 0
        else:
            self.num_of_blocks[self.insert_item] += 1

    def PCRowAccess(self):
        self.multiplyAccess = 1
        self.insertAccess = 0
        self.synthesisAcces = 0
        self.y_decoder_access = 0
        window = PCRowSyn(self.master)
        window.wm_attributes('-topmost', True)
        window.resizable(False, False)
        window.title('TopoPlot: PC blocks Row')
        window.iconbitmap(r'nano.ico')
        self.columns = window.open()
        # filepath = self.filefolder+'\examples\PC_block.txt'

        if self.foundry.get() == 'Microwind65':
            filepath = self.filefolder+'\examples\PC_exp.txt'
            filename = os.path.basename(filepath)[:-4]
            self.device_coords = ReadTXT_MW(
                path=filepath, name=filename).getCoords()

        elif self.foundry.get() == 'SkyWater130':
            # filepath = self.filefolder+'\examples\PC_block.mag'
            filepath = self.filefolder+'\examples\PC_exp.mag'
            filename = os.path.basename(filepath)[:-4]
            self.device_coords = ReadTXT_SW(
                path=filepath, name=filename).getCoords()

        # print(self.device_coords)

        self.insert_item = re.split("_", filename.strip())
        self.insert_item = self.insert_item[0]
        no_update = False

        for fig in self.canvas.find_all():
            figure = self.canvas.gettags(fig)[0]
            figure = re.split("_", figure.strip())
            figure = figure[0]
            if figure == self.insert_item:
                no_update = True
            else:
                pass

        if not self.canvas.find_all() or no_update == False:
            self.num_of_blocks[self.insert_item] = 0
        else:
            self.num_of_blocks[self.insert_item] += 1

    def XCONNECTAccess(self):
        self.multiplyAccess = 0
        self.insertAccess = 0
        self.synthesisAcces = 0
        self.x_connect_access = 1
        # self.CellAccess = 1
        window = XDCCon(self.master)
        fanout = window.open()
        self.XDC_outputs = fanout[0]
        # self.XCONNECT_objects_coords = DCObjectItems_MW.device_coords['XCONNECT']

    def XDCAccess(self):
        self.multiplyAccess = 0
        self.insertAccess = 0
        self.synthesisAcces = 0
        self.x_decoder_access = 1
        # self.CellAccess = 1
        window = XDCSyn(self.master)
        window.wm_attributes('-topmost', True)
        window.resizable(False, False)
        window.title('TopoPlot: X Decoder synthesis')
        window.iconbitmap(r'nano.ico')
        fanout = window.open()
        self.XDC_outputs = fanout[0]
        self.XDC_inputs = fanout[1]
        self.DC_mode = fanout[2]
        if self.DC_mode == 'by blocks':
            self.XDC_objects_coords = DCObjectItems_MW.device_coords['XDC']

    def YDCAccess(self):
        self.multiplyAccess = 0
        self.insertAccess = 0
        self.synthesisAcces = 0
        self.y_decoder_access = 1
        # self.CellAccess = 1
        window = YDCSyn(self.master)
        window.wm_attributes('-topmost', True)
        window.resizable(False, False)
        window.title('TopoPlot: Y Decoder synthesis')
        window.iconbitmap(r'nano.ico')
        fanout = window.open()
        self.YDC_outputs = fanout[0]
        self.YDC_inputs = fanout[1]
        self.DC_mode = fanout[2]
        if self.DC_mode == 'by blocks':
            self.YDC_objects_coords = DCObjectItems_MW.device_coords['YDC']
            '''
            if not self.canvas.find_all():
                self.num_of_blocks[self.insert_item_Ynands] = 0
                self.num_of_blocks[self.insert_item_YNnands] = 0
                self.num_of_blocks[self.insert_item_Ynors] = 0
                self.num_of_blocks[self.insert_item_YNnors] = 0
                self.num_of_blocks[self.insert_item_base_Ynor] = 0
                self.num_of_blocks[self.insert_item_base_Ynand] = 0
            else:
                self.num_of_blocks[self.insert_item_Ynands] += 1
                self.num_of_blocks[self.insert_item_YNnands] += 1
                self.num_of_blocks[self.insert_item_Ynors] += 1
                self.num_of_blocks[self.insert_item_YNnors] += 1
                self.num_of_blocks[self.insert_item_base_Ynor] += 1
                self.num_of_blocks[self.insert_item_base_Ynand] += 1
            '''

    def rotate_shape(self, shape_coords, x_c, y_c, angle):
        # R_cw = array([[round(cos(angle)), -round(sin(angle))], [round(sin(angle)),  round(cos(angle))]])
        R = array([[round(cos(angle)),  round(sin(angle))],
                  [-round(sin(angle)), round(cos(angle))]])
        # if angle > 0:
        # R = R_cw
        # print('ccw', R_ccw)
        # else:
        # R = R_ccw
        # print('cw',R_cw)
        # R = R_ccw if angle > 0 else R_cw
        # print(R)
        Trans = array([[x_c], [y_c]])
        top_left = array(shape_coords[:2]).reshape(-1, 1)
        right_bottom = array(shape_coords[2:]).reshape(-1, 1)
        shape_coords_1 = (
            transpose(dot(R, top_left - Trans) + Trans)[0]).tolist()
        shape_coords_2 = (
            transpose(dot(R, right_bottom - Trans) + Trans)[0]).tolist()
        shape_coords = shape_coords_1 + shape_coords_2
        return tuple(shape_coords)

    def mirror_shape(self, shape_coords, x_c, y_c, axis):
        if axis is not None:
            if axis == 'Y':
                axis = 1
            elif axis == 'X':
                axis = -1
            I = array([[-axis, 0], [0, axis]])
            Trans = array([[x_c], [y_c]])
            top_left = array(shape_coords[:2]).reshape(-1, 1)
            right_bottom = array(shape_coords[2:]).reshape(-1, 1)
            shape_coords_1 = (
                transpose(dot(I, top_left - Trans) + Trans)[0]).tolist()
            shape_coords_2 = (
                transpose(dot(I, right_bottom - Trans) + Trans)[0]).tolist()
            shape_coords = shape_coords_1 + shape_coords_2
        return tuple(shape_coords)

    def matrixDC(self, axis_point_x, axis_point_y, Lambda, axis, angle, I, mirr_axis, dop_shift):
        x0 = axis_point_x - 3*Lambda  # добавка чтобы сместить начало рисования в NE точку OP
        y0 = axis_point_y + 32*Lambda

        M = 2**I  # amount of outputs
        w = 4*Lambda
        a = 4*Lambda
        b = 4*Lambda
        gap = 3*Lambda
        big_gap = 10*Lambda
        L = M*b+2*gap+(M-1)*big_gap
        nw_1_x = x0-gap-I*(w+3*a)-w
        nw_2_x = nw_1_x - 5*a - Lambda
        NW_1_x = x0+gap
        NW_2_x = nw_1_x
        NW_1_y = y0-2*gap-3*b
        NW_2_y = y0+L+M*b+gap
        '''---------------crossbar creating--------------'''
        '''OP layer creating'''
        OP_coords = (x0+gap, y0-7*b-gap-Lambda, NW_2_x -
                     gap-4*I*a-w-5*Lambda, y0+L+(M+1)*b)
        OP_coords = self.rotate_shape(
            OP_coords, axis_point_x, axis_point_y, angle)
        OP_coords = self.mirror_shape(
            OP_coords, axis_point_x, axis_point_y, mirr_axis)
        if self.choosed_blocks[f'DC{axis}']:
            self.create_rec_with_mem(
                *OP_coords, outline='orange', tags=f"DC{axis}_{0}_OP_layer")

            forward = [0]*M
            revers = [0]*M
            crossbar = [0]*M
            for i in range(M):
                decimal = i
                binary = ""
                while decimal > 0:
                    remainder = decimal % 2
                    binary = str(remainder) + binary
                    decimal = decimal // 2
                forward[i] = list(binary.zfill(I))
            for i in range(M):
                revers[i] = forward[-i-1]
                # crossbar[i] = forward[i] + revers[i]
            revers = transpose(array(revers))
            forward = transpose(array(forward))
            crossbar = transpose(column_stack(
                (forward, revers)).reshape(-1, forward.shape[1]))

            # NDiff matrix creating
            crossbar = crossbar.astype('int')
            # one way using np.where, and taking the bitwise XOR of a given value when it is either 0 or 1
            me_crossbar = where((crossbar == 0) | (crossbar == 1), crossbar ^ 1, crossbar)
            ndiff_crossbar = crossbar
            s_array = zeros((M, 2*I+1))
            for j in range(2*I+1):
                if j == 0:
                    s_array[:, j] = crossbar[:, j]
                elif j == 2*I:
                    s_array[:, j] = crossbar[:, -1]
                else:
                    s_array[:, j] = crossbar[:, j-1] | crossbar[:, j]
            # co_crossbar=np.where((crossbar==0)|(crossbar==1), crossbar^1, crossbar)
            n = 0
            for j in range(2*I+1):
                me_crossbar = insert(me_crossbar, n, ones(M), axis=1)
                ndiff_crossbar = insert(
                    ndiff_crossbar, n, s_array[:, j], axis=1)
                n += 2
            # print(ndiff_crossbar)
            co_crossbar = zeros((M, 4*I+1))
            co_crossbar = co_crossbar.astype('int')
            for j in range(4*I+1):
                if j % 2 == 0:
                    co_crossbar[:, j] = ndiff_crossbar[:, j]

            '''-----------------------------------------------'''
            for m in range(M):
                dop = (m//2)*dop_shift
                for n in range(2*I):
                    if int(crossbar[m][-n-1]) == 1:
                        crossbar_cords = (x0-(n+1)*w-n*a, y0+gap+big_gap*m+m*b *
                                          2 + dop, x0-(n+1)*(w+a), y0+gap+big_gap*m+m*b*2+2*b + dop)
                        crossbar_cords = self.rotate_shape(
                            crossbar_cords, axis_point_x, axis_point_y, angle)
                        crossbar_cords = self.mirror_shape(
                            crossbar_cords, axis_point_x, axis_point_y, mirr_axis)
                        if self.choosed_blocks[f'DC{axis}']:
                            self.create_rec_with_mem(
                                *crossbar_cords, outline='brown', fill='brown', tags=f"DC{axis}_{m}{n}_DP_cross")

            for m in range(M):
                dop = (m//2)*dop_shift
                for n in range(4*I+1):
                    if int(ndiff_crossbar[m][-n-1]) == 1:
                        ndiff_crossbar_coords = (
                            NW_2_x-gap-n*w, y0+gap+big_gap*m+m*b*2 + dop, NW_2_x-gap-(n+1)*w, y0+gap+big_gap*m+m*b*2+2*b + dop)
                        ndiff_crossbar_coords = self.rotate_shape(
                            ndiff_crossbar_coords, axis_point_x, axis_point_y, angle)
                        ndiff_crossbar_coords = self.mirror_shape(
                            ndiff_crossbar_coords, axis_point_x, axis_point_y, mirr_axis)
                        if self.choosed_blocks[f'DC{axis}']:
                            self.create_rec_with_mem(
                                *ndiff_crossbar_coords, outline='green', fill='green', tags=f"DC{axis}_{m}{n}_DN_cross")

            for m in range(M):
                dop = (m//2)*dop_shift
                for n in range(4*I+1):
                    if int(me_crossbar[m][-n-1]) == 1:
                        me_crossbar_coords = (
                            NW_2_x-gap-n*w, y0+gap+big_gap*m+m*b*2 + dop, NW_2_x-gap-(n+1)*w, y0+gap+big_gap*m+m*b*2+b + dop)
                        me_crossbar_coords = self.rotate_shape(
                            me_crossbar_coords, axis_point_x, axis_point_y, angle)
                        me_crossbar_coords = self.mirror_shape(
                            me_crossbar_coords, axis_point_x, axis_point_y, mirr_axis)
                        if self.choosed_blocks[f'DC{axis}']:
                            self.create_rec_with_mem(
                                *me_crossbar_coords, fill='blue', outline='blue', tags=f"DC{axis}_{m}{n}_ME_cross")

            for m in range(M):
                dop = (m//2)*dop_shift
                for n in range(4*I+1):
                    if int(co_crossbar[m][-n-1]) == 1:
                        co_crossbar_coords = (NW_2_x-gap-n*w-Lambda, y0+gap+big_gap*m+m*b*2+Lambda +
                                              dop, NW_2_x-gap-(n+1)*w+Lambda, y0+gap+big_gap*m+m*b*2+b-Lambda + dop)
                        co_crossbar_coords = self.rotate_shape(
                            co_crossbar_coords, axis_point_x, axis_point_y, angle)
                        co_crossbar_coords = self.mirror_shape(
                            co_crossbar_coords, axis_point_x, axis_point_y, mirr_axis)
                        if self.choosed_blocks[f'DC{axis}']:
                            self.create_rec_with_mem(
                                *co_crossbar_coords, outline='black', fill='black', tags=f"DC{axis}_{m}{n}_CO_cross")

            '''main block of pdiff fingers'''
            for j in range(I+1):
                # create shapes
                T_coords = (x0-j*(w+3*a), (y0-b), x0-j*(w+3*a) -
                            w, (y0+L+M*b))  # + 4*b - more pmos
                B_coords_T = (x0-j*(w+3*a)-Lambda, y0-gap,
                              x0-j*(w+3*a)-w+Lambda, y0-Lambda)
                # T_coords = (-j*(w+3*a), 0, -j*(w+3*a)-w, L)

                # rotate shapes
                T_coords = self.rotate_shape(
                    T_coords, axis_point_x, axis_point_y, angle)
                B_coords_T = self.rotate_shape(
                    B_coords_T, axis_point_x, axis_point_y, angle)

                # mirror shapes
                T_coords = self.mirror_shape(
                    T_coords, axis_point_x, axis_point_y, mirr_axis)
                B_coords_T = self.mirror_shape(
                    B_coords_T, axis_point_x, axis_point_y, mirr_axis)

                if self.choosed_blocks[f'DC{axis}']:
                    self.create_rec_with_mem(
                        *T_coords, outline='brown', fill='brown', tags=f"DC{axis}_T_DP_{j}")
                    self.create_rec_with_mem(
                        *B_coords_T, outline='black', fill='black', tags=f"DC{axis}_BT_CO_{j}")
                for i in range(M+1):
                    dop = ((i-1)//2)*dop_shift
                    if j != I:
                        if i == 0:
                            C_coords = (x0-j*(w+3*a)-(w+a), y0-b +
                                        dop, x0-j*(w+3*a)-(w+2*a), y0+dop)
                            B_coords = (x0-j*(w+3*a)-(w+a)-Lambda, y0-b+Lambda +
                                        dop, x0-j*(w+3*a)-(w+2*a)+Lambda, y0-Lambda+dop)
                        else:
                            C_coords = (x0-j*(w+3*a)-(w+a), y0+gap+big_gap*(i-1)+2*b*(
                                i-1)+dop, x0-j*(w+3*a)-(w+2*a), y0+gap+big_gap*(i-1)+2*b*i+dop)
                            B_coords = (x0-j*(w+3*a)-(w+a)-Lambda, y0+gap+big_gap*(i-1)+2*b*(
                                i-1)+Lambda+dop, x0-j*(w+3*a)-(w+2*a)+Lambda, y0+gap+(big_gap+2*b)*(i-1)+b-Lambda+dop)
                        if i != 0:
                            C_color = 'brown'
                            area = 'DP'
                        else:
                            C_color = 'green'
                            area = 'DN'
                        # rotate shapes
                        C_coords = self.rotate_shape(
                            C_coords, axis_point_x, axis_point_y, angle)
                        B_coords = self.rotate_shape(
                            B_coords, axis_point_x, axis_point_y, angle)
                        # mirror shapes
                        C_coords = self.mirror_shape(
                            C_coords, axis_point_x, axis_point_y, mirr_axis)
                        B_coords = self.mirror_shape(
                            B_coords, axis_point_x, axis_point_y, mirr_axis)
                        # draw shapes
                        if self.choosed_blocks[f'DC{axis}']:
                            self.create_rec_with_mem(
                                *C_coords, outline=C_color, fill=C_color, tags=f"DC{axis}_{j}{i}_{area}_C")
                            self.create_rec_with_mem(
                                *B_coords, outline='black', fill='black', tags=f"DC{axis}_{j}{i}_CO_B")

            for i in range(M):
                dop = (i//2)*dop_shift
                metal_outline = (nw_1_x-gap, y0+gap+big_gap*i+2 *
                                 w*i+dop, x0+gap, y0+gap+big_gap*i+2*w*i+w + dop)
                metal_outline = self.rotate_shape(
                    metal_outline, axis_point_x, axis_point_y, angle)
                metal_outline = self.mirror_shape(
                    metal_outline, axis_point_x, axis_point_y, mirr_axis)
                if self.choosed_blocks[f'DC{axis}']:
                    self.create_rec_with_mem(
                        *metal_outline, fill='blue', outline='blue', tags=f"DC{axis}_MetalOutline_ME_{i}")

            '''NWell creating'''
            NW_coords = (NW_1_x, NW_1_y, NW_2_x, NW_2_y)
            NW_coords = self.rotate_shape(
                NW_coords, axis_point_x, axis_point_y, angle)
            NW_coords = self.mirror_shape(
                NW_coords, axis_point_x, axis_point_y, mirr_axis)
            if self.choosed_blocks[f'DC{axis}']:
                self.create_rec_with_mem(
                    *NW_coords, outline='green', dash='--', tags=f"DC{axis}_0_NW_area")

            '''NMOS polarization creating'''

            for i in range(M):
                dop = (i//2)*dop_shift
                # get coords
                polar_met = (NW_2_x-gap-4*I*a-w, y0+gap+big_gap*i+i*b*2+dop,
                             NW_2_x-gap-4*I*a-w-5*Lambda, y0+gap+big_gap*i+i*b*2+w+dop)
                polar_coords = (NW_2_x-gap-4*I*a-w-Lambda, y0+gap+big_gap*i+i*b *
                                2+dop, NW_2_x-gap-4*I*a-w-5*Lambda, y0+gap+big_gap*i+i*b*2+w+dop)
                cont_coords = (NW_2_x-gap-4*I*a-w-w/2, y0+gap+big_gap*i+i*b*2+Lambda +
                               dop, NW_2_x-gap-4*I*a-w-4*Lambda, y0+gap+big_gap*i+i*b*2+w-Lambda+dop)
                # rotating shapes
                polar_met = self.rotate_shape(
                    polar_met, axis_point_x, axis_point_y, angle)
                polar_coords = self.rotate_shape(
                    polar_coords, axis_point_x, axis_point_y, angle)
                cont_coords = self.rotate_shape(
                    cont_coords, axis_point_x, axis_point_y, angle)
                # mirror shapes
                polar_met = self.mirror_shape(
                    polar_met, axis_point_x, axis_point_y, mirr_axis)
                polar_coords = self.mirror_shape(
                    polar_coords, axis_point_x, axis_point_y, mirr_axis)
                cont_coords = self.mirror_shape(
                    cont_coords, axis_point_x, axis_point_y, mirr_axis)
                # draw shapes
                if self.choosed_blocks[f'DC{axis}']:
                    self.create_rec_with_mem(
                        *polar_coords, outline='brown', fill='brown', tags=f"DC{axis}_NmosPol_DP_{i}")
                    self.create_rec_with_mem(
                        *cont_coords, outline='black', fill='black', tags=f"DC{axis}_PolCont_CO_{i}")
                    self.create_rec_with_mem(
                        *polar_met, fill='blue', outline='blue', tags=f"DC{axis}_pol_ME_{i}")

            '''metal layers creating'''
            # get coords
            m1_vss = (NW_2_x-gap-4*I*a-5*Lambda, y0+gap,
                      NW_2_x-gap-4*I*a-5*Lambda-w, y0+L+(M-1)*b)
            m1_vdd = (nw_1_x, y0-b, x0, y0)
            m_plus = (x0 + gap, y0-7*b-gap-Lambda, x0 + gap - w, y0)
            # rotating shapes
            m1_vss = self.rotate_shape(
                m1_vss, axis_point_x, axis_point_y, angle)
            m1_vdd = self.rotate_shape(
                m1_vdd, axis_point_x, axis_point_y, angle)
            m_plus = self.rotate_shape(
                m_plus, axis_point_x, axis_point_y, angle)
            # mirror shapes
            m1_vss = self.mirror_shape(
                m1_vss, axis_point_x, axis_point_y, mirr_axis)
            m1_vdd = self.mirror_shape(
                m1_vdd, axis_point_x, axis_point_y, mirr_axis)
            m_plus = self.mirror_shape(
                m_plus, axis_point_x, axis_point_y, mirr_axis)
            # making list
            metals = [m1_vdd, m_plus, m1_vss]
            if self.choosed_blocks[f'DC{axis}']:
                for i in range(len(metals)):
                    self.create_rec_with_mem(
                        *metals[i], fill='blue', outline='blue', tags=f"DC{axis}_vdd_ME_{i}")

            '''Poly-Si creating'''

            # between pdiff polysi
            for j in range(2*I):
                dop = (j//2)*dop_shift
                if j % 2 == 0:
                    P_coords = (x0-5*Lambda - j*2*w, y0-4*b, x0 -
                                5*Lambda - j*2*w - w/2, y0+L+M*b)
                    P_square_coords = (x0-5*Lambda - j*2*w, y0+j*w+(j+1)*(
                        2*(b+gap))+dop, x0-5*Lambda - j*2*w - w, y0+(j+1)*(w+(2*(b+gap)))+dop)
                    # contacts for squared PO
                    CO_square_coords = (x0-6*Lambda - j*2*w, y0+j*w+(j+1)*(
                        2*(b+gap))+Lambda+dop, x0-4*Lambda - j*2*w - w, y0+(j+1)*(w+(2*(b+gap)))-Lambda+dop)

                else:
                    P_coords = (x0-5*Lambda - j*2*w, y0-7*b, x0 -
                                5*Lambda - j*2*w - w/2, y0+L+M*b)
                    P_square_coords = (x0-5*Lambda - j*2*w+w/2, y0+j*w+(j+1)*(
                        2*(b+gap))+dop, x0-5*Lambda - j*2*w - w/2, y0+(j+1)*(w+(2*(b+gap)))+dop)
                    # contacts for squared PO
                    CO_square_coords = (x0-6*Lambda - j*2*w+w/2, y0+j*w+(j+1)*(
                        2*(b+gap))+Lambda+dop, x0-4*Lambda - j*2*w - w/2, y0+(j+1)*(w+(2*(b+gap)))-Lambda+dop)

                # rotating shapes
                P_coords = self.rotate_shape(
                    P_coords, axis_point_x, axis_point_y, angle)
                P_square_coords = self.rotate_shape(
                    P_square_coords, axis_point_x, axis_point_y, angle)
                CO_square_coords = self.rotate_shape(
                    CO_square_coords, axis_point_x, axis_point_y, angle)
                # mirror shapes
                P_coords = self.mirror_shape(
                    P_coords, axis_point_x, axis_point_y, mirr_axis)
                P_square_coords = self.mirror_shape(
                    P_square_coords, axis_point_x, axis_point_y, mirr_axis)
                CO_square_coords = self.mirror_shape(
                    CO_square_coords, axis_point_x, axis_point_y, mirr_axis)
                # draw shapes
                if self.choosed_blocks[f'DC{axis}']:
                    self.create_rec_with_mem(
                        *P_coords, outline='red', fill='red', tags=f"DC{axis}_areaN_PO_{j}")
                    self.create_rec_with_mem(
                        *P_square_coords, outline='red', fill='red', tags=f"DC{axis}_squareN_PO_{j}")
                    self.create_rec_with_mem(
                        *CO_square_coords, outline='black', fill='black', tags=f"DC{axis}_squareN_CO_{j}")

            # between ndiff polysi
            for j in range(2*I):
                dop = (j//2)*dop_shift
                P_coords = (NW_2_x-gap-5*Lambda - j*2*w, y0,
                            NW_2_x-gap-5*Lambda - j*2*w - w/2, y0+L+M*b)
                P_square_coords = (NW_2_x-gap-5*Lambda - j*2*w+w/2, y0+j*w+(j+1)*(
                    2*(b+gap))+dop, NW_2_x-gap-5*Lambda - j*2*w - w/2, y0+(j+1)*(w+(2*(b+gap)))+dop)
                # contacts for squared PO
                CO_square_coords = (NW_2_x-gap-6*Lambda - j*2*w+w/2, y0+j*w+(j+1)*(2*(b+gap)) +
                                    Lambda+dop, NW_2_x-gap-4*Lambda - j*2*w - w/2, y0+(j+1)*(w+(2*(b+gap)))-Lambda+dop)

                # rotating shapes
                P_coords = self.rotate_shape(
                    P_coords, axis_point_x, axis_point_y, angle)
                P_square_coords = self.rotate_shape(
                    P_square_coords, axis_point_x, axis_point_y, angle)
                CO_square_coords = self.rotate_shape(
                    CO_square_coords, axis_point_x, axis_point_y, angle)
                # mirror shapes
                P_coords = self.mirror_shape(
                    P_coords, axis_point_x, axis_point_y, mirr_axis)
                P_square_coords = self.mirror_shape(
                    P_square_coords, axis_point_x, axis_point_y, mirr_axis)
                CO_square_coords = self.mirror_shape(
                    CO_square_coords, axis_point_x, axis_point_y, mirr_axis)
                # draw shapes
                if self.choosed_blocks[f'DC{axis}']:
                    self.create_rec_with_mem(
                        *P_coords, outline='red', fill='red', tags=f"DC{axis}_areaP_PO_{j}")
                    self.create_rec_with_mem(
                        *P_square_coords, outline='red', fill='red', tags=f"DC{axis}_squareP_PO_{j}")
                    self.create_rec_with_mem(
                        *CO_square_coords, outline='black', fill='black', tags=f"DC{axis}_squareP_CO_{j}")

            # metals creating between PO squares in P and N wells
            for j in range(2*I):
                dop = (j//2)*dop_shift
                if j % 2 == 0:
                    ME_coords = (x0-5*Lambda - j*2*w, y0+j*w+(j+1)*(2*(b+gap))+dop,
                                 NW_2_x-gap-5*Lambda - j*2*w - w/2, y0+(j+1)*(w+(2*(b+gap)))+dop)
                else:
                    ME_coords = (x0-5*Lambda - j*2*w+w/2, y0+j*w+(j+1)*(2*(b+gap))+dop,
                                 NW_2_x-gap-5*Lambda - j*2*w - w/2, y0+(j+1)*(w+(2*(b+gap)))+dop)
                ME_coords = self.rotate_shape(
                    ME_coords, axis_point_x, axis_point_y, angle)
                ME_coords = self.mirror_shape(
                    ME_coords, axis_point_x, axis_point_y, mirr_axis)
                if self.choosed_blocks[f'DC{axis}']:
                    self.create_rec_with_mem(
                        *ME_coords, fill='blue', outline='blue', tags=f"DC{axis}_betweenPOsquares_ME_{j}")

            '''--------------------Invertors creating-----------------'''
            # -----------PDiff creating----------
            for j in range(I):
                # get coords
                PDiff_cooords = (x0-j*(w+3*a)-(w+a), y0-3*b -
                                 gap, x0-j*(w+3*a)-(w+4*a), y0-b-gap)
                PDiff_pol = (x0-j*(w+3*a)-(w+3*a), y0-6*b-gap-b/2 -
                             Lambda, x0-j*(w+3*a)-(w+4*a), y0-5*b-gap-b/2-Lambda)
                PDiff_pol_CO = (x0-j*(w+3*a)-(w+3*a)-Lambda, y0-6 *
                                b-gap-b/2, x0-j*(w+3*a)-(w+4*a)+Lambda, y0-6*b-gap)
                # rotating shapes
                PDiff_cooords = self.rotate_shape(
                    PDiff_cooords, axis_point_x, axis_point_y, angle)
                PDiff_pol = self.rotate_shape(
                    PDiff_pol, axis_point_x, axis_point_y, angle)
                PDiff_pol_CO = self.rotate_shape(
                    PDiff_pol_CO, axis_point_x, axis_point_y, angle)
                # mirror shapes
                PDiff_cooords = self.mirror_shape(
                    PDiff_cooords, axis_point_x, axis_point_y, mirr_axis)
                PDiff_pol = self.mirror_shape(
                    PDiff_pol, axis_point_x, axis_point_y, mirr_axis)
                PDiff_pol_CO = self.mirror_shape(
                    PDiff_pol_CO, axis_point_x, axis_point_y, mirr_axis)
                # draw shapes
                if self.choosed_blocks[f'DC{axis}']:
                    self.create_rec_with_mem(*PDiff_cooords, outline='brown', fill='brown', tags=f"DC{axis}_inv_DP_{j}")
                    self.create_rec_with_mem(*PDiff_pol, outline='brown', fill='brown', tags=f"DC{axis}_invPol_DP_{j}")
                    self.create_rec_with_mem(*PDiff_pol_CO, outline='black', fill='black', tags=f"DC{axis}_invDPpol_CO_{j}")
                for v in range(2):
                    PDiff_CO = (x0-j*(w+3*a)-(w+a)-Lambda-v*2*a, y0-2*b-gap+Lambda,
                                x0-j*(w+3*a)-(w+a)-Lambda-a/2-v*2*a, y0-b-gap-Lambda)
                    PDiff_CO = self.rotate_shape(
                        PDiff_CO, axis_point_x, axis_point_y, angle)
                    PDiff_CO = self.mirror_shape(
                        PDiff_CO, axis_point_x, axis_point_y, mirr_axis)
                    if self.choosed_blocks[f'DC{axis}']:
                        self.create_rec_with_mem(*PDiff_CO, outline='black', fill='black', tags=f"DC{axis}_invDP_CO_{j}{v}")
            # -----------NDiff creating----------
            for j in range(I):
                NDiff_coords = (x0-j*(w+3*a)-(w+a), y0-5*b -
                                gap-b/2, x0-j*(w+3*a)-(w+4*a), y0-4*b-gap-b/2)
                NDiff_coords = self.rotate_shape(
                    NDiff_coords, axis_point_x, axis_point_y, angle)
                NDiff_coords = self.mirror_shape(
                    NDiff_coords, axis_point_x, axis_point_y, mirr_axis)
                if self.choosed_blocks[f'DC{axis}']:
                    self.create_rec_with_mem(*NDiff_coords, outline='green', fill='green', tags=f"DC{axis}_inv_DN_{j}")
                for v in range(2):
                    NDiff_CO = (x0-j*(w+3*a)-(w+a)-Lambda-v*2*a, y0-5*b-gap-b/2+Lambda,
                                x0-j*(w+3*a)-(w+a)-Lambda-a/2-v*2*a, y0-4*b-gap-b/2-Lambda)
                    NDiff_CO = self.rotate_shape(
                        NDiff_CO, axis_point_x, axis_point_y, angle)
                    NDiff_CO = self.mirror_shape(
                        NDiff_CO, axis_point_x, axis_point_y, mirr_axis)
                    if self.choosed_blocks[f'DC{axis}']:
                        self.create_rec_with_mem(*NDiff_CO, outline='black', fill='black', tags=f"DC{axis}_invDN_CO_{j}{v}")

            # -----------POlySi creating----------
            for j in range(2*I):
                # polysi creating and metall on polysi creating
                if j % 2 == 0:
                    PO_coords = (x0-5*Lambda - j*2*w, y0-5*b,
                                 x0-5*Lambda - j*2*w-b, y0-4*b)
                    PO_ME = (x0-5*Lambda - j*2*w, y0-5*b,
                             x0-5*Lambda - j*2*w-b, y0-4*b)
                    PO_CO = (x0-6*Lambda - j*2*w, y0-5*b+Lambda,
                             x0-4*Lambda - j*2*w-b, y0-4*b-Lambda)
                else:
                    PO_coords = (x0-5*Lambda - j*2*w+a, y0-8*b,
                                 x0-5*Lambda - j*2*w, y0-7*b+b/2)
                    PO_ME = (x0-5*Lambda - j*2*w+a, y0-8 *
                             b, x0-5*Lambda - j*2*w, y0-7*b)
                    PO_CO = (x0-6*Lambda - j*2*w+a, y0-8*b+Lambda,
                             x0-4*Lambda - j*2*w, y0-7*b-Lambda)
                # rotating shapes
                PO_coords = self.rotate_shape(
                    PO_coords, axis_point_x, axis_point_y, angle)
                PO_ME = self.rotate_shape(
                    PO_ME, axis_point_x, axis_point_y, angle)
                PO_CO = self.rotate_shape(
                    PO_CO, axis_point_x, axis_point_y, angle)
                # mirror shapes
                PO_coords = self.mirror_shape(
                    PO_coords, axis_point_x, axis_point_y, mirr_axis)
                PO_ME = self.mirror_shape(
                    PO_ME, axis_point_x, axis_point_y, mirr_axis)
                PO_CO = self.mirror_shape(
                    PO_CO, axis_point_x, axis_point_y, mirr_axis)
                # draw shapes
                if self.choosed_blocks[f'DC{axis}']:
                    self.create_rec_with_mem(
                        *PO_coords, outline='red', fill='red', tags=f"DC{axis}_area_PO_{j}")
                    self.create_rec_with_mem(
                        *PO_ME, outline='blue', tags=f"DC{axis}_areaPO_ME_{j}")
                    self.create_rec_with_mem(
                        *PO_CO, outline='black', fill='black', tags=f"DC{axis}_areaPO_CO_{j}")
            # -----------MEtall creating----------
            for j in range(I):
                ME_coords = (x0-j*(w+3*a)-(w+a), y0-5*b-gap-b /
                             2, x0-j*(w+3*a)-(w+2*a), y0-b-gap)
                ME_coords = self.rotate_shape(
                    ME_coords, axis_point_x, axis_point_y, angle)
                ME_coords = self.mirror_shape(
                    ME_coords, axis_point_x, axis_point_y, mirr_axis)
                if self.choosed_blocks[f'DC{axis}']:
                    self.create_rec_with_mem(
                        *ME_coords, fill='blue', outline='blue', tags=f"DC{axis}_inv_ME_{j}")

            for j in range(1, I+1):
                ME_coords = [(x0-j*(w+3*a), y0-2*b-gap, x0-j*(w+3*a)-w, y0), (x0 -
                                                                              j*(w+3*a), y0-6*b-gap-b/2-Lambda, x0-j*(w+3*a)-w, y0-4*b-gap-b/2)]
                for v in range(len(ME_coords)):
                    ME_coords[v] = self.rotate_shape(
                        ME_coords[v], axis_point_x, axis_point_y, angle)
                    ME_coords[v] = self.mirror_shape(
                        ME_coords[v], axis_point_x, axis_point_y, mirr_axis)
                    if self.choosed_blocks[f'DC{axis}']:
                        self.create_rec_with_mem(
                            *ME_coords[v], fill='blue', outline='blue', tags=f"DC{axis}_inv_ME_{j}")
            # -----------VIa creating----------
            for j in range(I):
                # get coords
                VI_coords = (x0-j*(w+3*a)-(w+a)-Lambda-2*a, y0-5*b-gap-b/2+Lambda,
                             x0-j*(w+3*a)-(w+a)-Lambda-a/2-2*a, y0-4*b-gap-b/2-Lambda)
                ME2_coords = (x0-j*(w+3*a)-(w+a)-2*a, y0-5*b -
                              gap-b/2, x0-j*(w+3*a)-(w+a)-3*a, y0-4*b-gap-b/2)
                # rotating shapes
                VI_coords = self.rotate_shape(
                    VI_coords, axis_point_x, axis_point_y, angle)
                ME2_coords = self.rotate_shape(
                    ME2_coords, axis_point_x, axis_point_y, angle)
                # mirror shapes
                VI_coords = self.mirror_shape(
                    VI_coords, axis_point_x, axis_point_y, mirr_axis)
                ME2_coords = self.mirror_shape(
                    ME2_coords, axis_point_x, axis_point_y, mirr_axis)
                # draw shapes
                if self.choosed_blocks[f'DC{axis}']:
                    self.create_rec_with_mem(*VI_coords, outline='gray', fill='gray', tags= f"DC{axis}_inv_VI_{j}")
                    self.create_rec_with_mem(*ME2_coords, outline='#00008B', fill='#00008B', dash= '-.', tags = f"DC{axis}_inv_M2_{j}")

            # -----------VI for vss creating----------
            VI_pol = (NW_2_x-gap-4*I*a-Lambda, y0+gap+Lambda,
                      NW_2_x-gap-4*I*a-w+Lambda, y0+(gap+w)-Lambda)
            VI_pol = self.rotate_shape(
                VI_pol, axis_point_x, axis_point_y, angle)
            VI_pol = self.mirror_shape(
                VI_pol, axis_point_x, axis_point_y, mirr_axis)
            if self.choosed_blocks[f'DC{axis}']:
                self.create_rec_with_mem(*VI_pol, outline='gray', fill='gray', tags= f"DC{axis}_{0}_VI_pol")
            # -----------ME2 creating----------
            ME2_coords = (x0 + gap, y0-5*b-gap, NW_2_x-gap-4*I*a-w, y0-4*b-gap)
            ME2_coords = self.rotate_shape(
                ME2_coords, axis_point_x, axis_point_y, angle)
            ME2_coords = self.mirror_shape(
                ME2_coords, axis_point_x, axis_point_y, mirr_axis)
            if self.choosed_blocks[f'DC{axis}']:
                self.create_rec_with_mem(*ME2_coords, outline='#00008B', fill='#00008B', dash= '-.', tags = f"DC{axis}_{0}_M2_vss")

            ME2_coords = (NW_2_x-gap-4*I*a, y0-7*b-gap -
                          Lambda, NW_2_x-gap-4*I*a-w, y0+b+gap)
            ME2_coords = self.rotate_shape(
                ME2_coords, axis_point_x, axis_point_y, angle)
            ME2_coords = self.mirror_shape(
                ME2_coords, axis_point_x, axis_point_y, mirr_axis)
            if self.choosed_blocks[f'DC{axis}']:
                self.create_rec_with_mem(*ME2_coords, outline='#00008B', fill='#00008B', dash= '-.', tags = f"DC{axis}_{0}_M2_vss")
            '''-------------------------------------------------------'''

    def compact_matrix_DC_SW(self, axis_point_x, axis_point_y, Lambda_init, axis, angle, I, mirr_axis, dop_shift):
        # чтобы проще было считать в клетках в magic, что эквивалентно 1 клетка = 50 нм
        Lambda = Lambda_init * 5
        # print('Lambda:', Lambda)
        # x0 = axis_point_x - 3*Lambda # добавка чтобы сместить начало рисования в NE точку OP
        # y0 = axis_point_y + 32*Lambda

        M = 2**I  # amount of outputs

        gate_length = 3 * Lambda
        gate_vs_active = 2 * Lambda
        active_width = 8 * Lambda
        polar_width = 8 * Lambda
        active_h_delta = 6 * Lambda
        pmos_width = 16 * Lambda

        co_size = 4 * Lambda
        polar_gap = 1 * Lambda
        gap = 4 * Lambda

        mos_length = 2 * active_width + gate_length + 2 * gate_vs_active
        inv_p_width = 48 * Lambda
        inv_n_width = 16 * Lambda
        inv_p_gap = 2 * active_width

        x0 = axis_point_x - gap
        y0 = axis_point_y - (- inv_p_width - inv_p_gap -
                             inv_n_width - 2 * (active_width + active_h_delta))

        NW_1_x = x0 + gap
        NW_1_y = y0 - polar_width - 2 * polar_gap - inv_p_width - active_h_delta - gap
        NW_2_x = x0 - active_width * \
            (2 * I + 1) - 2 * I * (gate_length + gate_vs_active * 2) - gap
        NW_2_y = y0 + active_h_delta + pmos_width * M + \
            active_width * (M - 1) + gate_vs_active * 4 * M + gap

        '''---------------crossbar creating--------------'''
        '''OP layer creating'''
        OP_coords = (
            x0 + gap,
            y0 - inv_p_width - inv_p_gap - inv_n_width -
            2 * (active_width + active_h_delta),
            NW_2_x - ((mos_length + 2 * gate_vs_active + gate_length) * I +
                      2 * active_h_delta + polar_gap + active_width) - active_width,
            y0 + active_h_delta + pmos_width * M + active_width *
            (M - 1) + gate_vs_active * 4 * M + gap
        )
        OP_coords = self.rotate_shape(
            OP_coords, axis_point_x, axis_point_y, angle)
        OP_coords = self.mirror_shape(
            OP_coords, axis_point_x, axis_point_y, mirr_axis)
        self.create_rec_with_mem(
            *OP_coords, outline=lookup['SkyWater130']['OP']['color'], tags=f"DC{axis}_{0}_OP_layer")

        forward = [0]*M
        revers = [0]*M
        crossbar = [0]*M
        for i in range(M):
            decimal = i
            binary = ""
            while decimal > 0:
                remainder = decimal % 2
                binary = str(remainder) + binary
                decimal = decimal // 2
            forward[i] = list(binary.zfill(I))
        for i in range(M):
            revers[i] = forward[-i-1]
            # crossbar[i] = forward[i] + revers[i]
        revers = transpose(array(revers))
        forward = transpose(array(forward))
        crossbar = transpose(column_stack(
            (forward, revers)).reshape(-1, forward.shape[1]))

        # NDiff matrix creating
        crossbar = crossbar.astype('int')
        # one way using np.where, and taking the bitwise XOR of a given value when it is either 0 or 1
        me_crossbar = where((crossbar == 0) | (crossbar == 1), crossbar ^ 1, crossbar)
        ndiff_crossbar = crossbar
        s_array = zeros((M, 2*I+1))
        for j in range(2*I+1):
            if j == 0:
                s_array[:, j] = crossbar[:, j]
            elif j == 2*I:
                s_array[:, j] = crossbar[:, -1]
            else:
                s_array[:, j] = crossbar[:, j-1] | crossbar[:, j]
        # co_crossbar=np.where((crossbar==0)|(crossbar==1), crossbar^1, crossbar)
        n = 0
        for j in range(2*I+1):
            me_crossbar = insert(me_crossbar, n, ones(M), axis=1)
            ndiff_crossbar = insert(ndiff_crossbar, n, s_array[:, j], axis=1)
            n += 2
        # print(ndiff_crossbar)
        co_crossbar = zeros((M, 4*I+1))
        co_crossbar = co_crossbar.astype('int')
        for j in range(4*I+1):
            if j % 2 == 0:
                co_crossbar[:, j] = ndiff_crossbar[:, j]

        '''-----------------------------------------------'''
        for m in range(M):
            for n in range(2*I):
                if int(crossbar[m][-n-1]) == 1:
                    # make coords
                    crossbar_cords = (
                        x0 - active_width * (n + 1) - n *
                        (gate_length + 2 * gate_vs_active),
                        y0 + active_h_delta + m *
                        (pmos_width + active_width + 4 * gate_vs_active),
                        x0 - active_width *
                        (n + 1) - n * (gate_length + 2 * gate_vs_active) -
                        (gate_length + 2 * gate_vs_active),
                        y0 + active_h_delta + m *
                        (pmos_width + active_width +
                         4 * gate_vs_active) + pmos_width
                    )
                    # rotate shapes
                    crossbar_cords = self.rotate_shape(
                        crossbar_cords, axis_point_x, axis_point_y, angle)
                    # mirror shapes
                    crossbar_cords = self.mirror_shape(
                        crossbar_cords, axis_point_x, axis_point_y, mirr_axis)
                    self.create_rec_with_mem(*crossbar_cords, outline=lookup['SkyWater130']['pdiff']['color'], fill=lookup['SkyWater130']['pdiff']['fill'], tags=f"DC{axis}_{m}{n}_pdiff_cross")

        for m in range(M):
            k_a = 0
            k_b = 0
            for n in range(4*I+1):
                if int(ndiff_crossbar[m][-n-1]) == 1:
                    ndiff_crossbar_coords = (
                        (NW_2_x - active_h_delta - polar_gap) - (k_a *
                                                                 active_width + k_b * (gate_length + 2 * gate_vs_active)),
                        y0 + active_h_delta + m *
                        (pmos_width + active_width + 4 * gate_vs_active),
                        (NW_2_x - active_h_delta - polar_gap) - (k_a * active_width + k_b * (gate_length + 2 *
                                                                                             gate_vs_active)) - active_width * ((n + 1) % 2) - (2 * gate_vs_active + gate_length) * (n % 2),
                        y0 + active_h_delta + m *
                        (pmos_width + active_width +
                         4 * gate_vs_active) + pmos_width
                    )
                    ndiff_crossbar_coords = self.rotate_shape(
                        ndiff_crossbar_coords, axis_point_x, axis_point_y, angle)
                    ndiff_crossbar_coords = self.mirror_shape(
                        ndiff_crossbar_coords, axis_point_x, axis_point_y, mirr_axis)
                    self.create_rec_with_mem(*ndiff_crossbar_coords, outline=lookup['SkyWater130']['ndiff']['color'], fill=lookup['SkyWater130']['ndiff']['fill'], tags=f"DC{axis}_{m}{n}_ndiff_cross")
                if n % 2 == 0:
                    k_a += 1
                else:
                    k_b += 1

        for m in range(M):
            k_a = 0
            k_b = 0
            for n in range(4*I+1):
                if int(me_crossbar[m][-n-1]) == 1:
                    me_crossbar_coords = (
                        (NW_2_x - active_h_delta - polar_gap) - (k_a *
                                                                 active_width + k_b * (gate_length + 2 * gate_vs_active)),
                        y0 + active_h_delta + m *
                        (pmos_width + active_width + 4 * gate_vs_active),
                        (NW_2_x - active_h_delta - polar_gap) - (k_a * active_width + k_b * (gate_length + 2 *
                                                                                             gate_vs_active)) - active_width * ((n + 1) % 2) - (2 * gate_vs_active + gate_length) * (n % 2),
                        y0 + active_h_delta + m *
                        (pmos_width + active_width + 4 *
                         gate_vs_active) + active_width
                    )
                    me_crossbar_coords = self.rotate_shape(
                        me_crossbar_coords, axis_point_x, axis_point_y, angle)
                    me_crossbar_coords = self.mirror_shape(
                        me_crossbar_coords, axis_point_x, axis_point_y, mirr_axis)
                    self.create_rec_with_mem(*me_crossbar_coords, fill=lookup['SkyWater130']['locali']['fill'], outline=lookup['SkyWater130']['locali']['color'], tags=f"DC{axis}_{m}{n}_locali_cross")
                if n % 2 == 0:
                    k_a += 1
                else:
                    k_b += 1

        for m in range(M):
            k_a = 0
            k_b = 0
            for n in range(4*I+1):
                if int(co_crossbar[m][-n-1]) == 1:
                    co_crossbar_coords = (
                        (NW_2_x - active_h_delta - polar_gap) - (k_a * active_width + k_b *
                                                                 (gate_length + 2 * gate_vs_active)) - (active_width - co_size) / 2,
                        y0 + active_h_delta + m *
                        (pmos_width + active_width + 4 * gate_vs_active) +
                        (active_width - co_size) / 2,
                        (NW_2_x - active_h_delta - polar_gap) - (k_a * active_width + k_b * (gate_length + 2 * gate_vs_active)) -
                        active_width * ((n + 1) % 2) - (2 * gate_vs_active +
                                                        gate_length) * (n % 2) + (active_width - co_size) / 2,
                        y0 + active_h_delta + m *
                        (pmos_width + active_width + 4 * gate_vs_active) +
                        (active_width - co_size) / 2 + co_size
                    )
                    co_crossbar_coords = self.rotate_shape(
                        co_crossbar_coords, axis_point_x, axis_point_y, angle)
                    co_crossbar_coords = self.mirror_shape(
                        co_crossbar_coords, axis_point_x, axis_point_y, mirr_axis)
                    self.create_rec_with_mem(*co_crossbar_coords, outline=lookup['SkyWater130']['ndiffc']['color'], fill=lookup['SkyWater130']['ndiffc']['fill'], tags=f"DC{axis}_{m}{n}_ndiffc_cross")
                if n % 2 == 0:
                    k_a += 1
                else:
                    k_b += 1

        '''main block of pdiff fingers'''
        for j in range(I+1):
            # make coords
            T_coords = (
                x0 - j * (active_width + 2 * gate_length +
                          polar_width + 4 * gate_vs_active),
                y0 - active_width,
                x0 - j * (active_width + 2 * gate_length +
                          polar_width + 4 * gate_vs_active) - active_width,
                y0 + active_h_delta + pmos_width * M +
                active_width * (M - 1) + gate_vs_active * 4 * M
            )
            B_coords_T = (
                T_coords[0] - (active_width - co_size) / 2,
                T_coords[1] + (active_width - co_size) / 2,
                T_coords[0] - (active_width - co_size) / 2 - co_size,
                T_coords[1] + (active_width - co_size) / 2 + co_size
            )

            for i in range(M+1):
                if j != I:
                    # make coords
                    if i == 0:
                        C_coords = (
                            T_coords[2] - gate_length - 2 * gate_vs_active,
                            y0 - active_width - 2 * Lambda,
                            T_coords[2] - gate_length - 2 *
                            gate_vs_active - active_width,
                            y0
                        )
                        B_coords = (
                            C_coords[0] - (active_width - co_size) / 2,
                            C_coords[1] +
                            (polar_width - co_size) / 2 + polar_gap,
                            C_coords[2] + (active_width - co_size) / 2,
                            C_coords[3] -
                            (polar_width - co_size) / 2 - polar_gap,
                        )
                    else:
                        C_coords = (
                            T_coords[2] - gate_length - 2 * gate_vs_active,
                            y0 + active_h_delta +
                            (pmos_width + active_width +
                             4 * gate_vs_active) * (i - 1),
                            T_coords[2] - gate_length - 2 *
                            gate_vs_active - active_width,
                            y0 + active_h_delta +
                            (pmos_width + active_width + 4 *
                                 gate_vs_active) * (i - 1) + pmos_width
                        )
                        B_coords = (
                            C_coords[0] - (active_width - co_size) / 2,
                            C_coords[1] + (active_width - co_size) / 2,
                            C_coords[0] - (active_width -
                                           co_size) / 2 - co_size,
                            C_coords[1] + (active_width -
                                           co_size) / 2 + co_size
                        )
                    if i != 0:
                        C_color = lookup['SkyWater130']['pdiff']['color']
                        area = 'pdiff'
                        co_color = lookup['SkyWater130']['pdiffc']['color']
                        co_area = 'pdiffc'
                    else:
                        C_color = lookup['SkyWater130']['nsubdiff']['color']
                        area = 'nsubdiff'
                        co_color = lookup['SkyWater130']['nsubdiffcont']['color']
                        co_area = 'nsubdiffcont'

                    # rotate shapes
                    C_coords = self.rotate_shape(
                        C_coords, axis_point_x, axis_point_y, angle)
                    B_coords = self.rotate_shape(
                        B_coords, axis_point_x, axis_point_y, angle)
                    # mirror shapes
                    C_coords = self.mirror_shape(
                        C_coords, axis_point_x, axis_point_y, mirr_axis)
                    B_coords = self.mirror_shape(
                        B_coords, axis_point_x, axis_point_y, mirr_axis)
                    # draw shapes
                    self.create_rec_with_mem(
                        *C_coords, outline=C_color, fill=C_color, tags=f"DC{axis}_{j}{i}_{area}_C")
                    self.create_rec_with_mem(
                        *B_coords, outline=co_color, fill=co_color, tags=f"DC{axis}_{j}{i}_{co_area}_B")

            # rotate shapes
            T_coords = self.rotate_shape(
                T_coords, axis_point_x, axis_point_y, angle)
            B_coords_T = self.rotate_shape(
                B_coords_T, axis_point_x, axis_point_y, angle)
            # mirror shapes
            T_coords = self.mirror_shape(
                T_coords, axis_point_x, axis_point_y, mirr_axis)
            B_coords_T = self.mirror_shape(
                B_coords_T, axis_point_x, axis_point_y, mirr_axis)
            # create shapes
            self.create_rec_with_mem(*T_coords, outline=lookup['SkyWater130']['pdiff']['color'], fill=lookup['SkyWater130']['pdiff']['fill'], tags=f"DC{axis}_T_pdiff_{j}")
            self.create_rec_with_mem(*B_coords_T, outline=lookup['SkyWater130']['pdiffc']['color'], fill=lookup['SkyWater130']['pdiffc']['fill'], tags=f"DC{axis}_BT_pdiffc_{j}")

        for i in range(1, M+1):
            # make coords
            metal_outline = (
                x0 + gap,
                y0 + active_h_delta +
                (i - 1) * (pmos_width + active_width + 4 * gate_vs_active),
                NW_2_x - active_h_delta - polar_gap,
                y0 + active_h_delta +
                (i - 1) * (pmos_width + active_width +
                           4 * gate_vs_active) + active_width
            )
            # rotate shapes
            metal_outline = self.rotate_shape(
                metal_outline, axis_point_x, axis_point_y, angle)
            # mirror shapes
            metal_outline = self.mirror_shape(
                metal_outline, axis_point_x, axis_point_y, mirr_axis)
            # draw shapes
            self.create_rec_with_mem(*metal_outline, fill=lookup['SkyWater130']['locali']['fill'],
                                     outline=lookup['SkyWater130']['locali']['color'], tags=f"DC{axis}_MetalOutline_locali_{i}")

        '''NWell creating'''
        # make coords
        NW_coords = (NW_1_x, NW_1_y, NW_2_x, NW_2_y)
        # rotate shapes
        NW_coords = self.rotate_shape(
            NW_coords, axis_point_x, axis_point_y, angle)
        # mirror shapes
        NW_coords = self.mirror_shape(
            NW_coords, axis_point_x, axis_point_y, mirr_axis)
        # draw shapes
        self.create_rec_with_mem(*NW_coords, outline=lookup['SkyWater130']['nwell']['color'],
                                 dash=lookup['SkyWater130']['nwell']['border'], tags=f"DC{axis}_0_nwell_area")

        '''NMOS polarization creating'''

        for m in range(M):
            # get coords
            polar_coords = (
                NW_2_x - ((mos_length + 2 * gate_vs_active + gate_length)
                          * I + 2 * active_h_delta + polar_gap + active_width),
                y0 + active_h_delta + m *
                (pmos_width + active_width + 4 * gate_vs_active) - polar_gap,
                NW_2_x - ((mos_length + 2 * gate_vs_active + gate_length) * I +
                          2 * active_h_delta + polar_gap + active_width) - active_width,
                y0 + active_h_delta + m *
                (pmos_width + active_width + 4 * gate_vs_active) +
                active_width + polar_gap
            )
            polar_met = (
                NW_2_x - ((mos_length + 2 * gate_vs_active + gate_length)
                          * I + active_h_delta + polar_gap + active_width),
                y0 + active_h_delta + m *
                (pmos_width + active_width + 4 * gate_vs_active),
                NW_2_x - ((mos_length + 2 * gate_vs_active + gate_length) * I +
                          2 * active_h_delta + polar_gap + active_width) - active_width,
                y0 + active_h_delta + m *
                (pmos_width + active_width + 4 * gate_vs_active) + active_width
            )
            cont_coords = (
                NW_2_x - ((mos_length + 2 * gate_vs_active + gate_length) * I + 2 *
                          active_h_delta + polar_gap + active_width) - (active_width - co_size) / 2,
                y0 + active_h_delta + m *
                (pmos_width + active_width + 4 * gate_vs_active) +
                (active_width - co_size) / 2,
                NW_2_x - ((mos_length + 2 * gate_vs_active + gate_length) * I + 2 * active_h_delta +
                          polar_gap + active_width) - active_width + (active_width - co_size) / 2,
                y0 + active_h_delta + m *
                (pmos_width + active_width + 4 * gate_vs_active) +
                active_width - (active_width - co_size) / 2
            )
            # rotating shapes
            polar_met = self.rotate_shape(
                polar_met, axis_point_x, axis_point_y, angle)
            polar_coords = self.rotate_shape(
                polar_coords, axis_point_x, axis_point_y, angle)
            cont_coords = self.rotate_shape(
                cont_coords, axis_point_x, axis_point_y, angle)
            # mirror shapes
            polar_met = self.mirror_shape(
                polar_met, axis_point_x, axis_point_y, mirr_axis)
            polar_coords = self.mirror_shape(
                polar_coords, axis_point_x, axis_point_y, mirr_axis)
            cont_coords = self.mirror_shape(
                cont_coords, axis_point_x, axis_point_y, mirr_axis)
            # draw shapes
            self.create_rec_with_mem(*polar_coords, outline=lookup['SkyWater130']['psubdiff']['color'],
                                     fill=lookup['SkyWater130']['psubdiff']['fill'], tags=f"DC{axis}_NmosPol_psubdiff_{i}")
            self.create_rec_with_mem(*cont_coords, outline=lookup['SkyWater130']['psubdiffcont']['color'],
                                     fill=lookup['SkyWater130']['psubdiffcont']['fill'], tags=f"DC{axis}_PolCont_psubdiffcont_{i}")
            self.create_rec_with_mem(*polar_met, outline=lookup['SkyWater130']['locali']['color'],
                                     fill=lookup['SkyWater130']['locali']['fill'], tags=f"DC{axis}_pol_locali_{i}")

        '''metal layers creating'''
        # get coords
        m1_vss = (
            NW_2_x - ((mos_length + 2 * gate_vs_active + gate_length) * I +
                      active_h_delta + polar_gap + active_width) - active_width + gate_vs_active,
            y0 + active_h_delta,
            NW_2_x - ((mos_length + 2 * gate_vs_active + gate_length) * I + active_h_delta +
                      polar_gap + active_width) - 2 * active_width + gate_vs_active,
            NW_2_y
        )

        m1_vdd = (
            OP_coords[0],
            OP_coords[1],
            OP_coords[0] - active_width,
            y0
        )

        m_plus = (
            x0 + gap,
            y0 - active_width,
            NW_2_x,
            y0
        )
        # rotating shapes
        m1_vss = self.rotate_shape(m1_vss, axis_point_x, axis_point_y, angle)
        m1_vdd = self.rotate_shape(m1_vdd, axis_point_x, axis_point_y, angle)
        m_plus = self.rotate_shape(m_plus, axis_point_x, axis_point_y, angle)
        # mirror shapes
        m1_vss = self.mirror_shape(
            m1_vss, axis_point_x, axis_point_y, mirr_axis)
        m1_vdd = self.mirror_shape(
            m1_vdd, axis_point_x, axis_point_y, mirr_axis)
        m_plus = self.mirror_shape(
            m_plus, axis_point_x, axis_point_y, mirr_axis)
        # making list
        metals = [m1_vdd, m_plus, m1_vss]
        for i in range(len(metals)):
            self.create_rec_with_mem(*metals[i], outline=lookup['SkyWater130']['locali']['color'],
                                     fill=lookup['SkyWater130']['locali']['fill'], tags=f"DC{axis}_vdd_locali_{i}")

        '''Poly-Si creating'''

        # between pdiff polysi
        for j in range(2*I):
            if j % 2 == 0:
                P_coords = (
                    x0 - (active_width + gate_vs_active) * (j + 1) -
                    (gate_length + gate_vs_active) * j,
                    y0 - inv_p_width - inv_p_gap - active_width - active_h_delta / 2,
                    x0 - (active_width + gate_vs_active) * (j + 1) -
                    (gate_length + gate_vs_active) * j - gate_length,
                    y0 + active_h_delta + pmos_width * M +
                    active_width * (M - 1) + gate_vs_active * 4 * M
                )
                P_square_coords = (
                    P_coords[0],
                    y0 + active_h_delta +
                    (pmos_width + 2 * gate_vs_active) * (j + 1) +
                    (active_width + 2 * gate_vs_active) * j,
                    P_coords[0] - Lambda - active_width,
                    y0 + active_h_delta + (pmos_width + 2 * gate_vs_active) * (
                        j + 1) + (active_width + 2 * gate_vs_active) * j + active_width
                )
                # contacts for squared PO
                CO_square_coords = (
                    P_square_coords[0] - (active_width - co_size) / 2 - Lambda,
                    P_square_coords[1] + (active_width - co_size) / 2,
                    P_square_coords[2] + (active_width - co_size) / 2,
                    P_square_coords[3] - (active_width - co_size) / 2,
                )
            else:
                P_coords = (
                    x0 - (active_width + gate_vs_active) * (j + 1) -
                    (gate_length + gate_vs_active) * j,
                    y0 - inv_p_width - inv_p_gap - active_width - active_h_delta / 2 -
                    (inv_n_width + active_h_delta / 2 +
                     gap + active_width) + 7 * Lambda,
                    x0 - (active_width + gate_vs_active) * (j + 1) -
                    (gate_length + gate_vs_active) * j - gate_length,
                    y0 + active_h_delta + pmos_width * M +
                    active_width * (M - 1) + gate_vs_active * 4 * M
                )
                P_square_coords = (
                    P_coords[2],
                    y0 + active_h_delta +
                    (pmos_width + 2 * gate_vs_active) * (j + 1) +
                    (active_width + 2 * gate_vs_active) * j,
                    P_coords[2] + Lambda + active_width,
                    y0 + active_h_delta + (pmos_width + 2 * gate_vs_active) * (
                        j + 1) + (active_width + 2 * gate_vs_active) * j + active_width
                )
                # contacts for squared PO
                CO_square_coords = (
                    P_square_coords[2] - (active_width - co_size) / 2,
                    P_square_coords[1] + (active_width - co_size) / 2,
                    P_square_coords[2] -
                    (active_width - co_size) / 2 - co_size,
                    P_square_coords[3] - (active_width - co_size) / 2,
                )

            # rotating shapes
            P_coords = self.rotate_shape(
                P_coords, axis_point_x, axis_point_y, angle)
            P_square_coords = self.rotate_shape(
                P_square_coords, axis_point_x, axis_point_y, angle)
            CO_square_coords = self.rotate_shape(
                CO_square_coords, axis_point_x, axis_point_y, angle)

            # mirror shapes
            P_coords = self.mirror_shape(
                P_coords, axis_point_x, axis_point_y, mirr_axis)
            P_square_coords = self.mirror_shape(
                P_square_coords, axis_point_x, axis_point_y, mirr_axis)
            CO_square_coords = self.mirror_shape(
                CO_square_coords, axis_point_x, axis_point_y, mirr_axis)

            # draw shapes
            self.create_rec_with_mem(*P_coords, outline=lookup['SkyWater130']['poly']['color'],
                                     fill=lookup['SkyWater130']['poly']['fill'], tags=f"DC{axis}_areaN_poly_{j}")
            self.create_rec_with_mem(*P_square_coords, outline=lookup['SkyWater130']['poly']['color'],
                                     fill=lookup['SkyWater130']['poly']['fill'], tags=f"DC{axis}_squareN_poly_{j}")
            self.create_rec_with_mem(*CO_square_coords, outline=lookup['SkyWater130']['polycont']['color'],
                                     fill=lookup['SkyWater130']['polycont']['fill'], tags=f"DC{axis}_squareN_polycont_{j}")

        # between ndiff polysi
        for j in range(2*I):
            P_coords = (
                NW_2_x - (active_h_delta + polar_gap) - (active_width +
                                                         gate_vs_active) * (j + 1) - (gate_length + gate_vs_active) * j,
                y0 + gate_length,
                NW_2_x - (active_h_delta + polar_gap) - (active_width + gate_vs_active) *
                (j + 1) - (gate_length + gate_vs_active) * j - gate_length,
                y0 + active_h_delta + pmos_width * M +
                active_width * (M - 1) + gate_vs_active * 4 * M
            )

            P_square_coords = (
                NW_2_x - (active_h_delta + polar_gap) - (active_width + gate_vs_active) * (
                    j + 1) - (gate_length + gate_vs_active) * j + (active_width - gate_length),
                y0 + active_h_delta + (pmos_width + 2 * gate_vs_active) *
                (j + 1) + (active_width + 2 * gate_vs_active) * j,
                NW_2_x - (active_h_delta + polar_gap) - (active_width + gate_vs_active) *
                (j + 1) - (gate_length + gate_vs_active) * j - gate_length,
                y0 + active_h_delta + (pmos_width + 2 * gate_vs_active) * (
                    j + 1) + (active_width + 2 * gate_vs_active) * j + active_width
            )

            CO_square_coords = (
                NW_2_x - (active_h_delta + polar_gap) - (active_width + gate_vs_active) * (j + 1) - (
                    gate_length + gate_vs_active) * j + (active_width - gate_length) - (active_width - co_size) / 2,
                y0 + active_h_delta + (pmos_width + 2 * gate_vs_active) * (j + 1) + (
                    active_width + 2 * gate_vs_active) * j + (active_width - co_size) / 2,
                NW_2_x - (active_h_delta + polar_gap) - (active_width + gate_vs_active) * (j + 1) - (
                    gate_length + gate_vs_active) * j - gate_length + (active_width - co_size) / 2,
                y0 + active_h_delta + (pmos_width + 2 * gate_vs_active) * (j + 1) + (
                    active_width + 2 * gate_vs_active) * j + active_width - (active_width - co_size) / 2
            )

            # rotating shapes
            P_coords = self.rotate_shape(
                P_coords, axis_point_x, axis_point_y, angle)
            P_square_coords = self.rotate_shape(
                P_square_coords, axis_point_x, axis_point_y, angle)
            CO_square_coords = self.rotate_shape(
                CO_square_coords, axis_point_x, axis_point_y, angle)

            # mirror shapes
            P_coords = self.mirror_shape(
                P_coords, axis_point_x, axis_point_y, mirr_axis)
            P_square_coords = self.mirror_shape(
                P_square_coords, axis_point_x, axis_point_y, mirr_axis)
            CO_square_coords = self.mirror_shape(
                CO_square_coords, axis_point_x, axis_point_y, mirr_axis)

            # draw shapes
            self.create_rec_with_mem(*P_coords, outline=lookup['SkyWater130']['poly']['color'],
                                     fill=lookup['SkyWater130']['poly']['fill'], tags=f"DC{axis}_areaP_poly_{j}")
            self.create_rec_with_mem(*P_square_coords, outline=lookup['SkyWater130']['poly']['color'],
                                     fill=lookup['SkyWater130']['poly']['fill'], tags=f"DC{axis}_squareP_poly_{j}")
            self.create_rec_with_mem(*CO_square_coords, outline=lookup['SkyWater130']['polycont']['color'],
                                     fill=lookup['SkyWater130']['polycont']['fill'], tags=f"DC{axis}_squareP_polycont_{j}")

        # metals creating between PO squares in P and N wells
        for j in range(2*I):
            # make coords
            if j % 2 == 0:
                ME_coords = (
                    x0 - (active_width + gate_vs_active) * (j + 1) -
                    (gate_length + gate_vs_active) * j - Lambda,
                    y0 + active_h_delta +
                    (pmos_width + 2 * gate_vs_active) * (j + 1) +
                    (active_width + 2 * gate_vs_active) * j,
                    NW_2_x - (active_h_delta + polar_gap) - (active_width + gate_vs_active) *
                    (j + 1) - (gate_length + gate_vs_active) * j - gate_length,
                    y0 + active_h_delta + (pmos_width + 2 * gate_vs_active) * (
                        j + 1) + (active_width + 2 * gate_vs_active) * j + active_width
                )
            else:
                ME_coords = (
                    x0 - (active_width + gate_vs_active) * (j + 1) - (gate_length +
                                                                      gate_vs_active) * j - gate_length + Lambda + active_width,
                    y0 + active_h_delta +
                    (pmos_width + 2 * gate_vs_active) * (j + 1) +
                    (active_width + 2 * gate_vs_active) * j,
                    NW_2_x - (active_h_delta + polar_gap) - (active_width + gate_vs_active) *
                    (j + 1) - (gate_length + gate_vs_active) * j - gate_length,
                    y0 + active_h_delta + (pmos_width + 2 * gate_vs_active) * (
                        j + 1) + (active_width + 2 * gate_vs_active) * j + active_width
                )
            # rotating shapes
            ME_coords = self.rotate_shape(
                ME_coords, axis_point_x, axis_point_y, angle)
            # mirror shapes
            ME_coords = self.mirror_shape(
                ME_coords, axis_point_x, axis_point_y, mirr_axis)
            # draw shapes
            self.create_rec_with_mem(*ME_coords, fill=lookup['SkyWater130']['locali']['fill'], outline=lookup['SkyWater130']['locali']['color'], tags= f"DC{axis}_betweenPOsquares_locali_{j}")

        '''--------------------Invertors creating-----------------'''
        # -----------PDiff creating----------
        for j in range(I):

            # get coords
            PDiff_cooords = (
                x0 - active_width -
                (gate_length + 2 * gate_vs_active) * (j + 1) - mos_length * j,
                y0 - inv_p_width - inv_p_gap,
                x0 - active_width -
                (gate_length + 2 * gate_vs_active) *
                (j + 1) - mos_length * (j + 1),
                y0 - inv_p_gap
            )

            PDiff_pol = (
                PDiff_cooords[2] + active_width + polar_gap,
                PDiff_cooords[1] - inv_n_width - 2 *
                (active_h_delta + active_width),
                PDiff_cooords[2] - polar_gap,
                PDiff_cooords[1] - inv_n_width - 2 *
                (active_h_delta + active_width) + active_width
            )

            PDiff_pol_CO = (
                PDiff_pol[0] - (active_width - co_size) / 2 - polar_gap,
                PDiff_pol[1] + (active_width - co_size) / 2,
                PDiff_pol[2] + (active_width - co_size) / 2 + polar_gap,
                PDiff_pol[3] - (active_width - co_size) / 2
            )

            for v in range(2):
                for h in range(6):
                    # get coords
                    PDiff_CO = (
                        PDiff_cooords[0] - (active_width - co_size) / 2 - v *
                        (active_width + gate_length + 2 * gate_vs_active),
                        PDiff_cooords[1] + (active_width -
                                            co_size) / 2 + h * 2 * co_size,
                        PDiff_cooords[0] - (active_width - co_size) / 2 - co_size - v * (
                            active_width + gate_length + 2 * gate_vs_active),
                        PDiff_cooords[1] + (active_width - co_size) /
                        2 + co_size + h * 2 * co_size
                    )
                    # rotating shapes
                    PDiff_CO = self.rotate_shape(
                        PDiff_CO, axis_point_x, axis_point_y, angle)
                    # mirror shapes
                    PDiff_CO = self.mirror_shape(
                        PDiff_CO, axis_point_x, axis_point_y, mirr_axis)
                    # draw shapes
                    self.create_rec_with_mem(*PDiff_CO, outline=lookup['SkyWater130']['pdiffc']['color'], fill=lookup['SkyWater130']['pdiffc']['fill'], tags=f"DC{axis}_invDP_pdiffc_{j}{v}")

            # rotating shapes
            PDiff_cooords = self.rotate_shape(
                PDiff_cooords, axis_point_x, axis_point_y, angle)
            PDiff_pol = self.rotate_shape(
                PDiff_pol, axis_point_x, axis_point_y, angle)
            PDiff_pol_CO = self.rotate_shape(
                PDiff_pol_CO, axis_point_x, axis_point_y, angle)

            # mirror shapes
            PDiff_cooords = self.mirror_shape(
                PDiff_cooords, axis_point_x, axis_point_y, mirr_axis)
            PDiff_pol = self.mirror_shape(
                PDiff_pol, axis_point_x, axis_point_y, mirr_axis)
            PDiff_pol_CO = self.mirror_shape(
                PDiff_pol_CO, axis_point_x, axis_point_y, mirr_axis)

            # draw shapes
            self.create_rec_with_mem(*PDiff_cooords, outline=lookup['SkyWater130']['pdiff']['color'], fill=lookup['SkyWater130']['pdiff']['fill'], tags=f"DC{axis}_inv_pdiff_{j}")
            self.create_rec_with_mem(*PDiff_pol, outline=lookup['SkyWater130']['psubdiff']['color'], fill=lookup['SkyWater130']['psubdiff']['fill'], tags=f"DC{axis}_invPol_psubdiff_{j}")
            self.create_rec_with_mem(*PDiff_pol_CO, outline=lookup['SkyWater130']['psubdiffcont']['color'], fill=lookup['SkyWater130']['psubdiffcont']['fill'], tags=f"DC{axis}_invDPpol_psubdiffcont_{j}")

        # -----------NDiff creating----------
        for j in range(I):
            # get coords
            NDiff_coords = (
                x0 - active_width -
                (gate_length + 2 * gate_vs_active) * (j + 1) - mos_length * j,
                y0 - inv_p_width - inv_p_gap - inv_n_width - active_width - active_h_delta,
                x0 - active_width -
                (gate_length + 2 * gate_vs_active) *
                (j + 1) - mos_length * (j + 1),
                y0 - inv_p_width - inv_p_gap - active_width - active_h_delta
            )

            for v in range(2):
                # get coords
                for h in range(2):
                    # get coords
                    NDiff_CO = (
                        NDiff_coords[0] - (active_width - co_size) / 2 - v *
                        (active_width + gate_length + 2 * gate_vs_active),
                        NDiff_coords[1] + (active_width -
                                           co_size) / 2 + h * 2 * co_size,
                        NDiff_coords[0] - (active_width - co_size) / 2 - co_size -
                        v * (active_width + gate_length + 2 * gate_vs_active),
                        NDiff_coords[1] + (active_width - co_size) /
                        2 + co_size + h * 2 * co_size
                    )

                    # rotating shapes
                    NDiff_CO = self.rotate_shape(
                        NDiff_CO, axis_point_x, axis_point_y, angle)
                    # mirror shapes
                    NDiff_CO = self.mirror_shape(
                        NDiff_CO, axis_point_x, axis_point_y, mirr_axis)
                    # draw shapes
                    self.create_rec_with_mem(*NDiff_CO, outline=lookup['SkyWater130']['ndiffc']['color'], fill=lookup['SkyWater130']['ndiffc']['fill'], tags=f"DC{axis}_invDN_ndiffc_{j}{v}")

            # rotating shapes
            NDiff_coords = self.rotate_shape(
                NDiff_coords, axis_point_x, axis_point_y, angle)
            # mirror shapes
            NDiff_coords = self.mirror_shape(
                NDiff_coords, axis_point_x, axis_point_y, mirr_axis)
            # draw shapes
            self.create_rec_with_mem(*NDiff_coords, outline=lookup['SkyWater130']['ndiff']['color'], fill=lookup['SkyWater130']['ndiff']['fill'], tags=f"DC{axis}_inv_ndiff_{j}")

        # -----------POlySi creating----------
        for j in range(I):
            # polysi creating and metall on polysi creating
            for v in range(2):
                PO_coords = (
                    x0 - active_width - (gate_length + 2 * gate_vs_active) * (
                        j + 1) - mos_length * j + active_width / 2 - Lambda - v * (gap - Lambda),
                    y0 - inv_p_width - inv_p_gap - active_width - active_h_delta / 2 - v *
                    (inv_n_width + active_h_delta / 2 +
                     gap + active_width + 2 * Lambda),
                    x0 - active_width - (gate_length + 2 * gate_vs_active) * (
                        j + 1) - mos_length * j - active_width / 2 - Lambda - v * (gap - Lambda),
                    y0 - inv_p_width - inv_p_gap - active_h_delta / 2 - v *
                    (inv_n_width + active_h_delta / 2 +
                     gap + active_width + 2 * Lambda)
                )
                PO_ME = PO_coords
                PO_CO = (
                    PO_ME[0] - (active_width - co_size) / 2,
                    PO_ME[1] + (active_width - co_size) / 2,
                    PO_ME[2] + (active_width - co_size) / 2,
                    PO_ME[3] - (active_width - co_size) / 2
                )

                dop_PO = (
                    PO_coords[0],
                    PO_coords[3] + Lambda,
                    PO_coords[2] - gate_vs_active,
                    PO_coords[3] + Lambda + gate_length
                )

                # --- хитрим чтобы DRC не ругалось ---
                PO_coords = (
                    PO_coords[0],
                    PO_coords[1],
                    PO_coords[2],
                    PO_coords[3] + Lambda
                )

                # rotating shapes
                PO_coords = self.rotate_shape(
                    PO_coords, axis_point_x, axis_point_y, angle)
                PO_ME = self.rotate_shape(
                    PO_ME, axis_point_x, axis_point_y, angle)
                PO_CO = self.rotate_shape(
                    PO_CO, axis_point_x, axis_point_y, angle)
                # mirror shapes
                PO_coords = self.mirror_shape(
                    PO_coords, axis_point_x, axis_point_y, mirr_axis)
                PO_ME = self.mirror_shape(
                    PO_ME, axis_point_x, axis_point_y, mirr_axis)
                PO_CO = self.mirror_shape(
                    PO_CO, axis_point_x, axis_point_y, mirr_axis)
                # draw shapes
                self.create_rec_with_mem(*PO_coords, outline=lookup['SkyWater130']['poly']['color'],
                                         fill=lookup['SkyWater130']['poly']['color'], tags=f"DC{axis}_area_poly_{j}")
                self.create_rec_with_mem(*PO_ME, outline=lookup['SkyWater130']['locali']['color'],
                                         fill=lookup['SkyWater130']['locali']['fill'], tags=f"DC{axis}_areaPO_locali_{j}")
                self.create_rec_with_mem(*PO_CO, outline=lookup['SkyWater130']['polycont']['color'],
                                         fill=lookup['SkyWater130']['polycont']['fill'], tags=f"DC{axis}_areaPO_polycont_{j}")

            dop_PO = self.rotate_shape(
                dop_PO, axis_point_x, axis_point_y, angle)
            dop_PO = self.mirror_shape(
                dop_PO, axis_point_x, axis_point_y, mirr_axis)
            self.create_rec_with_mem(*dop_PO, outline=lookup['SkyWater130']['poly']['color'],
                                     fill=lookup['SkyWater130']['poly']['fill'], tags=f"DC{axis}_area_poly_{j}")
        # -----------MEtall creating----------
        for j in range(I):
            ME_coords = (
                x0 - active_width -
                (gate_length + 2 * gate_vs_active) * (j + 1) - mos_length * j,
                y0 - inv_p_width - inv_p_gap - inv_n_width - active_width - active_h_delta,
                x0 - 2 * active_width -
                (gate_length + 2 * gate_vs_active) *
                (j + 1) - mos_length * j,
                y0 - inv_p_gap
            )
            ME_coords = self.rotate_shape(
                ME_coords, axis_point_x, axis_point_y, angle)
            ME_coords = self.mirror_shape(
                ME_coords, axis_point_x, axis_point_y, mirr_axis)
            self.create_rec_with_mem(*ME_coords, fill=lookup['SkyWater130']['locali']['fill'], outline=lookup['SkyWater130']['locali']['color'], tags= f"DC{axis}_inv_locali_{j}")

        for j in range(1, I+1):
            ME_coords = [
                (
                    x0 - (gate_length + 2 * gate_vs_active + mos_length) * j,
                    y0 - inv_p_width - inv_p_gap,
                    x0 - (gate_length + 2 * gate_vs_active +
                          mos_length) * j - active_width,
                    y0 - active_width
                ),
                (
                    x0 - (gate_length + 2 * gate_vs_active + mos_length) * j,
                    y0 - inv_p_width - inv_p_gap - inv_n_width -
                    2 * (active_width + active_h_delta),
                    x0 - (gate_length + 2 * gate_vs_active +
                          mos_length) * j - active_width,
                    y0 - inv_p_width - inv_p_gap - active_width - active_h_delta
                )
            ]
            for v in range(len(ME_coords)):
                ME_coords[v] = self.rotate_shape(
                    ME_coords[v], axis_point_x, axis_point_y, angle)
                ME_coords[v] = self.mirror_shape(
                    ME_coords[v], axis_point_x, axis_point_y, mirr_axis)
                self.create_rec_with_mem(*ME_coords[v], fill=lookup['SkyWater130']['locali']['fill'], outline=lookup['SkyWater130']['locali']['color'], tags=f"DC{axis}_inv_locali_{j}")
        # -----------VIa creating----------
        for j in range(1, I + 1):
            # get coords
            VI_coords = (
                x0 - (gate_length + 2 * gate_vs_active + mos_length) *
                j - (active_width - co_size) / 2,
                y0 - inv_p_width - inv_p_gap - inv_n_width -
                (active_width + active_h_delta) + (active_width - co_size) / 2,
                x0 - (gate_length + 2 * gate_vs_active + mos_length) *
                j - active_width + (active_width - co_size) / 2,
                y0 - inv_p_width - inv_p_gap - inv_n_width -
                (active_width + active_h_delta) +
                (active_width - co_size) / 2 + co_size
            )
            # rotating shapes
            VI_coords = self.rotate_shape(
                VI_coords, axis_point_x, axis_point_y, angle)
            # mirror shapes
            VI_coords = self.mirror_shape(
                VI_coords, axis_point_x, axis_point_y, mirr_axis)
            # draw shapes
            self.create_rec_with_mem(*VI_coords, outline=lookup['SkyWater130']['viali']['color'], fill=lookup['SkyWater130']['viali']['fill'], tags= f"DC{axis}_inv_viali_{j}")

        # -----------VI for vss creating----------
        VI_pol = (
            NW_2_x - ((mos_length + 2 * gate_vs_active + gate_length) * I + active_h_delta + polar_gap +
                      active_width) - active_width + gate_vs_active + active_h_delta + (active_width - co_size) / 2,
            y0 + active_h_delta + active_width -
            (active_width - co_size) / 2 - co_size,
            NW_2_x - ((mos_length + 2 * gate_vs_active + gate_length) * I + active_h_delta + polar_gap +
                      active_width) + gate_vs_active + active_h_delta - (active_width - co_size) / 2,
            y0 + active_h_delta + active_width - (active_width - co_size) / 2
        )
        VI_pol = self.rotate_shape(VI_pol, axis_point_x, axis_point_y, angle)
        VI_pol = self.mirror_shape(
            VI_pol, axis_point_x, axis_point_y, mirr_axis)
        self.create_rec_with_mem(*VI_pol, outline=lookup['SkyWater130']['viali']['color'], fill=lookup['SkyWater130']['viali']['fill'], tags= f"DC{axis}_{0}_viali_pol")
        # -----------ME2 creating----------
        ME2_coords = (
            x0 + gap,
            y0 - inv_p_width - inv_p_gap - inv_n_width -
            (active_width + active_h_delta),
            NW_2_x - ((mos_length + 2 * gate_vs_active + gate_length)
                      * I + active_h_delta + polar_gap),
            y0 - inv_p_width - inv_p_gap - inv_n_width -
            (active_width + active_h_delta) + active_width
        )
        ME2_coords = self.rotate_shape(
            ME2_coords, axis_point_x, axis_point_y, angle)
        ME2_coords = self.mirror_shape(
            ME2_coords, axis_point_x, axis_point_y, mirr_axis)
        self.create_rec_with_mem(*ME2_coords, outline=lookup['SkyWater130']['metal1']['color'], fill=lookup['SkyWater130']['metal1']['fill'], dash=lookup['SkyWater130']['metal1']['border'], tags = f"DC{axis}_{0}_metal1_vss")

        ME2_coords = (
            NW_2_x - ((mos_length + 2 * gate_vs_active + gate_length) * I + active_h_delta +
                      polar_gap + active_width) - active_width + gate_vs_active + active_h_delta,
            OP_coords[1],
            NW_2_x - ((mos_length + 2 * gate_vs_active + gate_length) * I +
                      active_h_delta + polar_gap + active_width) + gate_vs_active + active_h_delta,
            y0 + active_h_delta + active_width
        )
        ME2_coords = self.rotate_shape(
            ME2_coords, axis_point_x, axis_point_y, angle)
        ME2_coords = self.mirror_shape(
            ME2_coords, axis_point_x, axis_point_y, mirr_axis)
        self.create_rec_with_mem(*ME2_coords, outline=lookup['SkyWater130']['metal1']['color'], fill=lookup['SkyWater130']['metal1']['fill'], dash=lookup['SkyWater130']['metal1']['border'], tags = f"DC{axis}_{0}_metal1_vss")
        '''-------------------------------------------------------'''

    def compact_matrix_DC_MW(self, axis_point_x, axis_point_y, Lambda, axis, angle, I, mirr_axis, dop_shift):
        print('Lambda:', Lambda)
        x0 = axis_point_x - 3*Lambda  # добавка чтобы сместить начало рисования в NE точку OP
        y0 = axis_point_y + 32*Lambda

        M = 2**I  # amount of outputs
        w = 4*Lambda
        a = 4*Lambda
        b = 4*Lambda
        gap = 3*Lambda
        big_gap = 10*Lambda
        L = M*b+2*gap+(M-1)*big_gap
        nw_1_x = x0-gap-I*(w+3*a)-w
        nw_2_x = nw_1_x - 5*a - Lambda
        NW_1_x = x0+gap
        NW_2_x = nw_1_x
        NW_1_y = y0-2*gap-3*b
        NW_2_y = y0+L+M*b+gap
        '''---------------crossbar creating--------------'''
        '''OP layer creating'''
        OP_coords = (x0+gap, y0-7*b-gap-Lambda, NW_2_x -
                     gap-4*I*a-w-5*Lambda, y0+L+(M+1)*b)
        OP_coords = self.rotate_shape(
            OP_coords, axis_point_x, axis_point_y, angle)
        OP_coords = self.mirror_shape(
            OP_coords, axis_point_x, axis_point_y, mirr_axis)
        self.create_rec_with_mem(
            *OP_coords, outline='orange', tags=f"DC{axis}_{0}_OP_layer")

        forward = [0]*M
        revers = [0]*M
        crossbar = [0]*M
        for i in range(M):
            decimal = i
            binary = ""
            while decimal > 0:
                remainder = decimal % 2
                binary = str(remainder) + binary
                decimal = decimal // 2
            forward[i] = list(binary.zfill(I))
        for i in range(M):
            revers[i] = forward[-i-1]
            # crossbar[i] = forward[i] + revers[i]
        revers = transpose(array(revers))
        forward = transpose(array(forward))
        crossbar = transpose(column_stack(
            (forward, revers)).reshape(-1, forward.shape[1]))

        # NDiff matrix creating
        crossbar = crossbar.astype('int')
        # one way using np.where, and taking the bitwise XOR of a given value when it is either 0 or 1
        me_crossbar = where((crossbar == 0) | (crossbar == 1), crossbar ^ 1, crossbar)
        ndiff_crossbar = crossbar
        s_array = zeros((M, 2*I+1))
        for j in range(2*I+1):
            if j == 0:
                s_array[:, j] = crossbar[:, j]
            elif j == 2*I:
                s_array[:, j] = crossbar[:, -1]
            else:
                s_array[:, j] = crossbar[:, j-1] | crossbar[:, j]
        # co_crossbar=np.where((crossbar==0)|(crossbar==1), crossbar^1, crossbar)
        n = 0
        for j in range(2*I+1):
            me_crossbar = insert(me_crossbar, n, ones(M), axis=1)
            ndiff_crossbar = insert(ndiff_crossbar, n, s_array[:, j], axis=1)
            n += 2
        # print(ndiff_crossbar)
        co_crossbar = zeros((M, 4*I+1))
        co_crossbar = co_crossbar.astype('int')
        for j in range(4*I+1):
            if j % 2 == 0:
                co_crossbar[:, j] = ndiff_crossbar[:, j]

        '''-----------------------------------------------'''
        for m in range(M):
            dop = (m//2)*dop_shift
            for n in range(2*I):
                if int(crossbar[m][-n-1]) == 1:
                    crossbar_cords = (x0-(n+1)*w-n*a, y0+gap+big_gap*m+m*b *
                                      2 + dop, x0-(n+1)*(w+a), y0+gap+big_gap*m+m*b*2+2*b + dop)
                    crossbar_cords = self.rotate_shape(
                        crossbar_cords, axis_point_x, axis_point_y, angle)
                    crossbar_cords = self.mirror_shape(
                        crossbar_cords, axis_point_x, axis_point_y, mirr_axis)
                    self.create_rec_with_mem(
                        *crossbar_cords, outline='brown', fill='brown', tags=f"DC{axis}_{m}{n}_DP_cross")

        for m in range(M):
            dop = (m//2)*dop_shift
            for n in range(4*I+1):
                if int(ndiff_crossbar[m][-n-1]) == 1:
                    ndiff_crossbar_coords = (
                        NW_2_x-gap-n*w, y0+gap+big_gap*m+m*b*2 + dop, NW_2_x-gap-(n+1)*w, y0+gap+big_gap*m+m*b*2+2*b + dop)
                    ndiff_crossbar_coords = self.rotate_shape(
                        ndiff_crossbar_coords, axis_point_x, axis_point_y, angle)
                    ndiff_crossbar_coords = self.mirror_shape(
                        ndiff_crossbar_coords, axis_point_x, axis_point_y, mirr_axis)
                    self.create_rec_with_mem(
                        *ndiff_crossbar_coords, outline='green', fill='green', tags=f"DC{axis}_{m}{n}_DN_cross")

        for m in range(M):
            dop = (m//2)*dop_shift
            for n in range(4*I+1):
                if int(me_crossbar[m][-n-1]) == 1:
                    me_crossbar_coords = (NW_2_x-gap-n*w, y0+gap+big_gap*m+m*b *
                                          2 + dop, NW_2_x-gap-(n+1)*w, y0+gap+big_gap*m+m*b*2+b + dop)
                    me_crossbar_coords = self.rotate_shape(
                        me_crossbar_coords, axis_point_x, axis_point_y, angle)
                    me_crossbar_coords = self.mirror_shape(
                        me_crossbar_coords, axis_point_x, axis_point_y, mirr_axis)
                    self.create_rec_with_mem(
                        *me_crossbar_coords, fill='blue', outline='blue', tags=f"DC{axis}_{m}{n}_ME_cross")

        for m in range(M):
            dop = (m//2)*dop_shift
            for n in range(4*I+1):
                if int(co_crossbar[m][-n-1]) == 1:
                    co_crossbar_coords = (NW_2_x-gap-n*w-Lambda, y0+gap+big_gap*m+m*b*2+Lambda +
                                          dop, NW_2_x-gap-(n+1)*w+Lambda, y0+gap+big_gap*m+m*b*2+b-Lambda + dop)
                    co_crossbar_coords = self.rotate_shape(
                        co_crossbar_coords, axis_point_x, axis_point_y, angle)
                    co_crossbar_coords = self.mirror_shape(
                        co_crossbar_coords, axis_point_x, axis_point_y, mirr_axis)
                    self.create_rec_with_mem(
                        *co_crossbar_coords, outline='black', fill='black', tags=f"DC{axis}_{m}{n}_CO_cross")

        '''main block of pdiff fingers'''
        for j in range(I+1):
            # create shapes
            T_coords = (x0-j*(w+3*a), (y0-b), x0-j*(w+3*a) -
                        w, (y0+L+M*b))  # + 4*b - more pmos
            B_coords_T = (x0-j*(w+3*a)-Lambda, y0-gap,
                          x0-j*(w+3*a)-w+Lambda, y0-Lambda)
            # T_coords = (-j*(w+3*a), 0, -j*(w+3*a)-w, L)

            # rotate shapes
            T_coords = self.rotate_shape(
                T_coords, axis_point_x, axis_point_y, angle)
            B_coords_T = self.rotate_shape(
                B_coords_T, axis_point_x, axis_point_y, angle)

            # mirror shapes
            T_coords = self.mirror_shape(
                T_coords, axis_point_x, axis_point_y, mirr_axis)
            B_coords_T = self.mirror_shape(
                B_coords_T, axis_point_x, axis_point_y, mirr_axis)

            self.create_rec_with_mem(
                *T_coords, outline='brown', fill='brown', tags=f"DC{axis}_T_DP_{j}")
            self.create_rec_with_mem(
                *B_coords_T, outline='black', fill='black', tags=f"DC{axis}_BT_CO_{j}")
            for i in range(M+1):
                dop = ((i-1)//2)*dop_shift
                if j != I:
                    if i == 0:
                        C_coords = (x0-j*(w+3*a)-(w+a), y0-b+dop,
                                    x0-j*(w+3*a)-(w+2*a), y0+dop)
                        B_coords = (x0-j*(w+3*a)-(w+a)-Lambda, y0-b+Lambda +
                                    dop, x0-j*(w+3*a)-(w+2*a)+Lambda, y0-Lambda+dop)
                    else:
                        C_coords = (x0-j*(w+3*a)-(w+a), y0+gap+big_gap*(i-1)+2*b*(i-1) +
                                    dop, x0-j*(w+3*a)-(w+2*a), y0+gap+big_gap*(i-1)+2*b*i+dop)
                        B_coords = (x0-j*(w+3*a)-(w+a)-Lambda, y0+gap+big_gap*(i-1)+2*b*(i-1)+Lambda +
                                    dop, x0-j*(w+3*a)-(w+2*a)+Lambda, y0+gap+(big_gap+2*b)*(i-1)+b-Lambda+dop)
                    if i != 0:
                        C_color = 'brown'
                        area = 'DP'
                    else:
                        C_color = 'green'
                        area = 'DN'
                    # rotate shapes
                    C_coords = self.rotate_shape(
                        C_coords, axis_point_x, axis_point_y, angle)
                    B_coords = self.rotate_shape(
                        B_coords, axis_point_x, axis_point_y, angle)
                    # mirror shapes
                    C_coords = self.mirror_shape(
                        C_coords, axis_point_x, axis_point_y, mirr_axis)
                    B_coords = self.mirror_shape(
                        B_coords, axis_point_x, axis_point_y, mirr_axis)
                    # draw shapes
                    self.create_rec_with_mem(
                        *C_coords, outline=C_color, fill=C_color, tags=f"DC{axis}_{j}{i}_{area}_C")
                    self.create_rec_with_mem(
                        *B_coords, outline='black', fill='black', tags=f"DC{axis}_{j}{i}_CO_B")

        for i in range(M):
            dop = (i//2)*dop_shift
            metal_outline = (nw_1_x-gap, y0+gap+big_gap*i+2 *
                             w*i+dop, x0+gap, y0+gap+big_gap*i+2*w*i+w + dop)
            metal_outline = self.rotate_shape(
                metal_outline, axis_point_x, axis_point_y, angle)
            metal_outline = self.mirror_shape(
                metal_outline, axis_point_x, axis_point_y, mirr_axis)
            self.create_rec_with_mem(
                *metal_outline, fill='blue', outline='blue', tags=f"DC{axis}_MetalOutline_ME_{i}")

        '''NWell creating'''
        NW_coords = (NW_1_x, NW_1_y, NW_2_x, NW_2_y)
        NW_coords = self.rotate_shape(
            NW_coords, axis_point_x, axis_point_y, angle)
        NW_coords = self.mirror_shape(
            NW_coords, axis_point_x, axis_point_y, mirr_axis)
        self.create_rec_with_mem(
            *NW_coords, outline='green', dash='--', tags=f"DC{axis}_0_NW_area")

        '''NMOS polarization creating'''

        for i in range(M):
            dop = (i//2)*dop_shift
            # get coords
            polar_met = (NW_2_x-gap-4*I*a-w, y0+gap+big_gap*i+i*b*2+dop,
                         NW_2_x-gap-4*I*a-w-5*Lambda, y0+gap+big_gap*i+i*b*2+w+dop)
            polar_coords = (NW_2_x-gap-4*I*a-w-Lambda, y0+gap+big_gap*i+i*b *
                            2+dop, NW_2_x-gap-4*I*a-w-5*Lambda, y0+gap+big_gap*i+i*b*2+w+dop)
            cont_coords = (NW_2_x-gap-4*I*a-w-w/2, y0+gap+big_gap*i+i*b*2+Lambda +
                           dop, NW_2_x-gap-4*I*a-w-4*Lambda, y0+gap+big_gap*i+i*b*2+w-Lambda+dop)
            # rotating shapes
            polar_met = self.rotate_shape(
                polar_met, axis_point_x, axis_point_y, angle)
            polar_coords = self.rotate_shape(
                polar_coords, axis_point_x, axis_point_y, angle)
            cont_coords = self.rotate_shape(
                cont_coords, axis_point_x, axis_point_y, angle)
            # mirror shapes
            polar_met = self.mirror_shape(
                polar_met, axis_point_x, axis_point_y, mirr_axis)
            polar_coords = self.mirror_shape(
                polar_coords, axis_point_x, axis_point_y, mirr_axis)
            cont_coords = self.mirror_shape(
                cont_coords, axis_point_x, axis_point_y, mirr_axis)
            # draw shapes
            self.create_rec_with_mem(
                *polar_coords, outline='brown', fill='brown', tags=f"DC{axis}_NmosPol_DP_{i}")
            self.create_rec_with_mem(
                *cont_coords, outline='black', fill='black', tags=f"DC{axis}_PolCont_CO_{i}")
            self.create_rec_with_mem(
                *polar_met, outline='blue', tags=f"DC{axis}_pol_ME_{i}")

        '''metal layers creating'''
        # get coords
        m1_vss = (NW_2_x-gap-4*I*a-5*Lambda, y0+gap,
                  NW_2_x-gap-4*I*a-5*Lambda-w, y0+L+(M-1)*b)
        m1_vdd = (nw_1_x, y0-b, x0, y0)
        m_plus = (x0 + gap, y0-7*b-gap-Lambda, x0 + gap - w, y0)
        # rotating shapes
        m1_vss = self.rotate_shape(m1_vss, axis_point_x, axis_point_y, angle)
        m1_vdd = self.rotate_shape(m1_vdd, axis_point_x, axis_point_y, angle)
        m_plus = self.rotate_shape(m_plus, axis_point_x, axis_point_y, angle)
        # mirror shapes
        m1_vss = self.mirror_shape(
            m1_vss, axis_point_x, axis_point_y, mirr_axis)
        m1_vdd = self.mirror_shape(
            m1_vdd, axis_point_x, axis_point_y, mirr_axis)
        m_plus = self.mirror_shape(
            m_plus, axis_point_x, axis_point_y, mirr_axis)
        # making list
        metals = [m1_vdd, m_plus, m1_vss]
        for i in range(len(metals)):
            self.create_rec_with_mem(
                *metals[i], fill='blue', outline='blue', tags=f"DC{axis}_vdd_ME_{i}")

        '''Poly-Si creating'''

        # between pdiff polysi
        for j in range(2*I):
            dop = (j//2)*dop_shift
            if j % 2 == 0:
                P_coords = (x0-5*Lambda - j*2*w, y0-4*b, x0 -
                            5*Lambda - j*2*w - w/2, y0+L+M*b)
                P_square_coords = (x0-5*Lambda - j*2*w, y0+j*w+(j+1)*(2*(b+gap)) +
                                   dop, x0-5*Lambda - j*2*w - w, y0+(j+1)*(w+(2*(b+gap)))+dop)
                # contacts for squared PO
                CO_square_coords = (x0-6*Lambda - j*2*w, y0+j*w+(j+1)*(2*(b+gap))+Lambda +
                                    dop, x0-4*Lambda - j*2*w - w, y0+(j+1)*(w+(2*(b+gap)))-Lambda+dop)

            else:
                P_coords = (x0-5*Lambda - j*2*w, y0-7*b, x0 -
                            5*Lambda - j*2*w - w/2, y0+L+M*b)
                P_square_coords = (x0-5*Lambda - j*2*w+w/2, y0+j*w+(j+1)*(
                    2*(b+gap))+dop, x0-5*Lambda - j*2*w - w/2, y0+(j+1)*(w+(2*(b+gap)))+dop)
                # contacts for squared PO
                CO_square_coords = (x0-6*Lambda - j*2*w+w/2, y0+j*w+(j+1)*(2*(b+gap)) +
                                    Lambda+dop, x0-4*Lambda - j*2*w - w/2, y0+(j+1)*(w+(2*(b+gap)))-Lambda+dop)

            # rotating shapes
            P_coords = self.rotate_shape(
                P_coords, axis_point_x, axis_point_y, angle)
            P_square_coords = self.rotate_shape(
                P_square_coords, axis_point_x, axis_point_y, angle)
            CO_square_coords = self.rotate_shape(
                CO_square_coords, axis_point_x, axis_point_y, angle)
            # mirror shapes
            P_coords = self.mirror_shape(
                P_coords, axis_point_x, axis_point_y, mirr_axis)
            P_square_coords = self.mirror_shape(
                P_square_coords, axis_point_x, axis_point_y, mirr_axis)
            CO_square_coords = self.mirror_shape(
                CO_square_coords, axis_point_x, axis_point_y, mirr_axis)
            # draw shapes
            self.create_rec_with_mem(
                *P_coords, outline='red', fill='red', tags=f"DC{axis}_areaN_PO_{j}")
            self.create_rec_with_mem(
                *P_square_coords, outline='red', fill='red', tags=f"DC{axis}_squareN_PO_{j}")
            self.create_rec_with_mem(
                *CO_square_coords, outline='black', fill='black', tags=f"DC{axis}_squareN_CO_{j}")

        # between ndiff polysi
        for j in range(2*I):
            dop = (j//2)*dop_shift
            P_coords = (NW_2_x-gap-5*Lambda - j*2*w, y0, NW_2_x -
                        gap-5*Lambda - j*2*w - w/2, y0+L+M*b)
            P_square_coords = (NW_2_x-gap-5*Lambda - j*2*w+w/2, y0+j*w+(j+1)*(
                2*(b+gap))+dop, NW_2_x-gap-5*Lambda - j*2*w - w/2, y0+(j+1)*(w+(2*(b+gap)))+dop)
            # contacts for squared PO
            CO_square_coords = (NW_2_x-gap-6*Lambda - j*2*w+w/2, y0+j*w+(j+1)*(2*(b+gap)) +
                                Lambda+dop, NW_2_x-gap-4*Lambda - j*2*w - w/2, y0+(j+1)*(w+(2*(b+gap)))-Lambda+dop)

            # rotating shapes
            P_coords = self.rotate_shape(
                P_coords, axis_point_x, axis_point_y, angle)
            P_square_coords = self.rotate_shape(
                P_square_coords, axis_point_x, axis_point_y, angle)
            CO_square_coords = self.rotate_shape(
                CO_square_coords, axis_point_x, axis_point_y, angle)
            # mirror shapes
            P_coords = self.mirror_shape(
                P_coords, axis_point_x, axis_point_y, mirr_axis)
            P_square_coords = self.mirror_shape(
                P_square_coords, axis_point_x, axis_point_y, mirr_axis)
            CO_square_coords = self.mirror_shape(
                CO_square_coords, axis_point_x, axis_point_y, mirr_axis)
            # draw shapes
            self.create_rec_with_mem(
                *P_coords, outline='red', fill='red', tags=f"DC{axis}_areaP_PO_{j}")
            self.create_rec_with_mem(
                *P_square_coords, outline='red', fill='red', tags=f"DC{axis}_squareP_PO_{j}")
            self.create_rec_with_mem(
                *CO_square_coords, outline='black', fill='black', tags=f"DC{axis}_squareP_CO_{j}")

        # metals creating between PO squares in P and N wells
        for j in range(2*I):
            dop = (j//2)*dop_shift
            if j % 2 == 0:
                ME_coords = (x0-5*Lambda - j*2*w, y0+j*w+(j+1)*(2*(b+gap))+dop,
                             NW_2_x-gap-5*Lambda - j*2*w - w/2, y0+(j+1)*(w+(2*(b+gap)))+dop)
            else:
                ME_coords = (x0-5*Lambda - j*2*w+w/2, y0+j*w+(j+1)*(2*(b+gap))+dop,
                             NW_2_x-gap-5*Lambda - j*2*w - w/2, y0+(j+1)*(w+(2*(b+gap)))+dop)
            ME_coords = self.rotate_shape(
                ME_coords, axis_point_x, axis_point_y, angle)
            ME_coords = self.mirror_shape(
                ME_coords, axis_point_x, axis_point_y, mirr_axis)
            self.create_rec_with_mem(*ME_coords, fill='blue', outline='blue', tags= f"DC{axis}_betweenPOsquares_ME_{j}")

        '''--------------------Invertors creating-----------------'''
        # -----------PDiff creating----------
        for j in range(I):
            # get coords
            PDiff_cooords = (x0-j*(w+3*a)-(w+a), y0-3*b-gap,
                             x0-j*(w+3*a)-(w+4*a), y0-b-gap)
            PDiff_pol = (x0-j*(w+3*a)-(w+3*a), y0-6*b-gap-b/2-Lambda,
                         x0-j*(w+3*a)-(w+4*a), y0-5*b-gap-b/2-Lambda)
            PDiff_pol_CO = (x0-j*(w+3*a)-(w+3*a)-Lambda, y0-6 *
                            b-gap-b/2, x0-j*(w+3*a)-(w+4*a)+Lambda, y0-6*b-gap)
            # rotating shapes
            PDiff_cooords = self.rotate_shape(
                PDiff_cooords, axis_point_x, axis_point_y, angle)
            PDiff_pol = self.rotate_shape(
                PDiff_pol, axis_point_x, axis_point_y, angle)
            PDiff_pol_CO = self.rotate_shape(
                PDiff_pol_CO, axis_point_x, axis_point_y, angle)
            # mirror shapes
            PDiff_cooords = self.mirror_shape(
                PDiff_cooords, axis_point_x, axis_point_y, mirr_axis)
            PDiff_pol = self.mirror_shape(
                PDiff_pol, axis_point_x, axis_point_y, mirr_axis)
            PDiff_pol_CO = self.mirror_shape(
                PDiff_pol_CO, axis_point_x, axis_point_y, mirr_axis)
            # draw shapes
            self.create_rec_with_mem(*PDiff_cooords, outline='brown', fill='brown', tags=f"DC{axis}_inv_DP_{j}")
            self.create_rec_with_mem(*PDiff_pol, outline='brown', fill='brown', tags=f"DC{axis}_invPol_DP_{j}")
            self.create_rec_with_mem(*PDiff_pol_CO, outline='black', fill='black', tags=f"DC{axis}_invDPpol_CO_{j}")
            for v in range(2):
                PDiff_CO = (x0-j*(w+3*a)-(w+a)-Lambda-v*2*a, y0-2*b-gap+Lambda,
                            x0-j*(w+3*a)-(w+a)-Lambda-a/2-v*2*a, y0-b-gap-Lambda)
                PDiff_CO = self.rotate_shape(
                    PDiff_CO, axis_point_x, axis_point_y, angle)
                PDiff_CO = self.mirror_shape(
                    PDiff_CO, axis_point_x, axis_point_y, mirr_axis)
                self.create_rec_with_mem(*PDiff_CO, outline='black', fill='black', tags=f"DC{axis}_invDP_CO_{j}{v}")
        # -----------NDiff creating----------
        for j in range(I):
            NDiff_coords = (x0-j*(w+3*a)-(w+a), y0-5*b-gap-b/2,
                            x0-j*(w+3*a)-(w+4*a), y0-4*b-gap-b/2)
            NDiff_coords = self.rotate_shape(
                NDiff_coords, axis_point_x, axis_point_y, angle)
            NDiff_coords = self.mirror_shape(
                NDiff_coords, axis_point_x, axis_point_y, mirr_axis)
            self.create_rec_with_mem(*NDiff_coords, outline='green', fill='green', tags=f"DC{axis}_inv_DN_{j}")
            for v in range(2):
                NDiff_CO = (x0-j*(w+3*a)-(w+a)-Lambda-v*2*a, y0-5*b-gap-b/2+Lambda,
                            x0-j*(w+3*a)-(w+a)-Lambda-a/2-v*2*a, y0-4*b-gap-b/2-Lambda)
                NDiff_CO = self.rotate_shape(
                    NDiff_CO, axis_point_x, axis_point_y, angle)
                NDiff_CO = self.mirror_shape(
                    NDiff_CO, axis_point_x, axis_point_y, mirr_axis)
                self.create_rec_with_mem(*NDiff_CO, outline='black', fill='black', tags=f"DC{axis}_invDN_CO_{j}{v}")

        # -----------POlySi creating----------
        for j in range(2*I):
            # polysi creating and metall on polysi creating
            if j % 2 == 0:
                PO_coords = (x0-5*Lambda - j*2*w, y0-5*b,
                             x0-5*Lambda - j*2*w-b, y0-4*b)
                PO_ME = (x0-5*Lambda - j*2*w, y0-5*b,
                         x0-5*Lambda - j*2*w-b, y0-4*b)
                PO_CO = (x0-6*Lambda - j*2*w, y0-5*b+Lambda,
                         x0-4*Lambda - j*2*w-b, y0-4*b-Lambda)
            else:
                PO_coords = (x0-5*Lambda - j*2*w+a, y0-8*b,
                             x0-5*Lambda - j*2*w, y0-7*b+b/2)
                PO_ME = (x0-5*Lambda - j*2*w+a, y0-8 *
                         b, x0-5*Lambda - j*2*w, y0-7*b)
                PO_CO = (x0-6*Lambda - j*2*w+a, y0-8*b+Lambda,
                         x0-4*Lambda - j*2*w, y0-7*b-Lambda)
            # rotating shapes
            PO_coords = self.rotate_shape(
                PO_coords, axis_point_x, axis_point_y, angle)
            PO_ME = self.rotate_shape(PO_ME, axis_point_x, axis_point_y, angle)
            PO_CO = self.rotate_shape(PO_CO, axis_point_x, axis_point_y, angle)
            # mirror shapes
            PO_coords = self.mirror_shape(
                PO_coords, axis_point_x, axis_point_y, mirr_axis)
            PO_ME = self.mirror_shape(
                PO_ME, axis_point_x, axis_point_y, mirr_axis)
            PO_CO = self.mirror_shape(
                PO_CO, axis_point_x, axis_point_y, mirr_axis)
            # draw shapes
            self.create_rec_with_mem(
                *PO_coords, outline='red', fill='red', tags=f"DC{axis}_area_PO_{j}")
            self.create_rec_with_mem(
                *PO_ME, outline='blue', tags=f"DC{axis}_areaPO_ME_{j}")
            self.create_rec_with_mem(
                *PO_CO, outline='black', fill='black', tags=f"DC{axis}_areaPO_CO_{j}")
        # -----------MEtall creating----------
        for j in range(I):
            ME_coords = (x0-j*(w+3*a)-(w+a), y0-5*b-gap-b /
                         2, x0-j*(w+3*a)-(w+2*a), y0-b-gap)
            ME_coords = self.rotate_shape(
                ME_coords, axis_point_x, axis_point_y, angle)
            ME_coords = self.mirror_shape(
                ME_coords, axis_point_x, axis_point_y, mirr_axis)
            self.create_rec_with_mem(*ME_coords, fill='blue', outline='blue', tags= f"DC{axis}_inv_ME_{j}")

        for j in range(1, I+1):
            ME_coords = [(x0-j*(w+3*a), y0-2*b-gap, x0-j*(w+3*a)-w, y0), (x0 -
                                                                          j*(w+3*a), y0-6*b-gap-b/2-Lambda, x0-j*(w+3*a)-w, y0-4*b-gap-b/2)]
            for v in range(len(ME_coords)):
                ME_coords[v] = self.rotate_shape(
                    ME_coords[v], axis_point_x, axis_point_y, angle)
                ME_coords[v] = self.mirror_shape(
                    ME_coords[v], axis_point_x, axis_point_y, mirr_axis)
                self.create_rec_with_mem(*ME_coords[v], fill='blue', outline='blue', tags= f"DC{axis}_inv_ME_{j}")
        # -----------VIa creating----------
        for j in range(I):
            # get coords
            VI_coords = (x0-j*(w+3*a)-(w+a)-Lambda-2*a, y0-5*b-gap-b/2+Lambda,
                         x0-j*(w+3*a)-(w+a)-Lambda-a/2-2*a, y0-4*b-gap-b/2-Lambda)
            ME2_coords = (x0-j*(w+3*a)-(w+a)-2*a, y0-5*b-gap-b/2,
                          x0-j*(w+3*a)-(w+a)-3*a, y0-4*b-gap-b/2)
            # rotating shapes
            VI_coords = self.rotate_shape(
                VI_coords, axis_point_x, axis_point_y, angle)
            ME2_coords = self.rotate_shape(
                ME2_coords, axis_point_x, axis_point_y, angle)
            # mirror shapes
            VI_coords = self.mirror_shape(
                VI_coords, axis_point_x, axis_point_y, mirr_axis)
            ME2_coords = self.mirror_shape(
                ME2_coords, axis_point_x, axis_point_y, mirr_axis)
            # draw shapes
            self.create_rec_with_mem(*VI_coords, outline='gray', fill='gray', tags= f"DC{axis}_inv_VI_{j}")
            self.create_rec_with_mem(*ME2_coords, outline='#00008B', fill='#00008B', dash= '-.', tags = f"DC{axis}_inv_M2_{j}")

        # -----------VI for vss creating----------
        VI_pol = (NW_2_x-gap-4*I*a-Lambda, y0+gap+Lambda,
                  NW_2_x-gap-4*I*a-w+Lambda, y0+(gap+w)-Lambda)
        VI_pol = self.rotate_shape(VI_pol, axis_point_x, axis_point_y, angle)
        VI_pol = self.mirror_shape(
            VI_pol, axis_point_x, axis_point_y, mirr_axis)
        self.create_rec_with_mem(*VI_pol, outline='gray', fill='gray', tags= f"DC{axis}_{0}_VI_pol")
        # -----------ME2 creating----------
        ME2_coords = (x0 + gap, y0-5*b-gap, NW_2_x-gap-4*I*a-w, y0-4*b-gap)
        ME2_coords = self.rotate_shape(
            ME2_coords, axis_point_x, axis_point_y, angle)
        ME2_coords = self.mirror_shape(
            ME2_coords, axis_point_x, axis_point_y, mirr_axis)
        self.create_rec_with_mem(*ME2_coords, outline='#00008B', fill='#00008B', dash= '-.', tags = f"DC{axis}_{0}_M2_vss")

        ME2_coords = (NW_2_x-gap-4*I*a, y0-7*b-gap -
                      Lambda, NW_2_x-gap-4*I*a-w, y0+b+gap)
        ME2_coords = self.rotate_shape(
            ME2_coords, axis_point_x, axis_point_y, angle)
        ME2_coords = self.mirror_shape(
            ME2_coords, axis_point_x, axis_point_y, mirr_axis)
        self.create_rec_with_mem(*ME2_coords, outline='#00008B', fill='#00008B', dash= '-.', tags = f"DC{axis}_{0}_M2_vss")
        '''-------------------------------------------------------'''

    def MatrixNAND_DC(self, event, axis):
        # self.GridUnits = self.form.get_tech()
        self.GridUnits = self.GridLambda.get()
        decoder_access = self.y_decoder_access if axis == 'Y' else self.x_decoder_access
        if self.GridUnits == 0:
            messagebox.showerror("Error", "Choose foundry, please")
        else:
            self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
            if decoder_access == 0 and (self.insertAccess == 1 or self.multiplyAccess == 1 and self.synthesisAcces == 1):
                pass
            elif decoder_access == 1:
                self.multiplyAccess = 0
                self.insertAccess = 0
                self.synthesisAcces = 0
                if axis == 'Y':
                    self.y_decoder_access = 0
                    angle = 0
                    I = self.YDC_inputs  # amount of inputs
                else:
                    self.x_decoder_access = 0
                    angle = pi/2
                    I = self.XDC_inputs  # amount of inputs

                axis_point_x = self.canvas.canvasx(event.x)
                axis_point_y = self.canvas.canvasy(event.y)
                mirr_axis = None
                dop_shift = 0
                if self.foundry.get() == 'Microwind65':
                    self.compact_matrix_DC_MW(
                        axis_point_x, axis_point_y, self.Lambda, axis, angle, I, mirr_axis, dop_shift)  # compact version
                elif self.foundry.get() == 'SkyWater130':
                    self.compact_matrix_DC_SW(
                        axis_point_x, axis_point_y, self.Lambda, axis, angle, I, mirr_axis, dop_shift)

    def PulseRowAccess(self):
        self.multiplyAccess = 1
        self.x_decoder_access = 0
        self.y_decoder_access = 0
        self.x_connect_access = 0
        self.insertAccess = 0
        self.synthesisAcces = 0
        self.CellAccess = 1
        self.PulseY = 0
        self.PulseX = 1
        window = PULSEXSyn(self.master)
        window.wm_attributes('-topmost', True)
        window.resizable(False, False)
        window.title('TopoPlot: Pulse Blocks X axis')
        window.iconbitmap(r'nano.ico')
        self.rows = 1
        self.columns = window.open()
        # ------------------------------------------------------------------------
        if self.foundry.get() == 'Microwind65':
            filepath = self.filefolder+'\examples\PULSEX_block.txt'
            filename = os.path.basename(filepath)[:-4]
            self.device_coords_pulsex = ReadTXT_MW(
                path=filepath, name=filename).getCoords()
        elif self.foundry.get() == 'SkyWater130':
            filepath = self.filefolder+'\examples\PULSEX_block.mag'
            filename = os.path.basename(filepath)[:-4]
            self.device_coords_pulsex = ReadTXT_SW(
                path=filepath, name=filename).getCoords()

        self.insert_item_pulsex = re.split("_", filename.strip())
        self.insert_item_pulsex = self.insert_item_pulsex[0]

        no_update = False
        for fig in self.canvas.find_all():
            figure = self.canvas.gettags(fig)[0]
            figure = re.split("_", figure.strip())
            figure = figure[0]
            if figure == self.insert_item_pulsex:  # or figure == self.insert_item_pulsey1:
                no_update = True

        if not self.canvas.find_all() or no_update == False:
            self.num_of_blocks[self.insert_item_pulsex] = 0
        else:
            self.num_of_blocks[self.insert_item_pulsex] += 1

    def PulseColoumnAccess(self):
        self.multiplyAccess = 1
        self.y_decoder_access = 0
        self.x_decoder_access = 0
        self.x_connect_access = 0
        self.insertAccess = 0
        self.synthesisAcces = 0
        self.CellAccess = 1
        self.PulseY = 1
        self.PulseX = 0
        window = PULSEYSyn(self.master)
        window.wm_attributes('-topmost', True)
        window.resizable(False, False)
        window.title('TopoPlot: Pulse Blocks Y axis')
        window.iconbitmap(r'nano.ico')
        self.rows = window.open()
        self.columns = 1
        # ------------------------------------------------------------------------
        if self.foundry.get() == 'Microwind65':
            filepath = self.filefolder+'\examples\PULSEY_block.txt'
            filename = os.path.basename(filepath)[:-4]
            self.device_coords_pulsey = ReadTXT_MW(
                path=filepath, name=filename).getCoords()
        elif self.foundry.get() == 'SkyWater130':
            filepath = self.filefolder+'\examples\PULSEY_block.mag'
            filename = os.path.basename(filepath)[:-4]
            self.device_coords_pulsey = ReadTXT_SW(
                path=filepath, name=filename).getCoords()

        self.insert_item_pulsey = re.split("_", filename.strip())
        self.insert_item_pulsey = self.insert_item_pulsey[0]

        no_update = False
        for fig in self.canvas.find_all():
            figure = self.canvas.gettags(fig)[0]
            figure = re.split("_", figure.strip())
            figure = figure[0]
            if figure == self.insert_item_pulsey:  # or figure == self.insert_item_pulsey1:
                no_update = True

        if not self.canvas.find_all() or no_update == False:
            self.num_of_blocks[self.insert_item_pulsey] = 0
        else:
            self.num_of_blocks[self.insert_item_pulsey] += 1

    def synAccess(self):
        self.synthesisAcces = 1
        self.insertAccess = 0
        self.multiplyAccess = 0
        self.y_decoder_access = 0
        window = DeviceSynthes(self.master, self.foundry.get())
        window.wm_attributes('-topmost', True)
        window.resizable(False, False)
        window.title('TopoPlot: SRAM synthesis')
        window.iconbitmap(r'nano.ico')
        params = window.open()
        self.rows = params[0]  # bit depth
        self.columns = params[1]  # bit depth
        self.choosed_blocks = params[2]
        # print(self.choosed_blocks)

        # --------------------------------------------
        if self.foundry.get() == 'Microwind65':
            tech_ext = 'txt'
        elif self.foundry.get() == 'SkyWater130':
            tech_ext = 'mag'

        # filepath_PC = self.filefolder+'\examples\PC_block.txt'
        filepath_PC = self.filefolder+f'\examples\PC_exp.{tech_ext}'
        filepath_CELL = self.filefolder+f'\examples\SRAM_cell.{tech_ext}'
        filepath_BUFF = self.filefolder+f'\examples\BUFFER_block.{tech_ext}'
        filepath_pulsey = self.filefolder+f'\examples\PULSEY_block.{tech_ext}'
        filepath_OUT = self.filefolder+f'\examples\OUT_block.{tech_ext}'
        filepath_RSA = self.filefolder+f'\examples\RSA_block.{tech_ext}'
        filepath_WR = self.filefolder+f'\examples\WRITE_block.{tech_ext}'
        # if self.columns == 8:
        # filepath_CTRL = self.filefolder+f'\examples\CONTROL3_block.{tech_ext}'
        # elif self.columns == 4:
        # filepath_CTRL = self.filefolder+f'\examples\CONTROL2_block.{tech_ext}'
        # else:
        filepath_CTRL = self.filefolder+f'\examples\CONTROL_block.{tech_ext}'
        filepath_bottom_pc_empty = self.filefolder + \
            f'\examples\_bottomPC_empty_block.{tech_ext}'
        filepath_top_pulse_empty = self.filefolder + \
            f'\examples\_topPULSE_empty_block.{tech_ext}'
        filepath_for_pc_ctrl = self.filefolder + \
            f'\examples\_forPCctrl_block.{tech_ext}'
        filepath_y_connect = self.filefolder + \
            f'\examples\YCONNECT_block.{tech_ext}'
        filepath_pulsex = self.filefolder+f'\examples\_PULSEX_block.{tech_ext}'
        filepath_vdd_line = self.filefolder + \
            f'\examples\_VddLine_block.{tech_ext}'
        filepath_vdd_top = self.filefolder + \
            f'\examples\_VddTop_block.{tech_ext}'
        filepath_vdd_pulsex = self.filefolder + \
            f'\examples\_vddpulsex_block.{tech_ext}'

        # --------------------------------------------
        filename_PC = os.path.basename(filepath_PC)[:-4]
        filename_CELL = os.path.basename(filepath_CELL)[:-4]
        filename_BUFF = os.path.basename(filepath_BUFF)[:-4]
        filename_pulsey = os.path.basename(filepath_pulsey)[:-4]
        filename_OUT = os.path.basename(filepath_OUT)[:-4]
        filename_RSA = os.path.basename(filepath_RSA)[:-4]
        filename_WR = os.path.basename(filepath_WR)[:-4]
        filename_CTRL = os.path.basename(filepath_CTRL)[:-4]
        filename_y_connect = os.path.basename(filepath_y_connect)[:-4]
        filename_bottom_pc_empty = os.path.basename(
            filepath_bottom_pc_empty)[:-4]
        filename_top_pulse_empty = os.path.basename(
            filepath_top_pulse_empty)[:-4]
        filename_for_pc_ctrl = os.path.basename(filepath_for_pc_ctrl)[:-4]
        filename_pulsex = os.path.basename(filepath_pulsex)[:-4]
        filename_vdd_line = os.path.basename(filepath_vdd_line)[:-4]
        filename_vdd_top = os.path.basename(filepath_vdd_top)[:-4]
        filename_vdd_pulsex = os.path.basename(filepath_vdd_pulsex)[:-4]
        # --------------------------------------------
        if self.foundry.get() == 'Microwind65':
            self.device_coords_y_connect = ReadTXT_MW(
                path=filepath_y_connect, name=filename_y_connect).getCoords()
            self.device_coords_PC = ReadTXT_MW(
                path=filepath_PC, name=filename_PC).getCoords()
            self.device_coords_CELL = ReadTXT_MW(
                path=filepath_CELL, name=filename_CELL).getCoords()
            self.device_coords_BUFF = ReadTXT_MW(
                path=filepath_BUFF, name=filename_BUFF).getCoords()
            self.device_coords_pulsey = ReadTXT_MW(
                path=filepath_pulsey, name=filename_pulsey).getCoords()
            self.device_coords_OUT = ReadTXT_MW(
                path=filepath_OUT, name=filename_OUT).getCoords()
            self.device_coords_RSA = ReadTXT_MW(
                path=filepath_RSA, name=filename_RSA).getCoords()
            self.device_coords_WR = ReadTXT_MW(
                path=filepath_WR, name=filename_WR).getCoords()
            self.device_coords_CTRL = ReadTXT_MW(
                path=filepath_CTRL, name=filename_CTRL).getCoords()
            self.device_coords_bottom_pc_empty = ReadTXT_MW(
                path=filepath_bottom_pc_empty, name=filename_bottom_pc_empty).getCoords()
            self.device_coords_top_pulse_empty = ReadTXT_MW(
                path=filepath_top_pulse_empty, name=filename_top_pulse_empty).getCoords()
            self.device_coords_for_pc_ctrl = ReadTXT_MW(
                path=filepath_for_pc_ctrl, name=filename_for_pc_ctrl).getCoords()
            self.device_coords_pulsex = ReadTXT_MW(
                path=filepath_pulsex, name=filename_pulsex).getCoords()
            self.device_coords_vdd_line = ReadTXT_MW(
                path=filepath_vdd_line, name=filename_vdd_line).getCoords()
            self.device_coords_vdd_top = ReadTXT_MW(
                path=filepath_vdd_top, name=filename_vdd_top).getCoords()
            self.device_coords_vdd_pulsex = ReadTXT_MW(
                path=filepath_vdd_pulsex, name=filename_vdd_pulsex).getCoords()
        elif self.foundry.get() == 'SkyWater130':
            self.device_coords_PC = ReadTXT_SW(
                path=filepath_PC, name=filename_PC).getCoords()
            self.device_coords_CELL = ReadTXT_SW(
                path=filepath_CELL, name=filename_CELL).getCoords()
            self.device_coords_BUFF = ReadTXT_SW(
                path=filepath_BUFF, name=filename_BUFF).getCoords()
            self.device_coords_pulsey = ReadTXT_SW(
                path=filepath_pulsey, name=filename_pulsey).getCoords()
            self.device_coords_OUT = ReadTXT_SW(
                path=filepath_OUT, name=filename_OUT).getCoords()
            self.device_coords_RSA = ReadTXT_SW(
                path=filepath_RSA, name=filename_RSA).getCoords()
            self.device_coords_WR = ReadTXT_SW(
                path=filepath_WR, name=filename_WR).getCoords()
            self.device_coords_CTRL = ReadTXT_SW(
                path=filepath_CTRL, name=filename_CTRL).getCoords()
            self.device_coords_bottom_pc_empty = ReadTXT_SW(
                path=filepath_bottom_pc_empty, name=filename_bottom_pc_empty).getCoords()
            self.device_coords_top_pulse_empty = ReadTXT_SW(
                path=filepath_top_pulse_empty, name=filename_top_pulse_empty).getCoords()
            self.device_coords_for_pc_ctrl = ReadTXT_SW(
                path=filepath_for_pc_ctrl, name=filename_for_pc_ctrl).getCoords()
            self.device_coords_pulsex = ReadTXT_SW(
                path=filepath_pulsex, name=filename_pulsex).getCoords()
            self.device_coords_vdd_line = ReadTXT_SW(
                path=filepath_vdd_line, name=filename_vdd_line).getCoords()
            self.device_coords_vdd_top = ReadTXT_SW(
                path=filepath_vdd_top, name=filename_vdd_top).getCoords()
            self.device_coords_vdd_pulsex = ReadTXT_SW(
                path=filepath_vdd_pulsex, name=filename_vdd_pulsex).getCoords()
        # --------------------------------------------
        if self.foundry.get() == 'Microwind65':
            if self.device_coords_y_connect:
                self.insert_item_y_connect = re.split(
                    "_", filename_y_connect.strip())
                self.insert_item_y_connect = self.insert_item_y_connect[0]

        if self.device_coords_PC:
            self.insert_item_PC = re.split("_", filename_PC.strip())
            self.insert_item_PC = self.insert_item_PC[0]

        if self.device_coords_bottom_pc_empty:
            self.insert_item_bottom_pc_empty = re.split(
                "_", filename_bottom_pc_empty.strip())
            self.insert_item_bottom_pc_empty = self.insert_item_bottom_pc_empty[1]

        if self.device_coords_top_pulse_empty:
            self.insert_item_top_pulse_empty = re.split(
                "_", filename_top_pulse_empty.strip())
            self.insert_item_top_pulse_empty = self.insert_item_top_pulse_empty[1]

        if self.device_coords_for_pc_ctrl:
            self.insert_item_for_pc_ctrl = re.split(
                "_", filename_for_pc_ctrl.strip())
            self.insert_item_for_pc_ctrl = self.insert_item_for_pc_ctrl[1]

        if self.device_coords_CELL:
            self.insert_item_CELL = re.split("_", filename_CELL.strip())
            self.insert_item_CELL = self.insert_item_CELL[0]

        if self.device_coords_BUFF:
            self.insert_item_BUFF = re.split("_", filename_BUFF.strip())
            self.insert_item_BUFF = self.insert_item_BUFF[0]

        if self.device_coords_pulsey:
            self.insert_item_pulsey = re.split("_", filename_pulsey.strip())
            self.insert_item_pulsey = self.insert_item_pulsey[0]

        if self.device_coords_OUT:
            self.insert_item_OUT = re.split("_", filename_OUT.strip())
            self.insert_item_OUT = self.insert_item_OUT[0]

        if self.device_coords_RSA:
            self.insert_item_RSA = re.split("_", filename_RSA.strip())
            self.insert_item_RSA = self.insert_item_RSA[0]

        if self.device_coords_WR:
            self.insert_item_WR = re.split("_", filename_WR.strip())
            self.insert_item_WR = self.insert_item_WR[0]

        if self.device_coords_CTRL:
            self.insert_item_CTRL = re.split("_", filename_CTRL.strip())
            self.insert_item_CTRL = self.insert_item_CTRL[0]

        if self.device_coords_pulsex:
            self.insert_item_pulsex = re.split("_", filename_pulsex.strip())
            self.insert_item_pulsex = self.insert_item_pulsex[1]

        if self.device_coords_vdd_line:
            self.insert_item_vdd_line = re.split(
                "_", filename_vdd_line.strip())
            self.insert_item_vdd_line = self.insert_item_vdd_line[1]

        if self.device_coords_vdd_top:
            self.insert_item_vdd_top = re.split("_", filename_vdd_top.strip())
            self.insert_item_vdd_top = self.insert_item_vdd_top[1]

        if self.device_coords_vdd_pulsex:
            self.insert_item_vdd_pulsex = re.split(
                "_", filename_vdd_pulsex.strip())
            self.insert_item_vdd_pulsex = self.insert_item_vdd_pulsex[1]

        '''--- for hierarchy dc creating ---'''
        '''
        #---------------------------------------------------
        #  for Y Decoder items
        #---------------------------------------------------
        if self.rows >= 4:
            self.YDC_objects_coords = DCObjectItems_SW.device_coords['YDC']
        #---------------------------------------------------
        #  for X Decoder items
        #---------------------------------------------------
        if self.columns >= 4:
            self.XDC_objects_coords = DCObjectItems_SW.device_coords['XDC']
        #---------------------------------------------------
        '''
# =============================================================================
#     def out_param_crop(self, obj_aimed, obj_aimed_coords, obj_aimed_tag):
#         #print(obj_aimed, obj_aimed_coords, obj_aimed_tag)
#         """cutting invertor's of write block with parametrizing"""
#         #формируем новые списки для объектов
#         list_of_objects = [None]
#         coords_of_objects = [None]
#         list_object_colors = [None]
#         shifted_rect = [None]
#         new_rect = [None]
#         x_0 = [None]
#         x_1 = [None]
#         y_0 = [None]
#         y_1 = [None]
#         min_shift_h = [None]
#         min_shift_v = [None]
#         #--------------------------------
#         self.shapes_flag.set(0)
#         self.del_flag.set(0)
#         self.bound_flag.set(0)
#         #self.GridUnits = self.form.get_tech()
#         self.GridUnits = self.GridLambda.get()
#         if self.GridUnits == 0:
#             messagebox.showerror("Error", "Choose foundry, please")
#         else:
#             self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
#             r = self.Lambda/2
#             #deleting corners of OP area
#             for item in self.canvas.find_all():
#                 #print(item)
#                 if self.canvas.gettags(item)[0][:6] == 'corner':
#                     self.canvas.delete(item)
#             #получаем информацию обо всех областях на холсте
#             amount = len(self.canvas.find_all())-self.amount_of_line
#             if list_of_objects[0] is None or coords_of_objects[0] is None or list_object_colors[0] is None:
#                 for i in range(amount-1):
#                     list_of_objects.append(None)
#                     coords_of_objects.append(None)
#                     list_object_colors.append(None)
#             #print("num_of_all:", self.canvas.find_all())
#             for i in range(amount):
#                 list_of_objects[i]= self.canvas.find_all()[i]
#                 #print('list_of_objects:',list_of_objects)
#                 coords_of_objects[i] = self.canvas.coords(list_of_objects[i])
#                 #print('coords_of_objects:',coords_of_objects)
#                 list_object_colors[i] = self.canvas.itemcget(list_of_objects[i],"tags")
#                 list_object_colors[i] = re.split("_", list_object_colors[i].strip())
#                 list_object_colors[i]= list_object_colors[i][-2]
#
#             #print('..............................')
#             #print('list_of_objects:',list_of_objects)
#             #print('coords_of_objects:',coords_of_objects)
#             #print('list_object_colors:',list_object_colors)
#             #print('..............................')
#
#             #------------------------------------------------------------------------
#
#             if sechenie_coords[0] is not None:
#
#                 if x_0[0] is None or y_0[0] is None:
#                     for i in range(amount-1):
#                         x_0.append(None)
#                         x_1.append(None)
#                         y_0.append(None)
#                         y_1.append(None)
#                         min_shift_h.append(None)
#                         min_shift_v.append(None)
#                         shifted_rect.append(None)
#                         new_rect.append(None)
#                 #------------------------------------------
#                 intersection_v = False
#
#
#                 for j in range(amount):
#                     if sechenie_coords[0]>coords_of_objects[j][0] and sechenie_coords[0]<coords_of_objects[j][2]:
#                         intersection_v = True
#
#
#                 #-----------------get shift value (input param)-----------------
#
#                 if self.delta_value is not None:
#                     if self.PCParametrizeFlag == True:
#                         self.PCParametrizeFlag = False
#                     elif self.PULSEYParametrizeFlag == True:
#                         self.PULSEYParametrizeFlag= False
#                     elif self.WRParametrizeFlag == True:
#                         self.WRParametrizeFlag= False
#                     elif self.OUTParametrizeFlag == True:
#                         self.OUTParametrizeFlag= False
#
#                 #if (self.PCParametrizeFlag == False and self.PULSEYParametrizeFlag == False) and (self.delta_value is None) or (self.PC_count_flag == 0 and self.PULSEY_count_flag == 0):
#                     #window = CropParam(self.master)
#                     #self.delta_value = window.open()
#                     #self.delta_value *= self.Lambda
#
#                 if intersection_v == True and self.delta_value is not None:
#                     shift_v = self.delta_value
#                 else:
#                     shift_v = 0
#                 for i in range(amount):
#
#                     #-------if we found 'CO' area then we skip this area--------------
#                     aimed_area_tags = self.canvas.itemcget(list_of_objects[i],"tags")
#                     aimed_area_tags = re.split("_", aimed_area_tags.strip())
#                     aimed_area_coords = self.canvas.coords(list_of_objects[i])
#                     #print(aimed_area_tags)
#                     if self.foundry.get() == 'Microwind65':
#                         if aimed_area_tags [0] == 'OUT' and aimed_area_tags[-2] == 'CO' and aimed_area_coords[0] > obj_aimed_coords[0] and aimed_area_coords[2] < obj_aimed_coords[2]:# and aimed_area_tags[-1] not in defended_chars:
#                             #print('aga')
#                             continue
#
#                     #---------------------making the vertical crop-----------------
#
#                     x_v = sechenie_coords[0]
#                     y_0[i] = coords_of_objects[i][1]
#                     y_1[i] = coords_of_objects[i][3]
#
#                     if x_v > coords_of_objects[i][0] and x_v < coords_of_objects[i][2]:
#                         min_shift_v[i] = coords_of_objects[i][2] - x_v
#                         new_rect[i] = (coords_of_objects[i][0], y_0[i], x_v + min_shift_v[i] + shift_v, y_1[i])
#
#                     elif x_v < coords_of_objects[i][0] and x_v < coords_of_objects[i][2]:
#                         shifted_rect[i] = (coords_of_objects[i][0]+shift_v, y_0[i], coords_of_objects[i][2]+shift_v, y_1[i])
#
#
#                     #----------------------------------------------------------------
#                     try:
#                         #for thing in self.canvas.find_all():
#                         #    print(self.canvas.gettags(thing)[0])
#                         for areatype in area_props[self.foundry.get()].keys():
#                             if list_object_colors[i] == areatype:
#                                 block = self.canvas.itemcget(list_of_objects[i],"tags")
#                                 block = re.split("_",block.strip())
#                                 block_name = block[0]
#                                 block_num = block[1]
#                                 block_area_j = block[-1]
#                                 use_color = area_props[self.foundry.get()][areatype]['border_color']
#                                 filling = area_props[self.foundry.get()][areatype]['fill_color']
#                                 border = area_props[self.foundry.get()][areatype]['border_dash']
#                                 if new_rect[i] is not None:
#                                     #self.j_new[areatype] += 1
#                                     self.create_rec_with_mem(*new_rect[i], outline=use_color, fill = filling, dash = border, tags = f"{block_name}_{block_num}_{areatype}_{block_area_j}")
#                                     #-----------------------------------------------------------
#                                     if areatype == 'OP' and self.drag_flag.get() == 1:
#                                         rec_coord = new_rect[i]
#                                         for m in (0,2):
#                                             for n in (1,3):
#                                                 self.canvas.create_oval(rec_coord[m]-r, rec_coord[n]-r, rec_coord[m]+r, rec_coord[n]+r, fill = '',activefill = 'black', outline = 'black', tags = 'corner'+f'{m}'+f'{n}'+'_'+f'{i}')
#                                     #-----------------------------------------------------------
#                                 elif shifted_rect[i] is not None:
#                                     #self.j_shifted[areatype] += 1
#                                     self.create_rec_with_mem(*shifted_rect[i], outline=use_color, fill = filling, dash = border, tags = f"{block_name}_{block_num}_{areatype}_{block_area_j}")
#                                     #-----------------------------------------------------------
#                                     if areatype == 'OP' and self.drag_flag.get() == 1:
#                                         rec_coord = new_rect[i]
#                                         for m in (0,2):
#                                             for n in (1,3):
#                                                 self.canvas.create_oval(rec_coord[m]-r, rec_coord[n]-r, rec_coord[m]+r, rec_coord[n]+r, fill = '',activefill = 'black', outline = 'black', tags = 'corner'+f'{m}'+f'{n}'+'_'+f'{i}')
#                                     #-----------------------------------------------------------
#                                     self.canvas.delete(list_of_objects[i])
#
#
#                     except: pass
#
#                     if x_v > coords_of_objects[i][0] and x_v < coords_of_objects[i][2]:
#                         self.canvas.delete(list_of_objects[i])
#
#
#                     list_of_objects[i] = None
#                     coords_of_objects[i] = None
#                     list_object_colors[i] = None
#                     shifted_rect[i] = None
#                     new_rect[i] = None
#                     x_0[i] = None
#                     x_1[i] = None
#                     y_0[i] = None
#                     y_1[i] = None
#                     min_shift_h[i] = None
#                     min_shift_v[i] = None
#
#                 #-------- удаляем сечение-------
#                 line_item = self.canvas.find_withtag("Sechenie")
#                 self.amount_of_line = 0
#                 self.canvas.delete(line_item)
#                 #--------------------------------
#
#                 for i in range(len(sechenie_coords)):
#                     sechenie_coords[i] = None
#
#                 #--------------------------------------------------------------
# =============================================================================

    def out_param_crop(self, obj_aimed, obj_aimed_coords, obj_aimed_tag):

        # Проверка GridUnits
        self.GridUnits = self.GridLambda.get()
        if self.GridUnits == 0:
            messagebox.showerror("Error", "Choose foundry, please")
            return

        # Инициализация основных параметров
        self.Lambda = self.GridUnits * self.scale**self.wheel_count
        r = self.Lambda/2

        # Сброс флагов
        self.shapes_flag.set(0)
        self.del_flag.set(0)
        self.bound_flag.set(0)

        # Удаление угловых точек
        self.canvas.delete(*[item for item in self.canvas.find_all()
                             if self.canvas.gettags(item)[0].startswith('corner')])

        # Получение информации об областях
        all_items = self.canvas.find_all()
        amount = len(all_items) - self.amount_of_line

        # Создание списков с предварительно выделенной памятью
        objects_data = []
        for i in range(amount):
            item = all_items[i]            
            tags = self.canvas.itemcget(item, "tags")
            if tags != 'Sechenie':
                coords = self.canvas.coords(item)
                color = re.split("_", tags.strip())[-2]
                objects_data.append((item, coords, color))

        if sechenie_coords[0] is not None:
            # Проверка вертикального пересечения
            intersection_v = any(sechenie_coords[0] > data[1][0] and sechenie_coords[0] < data[1][2] for data in objects_data)
            ## Проверка горизонтального пересечения
            #intersection_h = any(sechenie_coords[1] > data[1][1] and sechenie_coords[1] < data[1][3] for data in objects_data)            

            # Получение значения сдвига по горизонтали
            shift_v = self.delta_value if intersection_v and self.delta_value is not None else 0
            ## Получение значения сдвига по вертикали
            #shift_h = self.delta_value if intersection_h and self.delta_value is not None else 0            
            

            x_v = sechenie_coords[0]
            #y_h = sechenie_coords[1]

            # Обработка каждого объекта
            for item, coords, color in objects_data:
                tags = self.canvas.itemcget(item, "tags").split("_")

                # Пропуск областей CO для Microwind65
                if (self.foundry.get() == 'Microwind65' and
                    tags[0] == 'OUT' and tags[-2] == 'CO' and
                    coords[0] > obj_aimed_coords[0] and coords[2] < obj_aimed_coords[2]):
                    continue

                # Расчет новых координат вертикального сечения
                if x_v > coords[0] and x_v < coords[2]:
                    min_shift_v = coords[2] - x_v
                    new_rect = (coords[0], coords[1], x_v + min_shift_v + shift_v, coords[3])
                    self._create_area(new_rect, tags, color, r)
                    self.canvas.delete(item)
                elif x_v < coords[0] and x_v < coords[2]:
                    shifted_rect = (coords[0] + shift_v, coords[1], coords[2] + shift_v, coords[3])
                    self._create_area(shifted_rect, tags, color, r)
                    self.canvas.delete(item)
                    
                # Расчет новых координат горизонтального сечения
                #if y_h > coords[1] and y_h < coords[3]:
                    #min_shift_h = coords[3] - y_h
                    #new_rect = (coords[0], coords[1], coords[2], y_h + min_shift_h + shift_h)
                    #self._create_area(new_rect, tags, color, r)
                    #self.canvas.delete(item)
                #elif y_h < coords[1] and y_h < coords[3]:
                    #shifted_rect = (coords[0], coords[1] + shift_h, coords[2], coords[3] + shift_h)
                    #self._create_area(shifted_rect, tags, color, r)
                    #self.canvas.delete(item)                

            # Очистка сечения
            self.canvas.delete("Sechenie")
            self.amount_of_line = 0
            sechenie_coords[:] = [None] * len(sechenie_coords)


# =============================================================================
#     def wr_param_crop(self, obj_aimed, obj_aimed_coords, obj_aimed_tag):
#         #print(obj_aimed, obj_aimed_coords, obj_aimed_tag)
#         """cutting invertor's of write block with parametrizing"""
#         #формируем новые списки для объектов
#         list_of_objects = [None]
#         coords_of_objects = [None]
#         list_object_colors = [None]
#         shifted_rect = [None]
#         new_rect = [None]
#         x_0 = [None]
#         x_1 = [None]
#         y_0 = [None]
#         y_1 = [None]
#         min_shift_h = [None]
#         min_shift_v = [None]
#         #--------------------------------
#         self.shapes_flag.set(0)
#         self.del_flag.set(0)
#         self.bound_flag.set(0)
#         #self.GridUnits = self.form.get_tech()
#         self.GridUnits = self.GridLambda.get()
#         if self.GridUnits == 0:
#             messagebox.showerror("Error", "Choose foundry, please")
#         else:
#             self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
#             r = self.Lambda/2
#             #deleting corners of OP area
#             for item in self.canvas.find_all():
#                 #print(item)
#                 if self.canvas.gettags(item)[0][:6] == 'corner':
#                     self.canvas.delete(item)
#             #получаем информацию обо всех областях на холсте
#             amount = len(self.canvas.find_all())-self.amount_of_line
#             if list_of_objects[0] is None or coords_of_objects[0] is None or list_object_colors[0] is None:
#                 for i in range(amount-1):
#                     list_of_objects.append(None)
#                     coords_of_objects.append(None)
#                     list_object_colors.append(None)
#             #print("num_of_all:", self.canvas.find_all())
#             for i in range(amount):
#                 list_of_objects[i]= self.canvas.find_all()[i]
#                 #print('list_of_objects:',list_of_objects)
#                 coords_of_objects[i] = self.canvas.coords(list_of_objects[i])
#                 #print('coords_of_objects:',coords_of_objects)
#                 list_object_colors[i] = self.canvas.itemcget(list_of_objects[i],"tags")
#                 list_object_colors[i] = re.split("_", list_object_colors[i].strip())
#                 list_object_colors[i]= list_object_colors[i][-2]
#
#             #print('..............................')
#             #print('list_of_objects:',list_of_objects)
#             #print('coords_of_objects:',coords_of_objects)
#             #print('list_object_colors:',list_object_colors)
#             #print('..............................')
#
#             #------------------------------------------------------------------------
#
#             if sechenie_coords[0] is not None:
#
#                 if x_0[0] is None or y_0[0] is None:
#                     for i in range(amount-1):
#                         x_0.append(None)
#                         x_1.append(None)
#                         y_0.append(None)
#                         y_1.append(None)
#                         min_shift_h.append(None)
#                         min_shift_v.append(None)
#                         shifted_rect.append(None)
#                         new_rect.append(None)
#                 #------------------------------------------
#                 intersection_v = False
#
#
#                 for j in range(amount):
#                     if sechenie_coords[0]>coords_of_objects[j][0] and sechenie_coords[0]<coords_of_objects[j][2]:
#                         intersection_v = True
#
#
#                 #-----------------get shift value (input param)-----------------
#
#                 if self.delta_value is not None:
#                     if self.PCParametrizeFlag == True:
#                         self.PCParametrizeFlag = False
#                     elif self.PULSEYParametrizeFlag == True:
#                         self.PULSEYParametrizeFlag= False
#                     elif self.WRParametrizeFlag == True:
#                         self.WRParametrizeFlag= False
#
#                 #if (self.PCParametrizeFlag == False and self.PULSEYParametrizeFlag == False) and (self.delta_value is None) or (self.PC_count_flag == 0 and self.PULSEY_count_flag == 0):
#                     #window = CropParam(self.master)
#                     #self.delta_value = window.open()
#                     #self.delta_value *= self.Lambda
#
#                 if intersection_v == True and self.delta_value is not None:
#                     shift_v = self.delta_value
#                 else:
#                     shift_v = 0
#                 for i in range(amount):
#
#                     #-------if we found 'CO' area then we skip this area--------------
#                     aimed_area_tags = self.canvas.itemcget(list_of_objects[i],"tags")
#                     aimed_area_tags = re.split("_", aimed_area_tags.strip())
#                     aimed_area_coords = self.canvas.coords(list_of_objects[i])
#                     #print(aimed_area_tags)
#                     if self.foundry.get() == 'Microwind65':
#                         if aimed_area_tags [0] == 'WRITE' and aimed_area_tags[-2] == 'CO' and aimed_area_coords[0] > obj_aimed_coords[0] and aimed_area_coords[2] < obj_aimed_coords[2]:# and aimed_area_tags[-1] not in defended_chars:
#                             #print('aga')
#                             continue
#
#                     #---------------------making the vertical crop-----------------
#
#                     x_v = sechenie_coords[0]
#                     y_0[i] = coords_of_objects[i][1]
#                     y_1[i] = coords_of_objects[i][3]
#
#                     if x_v > coords_of_objects[i][0] and x_v < coords_of_objects[i][2]:
#                         min_shift_v[i] = coords_of_objects[i][2] - x_v
#                         new_rect[i] = (coords_of_objects[i][0], y_0[i], x_v + min_shift_v[i] + shift_v, y_1[i])
#
#                     elif x_v < coords_of_objects[i][0] and x_v < coords_of_objects[i][2]:
#                         shifted_rect[i] = (coords_of_objects[i][0]+shift_v, y_0[i], coords_of_objects[i][2]+shift_v, y_1[i])
#
#
#                     #----------------------------------------------------------------
#                     try:
#                         #for thing in self.canvas.find_all():
#                         #    print(self.canvas.gettags(thing)[0])
#                         for areatype in area_props[self.foundry.get()].keys():
#                             if list_object_colors[i] == areatype:
#                                 block = self.canvas.itemcget(list_of_objects[i],"tags")
#                                 block = re.split("_",block.strip())
#                                 block_name = block[0]
#                                 block_num = block[1]
#                                 block_area_j = block[-1]
#                                 use_color = area_props[self.foundry.get()][areatype]['border_color']
#                                 filling = area_props[self.foundry.get()][areatype]['fill_color']
#                                 border = area_props[self.foundry.get()][areatype]['border_dash']
#                                 if new_rect[i] is not None:
#                                     #self.j_new[areatype] += 1
#                                     self.create_rec_with_mem(*new_rect[i], outline=use_color, fill = filling, dash = border, tags = f"{block_name}_{block_num}_{areatype}_{block_area_j}")
#                                     #-----------------------------------------------------------
#                                     if areatype == 'OP' and self.drag_flag.get() == 1:
#                                         rec_coord = new_rect[i]
#                                         for m in (0,2):
#                                             for n in (1,3):
#                                                 self.canvas.create_oval(rec_coord[m]-r, rec_coord[n]-r, rec_coord[m]+r, rec_coord[n]+r, fill = '',activefill = 'black', outline = 'black', tags = 'corner'+f'{m}'+f'{n}'+'_'+f'{i}')
#                                     #-----------------------------------------------------------
#                                 elif shifted_rect[i] is not None:
#                                     #self.j_shifted[areatype] += 1
#                                     self.create_rec_with_mem(*shifted_rect[i], outline=use_color, fill = filling, dash = border, tags = f"{block_name}_{block_num}_{areatype}_{block_area_j}")
#                                     #-----------------------------------------------------------
#                                     if areatype == 'OP' and self.drag_flag.get() == 1:
#                                         rec_coord = new_rect[i]
#                                         for m in (0,2):
#                                             for n in (1,3):
#                                                 self.canvas.create_oval(rec_coord[m]-r, rec_coord[n]-r, rec_coord[m]+r, rec_coord[n]+r, fill = '',activefill = 'black', outline = 'black', tags = 'corner'+f'{m}'+f'{n}'+'_'+f'{i}')
#                                     #-----------------------------------------------------------
#                                     self.canvas.delete(list_of_objects[i])
#
#
#                     except: pass
#
#                     if x_v > coords_of_objects[i][0] and x_v < coords_of_objects[i][2]:
#                         self.canvas.delete(list_of_objects[i])
#
#
#                     list_of_objects[i] = None
#                     coords_of_objects[i] = None
#                     list_object_colors[i] = None
#                     shifted_rect[i] = None
#                     new_rect[i] = None
#                     x_0[i] = None
#                     x_1[i] = None
#                     y_0[i] = None
#                     y_1[i] = None
#                     min_shift_h[i] = None
#                     min_shift_v[i] = None
#
#                 #-------- удаляем сечение-------
#                 line_item = self.canvas.find_withtag("Sechenie")
#                 self.amount_of_line = 0
#                 self.canvas.delete(line_item)
#                 #--------------------------------
#
#                 for i in range(len(sechenie_coords)):
#                     sechenie_coords[i] = None
#
#                 #--------------------------------------------------------------
# =============================================================================

    def wr_param_crop(self, obj_aimed, obj_aimed_coords, obj_aimed_tag):
        """Cutting invertor's of write block with parametrizing"""

        # Проверка GridUnits
        self.GridUnits = self.GridLambda.get()
        if self.GridUnits == 0:
            messagebox.showerror("Error", "Choose foundry, please")
            return

        # Инициализация основных параметров
        self.Lambda = self.GridUnits * self.scale**self.wheel_count
        r = self.Lambda/2

        # Сброс флагов
        self.shapes_flag.set(0)
        self.del_flag.set(0)
        self.bound_flag.set(0)

        # Удаление угловых точек
        self.canvas.delete(*[item for item in self.canvas.find_all()
                             if self.canvas.gettags(item)[0].startswith('corner')])

        # Получение информации об областях
        all_items = self.canvas.find_all()
        amount = len(all_items) - self.amount_of_line

        # Создание списков с предварительно выделенной памятью
        objects_data = []
        for i in range(amount):
            item = all_items[i]            
            tags = self.canvas.itemcget(item, "tags")
            if tags != 'Sechenie':
                coords = self.canvas.coords(item)
                color = re.split("_", tags.strip())[-2]
                objects_data.append((item, coords, color))

        if sechenie_coords[0] is not None:
            # Проверка вертикального пересечения
            intersection_v = any(sechenie_coords[0] > data[1][0] and
                                 sechenie_coords[0] < data[1][2] for data in objects_data)

            # Получение значения сдвига
            shift_v = self.delta_value if intersection_v and self.delta_value is not None else 0

            x_v = sechenie_coords[0]

            # Обработка каждого объекта
            for item, coords, color in objects_data:
                tags = self.canvas.itemcget(item, "tags").split("_")

                # Пропуск областей CO для Microwind65
                if (self.foundry.get() == 'Microwind65' and
                    tags[0] == 'WRITE' and tags[-2] == 'CO' and
                    coords[0] > obj_aimed_coords[0] and
                        coords[2] < obj_aimed_coords[2]):
                    continue

                # Расчет новых координат
                if x_v > coords[0] and x_v < coords[2]:
                    min_shift_v = coords[2] - x_v
                    new_rect = (coords[0], coords[1],
                                x_v + min_shift_v + shift_v, coords[3])
                    self._create_area(new_rect, tags, color, r)
                    self.canvas.delete(item)
                elif x_v < coords[0] and x_v < coords[2]:
                    shifted_rect = (coords[0] + shift_v, coords[1],
                                    coords[2] + shift_v, coords[3])
                    self._create_area(shifted_rect, tags, color, r)
                    self.canvas.delete(item)

            # Очистка сечения
            self.canvas.delete("Sechenie")
            self.amount_of_line = 0
            sechenie_coords[:] = [None] * len(sechenie_coords)

    def _create_area(self, rect_coords, tags, areatype, r):
        """Вспомогательный метод для создания области"""
        area_prop = area_props[self.foundry.get()][areatype]
        self.create_rec_with_mem(*rect_coords,
                                 outline=area_prop['border_color'],
                                 fill=area_prop['fill_color'],
                                 dash=area_prop['border_dash'],
                                 tags=f"{tags[0]}_{tags[1]}_{areatype}_{tags[-1]}")

        #if areatype == 'OP' and self.drag_flag.get() == 1:
            #for m in (0, 2):
                #for n in (1, 3):
                    #self.canvas.create_oval(
                        #rect_coords[m]-r, rect_coords[n]-r,
                        #rect_coords[m]+r, rect_coords[n]+r,
                        #fill='', activefill='black',
                        #outline='black',
                        #tags=f'corner{m}{n}_{tags[-1]}'
                    #)


# =============================================================================
#     def pulsey_param_crop(self, obj_aimed, obj_aimed_coords, obj_aimed_tag):
#         """cutting pulsey block's with parametrizing"""
#         #формируем новые списки для объектов
#         list_of_objects = [None]
#         coords_of_objects = [None]
#         list_object_colors = [None]
#         shifted_rect = [None]
#         new_rect = [None]
#         x_0 = [None]
#         x_1 = [None]
#         y_0 = [None]
#         y_1 = [None]
#         min_shift_h = [None]
#         min_shift_v = [None]
#         #--------------------------------
#         self.shapes_flag.set(0)
#         self.del_flag.set(0)
#         self.bound_flag.set(0)
#         #self.GridUnits = self.form.get_tech()
#         self.GridUnits = self.GridLambda.get()
#         if self.GridUnits == 0:
#             messagebox.showerror("Error", "Choose foundry, please")
#         else:
#             self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
#             r = self.Lambda/2
#             #deleting corners of OP area
#             for item in self.canvas.find_all():
#                 #print(item)
#                 if self.canvas.gettags(item)[0][:6] == 'corner':
#                     self.canvas.delete(item)
#             #получаем информацию обо всех областях на холсте
#             amount = len(self.canvas.find_all())-self.amount_of_line
#             if list_of_objects[0] is None or coords_of_objects[0] is None or list_object_colors[0] is None:
#                 for i in range(amount-1):
#                     list_of_objects.append(None)
#                     coords_of_objects.append(None)
#                     list_object_colors.append(None)
#             #print("num_of_all:", self.canvas.find_all())
#             for i in range(amount):
#                 list_of_objects[i]= self.canvas.find_all()[i]
#                 #print('list_of_objects:',list_of_objects)
#                 coords_of_objects[i] = self.canvas.coords(list_of_objects[i])
#                 #print('coords_of_objects:',coords_of_objects)
#                 list_object_colors[i] = self.canvas.itemcget(list_of_objects[i],"tags")
#                 list_object_colors[i] = re.split("_", list_object_colors[i].strip())
#                 list_object_colors[i]= list_object_colors[i][-2]
#
#             #print('..............................')
#             #print('list_of_objects:',list_of_objects)
#             #print('coords_of_objects:',coords_of_objects)
#             #print('list_object_colors:',list_object_colors)
#             #print('..............................')
#
#             #------------------------------------------------------------------------
#
#             if sechenie_coords[0] is not None:
#
#                 if x_0[0] is None or y_0[0] is None:
#                     for i in range(amount-1):
#                         x_0.append(None)
#                         x_1.append(None)
#                         y_0.append(None)
#                         y_1.append(None)
#                         min_shift_h.append(None)
#                         min_shift_v.append(None)
#                         shifted_rect.append(None)
#                         new_rect.append(None)
#                 #-----------------------------------------
#                 intersection_v = False
#
#
#                 for j in range(amount):
#                     if sechenie_coords[0]>coords_of_objects[j][0] and sechenie_coords[0]<coords_of_objects[j][2]:
#                         intersection_v = True
#
#
#                 #-----------------get shift value (input param)-----------------
#
#                 #if self.delta_value is not None:
#                     #if self.PCParametrizeFlag == True:
#                         #self.PCParametrizeFlag = False
#                     #elif self.PULSEYParametrizeFlag == True:
#                         #self.PULSEYParametrizeFlag= False
#
#                 #if (self.PCParametrizeFlag == False and self.PULSEYParametrizeFlag == False) and (self.delta_value is None) or (self.PC_count_flag == 0 and self.PULSEY_count_flag == 0):
#                     #window = CropParam(self.master)
#                     #self.delta_value = window.open()
#                     #self.delta_value *= self.Lambda
#
#                 if intersection_v == True and self.delta_value is not None:
#                     shift_v = self.delta_value
#                     self.PULSEYParametrizeFlag = False
#                 else:
#                     shift_v = 0
#
#                 for i in range(amount):
#
#                     #-------if we found 'CO' area then we skip this area--------------
#                     aimed_area_tags = self.canvas.itemcget(list_of_objects[i],"tags")
#                     aimed_area_tags = re.split("_", aimed_area_tags.strip())
#                     aimed_area_coords = self.canvas.coords(list_of_objects[i])
#                     #print(aimed_area_tags)
#                     if aimed_area_tags [0] == 'PULSEY' and aimed_area_tags[-2] == 'CO' and aimed_area_coords[0] > obj_aimed_coords[0] and aimed_area_coords[2] < obj_aimed_coords[2]:# and aimed_area_tags[-1] not in defended_chars:
#                         #print('aga')
#                         continue
#                     #---------------------making the vertical crop-----------------
#                     x_v = sechenie_coords[0]
#                     y_0[i] = coords_of_objects[i][1]
#                     y_1[i] = coords_of_objects[i][3]
#
#                     if x_v > coords_of_objects[i][0] and x_v < coords_of_objects[i][2]:
#                         min_shift_v[i] = coords_of_objects[i][2] - x_v
#                         new_rect[i] = (coords_of_objects[i][0], y_0[i], x_v + min_shift_v[i] + shift_v, y_1[i])
#
#                     elif x_v < coords_of_objects[i][0] and x_v < coords_of_objects[i][2]:
#                         shifted_rect[i] = (coords_of_objects[i][0]+shift_v, y_0[i], coords_of_objects[i][2]+shift_v, y_1[i])
#                     #----------------------------------------------------------------
#                     try:
#                         #for thing in self.canvas.find_all():
#                         #    print(self.canvas.gettags(thing)[0])
#                         for areatype in area_props[self.foundry.get()].keys():
#                             if list_object_colors[i] == areatype:
#                                 block = self.canvas.itemcget(list_of_objects[i],"tags")
#                                 block = re.split("_",block.strip())
#                                 block_name = block[0]
#                                 block_num = block[1]
#                                 block_area_j = block[-1]
#                                 use_color = area_props[self.foundry.get()][areatype]['border_color']
#                                 filling = area_props[self.foundry.get()][areatype]['fill_color']
#                                 border = area_props[self.foundry.get()][areatype]['border_dash']
#                                 if new_rect[i] is not None:
#                                     #self.j_new[areatype] += 1
#                                     self.create_rec_with_mem(*new_rect[i], outline=use_color, fill = filling, dash = border, tags = f"{block_name}_{block_num}_{areatype}_{block_area_j}")
#                                     #-----------------------------------------------------------
#                                     if areatype == 'OP' and self.drag_flag.get() == 1:
#                                         rec_coord = new_rect[i]
#                                         for m in (0,2):
#                                             for n in (1,3):
#                                                 self.canvas.create_oval(rec_coord[m]-r, rec_coord[n]-r, rec_coord[m]+r, rec_coord[n]+r, fill = '',activefill = 'black', outline = 'black', tags = 'corner'+f'{m}'+f'{n}'+'_'+f'{i}')
#                                     #-----------------------------------------------------------
#                                 elif shifted_rect[i] is not None:
#                                     #self.j_shifted[areatype] += 1
#                                     self.create_rec_with_mem(*shifted_rect[i], outline=use_color, fill = filling, dash = border, tags = f"{block_name}_{block_num}_{areatype}_{block_area_j}")
#                                     #-----------------------------------------------------------
#                                     if areatype == 'OP' and self.drag_flag.get() == 1:
#                                         rec_coord = new_rect[i]
#                                         for m in (0,2):
#                                             for n in (1,3):
#                                                 self.canvas.create_oval(rec_coord[m]-r, rec_coord[n]-r, rec_coord[m]+r, rec_coord[n]+r, fill = '',activefill = 'black', outline = 'black', tags = 'corner'+f'{m}'+f'{n}'+'_'+f'{i}')
#                                     #-----------------------------------------------------------
#                                     self.canvas.delete(list_of_objects[i])
#
#
#                     except: pass
#                     if x_v > coords_of_objects[i][0] and x_v < coords_of_objects[i][2]:
#                         self.canvas.delete(list_of_objects[i])
#
#
#                     list_of_objects[i] = None
#                     coords_of_objects[i] = None
#                     list_object_colors[i] = None
#                     shifted_rect[i] = None
#                     new_rect[i] = None
#                     x_0[i] = None
#                     x_1[i] = None
#                     y_0[i] = None
#                     y_1[i] = None
#                     min_shift_h[i] = None
#                     min_shift_v[i] = None
#
#                 #-------- удаляем сечение-------
#                 line_item = self.canvas.find_withtag("Sechenie")
#                 self.amount_of_line = 0
#                 self.canvas.delete(line_item)
#                 #--------------------------------
#                 for i in range(len(sechenie_coords)):
#                     sechenie_coords[i] = None
#                 #--------------------------------------------------------------
# =============================================================================


    def pulsey_param_crop(self, obj_aimed, obj_aimed_coords, obj_aimed_tag):
        """Optimized function for cutting pulsey blocks with parametrizing"""
        # Проверка GridUnits
        self.GridUnits = self.GridLambda.get()
        if self.GridUnits == 0:
            messagebox.showerror("Error", "Choose foundry, please")
            return

        # Инициализация основных параметров
        self.Lambda = self.GridUnits * self.scale**self.wheel_count
        r = self.Lambda/2

        # Сброс флагов
        self.shapes_flag.set(0)
        self.del_flag.set(0)
        self.bound_flag.set(0)

        # Удаление угловых точек
        self.canvas.delete(*[item for item in self.canvas.find_all()
                             if self.canvas.gettags(item)[0].startswith('corner')])

        # Получение информации об областях
        all_items = self.canvas.find_all()
        amount = len(all_items) - self.amount_of_line

        # Создание списков с предварительно выделенной памятью
        objects_data = []
        for i in range(amount):
            item = all_items[i]            
            tags = self.canvas.itemcget(item, "tags")
            if tags != 'Sechenie':
                coords = self.canvas.coords(item)
                color = re.split("_", tags.strip())[-2]
                objects_data.append((item, coords, color))

        if sechenie_coords[0] is not None:
            # Проверка вертикального пересечения
            intersection_v = any(sechenie_coords[0] > data[1][0] and
                                 sechenie_coords[0] < data[1][2] for data in objects_data)

            # Получение значения сдвига
            shift_v = self.delta_value if intersection_v and self.delta_value is not None else 0

            x_v = sechenie_coords[0]

            # Обработка каждого объекта
            for item, coords, color in objects_data:
                tags = self.canvas.itemcget(item, "tags").split("_")

                # Пропуск областей CO для Microwind65
                if (self.foundry.get() == 'Microwind65' and
                    tags[0] == 'PULSEY' and tags[-2] == 'CO' and
                    coords[0] > obj_aimed_coords[0] and
                        coords[2] < obj_aimed_coords[2]):
                    continue

                # Расчет новых координат
                if x_v > coords[0] and x_v < coords[2]:
                    min_shift_v = coords[2] - x_v
                    new_rect = (coords[0], coords[1],
                                x_v + min_shift_v + shift_v, coords[3])
                    self._create_area(new_rect, tags, color, r)
                    self.canvas.delete(item)
                elif x_v < coords[0] and x_v < coords[2]:
                    shifted_rect = (coords[0] + shift_v, coords[1],
                                    coords[2] + shift_v, coords[3])
                    self._create_area(shifted_rect, tags, color, r)
                    self.canvas.delete(item)

            # Очистка сечения
            self.canvas.delete("Sechenie")
            self.amount_of_line = 0
            sechenie_coords[:] = [None] * len(sechenie_coords)


    def pulsex_param_crop(self, obj_aimed, obj_aimed_coords, obj_aimed_tag):
        # формируем новые списки для объектов
        list_of_objects = [None]
        coords_of_objects = [None]
        list_object_colors = [None]
        shifted_rect = [None]
        new_rect = [None]
        x_0 = [None]
        x_1 = [None]
        y_0 = [None]
        y_1 = [None]
        min_shift_h = [None]
        min_shift_v = [None]
        # -----------------------------------
        self.shapes_flag.set(0)
        self.del_flag.set(0)
        self.bound_flag.set(0)
        # self.GridUnits = self.form.get_tech()
        self.GridUnits = self.GridLambda.get()
        if self.GridUnits == 0:
            messagebox.showerror("Error", "Choose foundry, please")
        else:
            self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
            r = self.Lambda/2
            # deleting corners of OP area
            for item in self.canvas.find_all():
                # print(item)
                if self.canvas.gettags(item)[0][:6] == 'corner':
                    self.canvas.delete(item)
            # получаем информацию обо всех областях на холсте
            amount = len(self.canvas.find_all())-self.amount_of_line
            if list_of_objects[0] is None or coords_of_objects[0] is None or list_object_colors[0] is None:
                for i in range(amount-1):
                    list_of_objects.append(None)
                    coords_of_objects.append(None)
                    list_object_colors.append(None)
            # print("num_of_all:", self.canvas.find_all())
            for i in range(amount):
                list_of_objects[i] = self.canvas.find_all()[i]
                # print('list_of_objects:',list_of_objects)
                coords_of_objects[i] = self.canvas.coords(list_of_objects[i])
                # print('coords_of_objects:',coords_of_objects)
                list_object_colors[i] = self.canvas.itemcget(
                    list_of_objects[i], "tags")
                list_object_colors[i] = re.split(
                    "_", list_object_colors[i].strip())
                list_object_colors[i] = list_object_colors[i][-2]

            # print('..............................')
            # print('list_of_objects:',list_of_objects)
            # print('coords_of_objects:',coords_of_objects)
            # print('list_object_colors:',list_object_colors)
            # print('..............................')

            # ------------------------------------------------------------------------

            if sechenie_coords[0] is not None:

                if x_0[0] is None or y_0[0] is None:
                    for i in range(amount-1):
                        x_0.append(None)
                        x_1.append(None)
                        y_0.append(None)
                        y_1.append(None)
                        min_shift_h.append(None)
                        min_shift_v.append(None)
                        shifted_rect.append(None)
                        new_rect.append(None)
                        # print(shifted_rect)

                # ------------------------------------------
                intersection_h = False
                intersection_v = False

                for j in range(amount):
                    if sechenie_coords[1] > coords_of_objects[j][1] and sechenie_coords[1] < coords_of_objects[j][3]:
                        intersection_h = True

                    if sechenie_coords[0] > coords_of_objects[j][0] and sechenie_coords[0] < coords_of_objects[j][2]:
                        intersection_v = True

                # -----------------get shift value (input param)-----------------

                if self.delta_value is not None:
                    if self.PCParametrizeFlag == True:
                        self.PCParametrizeFlag = False
                    elif self.PULSEYParametrizeFlag == True:
                        self.PULSEYParametrizeFlag = False
                    elif self.PULSEXParametrizeFlag == True:
                        self.PULSEXParametrizeFlag = False

                # if (self.PCParametrizeFlag == False and self.PULSEYParametrizeFlag == False) and (self.delta_value is None) or (self.PC_count_flag == 0 and self.PULSEY_count_flag == 0):
                    # window = CropParam(self.master)
                    # self.delta_value = window.open()
                    # self.delta_value *= self.Lambda

                if intersection_h == True and self.delta_value is not None:
                    shift_h = self.delta_value
                else:
                    shift_h = 0

                if intersection_v == True and self.delta_value is not None:
                    shift_v = self.delta_value
                else:
                    shift_v = 0
                defended_chars_CO = ['2', '3', '7']
                defended_chars_ME = ['4', '11']
                for i in range(amount):
                    # -------if we found 'CO' area then we skip this area--------------
                    if self.foundry.get() == 'Microwind65':
                        aimed_area_tags = self.canvas.itemcget(
                            list_of_objects[i], "tags")
                        aimed_area_tags = re.split(
                            "_", aimed_area_tags.strip())
                        aimed_area_coords = self.canvas.coords(
                            list_of_objects[i])
                        # print(aimed_area_tags)
                        # and aimed_area_tags[-1] not in defended_chars:
                        if aimed_area_tags[0] == 'PC' and aimed_area_tags[-2] == 'CO' and aimed_area_coords[1] > obj_aimed_coords[1] and aimed_area_coords[3] < obj_aimed_coords[3]:
                            # print('aga')
                            continue
                        # and aimed_area_tags[-1] not in defended_chars:
                        elif aimed_area_tags[0] == 'PC' and aimed_area_tags[-2] == 'VI' and aimed_area_coords[1] > obj_aimed_coords[1] and aimed_area_coords[3] < obj_aimed_coords[3]:
                            # print('aga')
                            continue
                        # and aimed_area_tags[-1] not in defended_chars:
                        elif aimed_area_tags[0] == 'PC' and aimed_area_tags[-2] == 'ME' and aimed_area_coords[1] >= obj_aimed_coords[1] and aimed_area_coords[3] <= obj_aimed_coords[3] and aimed_area_tags[-1] in defended_chars_ME:
                            # print('aga')
                            continue

                    # ----------------------making the horizontal crop--------------
                    if self.hor_flag.get() == 1:

                        x_0[i] = coords_of_objects[i][0]
                        x_1[i] = coords_of_objects[i][2]
                        y_h = sechenie_coords[1]

                        if y_h > coords_of_objects[i][1] and y_h < coords_of_objects[i][3]:
                            min_shift_h[i] = -(coords_of_objects[i][1] - y_h)
                            new_rect[i] = (
                                x_0[i], y_h-min_shift_h[i]-shift_h, x_1[i], coords_of_objects[i][3])

                        elif y_h > coords_of_objects[i][1] and y_h > coords_of_objects[i][3]:
                            shifted_rect[i] = (
                                x_0[i], coords_of_objects[i][1]-shift_h, x_1[i], coords_of_objects[i][3]-shift_h)

                    # ---------------------making the vertical crop-----------------
                    if self.ver_flag.get() == 1:

                        x_v = sechenie_coords[0]
                        y_0[i] = coords_of_objects[i][1]
                        y_1[i] = coords_of_objects[i][3]

                        if x_v > coords_of_objects[i][0] and x_v < coords_of_objects[i][2]:
                            min_shift_v[i] = coords_of_objects[i][2] - x_v
                            new_rect[i] = (
                                coords_of_objects[i][0], y_0[i], x_v + min_shift_v[i] + shift_v, y_1[i])

                        elif x_v < coords_of_objects[i][0] and x_v < coords_of_objects[i][2]:
                            shifted_rect[i] = (
                                coords_of_objects[i][0]+shift_v, y_0[i], coords_of_objects[i][2]+shift_v, y_1[i])
                    # ----------------------------------------------------------------
                    try:
                        # for thing in self.canvas.find_all():
                        #    print(self.canvas.gettags(thing)[0])
                        for areatype in area_props[self.foundry.get()].keys():
                            if list_object_colors[i] == areatype:
                                block = self.canvas.itemcget(
                                    list_of_objects[i], "tags")
                                block = re.split("_", block.strip())
                                block_name = block[0]
                                block_num = block[1]
                                block_area_j = block[-1]
                                use_color = area_props[self.foundry.get(
                                )][areatype]['border_color']
                                filling = area_props[self.foundry.get(
                                )][areatype]['fill_color']
                                border = area_props[self.foundry.get(
                                )][areatype]['border_dash']
                                if new_rect[i] is not None:
                                    # self.j_new[areatype] += 1
                                    self.create_rec_with_mem(*new_rect[i], outline=use_color, fill=filling, dash=border, tags=f"{block_name}_{block_num}_{areatype}_{block_area_j}")
                                    # -----------------------------------------------------------
                                    if areatype == 'OP' and self.drag_flag.get() == 1:
                                        rec_coord = new_rect[i]
                                        for m in (0, 2):
                                            for n in (1, 3):
                                                self.canvas.create_oval(rec_coord[m]-r, rec_coord[n]-r, rec_coord[m]+r, rec_coord[n]+r, fill='', activefill='black', outline= 'black', tags = 'corner'+f'{m}'+f'{n}'+'_'+f'{i}')
                                    # -----------------------------------------------------------
                                elif shifted_rect[i] is not None:
                                    # self.j_shifted[areatype] += 1
                                    self.create_rec_with_mem(*shifted_rect[i], outline=use_color, fill=filling, dash=border, tags=f"{block_name}_{block_num}_{areatype}_{block_area_j}")
                                    # -----------------------------------------------------------
                                    if areatype == 'OP' and self.drag_flag.get() == 1:
                                        rec_coord = new_rect[i]
                                        for m in (0, 2):
                                            for n in (1, 3):
                                                self.canvas.create_oval(rec_coord[m]-r, rec_coord[n]-r, rec_coord[m]+r, rec_coord[n]+r, fill='', activefill='black', outline= 'black', tags = 'corner'+f'{m}'+f'{n}'+'_'+f'{i}')
                                    # -----------------------------------------------------------
                                    self.canvas.delete(list_of_objects[i])

                    except:
                        pass

                    if self.hor_flag.get() == 1:
                        if y_h > coords_of_objects[i][1] and y_h < coords_of_objects[i][3]:
                            self.canvas.delete(list_of_objects[i])

                    if self.ver_flag.get() == 1:
                        if x_v > coords_of_objects[i][0] and x_v < coords_of_objects[i][2]:
                            self.canvas.delete(list_of_objects[i])

                    # print('--------------------')
                    # print(list_of_objects)#, self.canvas.itemcget(list_of_objects[0], "tags"))
                    # print('--------------------')
                    list_of_objects[i] = None
                    coords_of_objects[i] = None
                    list_object_colors[i] = None
                    shifted_rect[i] = None
                    new_rect[i] = None
                    x_0[i] = None
                    x_1[i] = None
                    y_0[i] = None
                    y_1[i] = None
                    min_shift_h[i] = None
                    min_shift_v[i] = None

                # -------- удаляем сечение-------
                line_item = self.canvas.find_withtag("Sechenie")
                self.amount_of_line = 0
                self.canvas.delete(line_item)
                # --------------------------------

                for i in range(len(sechenie_coords)):
                    sechenie_coords[i] = None

                # --------------------------------------------------------------

            self.hor_flag.set(0)
            self.ver_flag.set(0)

# =============================================================================
    #def pc_param_crop(self, obj_aimed, obj_aimed_coords, obj_aimed_tag):
        #"""func defined below crop blocks with parametrizing"""
        ##формируем новые списки для объектов
        #list_of_objects = [None]
        #coords_of_objects = [None]
        #list_object_colors = [None]
        #shifted_rect = [None]
        #new_rect = [None]
        #x_0 = [None]
        #x_1 = [None]
        #y_0 = [None]
        #y_1 = [None]
        #min_shift_h = [None]
        #min_shift_v = [None]
        ##-----------------------------------
        #self.shapes_flag.set(0)
        #self.del_flag.set(0)
        #self.bound_flag.set(0)
        ##self.GridUnits = self.form.get_tech()
        #self.GridUnits = self.GridLambda.get()
        #if self.GridUnits == 0:
            #messagebox.showerror("Error", "Choose foundry, please")
        #else:
            #self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
            #r = self.Lambda/2
            ##deleting corners of OP area
            #for item in self.canvas.find_all():
                ##print(item)
                #if self.canvas.gettags(item)[0][:6] == 'corner':
                    #self.canvas.delete(item)
            ##получаем информацию обо всех областях на холсте
            #amount = len(self.canvas.find_all())-self.amount_of_line
            #if list_of_objects[0] is None or coords_of_objects[0] is None or list_object_colors[0] is None:
                #for i in range(amount-1):
                    #list_of_objects.append(None)
                    #coords_of_objects.append(None)
                    #list_object_colors.append(None)
            ##print("num_of_all:", self.canvas.find_all())
            #for i in range(amount):
                #list_of_objects[i]= self.canvas.find_all()[i]
                ##print('list_of_objects:',list_of_objects)
                #coords_of_objects[i] = self.canvas.coords(list_of_objects[i])
                ##print('coords_of_objects:',coords_of_objects)
                #list_object_colors[i] = self.canvas.itemcget(list_of_objects[i],"tags")
                #list_object_colors[i] = re.split("_", list_object_colors[i].strip())
                #list_object_colors[i]= list_object_colors[i][-2]

            ##print('..............................')
            ##print('list_of_objects:',list_of_objects)
            ##print('coords_of_objects:',coords_of_objects)
            ##print('list_object_colors:',list_object_colors)
            ##print('..............................')

            ##------------------------------------------------------------------------

            #if sechenie_coords[0] is not None:

                #if x_0[0] is None or y_0[0] is None:
                    #for i in range(amount-1):
                        #x_0.append(None)
                        #x_1.append(None)
                        #y_0.append(None)
                        #y_1.append(None)
                        #min_shift_h.append(None)
                        #min_shift_v.append(None)
                        #shifted_rect.append(None)
                        #new_rect.append(None)
                        ##print(shifted_rect)

                ##------------------------------------------
                #intersection_h = False
                #intersection_v = False


                #for j in range(amount):
                    #if sechenie_coords[1]>coords_of_objects[j][1] and sechenie_coords[1]<coords_of_objects[j][3]:
                        #intersection_h = True

                    #if sechenie_coords[0]>coords_of_objects[j][0] and sechenie_coords[0]<coords_of_objects[j][2]:
                        #intersection_v = True


                ##-----------------get shift value (input param)-----------------

                #if self.delta_value is not None:
                    #if self.PCParametrizeFlag == True:
                        #self.PCParametrizeFlag = False
                    #elif self.PULSEYParametrizeFlag == True:
                        #self.PULSEYParametrizeFlag= False

                ##if (self.PCParametrizeFlag == False and self.PULSEYParametrizeFlag == False) and (self.delta_value is None) or (self.PC_count_flag == 0 and self.PULSEY_count_flag == 0):
                    ##window = CropParam(self.master)
                    ##self.delta_value = window.open()
                    ##self.delta_value *= self.Lambda


                #if intersection_h == True and self.delta_value is not None:
                    #shift_h = self.delta_value
                #else:
                    #shift_h = 0

                #if intersection_v == True and self.delta_value is not None:
                    #shift_v = self.delta_value
                #else:
                    #shift_v = 0
                #defended_chars_CO = ['2', '3', '7']
                #defended_chars_ME = ['4', '11']
                #for i in range(amount):
                    ##-------if we found 'CO' area then we skip this area--------------
                    #if self.foundry.get() == 'Microwind65':
                        #aimed_area_tags = self.canvas.itemcget(list_of_objects[i],"tags")
                        #aimed_area_tags = re.split("_", aimed_area_tags.strip())
                        #aimed_area_coords = self.canvas.coords(list_of_objects[i])
                        ##print(aimed_area_tags)
                        #if aimed_area_tags [0] == 'PC' and aimed_area_tags[-2] == 'CO' and aimed_area_coords[1] > obj_aimed_coords[1] and aimed_area_coords[3] < obj_aimed_coords[3]:# and aimed_area_tags[-1] not in defended_chars:
                            ##print('aga')
                            #continue
                        #elif aimed_area_tags [0] == 'PC' and aimed_area_tags[-2] == 'VI' and aimed_area_coords[1] > obj_aimed_coords[1] and aimed_area_coords[3] < obj_aimed_coords[3]:# and aimed_area_tags[-1] not in defended_chars:
                            ##print('aga')
                            #continue
                        #elif aimed_area_tags [0] == 'PC' and aimed_area_tags[-2] == 'ME' and aimed_area_coords[1] >= obj_aimed_coords[1] and aimed_area_coords[3] <= obj_aimed_coords[3] and aimed_area_tags[-1] in defended_chars_ME:# and aimed_area_tags[-1] not in defended_chars:
                            ##print('aga')
                            #continue

                    ##----------------------making the horizontal crop--------------
                    #if self.hor_flag.get() == 1:

                        #x_0[i] = coords_of_objects[i][0]
                        #x_1[i] = coords_of_objects[i][2]
                        #y_h = sechenie_coords[1]

                        #if y_h > coords_of_objects[i][1] and y_h < coords_of_objects[i][3]:
                            #min_shift_h[i] = -(coords_of_objects[i][1] - y_h)
                            #new_rect[i] = (x_0[i], y_h-min_shift_h[i]-shift_h , x_1[i], coords_of_objects[i][3])

                        #elif y_h > coords_of_objects[i][1] and y_h > coords_of_objects[i][3]:
                            #shifted_rect[i] = (x_0[i], coords_of_objects[i][1]-shift_h, x_1[i], coords_of_objects[i][3]-shift_h)

                    ##---------------------making the vertical crop-----------------
                    #if self.ver_flag.get() == 1:

                        #x_v = sechenie_coords[0]
                        #y_0[i] = coords_of_objects[i][1]
                        #y_1[i] = coords_of_objects[i][3]

                        #if x_v > coords_of_objects[i][0] and x_v < coords_of_objects[i][2]:
                            #min_shift_v[i] = coords_of_objects[i][2] - x_v
                            #new_rect[i] = (coords_of_objects[i][0], y_0[i], x_v + min_shift_v[i] + shift_v, y_1[i])

                        #elif x_v < coords_of_objects[i][0] and x_v < coords_of_objects[i][2]:
                            #shifted_rect[i] = (coords_of_objects[i][0]+shift_v, y_0[i], coords_of_objects[i][2]+shift_v, y_1[i])
                    ##----------------------------------------------------------------
                    #try:
                        ##for thing in self.canvas.find_all():
                        ##    print(self.canvas.gettags(thing)[0])
                        #for areatype in area_props[self.foundry.get()].keys():
                            #if list_object_colors[i] == areatype:
                                #block = self.canvas.itemcget(list_of_objects[i],"tags")
                                #block = re.split("_",block.strip())
                                #block_name = block[0]
                                #block_num = block[1]
                                #block_area_j = block[-1]
                                #use_color = area_props[self.foundry.get()][areatype]['border_color']
                                #filling = area_props[self.foundry.get()][areatype]['fill_color']
                                #border = area_props[self.foundry.get()][areatype]['border_dash']
                                #if new_rect[i] is not None:
                                    ##self.j_new[areatype] += 1
                                    #self.create_rec_with_mem(*new_rect[i], outline=use_color, fill = filling, dash = border, tags = f"{block_name}_{block_num}_{areatype}_{block_area_j}")
                                    ##-----------------------------------------------------------
                                    #if areatype == 'OP' and self.drag_flag.get() == 1:
                                        #rec_coord = new_rect[i]
                                        #for m in (0,2):
                                            #for n in (1,3):
                                                #self.canvas.create_oval(rec_coord[m]-r, rec_coord[n]-r, rec_coord[m]+r, rec_coord[n]+r, fill = '',activefill = 'black', outline = 'black', tags = 'corner'+f'{m}'+f'{n}'+'_'+f'{i}')
                                    ##-----------------------------------------------------------
                                #elif shifted_rect[i] is not None:
                                    ##self.j_shifted[areatype] += 1
                                    #self.create_rec_with_mem(*shifted_rect[i], outline=use_color, fill = filling, dash = border, tags = f"{block_name}_{block_num}_{areatype}_{block_area_j}")
                                    ##-----------------------------------------------------------
                                    #if areatype == 'OP' and self.drag_flag.get() == 1:
                                        #rec_coord = new_rect[i]
                                        #for m in (0,2):
                                            #for n in (1,3):
                                                #self.canvas.create_oval(rec_coord[m]-r, rec_coord[n]-r, rec_coord[m]+r, rec_coord[n]+r, fill = '',activefill = 'black', outline = 'black', tags = 'corner'+f'{m}'+f'{n}'+'_'+f'{i}')
                                    ##-----------------------------------------------------------
                                    #self.canvas.delete(list_of_objects[i])


                    #except: pass

                    #if self.hor_flag.get() == 1:
                        #if y_h > coords_of_objects[i][1] and y_h < coords_of_objects[i][3]:
                            #self.canvas.delete(list_of_objects[i])

                    #if self.ver_flag.get() == 1:
                        #if x_v > coords_of_objects[i][0] and x_v < coords_of_objects[i][2]:
                            #self.canvas.delete(list_of_objects[i])

                    ##print('--------------------')
                    ##print(list_of_objects)#, self.canvas.itemcget(list_of_objects[0], "tags"))
                    ##print('--------------------')
                    
                    #list_of_objects[i] = None
                    #coords_of_objects[i] = None
                    #list_object_colors[i] = None
                    #shifted_rect[i] = None
                    #new_rect[i] = None
                    #x_0[i] = None
                    #x_1[i] = None
                    #y_0[i] = None
                    #y_1[i] = None
                    #min_shift_h[i] = None
                    #min_shift_v[i] = None

                ##-------- удаляем сечение-------
                #line_item = self.canvas.find_withtag("Sechenie")
                #self.amount_of_line = 0
                #self.canvas.delete(line_item)
                ##--------------------------------

                ##for i in range(len(list_of_objects)-1):
                    ##list_of_objects.pop()
                    ##coords_of_objects.pop()
                    ##list_object_colors.pop()
                    ##shifted_rect.pop()
                    ##new_rect.pop()
                    ##x_0.pop()
                    ##x_1.pop()
                    ##y_0.pop()
                    ##y_1.pop()
                    ##min_shift_h.pop()
                    ##min_shift_v.pop()

                #for i in range(len(sechenie_coords)):
                    #sechenie_coords[i] = None

                ##--------------------------------------------------------------

            #self.hor_flag.set(0)
            #self.ver_flag.set(0)

# =============================================================================
# =============================================================================
#     def pc_param_crop(self, obj_aimed, obj_aimed_coords, obj_aimed_tag):
#         self.shapes_flag.set(0)
#         self.del_flag.set(0)
#         self.bound_flag.set(0)
#         self.GridUnits = self.GridLambda.get()
#
#         if self.GridUnits == 0:
#             messagebox.showerror("Error", "Choose foundry, please")
#             return
#
#         self.Lambda = self.GridUnits * self.scale ** self.wheel_count
#         r = self.Lambda / 2
#
#         # Удаление углов OP области
#         self.canvas.delete('corner')
#
#         # Получение информации об объектах
#         canvas_items = self.canvas.find_all()
#         amount = len(canvas_items) - self.amount_of_line
#
#         # Инициализация списков сразу с нужным размером
#         list_of_objects = [None] * amount
#         coords_of_objects = [None] * amount
#         list_object_colors = [None] * amount
#         shifted_rect = [None] * amount
#         new_rect = [None] * amount
#         x_0 = [None] * amount
#         x_1 = [None] * amount
#         y_0 = [None] * amount
#         y_1 = [None] * amount
#         min_shift_h = [None] * amount
#         min_shift_v = [None] * amount
#
#         # Заполнение списков данными
#         for i, item in enumerate(canvas_items[:amount]):
#             list_of_objects[i] = item
#             coords_of_objects[i] = self.canvas.coords(item)
#             tags = self.canvas.itemcget(item, "tags").strip()
#             list_object_colors[i] = tags.split("_")[-2]
#
#         # Проверка наличия сечения
#         if sechenie_coords[0] is None:
#             return
#
#         # Определение сдвига
#         shift_h = shift_v = 0
#         if self.delta_value is not None:
#             shift_h = self.delta_value if any(sechenie_coords[1] > y1 and sechenie_coords[1] < y3 for _, y1, _, y3 in coords_of_objects) else 0
#             shift_v = self.delta_value if any(sechenie_coords[0] > x0 and sechenie_coords[0] < x2 for x0, _, x2, _ in coords_of_objects) else 0
#
#         # Обработка объектов
#         defended_chars_CO = {'2', '3', '7'}
#         defended_chars_ME = {'4', '11'}
#         foundry = self.foundry.get()
#
#         for i in range(amount):
#             item = list_of_objects[i]
#             coords = coords_of_objects[i]
#             tags = self.canvas.itemcget(item, "tags").strip().split("_")
#
#             # Пропуск защищенных областей
#             if foundry == 'Microwind65' and tags[0] == 'PC' and (
#                     (tags[-2] == 'CO' and coords[1] > obj_aimed_coords[1] and coords[3] < obj_aimed_coords[3]) or
#                     (tags[-2] == 'VI' and coords[1] > obj_aimed_coords[1] and coords[3] < obj_aimed_coords[3]) or
#                     (tags[-2] == 'ME' and coords[1] >= obj_aimed_coords[1] and coords[3] <= obj_aimed_coords[3] and tags[-1] in defended_chars_ME)):
#                 continue
#
#             # Горизонтальный кроп
#             if self.hor_flag.get():
#                 x_0[i], _, x_1[i], y_3 = coords
#                 y_h = sechenie_coords[1]
#                 if y_h > coords[1] and y_h < y_3:
#                     min_shift_h[i] = -(coords[1] - y_h)
#                     new_rect[i] = (x_0[i], y_h - min_shift_h[i] - shift_h, x_1[i], y_3)
#                 elif y_h > coords[1] and y_h > y_3:
#                     shifted_rect[i] = (x_0[i], coords[1] - shift_h, x_1[i], y_3 - shift_h)
#
#             # Вертикальный кроп
#             if self.ver_flag.get():
#                 x_v = sechenie_coords[0]
#                 _, y_0[i], x_2, y_1[i] = coords
#                 if x_v > coords[0] and x_v < x_2:
#                     min_shift_v[i] = x_2 - x_v
#                     new_rect[i] = (coords[0], y_0[i], x_v + min_shift_v[i] + shift_v, y_1[i])
#                 elif x_v < coords[0] and x_v < x_2:
#                     shifted_rect[i] = (coords[0] + shift_v, y_0[i], x_2 + shift_v, y_1[i])
#
#             # Создание новых объектов и удаление старых
#             try:
#                 areatype = list_object_colors[i]
#                 props = area_props[foundry][areatype]
#                 if new_rect[i]:
#                     self.create_rec_with_mem(*new_rect[i], outline=props['border_color'], fill=props['fill_color'], dash=props['border_dash'], tags=f"{tags[0]}_{tags[1]}_{areatype}_{tags[-1]}")
#                     if areatype == 'OP' and self.drag_flag.get():
#                         self._add_corners(new_rect[i], r)
#                 elif shifted_rect[i]:
#                     self.create_rec_with_mem(*shifted_rect[i], outline=props['border_color'], fill=props['fill_color'], dash=props['border_dash'], tags=f"{tags[0]}_{tags[1]}_{areatype}_{tags[-1]}")
#                     self.canvas.delete(item)
#             except KeyError:
#                 pass
#
#         # Удаление сечения
#         self.canvas.delete("Sechenie")
#         self.amount_of_line = 0
#
#         # Сброс флагов
#         self.hor_flag.set(0)
#         self.ver_flag.set(0)
#
#     def _add_corners(self, rect, r):
#         """Добавляет углы к области."""
#         for m in (0, 2):
#             for n in (1, 3):
#                 self.canvas.create_oval(rect[m] - r, rect[n] - r, rect[m] + r, rect[n] + r, fill='', activefill='black', outline='black', tags=f'corner_{m}_{n}')
# =============================================================================
    
    def pc_param_crop(self, obj_aimed, obj_aimed_coords, obj_aimed_tag):
        
        # Проверка GridUnits
        self.GridUnits = self.GridLambda.get()
        if self.GridUnits == 0:
            messagebox.showerror("Error", "Choose foundry, please")
            return

        # Инициализация основных параметров
        self.Lambda = self.GridUnits * self.scale**self.wheel_count
        r = self.Lambda/2

        # Сброс флагов
        self.shapes_flag.set(0)
        self.del_flag.set(0)
        self.bound_flag.set(0)

        # Удаление угловых точек
        self.canvas.delete(*[item for item in self.canvas.find_all()
                             if self.canvas.gettags(item)[0].startswith('corner')])

        # Получение информации об областях
        all_items = self.canvas.find_all()
        amount = len(all_items) - self.amount_of_line

        # Создание списков с предварительно выделенной памятью
        objects_data = []
        for i in range(amount):
            item = all_items[i]            
            tags = self.canvas.itemcget(item, "tags")
            if tags != 'Sechenie':
                coords = self.canvas.coords(item)
                color = re.split("_", tags.strip())[-2]
                objects_data.append((item, coords, color))

        #print('objects_data:', objects_data)
        #self.after(500)
        if sechenie_coords[1] is not None:
            # Проверка горизонтального пересечения
            intersection_h = any(sechenie_coords[1] > data[1][1] and sechenie_coords[1] < data[1][3] for data in objects_data)            

            # Получение значения сдвига по вертикали
            shift_h = self.delta_value if intersection_h and self.delta_value is not None else 0            
            
            y_h = sechenie_coords[1]

            # Обработка каждого объекта
            for item, coords, color in objects_data:
                tags = self.canvas.itemcget(item, "tags").split("_")

                # Пропуск областей CO для Microwind65
                if (self.foundry.get() == 'Microwind65' and
                    tags[0] == 'PC' and tags[-2] == 'CO' and
                    coords[0] > obj_aimed_coords[0] and coords[2] < obj_aimed_coords[2]):
                    continue
                    
                # Расчет новых координат горизонтального сечения
                if y_h > coords[1] and y_h < coords[3]:
                    min_shift_h = coords[3] - y_h
                    new_rect = (coords[0], coords[1], coords[2], y_h + min_shift_h + shift_h)
                    self._create_area(new_rect, tags, color, r)
                    self.canvas.delete(item)
                elif y_h < coords[1] and y_h < coords[3]:
                    shifted_rect = (coords[0], coords[1] + shift_h, coords[2], coords[3] + shift_h)
                    self._create_area(shifted_rect, tags, color, r)
                    self.canvas.delete(item)                

            # Очистка сечения
            self.canvas.delete("Sechenie")
            self.amount_of_line = 0
            sechenie_coords[:] = [None] * len(sechenie_coords)

    def crop(self):
        """func defined below only crop given fragment"""
        # формируем новые списки для объектов
        list_of_objects = [None]
        coords_of_objects = [None]
        list_object_colors = [None]
        shifted_rect = [None]
        new_rect = [None]
        x_0 = [None]
        x_1 = [None]
        y_0 = [None]
        y_1 = [None]
        min_shift_h = [None]
        min_shift_v = [None]
        # --------------------------------
        self.shapes_flag.set(0)
        self.del_flag.set(0)
        self.bound_flag.set(0)
        # self.GridUnits = self.form.get_tech()
        self.GridUnits = self.GridLambda.get()
        if self.GridUnits == 0:
            messagebox.showerror("Error", "Choose foundry, please")
        else:
            self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
            r = self.Lambda/2
            # deleting corners of OP area
            for item in self.canvas.find_all():
                # print(item)
                if self.canvas.gettags(item)[0][:6] == 'corner':
                    self.canvas.delete(item)
            # получаем информацию обо всех областях на холсте
            amount = len(self.canvas.find_all())-self.amount_of_line
            if list_of_objects[0] is None or coords_of_objects[0] is None or list_object_colors[0] is None:
                for i in range(amount-1):
                    list_of_objects.append(None)
                    coords_of_objects.append(None)
                    list_object_colors.append(None)
            # print("num_of_all:", self.canvas.find_all())
            for i in range(amount):
                list_of_objects[i] = self.canvas.find_all()[i]
                # print('list_of_objects:',list_of_objects)
                coords_of_objects[i] = self.canvas.coords(list_of_objects[i])
                # print('coords_of_objects:',coords_of_objects)
                list_object_colors[i] = self.canvas.itemcget(
                    list_of_objects[i], "tags")
                list_object_colors[i] = re.split(
                    "_", list_object_colors[i].strip())
                list_object_colors[i] = list_object_colors[i][-2]

            # print('..............................')
            # print('list_of_objects:',list_of_objects)
            # print('coords_of_objects:',coords_of_objects)
            # print('list_object_colors:',list_object_colors)
            # print('..............................')

            # ------------------------------------------------------------------------

            if sechenie_coords[0] is not None:

                if x_0[0] is None or y_0[0] is None:
                    for i in range(amount-1):
                        x_0.append(None)
                        x_1.append(None)
                        y_0.append(None)
                        y_1.append(None)
                        min_shift_h.append(None)
                        min_shift_v.append(None)
                        shifted_rect.append(None)
                        new_rect.append(None)
                        # print(shifted_rect)

                # ------------------------------------------
                intersection_h = False
                intersection_v = False

                for j in range(amount):
                    if sechenie_coords[1] > coords_of_objects[j][1] and sechenie_coords[1] < coords_of_objects[j][3]:
                        intersection_h = True

                    if sechenie_coords[0] > coords_of_objects[j][0] and sechenie_coords[0] < coords_of_objects[j][2]:
                        intersection_v = True

                # -----------------get shift value (input param)-----------------

                if self.delta_value is not None:
                    if self.PCParametrizeFlag == True:
                        self.PCParametrizeFlag = False
                    elif self.PULSEYParametrizeFlag == True:
                        self.PULSEYParametrizeFlag = False

                if (self.PCParametrizeFlag == False and self.PULSEYParametrizeFlag == False) and (self.delta_value is None) or (self.PC_count_flag == 0 and self.PULSEY_count_flag == 0):
                    window = CropParam(self.master)
                    window.wm_attributes('-topmost', True)
                    window.resizable(False, False)
                    window.title('TopoPlot: Crop parameters defining')
                    self.delta_value = window.open()
                    self.delta_value *= self.Lambda

                if intersection_h == True and self.delta_value is not None:
                    shift_h = self.delta_value
                else:
                    shift_h = 0

                if intersection_v == True and self.delta_value is not None:
                    shift_v = self.delta_value
                else:
                    shift_v = 0

                for i in range(amount):

                    # ----------------------making the horizontal crop--------------
                    if self.hor_flag.get() == 1:

                        x_0[i] = coords_of_objects[i][0]
                        x_1[i] = coords_of_objects[i][2]
                        y_h = sechenie_coords[1]

                        if y_h > coords_of_objects[i][1] and y_h < coords_of_objects[i][3]:
                            min_shift_h[i] = -(coords_of_objects[i][1] - y_h)
                            new_rect[i] = (
                                x_0[i], y_h-min_shift_h[i]-shift_h, x_1[i], coords_of_objects[i][3])

                        elif y_h > coords_of_objects[i][1] and y_h > coords_of_objects[i][3]:
                            shifted_rect[i] = (
                                x_0[i], coords_of_objects[i][1]-shift_h, x_1[i], coords_of_objects[i][3]-shift_h)

                    # ---------------------making the vertical crop-----------------
                    if self.ver_flag.get() == 1:

                        x_v = sechenie_coords[0]
                        y_0[i] = coords_of_objects[i][1]
                        y_1[i] = coords_of_objects[i][3]

                        if x_v > coords_of_objects[i][0] and x_v < coords_of_objects[i][2]:
                            min_shift_v[i] = coords_of_objects[i][2] - x_v
                            new_rect[i] = (
                                coords_of_objects[i][0], y_0[i], x_v + min_shift_v[i] + shift_v, y_1[i])

                        elif x_v < coords_of_objects[i][0] and x_v < coords_of_objects[i][2]:
                            shifted_rect[i] = (
                                coords_of_objects[i][0]+shift_v, y_0[i], coords_of_objects[i][2]+shift_v, y_1[i])
                    # ----------------------------------------------------------------
                    try:
                        # for thing in self.canvas.find_all():
                        #    print(self.canvas.gettags(thing)[0])
                        for areatype in area_props[self.foundry.get()].keys():
                            if list_object_colors[i] == areatype:
                                block = self.canvas.itemcget(
                                    list_of_objects[i], "tags")
                                block = re.split("_", block.strip())
                                block_name = block[0]
                                block_num = block[1]
                                block_area_j = block[-1]
                                use_color = area_props[self.foundry.get(
                                )][areatype]['border_color']
                                filling = area_props[self.foundry.get(
                                )][areatype]['fill_color']
                                border = area_props[self.foundry.get(
                                )][areatype]['border_dash']
                                if new_rect[i] is not None:
                                    # self.j_new[areatype] += 1
                                    self.create_rec_with_mem(*new_rect[i], outline=use_color, fill=filling, dash=border, tags=f"{block_name}_{block_num}_{areatype}_{block_area_j}")
                                    # -----------------------------------------------------------
                                    if areatype == 'OP' and self.drag_flag.get() == 1:
                                        rec_coord = new_rect[i]
                                        for m in (0, 2):
                                            for n in (1, 3):
                                                self.canvas.create_oval(rec_coord[m]-r, rec_coord[n]-r, rec_coord[m]+r, rec_coord[n]+r, fill='', activefill='black', outline= 'black', tags = 'corner'+f'{m}'+f'{n}'+'_'+f'{i}')
                                    # -----------------------------------------------------------
                                elif shifted_rect[i] is not None:
                                    # self.j_shifted[areatype] += 1
                                    self.create_rec_with_mem(*shifted_rect[i], outline=use_color, fill=filling, dash=border, tags=f"{block_name}_{block_num}_{areatype}_{block_area_j}")
                                    # -----------------------------------------------------------
                                    if areatype == 'OP' and self.drag_flag.get() == 1:
                                        rec_coord = new_rect[i]
                                        for m in (0, 2):
                                            for n in (1, 3):
                                                self.canvas.create_oval(rec_coord[m]-r, rec_coord[n]-r, rec_coord[m]+r, rec_coord[n]+r, fill='', activefill='black', outline= 'black', tags = 'corner'+f'{m}'+f'{n}'+'_'+f'{i}')
                                    # -----------------------------------------------------------
                                    self.canvas.delete(list_of_objects[i])

                    except:
                        pass

                    if self.hor_flag.get() == 1:
                        if y_h > coords_of_objects[i][1] and y_h < coords_of_objects[i][3]:
                            self.canvas.delete(list_of_objects[i])

                    if self.ver_flag.get() == 1:
                        if x_v > coords_of_objects[i][0] and x_v < coords_of_objects[i][2]:
                            self.canvas.delete(list_of_objects[i])

                    list_of_objects[i] = None
                    coords_of_objects[i] = None
                    list_object_colors[i] = None
                    shifted_rect[i] = None
                    new_rect[i] = None
                    x_0[i] = None
                    x_1[i] = None
                    y_0[i] = None
                    y_1[i] = None
                    min_shift_h[i] = None
                    min_shift_v[i] = None

                # -------- удаляем сечение-------
                line_item = self.canvas.find_withtag("Sechenie")
                self.amount_of_line = 0
                self.canvas.delete(line_item)
                # --------------------------------

                # формируем новые списки для объектов
                # for i in range(len(list_of_objects)-1):
                # list_of_objects.pop()
                # coords_of_objects.pop()
                # list_object_colors.pop()
                # shifted_rect.pop()
                # new_rect.pop()
                # x_0.pop()
                # x_1.pop()
                # y_0.pop()
                # y_1.pop()
                # min_shift_h.pop()
                # min_shift_v.pop()

                for i in range(len(sechenie_coords)):
                    sechenie_coords[i] = None

                # --------------------------------------------------------------

            self.hor_flag.set(0)
            self.ver_flag.set(0)

    '''
    def getDragPoints(self,event):
        print(self.push_k)
        if self.drag_flag.get() == 1:
            item = self.canvas.find_withtag(tk.CURRENT)
            tag = self.canvas.gettags(item)[0]
            self.full_view()
            coord = self.canvas.bbox(item)
            coords = self.canvas.coords(item)
            family_tag = self.canvas.gettags(item)[0][9:]
            family_coord = [0,0,0,0]
            #print("tag of object:", tag)
            print("bbox of object:", coord)
            print("coords of object:", coords)
            print("family tag:", family_tag)
            i=0

            if self.push_k < 2:
                for item in self.canvas.find_all():
                    if self.canvas.gettags(item)[0][9:] == family_tag and self.canvas.gettags(item)[0][:6] == 'corner':
                        family_coord[i] = list(self.canvas.bbox(item))
                        i+=1
                self.contact_blocks[self.push_k] = family_coord
                self.push_k+=1
                print(self.contact_blocks)

            if self.push_k == 2:
                self.push_k = 0

                # determine centers of corners for each blocks
                self.GridUnits = self.form.get_tech()
                self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
                r = self.Lambda/2
                for i in range(2):
                    for j in range(4):
                        for l in range(4):
                            if l >= 2:
                                self.contact_blocks[i][j][l] = self.contact_blocks[i][j][l] - r
                            else:
                                self.contact_blocks[i][j][l] = self.contact_blocks[i][j][l] + r

                print('corners centers:', self.contact_blocks)
                #--------------------------------------------
                #
                self.contact_blocks = [None, None]
                pass


        else:
            pass
    '''

    def delete_item(self, event):
        if self.del_flag.get() == 1:
            item = self.canvas.find_withtag(tk.CURRENT)
            if self.canvas.gettags(item)[0] == "Sechenie":
                self.amount_of_line -= 1
                for i in range(len(sechenie_coords)):
                    sechenie_coords[i] = None
            self.delete_from_mem(item)
            # self.canvas.delete(item)

    def cw_rot(self):
        self.bound_coords = self.canvas.coords('bound_rect')
        self.canvas.delete('bound_rect')
        self.bound_flag.set(0)
        for item in self.canvas.find_all():
            fig = re.split("_", self.canvas.gettags(item)[0].strip())
            # print(fig)
            if len(fig) >= 4:
                if fig[2] == 'OP':
                    op_item = item
        try:
            self.op_coords = self.canvas.coords(op_item)
        except:
            self.op_coords = self.bound_coords

        x_median = (self.bound_coords[0]+self.bound_coords[2])/2
        y_median = (self.bound_coords[1]+self.bound_coords[3])/2

        for item in self.canvas.find_all():
            old_coords = self.canvas.coords(item)
            k = 0
            for i in range(2):
                if old_coords[i] >= self.bound_coords[i] and old_coords[i+2] <= self.bound_coords[i+2]:
                    k += 1
            if k == 2:
                new_coords = self.rotate_shape(
                    old_coords, x_median, y_median, -pi/2)
                # new_coords = (old_coords[0], y_median+(y_median-old_coords[1]), old_coords[2], y_median+(y_median-old_coords[3]))
                self.canvas.coords(item, *new_coords)

    def ccw_rot(self):
        self.bound_coords = self.canvas.coords('bound_rect')
        self.canvas.delete('bound_rect')
        self.bound_flag.set(0)
        for item in self.canvas.find_all():
            fig = re.split("_", self.canvas.gettags(item)[0].strip())
            # print(fig)
            if len(fig) >= 4:
                if fig[2] == 'OP':
                    op_item = item
        try:
            self.op_coords = self.canvas.coords(op_item)
        except:
            self.op_coords = self.bound_coords

        x_median = (self.bound_coords[0]+self.bound_coords[2])/2
        y_median = (self.bound_coords[1]+self.bound_coords[3])/2

        for item in self.canvas.find_all():
            old_coords = self.canvas.coords(item)
            k = 0
            for i in range(2):
                if old_coords[i] >= self.bound_coords[i] and old_coords[i+2] <= self.bound_coords[i+2]:
                    k += 1
            if k == 2:
                new_coords = self.rotate_shape(
                    old_coords, x_median, y_median, pi/2)
                # new_coords = (old_coords[0], y_median+(y_median-old_coords[1]), old_coords[2], y_median+(y_median-old_coords[3]))
                self.canvas.coords(item, *new_coords)

    def hor_flip(self):
        self.bound_coords = self.canvas.coords('bound_rect')
        self.canvas.delete('bound_rect')
        self.bound_flag.set(0)
        for item in self.canvas.find_all():
            fig = re.split("_", self.canvas.gettags(item)[0].strip())
            # print(fig)
            if len(fig) >= 4:
                if fig[2] == 'OP':
                    op_item = item
        try:
            self.op_coords = self.canvas.coords(op_item)
        except:
            self.op_coords = self.bound_coords
        y_median = (self.op_coords[1]+self.op_coords[3])/2
        for item in self.canvas.find_all():
            old_coords = self.canvas.coords(item)
            k = 0
            for i in range(2):
                if old_coords[i] >= self.bound_coords[i] and old_coords[i+2] <= self.bound_coords[i+2]:
                    k += 1
            if k == 2:
                new_coords = (old_coords[0], y_median+(y_median-old_coords[1]),
                              old_coords[2], y_median+(y_median-old_coords[3]))
                self.canvas.coords(item, *new_coords)

    def ver_flip(self):
        self.bound_coords = self.canvas.coords('bound_rect')
        self.canvas.delete('bound_rect')
        self.bound_flag.set(0)
        for item in self.canvas.find_all():
            fig = re.split("_", self.canvas.gettags(item)[0].strip())
            if len(fig) >= 4:
                if fig[2] == 'OP':
                    op_item = item
        try:
            self.op_coords = self.canvas.coords(op_item)
        except:
            self.op_coords = self.bound_coords
        x_median = (self.op_coords[0]+self.op_coords[2])/2
        for item in self.canvas.find_all():
            old_coords = self.canvas.coords(item)
            k = 0
            for i in range(2):
                if old_coords[i] >= self.bound_coords[i] and old_coords[i+2] <= self.bound_coords[i+2]:
                    k += 1
            if k == 2:
                new_coords = (x_median+(x_median-old_coords[0]), old_coords[1], x_median+(
                    x_median-old_coords[2]), old_coords[3])
                self.canvas.coords(item, *new_coords)

    def bound_del(self):
        self.drag_flag.set(0)
        self.bound_coords = self.canvas.coords('bound_rect')
        for item in self.canvas.find_all():
            old_coords = self.canvas.coords(item)
            k = 0
            for i in range(2):
                if old_coords[i] >= self.bound_coords[i] and old_coords[i+2] <= self.bound_coords[i+2]:
                    if self.canvas.gettags(item)[0] == 'Sechenie':
                        self.amount_of_line -= 1
                        for i in range(len(sechenie_coords)):
                            sechenie_coords[i] = None
                    k += 1
            if k == 2:
                self.canvas.delete(item)

    def button_press(self, event):
        if self.bound_flag.get() != 1:
            item = self.canvas.find_withtag(tk.CURRENT)
            self.dnd_item = (item, event.x, event.y)
            # ----------------------------------------
            self.press_flag = True
            rec_coords = tuple(self.canvas.coords(item))
            rec_outline = self.canvas.itemcget(item, "outline")
            rec_fill = self.canvas.itemcget(item, "fill")
            rec_dash = self.canvas.itemcget(item, "dash")
            rec_tag = self.canvas.itemcget(item, "tags")[:-8]
            item_params = (rec_coords, rec_outline,
                           rec_fill, rec_dash, rec_tag)
            self.insert_to_mem(item_params)
            # ----------------------------------------
        else:
            self.dnd_coords = (event.x, event.y)
            self.items_for_move = []
            # ----------------------------------------
            self.bound_coords = self.canvas.coords('bound_rect')
            for item in self.canvas.find_all():
                old_coords = self.canvas.coords(item)
                k = 0
                for i in range(2):
                    if old_coords[i] >= self.bound_coords[i] and old_coords[i+2] <= self.bound_coords[i+2]:
                        k += 1
                if k == 2:
                    self.items_for_move.append(item)

    def button_release(self, event):
        if self.bound_flag.get() != 1:
            item = self.canvas.find_withtag(tk.CURRENT)
            self.dnd_item = (item, event.x, event.y)
            # ----------------------------------------
            if self.motion_flag:
                rec_coords = tuple(self.canvas.coords(item))
                rec_outline = self.canvas.itemcget(item, "outline")
                rec_fill = self.canvas.itemcget(item, "fill")
                rec_dash = self.canvas.itemcget(item, "dash")
                rec_tag = self.canvas.itemcget(item, "tags")[:-8]
                item_params = (rec_coords, rec_outline,
                               rec_fill, rec_dash, rec_tag)
                self.insert_to_mem(item_params)
            self.motion_flag = False
            self.press_flag = False
            # ----------------------------------------
        else:
            self.dnd_coords = (event.x, event.y)
        self.bound_flag.set(0)
        self.canvas.delete('bound_rect')

    def button_motion(self, event):
        # self.GridUnits = self.form.get_tech()
        self.GridUnits = self.GridLambda.get()
        if self.GridUnits == 0:
            messagebox.showerror("Error", "Choose foundry, please")
        else:
            self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
            x, y = event.x, event.y
            moving = {'X': {'F': 1, 'B': -1}, 'Y': {'F': 1, 'B': -1}}
            if self.bound_flag.get() == 1:
                x0, y0 = self.dnd_coords
                if abs(x - x0) >= self.Lambda or abs(y - y0) >= self.Lambda:
                    for item in self.items_for_move:
                        if abs(x - x0) > abs(y - y0):
                            axis = 'X'
                            ax, ay = 1, 0
                            if (x - x0) > 0:
                                direct = 'F'
                            elif (x - x0) < 0:
                                direct = 'B'
                        elif abs(x - x0) < abs(y - y0):
                            axis = 'Y'
                            ax, ay = 0, 1
                            if (y - y0) > 0:
                                direct = 'F'
                            elif (y - y0) < 0:
                                direct = 'B'
                        self.canvas.move(
                            item, ax * (moving[axis][direct] * self.Lambda), ay * (moving[axis][direct] * self.Lambda))
                        # x = x0 + ax * moving[axis][direct] * self.Lambda
                        # y = y0 + ay * moving[axis][direct] * self.Lambda
                    self.dnd_coords = (x, y)
            else:
                item, x0, y0 = self.dnd_item
                if abs(x - x0) >= self.Lambda or abs(y - y0) >= self.Lambda:
                    if abs(x - x0) > abs(y - y0):
                        axis = 'X'
                        ax, ay = 1, 0
                        if (x - x0) > 0:
                            direct = 'F'
                        elif (x - x0) < 0:
                            direct = 'B'
                    elif abs(x - x0) < abs(y - y0):
                        axis = 'Y'
                        ax, ay = 0, 1
                        if (y - y0) > 0:
                            direct = 'F'
                        elif (y - y0) < 0:
                            direct = 'B'
                    self.canvas.move(
                        item, ax * (moving[axis][direct] * self.Lambda), ay * (moving[axis][direct] * self.Lambda))
                    # x = x0 + ax * moving[axis][direct] * self.Lambda
                    # y = y0 + ay * moving[axis][direct] * self.Lambda
                    self.dnd_item = (item, x, y)
                    # -----------------------
                    self.motion_flag = True
                    # -----------------------

    def dragMove(self, event):
        self.drag_process += 1
        try:
            item = self.canvas.find_withtag(tk.CURRENT)
            item_tag = re.split("_", self.canvas.gettags(item)[0].strip())
            if item_tag[0] == 'corner':
                corner_coords = self.canvas.coords(item)
                if self.drag_process == 1:
                    self.point_1 = [
                        (corner_coords[0]+corner_coords[2])/2, (corner_coords[1]+corner_coords[3])/2]

                    for thing in self.canvas.find_all():
                        thing_tag = self.canvas.gettags(thing)[0]
                        thing_coords = self.canvas.coords(thing)
                        thing_tag_splitted = re.split(
                            "_", self.canvas.gettags(thing_tag)[0].strip())
                        for liter in thing_tag_splitted:
                            if liter == 'OP' and (self.point_1[0] == thing_coords[0] or self.point_1[0] == thing_coords[2]) and (self.point_1[1] == thing_coords[1] or self.point_1[1] == thing_coords[3]):
                                self.block_item = thing_tag

                elif self.drag_process == 2:
                    self.point_2 = [
                        (corner_coords[0]+corner_coords[2])/2, (corner_coords[1]+corner_coords[3])/2]

                    delx = self.point_2[0]-self.point_1[0]
                    dely = self.point_2[1]-self.point_1[1]

                    block = self.canvas.find_withtag(self.block_item)
                    block_coords = self.canvas.coords(block)

                    for fig in self.canvas.find_all():
                        fig_coords = self.canvas.coords(fig)
                        if int(fig_coords[0]) >= int(block_coords[0]) and int(fig_coords[1]) >= int(block_coords[1]) and int(fig_coords[2]) <= int(block_coords[2]) and int(fig_coords[3]) <= int(block_coords[3]):
                            self.canvas.move(fig, delx, dely)

                    self.drag_process = 0
        except:
            self.drag_process = 0
            self.drag_flag.set(0)
            for item in self.canvas.find_all():
                item_tag = re.split("_", self.canvas.gettags(item)[0].strip())
                if item_tag[0][:6] == 'corner':
                    self.canvas.delete(item)
            pass

    def drag_on(self):
        # self.GridUnits = self.form.get_tech()
        self.GridUnits = self.GridLambda.get()
        if self.GridUnits == 0:
            messagebox.showerror("Error", "Choose foundry, please")
        else:
            self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
            r = self.Lambda/2
            k = 0
            for item in self.canvas.find_all():
                if self.drag_flag.get() == 1:
                    k += 1
                    corner_thing = re.split(
                        "_", self.canvas.gettags(item)[0].strip())
                    try:
                        corner_thing = corner_thing[2]
                    except:
                        corner_thing = corner_thing[0]
                    if corner_thing == 'OP':
                        op_coords = self.canvas.coords(item)
                        for m in (0, 2):
                            for n in (1, 3):
                                self.canvas.create_oval(op_coords[m]-r, op_coords[n]-r, op_coords[m]+r, op_coords[n]+r, fill='', activefill='black', outline= 'black', tags = 'corner'+'_'+f'{m//2}'+f'{n//3}'+'_'+f'{k}')
                elif self.drag_flag.get() == 0 and self.canvas.gettags(item)[0][:6] == 'corner':
                    self.canvas.delete(item)

    def MUX(self, event):
        # print(self.insertAccess, self.multiplyAccess, self.synthesisAcces, self.y_decoder_access, self.x_decoder_access, self.x_connect_access, self.mult_access)
        if self.insertAccess == 1 and self.multiplyAccess == 0 and self.synthesisAcces == 0 and self.y_decoder_access == 0 and self.x_decoder_access == 0 and self.x_connect_access == 0 and self.mult_access == 0:
            self.let_insert(event)
        elif self.insertAccess == 0 and self.multiplyAccess == 1 and self.synthesisAcces == 0 and self.y_decoder_access == 0 and self.x_decoder_access == 0 and self.x_connect_access == 0 and self.mult_access == 0:
            self.multiply(event)
        elif self.insertAccess == 0 and self.multiplyAccess == 0 and self.synthesisAcces == 1 and self.y_decoder_access == 0 and self.x_decoder_access == 0 and self.x_connect_access == 0 and self.mult_access == 0:
            if self.foundry.get() == 'Microwind65':
                self.synthesis_MW(event)
            elif self.foundry.get() == 'SkyWater130':
                self.synthesis_SW(event)
        elif self.insertAccess == 0 and self.multiplyAccess == 0 and self.synthesisAcces == 0 and self.y_decoder_access == 1 and self.x_decoder_access == 0 and self.x_connect_access == 0 and self.mult_access == 0:
            if self.DC_mode == 'by blocks':
                self.Y_DC_Syn(event)
            elif self.DC_mode == 'by matrix':
                self.MatrixNAND_DC(event, 'Y')
        elif self.insertAccess == 0 and self.multiplyAccess == 0 and self.synthesisAcces == 0 and self.y_decoder_access == 0 and self.x_decoder_access == 1 and self.x_connect_access == 0 and self.mult_access == 0:
            if self.DC_mode == 'by blocks':
                self.X_DC_Syn(event)
            elif self.DC_mode == 'by matrix':
                self.MatrixNAND_DC(event, 'X')
        elif self.insertAccess == 0 and self.multiplyAccess == 0 and self.synthesisAcces == 0 and self.y_decoder_access == 0 and self.x_decoder_access == 0 and self.x_connect_access == 1 and self.mult_access == 0:
            if self.foundry.get() == 'Microwind65':
                self.X_Connect_MW(event)
            elif self.foundry.get() == 'SkyWater130':
                self.X_Connect_SW(event)
        elif self.insertAccess == 0 and self.multiplyAccess == 0 and self.synthesisAcces == 0 and self.y_decoder_access == 0 and self.x_decoder_access == 0 and self.x_connect_access == 0 and self.mult_access == 1:
            self.MultSyn(event)

        if self.bound_flag.get() == 1:  # and self.del_flag.get() != 1:
            self.draw(event)
        elif self.bound_flag.get() == 0:
            self.canvas.delete('bound_rect')

        if self.hor_flag.get() == 1 and self.del_flag.get() != 1:
            self.del_flag.set(0)
            self.shapes_flag.set(0)
            self.ver_flag.set(0)
            self.bound_flag.set(0)
            self.labeling_flag.set(0)
            self.draw(event)

        if self.ver_flag.get() == 1 and self.del_flag.get() != 1:
            self.del_flag.set(0)
            self.shapes_flag.set(0)
            self.hor_flag.set(0)
            self.bound_flag.set(0)
            self.labeling_flag.set(0)
            self.draw(event)

        if self.shapes_flag.get() == 1 and self.del_flag.get() != 1:
            self.del_flag.set(0)
            self.ver_flag.set(0)
            self.hor_flag.set(0)
            self.bound_flag.set(0)
            self.labeling_flag.set(0)
            self.draw(event)

        if self.del_flag.get() == 1:
            self.shapes_flag.set(0)
            self.hor_flag.set(0)
            self.ver_flag.set(0)
            self.bound_flag.set(0)
            self.labeling_flag.set(0)
            self.delete_item(event)

        if self.nmos_flag.get() == 1:
            self.shapes_flag.set(0)
            self.hor_flag.set(0)
            self.ver_flag.set(0)
            self.bound_flag.set(0)
            self.del_flag.set(0)
            self.pmos_flag.set(0)
            self.labeling_flag.set(0)
            self.create_mos(event)

        if self.pmos_flag.get() == 1:
            self.shapes_flag.set(0)
            self.hor_flag.set(0)
            self.ver_flag.set(0)
            self.bound_flag.set(0)
            self.del_flag.set(0)
            self.nmos_flag.set(0)
            self.create_mos(event)
            self.labeling_flag.set(0)

        if self.labeling_flag.get() == 1:
            self.shapes_flag.set(0)
            self.hor_flag.set(0)
            self.ver_flag.set(0)
            self.bound_flag.set(0)
            self.del_flag.set(0)
            self.nmos_flag.set(0)
            self.pmos_flag.set(0)
            self.draw(event)
        

    def bound_acces(self):
        if self.bound_flag.get() == 1:
            self.del_flag.set(0)
            self.shapes_flag.set(0)
            self.ver_flag.set(0)
            self.hor_flag.set(0)
            # self.canvas.bind("<Button-1>", self.draw)
        elif self.bound_flag.get() == 0:
            self.canvas.delete('bound_rect')
            # self.bound_flag.set(0)
            # self.items_for_move = []

    def draw(self, event):
        # self.GridUnits = self.form.get_tech()
        self.GridUnits = self.GridLambda.get()
        if self.GridUnits == 0:
            messagebox.showerror("Error", "Choose foundry, please")
        else:
            self.Lambda = (self.GridUnits)*self.scale**self.wheel_count
            if str(event.num) == "1" and (self.shapes_flag.get() == 1 or self.bound_flag.get() == 1):
                x, y = self.canvas.canvasx(event.x), self.canvas.canvasy(event.y)
                if not self.line_start:
                    self.line_start = (x, y)
                else:
                    x_origin, y_origin = self.line_start
                    self.line_start = None
                    nx = (x - x_origin) // self.Lambda
                    ny = (y - y_origin) // self.Lambda
                    rect = (x_origin, y_origin, x_origin + nx * self.Lambda, y_origin + ny * self.Lambda)
                    if self.shapes_flag.get() == 1:
                        # area = self.form.get_area()
                        area = self.layers_window_get_area()
                        # print(f'area:{area}')
                        color = area_props[self.foundry.get()
                                           ][area]['border_color']
                        filling = area_props[self.foundry.get(
                        )][area]['fill_color']
                        bordertype = area_props[self.foundry.get(
                        )][area]['border_dash']
                        rec_tag = f"{area}_{self.j[self.foundry.get()][area]}"
                        self.j[self.foundry.get()][area] += 1
                        self.create_rec_with_mem(*rect, outline=color, fill=filling, dash=bordertype, tags=rec_tag)

                        # ------------------------------
                        # self.insert_to_mem((rect,color,filling,bordertype,rec_tag))#needn't to use if used ()
                        # ------------------------------

                    elif self.bound_flag.get() == 1:
                        self.create_rec_with_mem(*rect, outline='black', fill='', dash='-', tags='bound_rect')

            elif str(event.num) == "1" and self.shapes_flag.get() != 1 and self.bound_flag.get() != 1:
                x, y = self.canvas.canvasx(
                    event.x), self.canvas.canvasy(event.y)
                if not self.line_start:
                    self.line_start = (x, y)
                else:
                    x_origin, y_origin = self.line_start
                    self.line_start = None

                    line = [None for i in range(4)]
                    color = 'black'
                    width = 1  # self.form.get_width()

                    if self.hor_flag.get() == 1:
                        line = (x_origin, y_origin, x, y_origin)
                        sechenie_coords[0] = x_origin
                        sechenie_coords[1] = y_origin
                        sechenie_coords[2] = x
                        sechenie_coords[3] = y_origin
                    elif self.ver_flag.get() == 1:
                        line = (x_origin, y_origin, x_origin, y)
                        sechenie_coords[0] = x_origin
                        sechenie_coords[1] = y_origin
                        sechenie_coords[2] = x_origin
                        sechenie_coords[3] = y

                    if line[0] is not None:
                        self.amount_of_line += 1
                        self.canvas.create_line(
                            *line, fill=color, width=width, tags="Sechenie")

            elif str(event.num) == "3":
                self.line_start = None


if __name__ == "__main__":
    # folder to work
    init_dir = f'{os.path.realpath(os.path.dirname(__file__))}'
    root = tk.Tk()
    app = App(root, folder=init_dir)
    app.mainloop()
