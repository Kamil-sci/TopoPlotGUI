import os
import re
top_area   = ('DN',      'DP',      'NW',      'PO',      'ME',      'M2',      'M3',      'M4',      'M5',       'CO',       'VI',       'V2',       'V3',       'V4',       'aarea',    'OP'     )
class ReadTXT():
    #init_dir=f'{os.path.realpath(os.path.dirname(__file__))}' # folder to work
    def __init__(self, path, name):
        self.name = name
        self.path = path
        file = open(self.path,"r")
        self.lines = file.readlines()
        file.close()
                             
    def getCoords(self):
        blocks = {}
        paths = {f'{self.name}':f"{self.path}"}

        blocks[self.name] = {} 
      
        for p in paths.keys():
            coords = self.getArea()
            for i in range(len(top_area)):
                blocks[p][top_area[i]] = coords[i]        
        return blocks[f'{self.name}']
            
    def getArea(self):
        n = len(top_area)
        amountArea = [0]*n
        coordArea = [0]*n
        zoom_coords = []
        
        for line in self.lines:
            line = line.strip()
            for i in range(n):
                if line.find(top_area[i]) != -1:
                    amountArea[i] += 1
            if line.find('OP') != -1:
                line = re.split("\(|,|\)",line.strip()) #  \  - экранирование метасимволов
                zoom_coords = list(map(int, line[1:5])) # find self.Lambda coords and convert to int
        for i in range(n):
                for j in range(amountArea[i]):
                    coordArea[i] = [0] * (j+1)
        #print(amountArea)
        for i in range(n):
            count = 0
            while count < amountArea[i]: 
                for line in self.lines:
                    line = re.split("\(|,|\)",line.strip()) #  \  - экранирование метасимволов
                    line.pop(-1)
                    if line[-1] == top_area[i]:
                        
                        coord_list = list(map(int, line[1:5])) # str->int
                        #print('до',coord_list)
                        for z in range(2):
                            if zoom_coords[z] < 0:
                                coord_list[z] += abs(zoom_coords[z]) 
                         
                            elif zoom_coords[z] > 0:
                                coord_list[z] -= zoom_coords[z]
            
                        if line[-1] != 'OP':
                            coord_list[1] = zoom_coords[3] - coord_list[1]   
                      
                        coordArea[i][count] = coord_list
                        count += 1
                        #print('после',coord_list)              
        return coordArea

def newpath(blocks):
    filefolder = f'{os.path.realpath(os.path.dirname(__file__))}' # folder to work
    #filefolder = r'C:\Users\kamil\OneDrive\Рабочий стол\MW2_automation\finish\examples'
    paths = tuple([f'{filefolder}\\examples\\MULT\\_{key}_block.txt' for key in blocks])
    return paths


MULT_blocks = ('HA', 'FA', 'LHA', 'LFA', 'AND', 'ANDT', 'PAND', 'PANDT', 'BC', 'AC', 'FAC', 'FBC', 'FHCD', 'FHCU', 'HCD', 'HCU', 'INB', 'FCT', 'FBL', 'UTS', 'UT', 'BCL', 'BCCB', 'BCT', 'TUTS', 'AUTS', 'TUT', 'AUT', 'ACT', 'HCHC', 'HCDC', 'HCB', 'ET', 'FCT', 'PB', 'TUTE', 'AUTE', 'ACUOT', 'ADDUOE', 'ANDTUOE', 'ACUOE', 'BCUOE', 'ANDTUOT', 'MBNADD', 'MBADD', 'AUTL', 'BCUOT', 'ADDUOL', 'ADDUOT', 'ANDUOT', 'ANDUOL', 'PBUO', 'MBADDE', 'MBLADD', 'LAUTE')

blocks = {'MULT':MULT_blocks }
device_coords={}
for key in blocks.keys():
    filepath = newpath(blocks[key]) 
    device = {k:v for k,v in zip(blocks[key], filepath)}
    device_coords[key]={}
    for item in device.keys():
        device_coords[key][item] = ReadTXT(device[item], item).getCoords()
