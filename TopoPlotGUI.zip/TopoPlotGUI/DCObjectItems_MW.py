import os
import re
top_area   = ('DN',      'DP',      'NW',      'PO',      'ME',      'M2',      'M3',      'M4',      'M5',       'CO',       'VI',       'V2',       'V3',       'V4',       'aarea',    'OP'     )
class ReadTXT():
    #init_dir=f'{os.path.realpath(os.path.dirname(__file__))}' # folder to work
    def __init__(self, path, name):
        self.name = name
        self.path = path
        file = open(self.path,"r")
        self.lines = file.readlines()
        file.close()
                             
    def getCoords(self):
        blocks = {}
        paths = {f'{self.name}':f"{self.path}"}

        blocks[self.name] = {} 
      
        for p in paths.keys():
            coords = self.getArea()
            for i in range(len(top_area)):
                blocks[p][top_area[i]] = coords[i]        
        return blocks[f'{self.name}']
            
    def getArea(self):
        coord_dict = {layer: [] for layer in top_area}
        x_shift, y_shift = 0, 0
        
        for row in self.lines:
            line = re.split("\(|,|\)", row.strip())
            if line[-2] in coord_dict.keys():
                layer_coords = list(map(int, line[1:5]))
                if line[-2] == 'OP':
                    x_shift, y_shift = -layer_coords[0], -layer_coords[1]
                shifted_coords = [layer_coords[0] + x_shift, layer_coords[1] + y_shift, layer_coords[2], layer_coords[3]]  
                coord_dict[line[-2]].append(shifted_coords)             
                #print(line)
                
        op_coords = coord_dict['OP'][0]
        #print(coord_dict)
        for layer in coord_dict.keys():
            if layer != 'OP' and coord_dict[layer]:
                #print(layer)
                for i in range(len(coord_dict[layer])):
                    coord_dict[layer][i] = [coord_dict[layer][i][0], coord_dict[layer][i][1] - op_coords[3], coord_dict[layer][i][2], coord_dict[layer][i][3]] 
                    coord_dict[layer][i] = [coord_dict[layer][i][0], coord_dict[layer][i][1] + 2 * (op_coords[1] - coord_dict[layer][i][1]) - coord_dict[layer][i][3], coord_dict[layer][i][2], coord_dict[layer][i][3]] 
        coord_list = list(coord_dict.values())
        '''
        print(coord_list)        
        n = len(top_area)
        amountArea = [0]*n
        coordArea = [0]*n
        zoom_coords = []
        
        for line in self.lines:
            line = line.strip()
            for i in range(n):
                if line.find(top_area[i]) != -1:
                    amountArea[i] += 1
            if line.find('OP') != -1:
                line = re.split("\(|,|\)",line.strip()) #  \  - экранирование метасимволов
                zoom_coords = list(map(int, line[1:5])) # find self.Lambda coords and convert to int
        for i in range(n):
                for j in range(amountArea[i]):
                    coordArea[i] = [0] * (j+1)
        #print(amountArea)
        for i in range(n):
            count = 0
            while count < amountArea[i]: 
                for line in self.lines:
                    line = re.split("\(|,|\)",line.strip()) #  \  - экранирование метасимволов
                    line.pop(-1)
                    if line[-1] == top_area[i]:
                        
                        coord_list = list(map(int, line[1:5])) # str->int
                        #print('до',coord_list)
                        for z in range(2):
                            if zoom_coords[z] < 0:
                                coord_list[z] += abs(zoom_coords[z]) 
                         
                            elif zoom_coords[z] > 0:
                                coord_list[z] -= zoom_coords[z]
            
                        if line[-1] != 'OP':
                            coord_list[1] = zoom_coords[3] - coord_list[1]   
                      
                        coordArea[i][count] = coord_list
                        count += 1
                        #print('после',coord_list)
        '''
        return coord_list

def newpath(blocks):
    filefolder = f'{os.path.realpath(os.path.dirname(__file__))}' # folder to work
    paths = tuple([f'{filefolder}\\examples\\_{key}_block.txt' for key in blocks])
    return paths


YDC_blocks = ('Ynands','YNnands','Ynors','YNnors','Ynand_base','Ynor_base','Yforward_inv','Ybackward_inv','YC','YT','YH','YL','YII','Yempty')
XDC_blocks = ('Xnands','XNnands','Xnors','XNnors','Xnand_base','Xnor_base','Xforward_inv','Xbackward_inv','XC','XT','XH','XL','XII','Xempty')
XCONNECT_blocks = ('BT','BC','BII','BL0','BL1','PULSEX','XVdd')

blocks = {'YDC':YDC_blocks, 'XDC':XDC_blocks, 'XCONNECT':XCONNECT_blocks}
device_coords={}
for key in blocks.keys():
    filepath = newpath(blocks[key]) 
    device = {k:v for k,v in zip(blocks[key], filepath)}
    device_coords[key]={}
    for item in device.keys():
        device_coords[key][item] = ReadTXT(device[item], item).getCoords()
