import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import root
from scipy.interpolate import CubicSpline


def load_spline_interpolation_data_simple(filename):
    """
    Загружает данные для интерполяции из файла (простой формат) и создает объекты CubicSpline.

    Args:
            filename (str): Путь к файлу с данными интерполяции (простой формат).

    Returns:
            dict: Словарь, где ключи - имена коэффициентов ('p00', 'p10', ...),
                      а значения - соответствующие объекты CubicSpline.
                      Возвращает пустой словарь, если файл не найден или ошибка парсинга.
    """
    spline_funcs = {}
    current_param_name = None
    current_x_values = []
    current_y_values = []

    try:
        with open(filename, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue

                if ',' not in line:
                    # Process the previous block if it exists
                    if current_param_name and len(current_x_values) >= 2 and len(current_x_values) == len(current_y_values):
                        try:
                            spline_funcs[current_param_name] = CubicSpline(
                                current_x_values, current_y_values, extrapolate=True)  # Добавлено extrapolate=True
                        except Exception as e:
                            print(
                                f"  Ошибка при создании сплайна для '{current_param_name}': {e}. Пропуск.")
                    elif current_param_name:
                        print(
                            f"  Предупреждение: Недостаточно валидных точек ({len(current_x_values)}) или несовпадение X/Y для сплайна '{current_param_name}'. Пропуск.")

                    # Start a new block
                    current_param_name = line
                    current_x_values = []
                    current_y_values = []
                else:
                    # Process the point line
                    if current_param_name is None:
                        print(
                            f"Предупреждение: Точка найдена ({line}) до определения имени коэффициента. Пропуск.")
                        continue
                    try:
                        x_str, y_str = line.split(',', 1)
                        x_val = float(x_str.strip())
                        y_val = float(y_str.strip())
                        current_x_values.append(x_val)
                        current_y_values.append(y_val)
                    except ValueError as e:
                        print(
                            f"  Предупреждение: Неверный формат числа в строке '{line}' для коэффициента '{current_param_name}': {e}. Пропуск точки.")
                    except Exception as e:
                        print(
                            f"  Неожиданная ошибка парсинга точки в строке '{line}' для коэффициента '{current_param_name}': {e}. Пропуск точки.")

            # Process the last block after the file ends
            if current_param_name and len(current_x_values) >= 2 and len(current_x_values) == len(current_y_values):
                try:
                    spline_funcs[current_param_name] = CubicSpline(
                        current_x_values, current_y_values, extrapolate=True)  # Добавлено extrapolate=True
                except Exception as e:
                    print(
                        f"  Ошибка при создании сплайна для '{current_param_name}': {e}. Пропуск.")
            elif current_param_name:
                print(
                    f"  Предупреждение: Недостаточно валидных точек ({len(current_x_values)}) или несовпадение X/Y для последнего сплайна '{current_param_name}'. Пропуск.")

    except FileNotFoundError:
        print(f"Ошибка загрузки сплайн-данных: Файл '{filename}' не найден.")
    except Exception as e:
        print(
            f"Неожиданная ошибка при загрузке сплайн-данных из '{filename}': {e}")

    print(
        f"Загружены сплайн-функции для коэффициентов: {list(spline_funcs.keys())}")
    return spline_funcs

def equation(W_N, R_L, C_L, target_t_out):
    return calculate_tdout_from_Wn(W_N, R_L, C_L) - target_t_out

def solve_W_N(R_L, C_L, target_t_out, initial_guess=1):
    # Alternatively, try using root with a different method
    result = root(equation, initial_guess, args=(R_L, C_L, target_t_out), method='lm')
    return result.x

def calculate_tdout_from_Wn(W_N_microns, R_L_ohm, C_L_fF):
    spline_coeffs={
        'p00':spline_coeffs_data['p00'](C_L_fF).item(),
        'p10':spline_coeffs_data['p10'](C_L_fF).item(),
        'p01':spline_coeffs_data['p01'](C_L_fF).item(),
        'p20':spline_coeffs_data['p20'](C_L_fF).item(),
        'p11':spline_coeffs_data['p11'](C_L_fF).item(),
        'p02':spline_coeffs_data['p02'](C_L_fF).item()
        }

    calculated_time_sec = spline_coeffs['p00'] + spline_coeffs['p10'] / W_N_microns ** spline_coeffs['p20'] + spline_coeffs['p01'] * R_L_ohm ** spline_coeffs['p02'] + spline_coeffs['p11'] / W_N_microns * R_L_ohm
    return calculated_time_sec 
    
    
interpolation_data_file = "interpolation_spline_coeffs.txt"
spline_coeffs_data = load_spline_interpolation_data_simple(interpolation_data_file)
param_names = ['p00', 'p10', 'p01', 'p20', 'p11', 'p02']
loaded_keys = set(spline_coeffs_data.keys())
if not all(name in loaded_keys for name in param_names):
    missing_keys = [name for name in param_names if name not in loaded_keys]
    spline_coeffs_data = {}

# Задаем параметры
R_L = 100  # Пример значения для R_L
C_L = 100e-15  # Пример значения для C_L
initial_guess = 1  # Начальное предположение для W_N

# Массив значений target_t_out
# Диапазон значений target_t_out
target_t_out_values = np.linspace(650e-12, 1310e-12, 1000)

# Инициализация массивов для результатов
W_N_values = []
verify_t_out_values = []
errors = []

# Цикл по значениям target_t_out
for target_t_out in target_t_out_values:
    # Решаем уравнение для нахождения W_N
    W_N = solve_W_N(R_L, C_L, target_t_out, initial_guess)
    W_N_values.append(W_N)

    # Выполняем обратную проверку
    verify_t_out = calculate_tdout_from_Wn(W_N, R_L, C_L)

    verify_t_out_values.append(verify_t_out)

    # Вычисляем погрешность
    error = abs(verify_t_out - target_t_out)
    errors.append(error)

verify_t_out_values = np.array(verify_t_out_values)*1e12
target_t_out_values = np.array(target_t_out_values)*1e12
errors = np.array(errors)*1e12
# Построение графика с двумя осями
fig, ax1 = plt.subplots(figsize=(12, 7))

plt.yscale('log')
#plt.xscale('log')
# Первая ось - значения t_out
color1 = 'red'
ax1.set_xlabel('Рассчитанное $W_N$, мкм')
ax1.set_ylabel('$t_{OUT}$, пс')
ax1.plot(W_N_values, verify_t_out_values,
         label='Вычисление', color=color1, linestyle='-')
ax1.scatter(W_N_values, target_t_out_values, label='Цель', color='blue')
ax1.tick_params(axis='y')
# Вторая ось - погрешность
ax2 = ax1.twinx()
color2 = 'green'
ax2.set_ylabel('Абсолютная Погрешность, пс')
ax2.plot(W_N_values, errors, label='Погрешность', color=color2, linestyle='--')
ax2.tick_params(axis='y')
# Общие настройки
fig.tight_layout()
ax1.legend(loc='upper left')
ax2.legend(loc='upper right')
ax1.grid(True, which="both", ls="-")


plt.title('Зависимость значений и погрешности от $W_N$')
plt.show()

# =============================================================================
# plt.figure(figsize=(10, 6))
# plt.plot(W_N_values, verify_t_out_values, label='Численный метод', color='red', linestyle='-')
# plt.scatter(W_N_values, target_t_out_values, label='Цель', color='blue')
# plt.xlabel('Рассчитанное $W_N$, мкм')
# plt.ylabel('$t_{WR}$, нс')
# #plt.xscale('log')  # Логарифмическая шкала для target_t_out
# #plt.yscale('log')  # Логарифмическая шкала для погрешности
# plt.legend()
# plt.grid(True, which="both", ls="--")
#
# plt.figure(figsize=(10, 6))
# plt.plot(target_t_out_values, errors, label='Погрешность', color='red', linestyle='-')
# #plt.xscale('log')  # Логарифмическая шкала для target_t_out
# #plt.yscale('log')  # Логарифмическая шкала для погрешности
# plt.xlabel('Целевое значение $t_{WR}$, нс')
# plt.ylabel('Погрешность, нс')
# plt.title('Зависимость погрешности от target_t_out')
# plt.legend()
# plt.grid(True, which="both", ls="--")
# plt.show()
# =============================================================================
