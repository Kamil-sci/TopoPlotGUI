import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from scipy.optimize import curve_fit
from sklearn.metrics import r2_score
import plotly.graph_objects as go
import plotly.offline as pyo
import plotly.colors
from scipy.interpolate import CubicSpline # Импортируем CubicSpline
import os # Для проверки существования файла

def load_and_prepare_data(filename):
    """Загружает данные из CSV и подготавливает их для анализа."""
    try:
        data = pd.read_csv(filename, sep='\t')
        print(f"Данные успешно загружены из '{filename}'.")
    except FileNotFoundError:
        print(f"Ошибка: Файл '{filename}' не найден.")
        return None
    except Exception as e:
        print(f"Ошибка при чтении файла '{filename}': {e}")
        return None

    widths = np.sort(data.iloc[:, 0].unique())
    res = np.sort(data.iloc[:, 1].unique())
    caps = np.sort(data.iloc[:, 2].unique())
    n_w, n_r, n_c = len(widths), len(res), len(caps)

    if n_w * n_r * n_c != len(data):
        print("Предупреждение: Размер данных не соответствует произведению уникальных значений измерений.")

    time_values = data.iloc[:, 3].values
    time_grid = time_values.reshape(n_w, n_r, n_c)

    prepared_data = {
        "widths": widths,
        "res": res,
        "caps": caps,
        "time_grid": time_grid,
    }
    return prepared_data

def plot_4d_scatter_interactive_optimized(prepared_data):
    """Интерактивный 3D scatter plot с цветом как 4-м измерением (оптимизированный)."""
    if prepared_data is None:
        print("Нет данных для визуализации.")
        return

    widths = prepared_data["widths"]
    res = prepared_data["res"]
    caps = prepared_data["caps"]
    time_grid = prepared_data["time_grid"]

    W_mesh, R_mesh, C_mesh = np.meshgrid(widths, res, caps, indexing='ij')

    w_flat = W_mesh.flatten()
    r_flat = R_mesh.flatten()
    c_flat = C_mesh.flatten()
    t_flat = time_grid.flatten()

    fig = go.Figure(data=[go.Scatter3d(
        x=r_flat,
        y=c_flat,
        z=t_flat,
        mode='markers',
        marker=dict(
            size=4,
            color=w_flat,
            colorscale='Rainbow',
            colorbar=dict(title='Width'),
            opacity=0.8
        ),
        text=[f'W={w:.2f}' for w in w_flat]
    )])

    fig.update_layout(
        title='Интерактивная 4D визуализация (R, C, Time, Width=Color)',
        scene=dict(
            xaxis_title='Resistance, Ohm',
            yaxis_title='Capacitance, F',
            zaxis_title='Time, s'
        ),
    )
    pyo.plot(fig, filename="4d_plot_interactive.html", auto_open=True)

def plot_2d_planes_more(prepared_data, fixed_dims):
    """
    Строит 2D графики срезов 4D данных для нескольких индексов фиксированных измерений.

    Parameters:
    - prepared_data: словарь с данными (widths, res, caps, time_grid).
    - fixed_dims: словарь, где ключи — фиксированные измерения, а значения — списки индексов.
    """
    if prepared_data is None:
        print("Нет данных для визуализации.")
        return
    if len(fixed_dims) != 2:
        print("Ошибка: Должно быть зафиксировано ровно 2 измерения.")
        return

    dims_data = {"width": prepared_data["widths"], "res": prepared_data["res"], "cap": prepared_data["caps"]}
    free_dims_keys = list(set(dims_data.keys()) - set(fixed_dims.keys()))
    if len(free_dims_keys) != 1:
        print("Ошибка: Неверные или дублирующиеся ключи для фиксированных измерений.")
        return
    free_dim_key = free_dims_keys[0]
    free_dim_values = dims_data[free_dim_key]
    time_grid = prepared_data["time_grid"]

    # Проверяем, что для каждого фиксированного измерения передан список индексов
    for key in fixed_dims:
        if not isinstance(fixed_dims[key], (list, tuple)):
            fixed_dims[key] = [fixed_dims[key]]  # Преобразуем одиночный индекс в список

    # Определяем количество кривых (произведение длин списков индексов)
    index_combinations = np.array(np.meshgrid(*[fixed_dims[key] for key in fixed_dims])).T.reshape(-1, 2)

    plt.figure(figsize=(10, 6))

    for idx_combo in index_combinations:
        try:
            slice_indices, vals_str = [], []
            fixed_dims_keys = list(fixed_dims.keys())
            for key in ["width", "res", "cap"]:
                if key in fixed_dims:
                    # Берем индекс из текущей комбинации
                    idx_pos = fixed_dims_keys.index(key)
                    idx = idx_combo[idx_pos]
                    if not (0 <= idx < len(dims_data[key])):
                        print(f"Предупреждение: Индекс {idx} для '{key}' вне допустимого диапазона [0, {len(dims_data[key])-1}]. Пропуск среза.")
                        continue
                    slice_indices.append(idx)
                    vals_str.append(f"{key.capitalize()}={dims_data[key][idx]:.2g}")
                else:
                    slice_indices.append(slice(None))

            time_slice = time_grid[tuple(slice_indices)].squeeze()
            title = f"Time vs {free_dim_key.capitalize()} при разных фиксированных параметрах"

            # Автоматическая генерация метки для легенды
            label = ", ".join(vals_str)

            # Построение кривой (matplotlib автоматически выберет стиль линии)
            plt.scatter(free_dim_values, time_slice, label=label)

        except IndexError:
            print(f"Ошибка: Указаны некорректные индексы для фиксированных измерений в '{label}'.")
        except Exception as e:
            print(f"Произошла ошибка при построении 2D среза для '{label}': {e}")

    #plt.yscale("log")
    plt.xlabel(free_dim_key.capitalize())
    plt.ylabel("Time, s")
    plt.title(title)
    plt.grid(True)
    #plt.legend()
    plt.tight_layout()
    plt.show()

def plot_3d_slices_interactive(prepared_data, fixed_dim_key, indices=None):
    """
    Интерактивная визуализация 3D срезов (точек рассеяния).

    Args:
        prepared_data (dict): Словарь с подготовленными данными.
        fixed_dim_key (str): Ключ фиксированного измерения ("width", "res", "cap").
        indices (list, optional): Список индексов для фиксированного измерения.
                                   Если None, используются все доступные индексы.
    """
    if prepared_data is None:
        print("Нет данных для визуализации.")
        return
    if fixed_dim_key not in ["width", "res", "cap"]:
        print(f"Ошибка: Неверный ключ для фиксированного измерения: {fixed_dim_key}")
        return

    dims_data = {"width": prepared_data["widths"], "res": prepared_data["res"], "cap": prepared_data["caps"]}
    fixed_dim_values = dims_data[fixed_dim_key]
    time_grid = prepared_data["time_grid"]

    if indices is None:
        indices = range(len(fixed_dim_values))
    else:
        valid_indices = []
        for i in indices:
            if 0 <= i < len(fixed_dim_values):
                valid_indices.append(i)
            else:
                print(f"Предупреждение: Индекс {i} для '{fixed_dim_key}' вне диапазона, пропущен.")
        indices = valid_indices
        if not indices:
            print("Нет корректных индексов для отображения.")
            return

    free_dim_keys = [k for k in ["width", "res", "cap"] if k != fixed_dim_key]
    free_dim1_key, free_dim2_key = free_dim_keys

    fig = go.Figure()
    dim_order = ["width", "res", "cap"]
    colors = plotly.colors.DEFAULT_PLOTLY_COLORS

    for i, idx in enumerate(indices):
        current_fixed_val = fixed_dim_values[idx]
        slice_indices = []
        for k in dim_order:
            if k == fixed_dim_key:
                slice_indices.append(idx)
            else:
                slice_indices.append(slice(None))

        Z = time_grid[tuple(slice_indices)].squeeze()

        mesh_dim1_vals = dims_data[free_dim1_key]
        mesh_dim2_vals = dims_data[free_dim2_key]

        # Создаем массивы для координат точек
        x_coords, y_coords = np.meshgrid(mesh_dim1_vals, mesh_dim2_vals, indexing='xy')
        x_coords = x_coords.flatten()
        y_coords = y_coords.flatten()
        z_coords = Z.T.flatten()

        color = colors[i % len(colors)]
        fig.add_trace(go.Scatter3d(
            x=x_coords,
            y=y_coords,
            z=z_coords,
            mode='markers',  # Используем markers для отображения точек
            name=f"{fixed_dim_key.capitalize()}={current_fixed_val:.2g}",
            marker=dict(
                size=3,
                color=color,
                colorscale='Rainbow',
                opacity=0.7,
            )
        ))


    fig.update_layout(
        title=f'3D Срезы: Time vs ({free_dim1_key.capitalize()}, {free_dim2_key.capitalize()}) при разных {fixed_dim_key.capitalize()}',
        scene=dict(
            xaxis_title=free_dim1_key.capitalize(),
            yaxis_title=free_dim2_key.capitalize(),
            zaxis_title='Time, s'
        ),
    )
    pyo.plot(fig, filename=f"3d_slices_{fixed_dim_key}_scatter.html", auto_open=True)  # Изменили имя файла

# --- Функции для Аппроксимации Поверхностей ---
def model_linear_2d(xy, p0, p1, p2):
    """Линейная модель: z = p0*x + p1*y + p2"""
    x, y = xy
    return p0 * x + p1 * y + p2

def model_manual_2d(xy, p00, p10, p01, p20, p11, p02):
    x, y = xy
    return p00 + p10 / x ** p20 + p01 * y ** p02  + p11 / x * y 
    #return p00 + p10 * x + p01 * y + p20 * x ** 2 + p11 * x * y + p02 * y**2
def model_poly2_2d(xy, p00, p10, p01, p20, p11, p02):
    """Полиномиальная модель 2-й степени: z = p00 + p10x + p01y + p20x^2 + p11xy + p02y^2"""
    x, y = xy
    return p00 + p10 * x + p01 * y + p20 * x**2 + p11 * x * y + p02 * y**2

def fit_surface_model(x_data, y_data, z_data, model_func, initial_guess):
    """Выполняет аппроксимацию поверхности."""
    xy_data = np.vstack((x_data.ravel(), y_data.ravel()))
    z_data_flat = z_data.ravel()

    try:
        print(f"  Аппроксимация моделью: {model_func.__name__}")
        popt, pcov = curve_fit(model_func, xy_data, z_data_flat, p0=initial_guess, maxfev=10000)
        z_pred_flat = model_func(xy_data, *popt)
        r2 = r2_score(z_data_flat, z_pred_flat)
        print(f"    Оптимальные параметры: {popt}")
        print(f"    R^2: {r2:.4f}")
        return popt, pcov, r2
    except RuntimeError as e:
        print(f"    Ошибка аппроксимации: {e}")
        return None, None, None
    except ValueError as e:
        print(f"    Ошибка в данных или нач. значениях: {e}")
        return None, None, None
    except Exception as e:
        print(f"    Неожиданная ошибка: {e}")
        return None, None, None
    
def plot_surface_fits_plotly_all(prepared_data, fixed_approximation_dim="width", fit_model_func=model_poly2_2d):
    coefficients = []  # Список для сохранения коэффициентов
    if prepared_data is None:
        print("Нет данных для аппроксимации.")
        return coefficients
    if fixed_approximation_dim not in ["width", "res", "cap"]:
        print(f"Ошибка: Неверный ключ для фиксированного измерения: {fixed_approximation_dim}")
        return coefficients

    dims_data = {"width": prepared_data["widths"], "res": prepared_data["res"], "cap": prepared_data["caps"]}
    time_grid = prepared_data["time_grid"]
    dim_order = ["width", "res", "cap"]

    fixed_vals = dims_data[fixed_approximation_dim]
    free_approx_keys = [k for k in dim_order if k != fixed_approximation_dim]
    dim1_key, dim2_key = free_approx_keys
    dim1_vals, dim2_vals = dims_data[dim1_key], dims_data[dim2_key]

    fig_all_fits = go.Figure()
    colors = plotly.colors.DEFAULT_PLOTLY_COLORS

    for i, fixed_val in enumerate(fixed_vals):
        print(f"\nАппроксимация для {fixed_approximation_dim} = {fixed_val:.2g} (индекс {i})")
        slice_indices = []
        for k in dim_order:
            if k == fixed_approximation_dim:
                slice_indices.append(i)
            else:
                slice_indices.append(slice(None))

        current_time_slice = time_grid[tuple(slice_indices)].squeeze()

        X_fit, Y_fit = np.meshgrid(dim1_vals, dim2_vals, indexing='xy')
        Z_fit_data = current_time_slice.T

        if Z_fit_data.shape != X_fit.shape:
            print(f"Пропуск среза {i} из-за несоответствия размеров.")
            continue

        initial_guess_map = {
            model_linear_2d: [0, 0, np.mean(Z_fit_data)],
            model_poly2_2d: [np.mean(Z_fit_data), 0, 0, 0, 0, 0],
            model_manual_2d: [1,1,1,1,1,1]
        }
        initial_guess = initial_guess_map.get(fit_model_func, None)
        if initial_guess is None:
            print(f"Начальное приближение не определено для модели {fit_model_func.__name__}, пропуск.")
            continue

        popt, _, r2 = fit_surface_model(
            X_fit, Y_fit, Z_fit_data,
            fit_model_func, initial_guess=initial_guess
        )

        if popt is not None:
            coefficients.append((fixed_val, popt))
            color = colors[i % len(colors)]
            legend_group = f"{fixed_approximation_dim.capitalize()}={fixed_val:.2g}"
            scatter_name = f"Данные ({legend_group})"
            fit_name = f"Аппр. ({legend_group}, R2={r2:.2f})"
    
            # Исходные данные в виде точек рассеяния
            fig_all_fits.add_trace(go.Scatter3d(
                x=X_fit.ravel(),
                y=Y_fit.ravel(),
                z=Z_fit_data.ravel(),
                mode='markers',
                marker=dict(size=2, color=color),
                name=scatter_name,
                legendgroup=legend_group,
            ))
    
            # Аппроксимирующая поверхность в виде сетки
            z_pred_fit = fit_model_func(
                (X_fit.ravel(), Y_fit.ravel()),
                *popt
            ).reshape(X_fit.shape)
    
            rows, cols = z_pred_fit.shape
            fit_line_color = 'black' # Используем черный для всех сеток аппроксимации
            # Линии вдоль dim1
            for r_idx in range(rows):
                fig_all_fits.add_trace(go.Scatter3d(
                    x=X_fit[r_idx, :],
                    y=Y_fit[r_idx, :],
                    z=z_pred_fit[r_idx, :],
                    mode='lines',
                    line=dict(color=fit_line_color, width=1),
                    legendgroup=legend_group,
                    showlegend=False
                ))
            # Линии вдоль dim2
            for c_idx in range(cols):
                fig_all_fits.add_trace(go.Scatter3d(
                    x=X_fit[:, c_idx],
                    y=Y_fit[:, c_idx],
                    z=z_pred_fit[:, c_idx],
                    mode='lines',
                    line=dict(color=fit_line_color, width=1),
                    legendgroup=legend_group,
                    showlegend=False
                ))
            # Добавляем один невидимый след для легенды аппроксимации
            fig_all_fits.add_trace(go.Scatter3d(
                x=[None], y=[None], z=[None],
                mode='lines',
                line=dict(color=fit_line_color, width=1),
                legendgroup=legend_group,
                showlegend=True,
                name=fit_name
            ))
    
    
    fig_all_fits.update_layout(
        title=f"Аппроксимация поверхностей ({fit_model_func.__name__}) для разных {fixed_approximation_dim.capitalize()}",
        scene=dict(
            xaxis_title=dim1_key.capitalize(),
            yaxis_title=dim2_key.capitalize(),
            zaxis_title='Time, s'
        ),
        showlegend=True
    )
    filename=f"all_surface_fits_{fixed_approximation_dim}.html"
    pyo.plot(fig_all_fits, filename=filename, auto_open=False)
    import webbrowser
    webbrowser.open(filename)
    return coefficients

def plot_coefficients_with_interpolation_error(coefficients, output_file=None):
    """
    Строит графики коэффициентов аппроксимации поверхности и выполняет
    кубическую сплайн-интерполяцию зависимости каждого коэффициента от Width.
    Выводит данные (точки x, y) для построения сплайна в отдельный файл.

    :param coefficients: список кортежей (width, [p00, p10, p01, p20, p11, p02])
                         Получен из plot_surface_fits_plotly_all.
    :param output_file: имя файла для вывода данных интерполяции (точек x, y)
    """
    if not coefficients:
        print("Нет данных для построения графиков коэффициентов или интерполяции.")
        return
    
    widths = np.array([c[0] for c in coefficients])
    params = np.array([c[1] for c in coefficients])
    # Имена параметров аппроксимации поверхности
    param_names = ['p00', 'p10', 'p01', 'p20', 'p11', 'p02']

    # Словарь для хранения данных (x, y точек) для каждого сплайна для записи в файл
    spline_data_for_file = {}

    fig, axs = plt.subplots(2, 3, figsize=(18, 12))
    axs = axs.flatten()

    print("\n--- Интерполяция коэффициентов поверхностей от Width ---")

    for i, name in enumerate(param_names):
        ax = axs[i]
        
        x_data = widths
        y_data = params[:, i]

        # Удаляем NaN или бесконечные значения
        valid_mask = np.isfinite(y_data)
        x_valid = x_data[valid_mask]
        y_valid = y_data[valid_mask]

        ax.scatter(x_valid, y_valid, color='blue', label='Данные из аппр. поверхности', alpha=0.6)
        
        if len(x_valid) < 2:
            print(f"Недостаточно валидных точек ({len(x_valid)}) для интерполяции коэффициента '{name}'. Пропуск.")
            ax.set_title(f"{name} (Нет данных)")
            ax.set_xlabel('Width')
            ax.grid(True)
            continue
        
        try:
            # Создаем сплайн для построения на графике
            spline_func = CubicSpline(x_valid, y_valid)

            # Генерируем точки для графика, включая некоторую область для экстраполяции
            x_min_plot = min(x_valid) * 0.9 if min(x_valid) > 0 else min(x_valid) * 1.1
            x_max_plot = max(x_valid) * 1.1
            x_plot_range = np.linspace(min(x_min_plot, min(x_valid)), max(x_max_plot, max(x_valid)), 200)
            y_plot_interp = spline_func(x_plot_range)

            ax.plot(x_plot_range, y_plot_interp, color='red', label='Интерполяция (Сплайн)')
            
            ax.set_title(f"{name}")
            ax.set_xlabel('Width')
            ax.set_ylabel('Коэффициент')
            ax.grid(True)
            ax.legend(loc='upper left')

            # Вычисление и построение погрешности (должна быть близка к 0 на узлах)
            y_interpolated_at_valid_points = spline_func(x_valid)
            absolute_error = y_valid - y_interpolated_at_valid_points
            relative_error_percent = np.zeros_like(absolute_error)
            non_zero_indices = np.abs(y_valid) > 1e-9
            if np.any(non_zero_indices):
                 relative_error_percent[non_zero_indices] = (absolute_error[non_zero_indices] / y_valid[non_zero_indices]) * 100

            ax2 = ax.twinx()
            ax2.plot(x_valid, relative_error_percent, color='green', label='Отн. погрешность на точках данных (%)', linestyle=':', marker='.')
            ax2.set_ylabel('Отн. погрешность (%)', color='green')
            ax2.tick_params(axis='y', labelcolor='green')
            ax2.legend(loc='lower right')

            # --- Сохраняем x_valid и y_valid для записи в файл ---
            # Сохраняем их как numpy массивы или списки для дальнейшей записи
            spline_data_for_file[name] = {
                'x_values': x_valid, # Сохраняем как numpy array
                'y_values': y_valid  # Сохраняем как numpy array
            }
            # --- Конец сохранения данных для файла ---

        except ValueError as e:
             print(f"Ошибка ValueError при создании сплайна для '{name}': {e}. Недостаточно уникальных точек?")
             ax.set_title(f"{name} (Ошибка интерполяции)")
             ax.set_xlabel('Width')
             ax.grid(True)
        except Exception as e:
            print(f"Произошла ошибка при интерполяции '{name}': {e}")
            ax.set_title(f"{name} (Ошибка)")
            ax.set_xlabel('Width')
            ax.grid(True)

    plt.tight_layout()
    plt.show()
    
    # --- Сохранение данных для сплайна в файл в простом формате ---
    if output_file:
        try:
            with open(output_file, 'w', encoding='utf-8') as f:
                f.write("# Данные для кубической сплайн-интерполяции коэффициентов поверхностной аппроксимации.\n")
                f.write("# Для каждого коэффициента ниже приведены точки (Width, Value) через которые проходит сплайн.\n")
                f.write("# Формат: КОЭФФИЦИЕНТ_NAME\\n x_value1,y_value1\\n x_value2,y_value2\\n ... \\n\\n\n")

                for param_name, data in spline_data_for_file.items():
                    f.write(f"{param_name}\n") # Заголовок - имя коэффициента
                    # Записываем точки построчно через запятую
                    for x, y in zip(data['x_values'], data['y_values']):
                        f.write(f"{x},{y}\n")
                    f.write("\n") # Пустая строка для разделения блоков

            print(f"Данные для интерполяции (точки Width, Value) сохранены в файл: {output_file}")
        except Exception as e:
            print(f"Ошибка при записи файла {output_file}: {e}")

def load_spline_interpolation_data_simple(filename):
    """
    Загружает данные для интерполяции из файла (простой формат) и создает объекты CubicSpline.

    Args:
        filename (str): Путь к файлу с данными интерполяции (простой формат).

    Returns:
        dict: Словарь, где ключи - имена коэффициентов ('p00', 'p10', ...),
              а значения - соответствующие объекты CubicSpline.
              Возвращает пустой словарь, если файл не найден или ошибка парсинга.
    """
    spline_funcs = {}
    current_param_name = None
    current_x_values = []
    current_y_values = []

    try:
        with open(filename, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue

                # Если строка не содержит запятой, считаем, что это имя коэффициента
                if ',' not in line:
                    # Обрабатываем данные предыдущего блока, если они есть
                    if current_param_name and len(current_x_values) >= 2 and len(current_x_values) == len(current_y_values):
                        try:
                            spline_funcs[current_param_name] = CubicSpline(current_x_values, current_y_values)
                            # print(f"  Spline created for {current_param_name}")
                        except Exception as e:
                            print(f"  Ошибка при создании сплайна для '{current_param_name}': {e}. Пропуск.")
                    elif current_param_name:
                         print(f"  Предупреждение: Недостаточно валидных точек ({len(current_x_values)}) или несовпадение X/Y для сплайна '{current_param_name}'. Пропуск.")


                    # Начинаем новый блок
                    current_param_name = line
                    current_x_values = []
                    current_y_values = []
                else:
                    # Если строка содержит запятую, считаем, что это пара точка x,y
                    if current_param_name is None:
                        print(f"Предупреждение: Точка найдена ({line}) до определения имени коэффициента. Пропуск.")
                        continue
                    try:
                        x_str, y_str = line.split(',', 1) # Split only on the first comma
                        x_val = float(x_str.strip())
                        y_val = float(y_str.strip())
                        current_x_values.append(x_val)
                        current_y_values.append(y_val)
                    except ValueError as e:
                        print(f"  Предупреждение: Неверный формат числа в строке '{line}' для коэффициента '{current_param_name}': {e}. Пропуск точки.")
                    except Exception as e:
                         print(f"  Неожиданная ошибка парсинга точки в строке '{line}' для коэффициента '{current_param_name}': {e}. Пропуск точки.")


        # Обрабатываем последний блок после окончания файла
        if current_param_name and len(current_x_values) >= 2 and len(current_x_values) == len(current_y_values):
            try:
                spline_funcs[current_param_name] = CubicSpline(current_x_values, current_y_values)
                # print(f"  Spline created for {current_param_name}")
            except Exception as e:
                 print(f"  Ошибка при создании сплайна для '{current_param_name}': {e}. Пропуск.")
        elif current_param_name:
            print(f"  Предупреждение: Недостаточно валидных точек ({len(current_x_values)}) или несовпадение X/Y для последнего сплайна '{current_param_name}'. Пропуск.")


    except FileNotFoundError:
        print(f"Ошибка загрузки сплайн-данных: Файл '{filename}' не найден.")
    except Exception as e:
        print(f"Неожиданная ошибка при загрузке сплайн-данных из '{filename}': {e}")

    print(f"Загружены сплайн-функции для коэффициентов: {list(spline_funcs.keys())}")
    return spline_funcs

def plot_coefficients_with_fits_error(coefficients, fit_functions=None, output_file=None):
    """
    Строит графики коэффициентов аппроксимации с их аппроксимацией.
    
    :param coefficients: список кортежей (width, [p00, p10, p01, p20, p11, p02])
    :param fit_functions: словарь вида {'p00': функция, 'p10': функция, ...}, 
                          каждая функция принимает (x, y) и возвращает (x_fit, y_fit)
    :param output_file: имя файла для вывода коэффициентов аппроксимации
    """
    if not coefficients:
        print("Нет данных для построения графиков коэффициентов.")
        return
    
    widths = np.array([c[0] for c in coefficients])
    params = np.array([c[1] for c in coefficients])
    param_names = ['p00', 'p10', 'p01', 'p20', 'p11', 'p02']

    if fit_functions is None:
        fit_functions = {}
    # Словарь для хранения результатов аппроксимации для каждого коэффициента
    fitted_params_dict = {}

    fig, axs = plt.subplots(2, 3, figsize=(15, 10))
    for i, name in enumerate(param_names):
        ax = axs[i // 3, i % 3]
        ax.scatter(widths, params[:, i], color='blue', label='Исходные данные', alpha=0.6)
        
        x_data = widths
        y_data = params[:, i]
        valid_indices = ~np.isnan(y_data)
        x_valid = x_data[valid_indices]
        y_valid = y_data[valid_indices]

        if len(x_valid) < 3:
            print(f"Недостаточно данных для аппроксимации {name}.")
            continue

        try:
            if name in fit_functions:
                # Пользовательская функция аппроксимации
                x_fit, y_fit, coeffs_fit = fit_functions[name](x_valid, y_valid)
                fitted_params_dict[name] = coeffs_fit  # Сохраняем коэффициенты
                
            else:
                # Аппроксимация по умолчанию: полином 4 степени
                coeffs_fit = np.polyfit(x_valid, y_valid, 4)
                x_fit = np.linspace(min(x_valid), max(x_valid), 30)
                y_fit = np.polyval(coeffs_fit, x_fit)
                fitted_params_dict[name] = coeffs_fit  # Сохраняем коэффициенты
            
            ax.plot(x_fit, y_fit, color='red', label='Аппроксимация')
            #plt.xscale('log')
            #plt.xscale('log')
            ax.set_title(name)
            ax.set_xlabel('Width')
            ax.grid(True)
            ax.legend(loc='upper left')

            # Вычисление погрешности аппроксимации
            rel_error = (y_valid - y_fit)/y_fit*100

            ax2 = ax.twinx()
            ax2.plot(x_valid, rel_error, color='green', label='Относительная погрешность', linestyle=':')
            ax2.legend(loc='lower right')

        except Exception as e:
            print(f"Ошибка при аппроксимации {name}: {e}")
    
    plt.tight_layout()
    plt.show()
    
    alphabet = [chr(i) for i in range(97, 123)]

    # Сохранение коэффициентов в файл
    with open(output_file, 'w', encoding='utf-8') as f:
        for param_name, coeffs in fitted_params_dict.items():
            f.write(f"{param_name}:\t")
            for i, num in enumerate(coeffs):
                f.write(f"{alphabet[i]}={num}\t")
            f.write("\n")
    print(f"Коэффициенты аппроксимации сохранены в файл: {output_file}")

if __name__ == "__main__":
    prepared_data = load_and_prepare_data('tran_results/OUT_tran_all.txt')

    if prepared_data:
        
        """ --- 4D Визуализация ---"""
        #plot_4d_scatter_optimized(prepared_data)
        #plot_4d_scatter_interactive_optimized(prepared_data)

        """ --- 2D Срезы ---"""
        # print("\n--- Построение 2D срезов ---")
        #plot_2d_planes_more(prepared_data, fixed_dims={"width": list(range(len(prepared_data['widths']))), "res": 0})
        #plot_2d_planes_more(prepared_data, fixed_dims={"width": 0, "res": list(range(len(prepared_data['res'])))})
        #plot_2d_planes_more(prepared_data, fixed_dims={"width": list(range(len(prepared_data['widths']))), "res": list(range(len(prepared_data['res'])))})

        """ --- 3D Срезы (Поверхности) --- """
        # print("\n--- Интерактивные 3D срезы ---")
        #plot_3d_slices_interactive(prepared_data, fixed_dim_key="width")#, indices=[0, len(prepared_data['widths']) // 2, len(prepared_data['widths']) - 1])
        #plot_3d_slices_interactive(prepared_data, fixed_dim_key="res")#, indices=[0, 1])
        #plot_3d_slices_interactive(prepared_data, fixed_dim_key="cap") # Все срезы

        """ --- Аппроксимация Поверхностей на одном графике --- """
        #print("\n--- Аппроксимация поверхностей (2D функции) на одном графике ---")
        coefficients = plot_surface_fits_plotly_all(prepared_data, fixed_approximation_dim="cap", fit_model_func=model_manual_2d)
        
        
        def custom_fit_poly_4(x, y):
            coeffs = np.polyfit(x, y, 4)
            x_fit = np.linspace(min(x), max(x), 30)
            y_fit = np.polyval(coeffs, x_fit)
            print(x_fit, y_fit, coeffs,'\n')
            return x_fit, y_fit, coeffs
        
        
        fit_funcs = {
            'p00': custom_fit_poly_4,  # don't change
            'p01': custom_fit_poly_4,# don't change
            'p10': custom_fit_poly_4,# don't change
            'p11': custom_fit_poly_4,  # don't change
            'p02': custom_fit_poly_4, # don't change
            'p20': custom_fit_poly_4  #
            # Остальные будут использовать аппроксимацию по умолчанию (полином 4 степени)
        }
        
        #plot_coefficients_with_fits_error(coefficients, fit_functions=fit_funcs, output_file="approximation_coeffs.txt")
        #plot_coefficients_with_fits(coefficients, fit_functions=fit_funcs)
        
        """ --- Интерполяция Коэффициентов от Width --- """
        # Затем интерполируем зависимость каждого из полученных коэффициентов (p00, p10, ...) от Width.
        print("\n--- Шаг 2: Интерполяция зависимости коэффициентов от Width ---")
        # Используем новую функцию, которая выполняет интерполяцию и выводит результат в файл
        plot_coefficients_with_interpolation_error(coefficients, output_file="interpolation_spline_coeffs.txt")
        
        print("\n--- Анализ завершен ---")