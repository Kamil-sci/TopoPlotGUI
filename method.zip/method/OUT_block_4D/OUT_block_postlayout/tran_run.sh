#!/bin/bash
ngspice -r "OUT_postlayout_tran_tb.raw" "OUT_postlayout_tran_tb.spice"
