#!/bin/bash

# Укажите диапазон чисел в имени файла
start=700
end=3600
step=100

# Создайте новый файл для вывода
output_file="WRITE_tran_all.txt"

# Очистите файл вывода
> "$output_file"
# Итерируйте по диапазону чисел
for num in $(seq $start $step $end); do
  # Укажите имя текущего файла
  file_name="WRITE_tran_Wn_$num.txt"
  
  # Проверьте, существует ли файл
  if [ -f "$file_name" ]; then
    #if [ $num -eq $start ]; then
      #head -n 1 "$file_name" | sed 's/ /\tWn\t/' > "$output_file"
      #head -n 1 "$file_name" | tr ' ' '\t' > "$output_file"
      #head -n 1 "$file_name" | tr '{printf "Wn\t"$1"\t"$2"\t"$3"\t"$4"\n"}' > "$output_file"
    #fi
    # Пропустите первую строку (заголовок) и выведите данные в файл вывода
    tail -n +2 "$file_name" | awk -v num=$num '{printf "%.2f\t%s\t%s\t%s\t%s\n",num/1000, $1, $2, $3, $4}' >> "$output_file"
  else
    echo "Файл $file_name не найден."
  fi
done

sed -i "1s/^/Wn\tRload\tCload\ttbl_pd\ttbl_wr\n/" "$output_file"
