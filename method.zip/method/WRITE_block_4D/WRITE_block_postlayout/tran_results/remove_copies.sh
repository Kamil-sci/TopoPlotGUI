#!/bin/bash

# Шаблон файлов для обработки
file_pattern="WRITE_tran_Wn_*.txt"
temp_file="temp.txt"
# Перебираем все файлы, соответствующие шаблону
for input_file in $file_pattern; do
    # Проверяем, что файл существует
    if [ -f "$input_file" ]; then
        # Создаем временный файл для результата
        tmp_file=$(mktemp)

        # Удаляем дубликаты с помощью awk и сохраняем результат во временный файл
        awk '!seen[$0]++' "$input_file" > "$temp_file"
        # Удаляем строки, содержащие "__", и сохраняем результат во временный файл
	grep -v "1.805E-12" "$temp_file" > "$tmp_file"

        # Проверяем статус выполнения команды
        if [ $? -eq 0 ]; then
            # Заменяем исходный файл обработанным
            mv "$tmp_file" "$input_file"
            echo "Успешно обработан файл: $input_file"
        else
            echo "Ошибка при обработке файла: $input_file"
            rm -f "$tmp_file"  # Убираем временный файл, если awk завершился ошибкой
        fi
    else
        echo "Файл не найден: $input_file"
    fi
done
