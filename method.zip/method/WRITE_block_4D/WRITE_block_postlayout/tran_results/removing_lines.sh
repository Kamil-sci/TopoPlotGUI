#!/bin/bash

# Входной файл
input_file="PC_tran_results_5.txt"
# Временный файл для результатов
temp_file="temp.txt"

# Проверяем существование входного файла
if [ ! -f "$input_file" ]; then
    echo "Ошибка: Файл $input_file не найден!"
    exit 1
fi

# Удаляем строки, содержащие "9.1E-13", и сохраняем результат во временный файл
grep -v "2.51E-12" "$input_file" > "$temp_file"

# Заменяем исходный файл временным
mv "$temp_file" "$input_file"

echo "Обработка завершена. Строки, содержащие '9.1E-13', удалены из $input_file"
