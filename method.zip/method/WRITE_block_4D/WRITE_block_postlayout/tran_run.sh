#!/bin/bash
ngspice -r "WRITE_postlayout_tran_tb.raw" "WRITE_postlayout_tran_tb.spice"
