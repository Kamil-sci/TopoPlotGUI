import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import root

# Коэффициенты аппроксимации
approx_coeffs = {    
    'p00': {'a': 1.604860384960851e-10, 'b': 0.25048057717263195, 'c': -2.3283468806116447e-11},
    'p10': {'a': 2.0455892280445003e-13, 'b': 1.2498580005170306, 'c': -1.5264871992401587e-13},
    'p01': {'a': 4827.83338991393, 'b': 0.028837087444793706, 'c': 7228.879008406911, 'd': -0.9054244063438566},
    'p20': {'a': 9.446995190910371e-17, 'b': 1.0896335678313898, 'c': 2.318376274772542, 'd': -0.26518503443034286},
    'p11': {'a': 0.5281505122263599, 'b': 0.384362468925356, 'c': 1.0561919366487627},
    'p02': {'a': 0.0, 'b': 0.0}
}

def t_wl(W_N, R_L, C_L):
    p00 = approx_coeffs['p00']['a'] * W_N ** approx_coeffs['p00']['b'] + approx_coeffs['p00']['c']
    p10 = approx_coeffs['p10']['a'] * np.exp(-approx_coeffs['p10']['b'] * W_N) + approx_coeffs['p10']['c']
    p01 = approx_coeffs['p01']['a'] * W_N ** approx_coeffs['p01']['d'] + approx_coeffs['p01']['b'] / W_N * approx_coeffs['p01']['c'] ** np.arctan(W_N)
    p20 = approx_coeffs['p20']['a'] * W_N ** approx_coeffs['p20']['b'] * np.arctan(approx_coeffs['p20']['c'] / W_N + approx_coeffs['p20']['d'])
    p11 = approx_coeffs['p11']['a'] * W_N ** approx_coeffs['p11']['b'] + approx_coeffs['p11']['c']
    p02 = approx_coeffs['p02']['a'] * W_N + approx_coeffs['p02']['b']
    
    return p00 + p10 * R_L + p01 * C_L + p20 * R_L ** 2 + p11 * R_L * C_L + p02 * C_L ** 2

def equation(W_N, R_L, C_L, target_t_wl):
    return t_wl(W_N, R_L, C_L) - target_t_wl

def jacobian(W_N, R_L, C_L):
    # Approximate the Jacobian using finite differences
    eps = 1e-6
    return (equation(W_N + eps, R_L, C_L, target_t_wl) - equation(W_N - eps, R_L, C_L, target_t_wl)) / (2 * eps)

def solve_W_N(R_L, C_L, target_t_wl, initial_guess=1):
    # Try using fsolve with a provided Jacobian
    # return fsolve(equation, initial_guess, args=(R_L, C_L, target_t_wl), fprime=jacobian)
    
    # Alternatively, try using root with a different method
    result = root(equation, initial_guess, args=(R_L, C_L, target_t_wl), method='lm')
    return result.x

# Задаем параметры
R_L = 100  # Пример значения для R_L
C_L = 100e-15  # Пример значения для C_L
initial_guess = 1  # Начальное предположение для W_N

# Массив значений target_t_wl
target_t_wl_values = np.linspace(0.435e-9, 0.8e-9, 1000)  # Диапазон значений target_t_wl

# Инициализация массивов для результатов
W_N_values = []
verify_t_wl_values = []
errors = []

# Цикл по значениям target_t_wl
for target_t_wl in target_t_wl_values:
    # Решаем уравнение для нахождения W_N
    W_N = solve_W_N(R_L, C_L, target_t_wl, initial_guess)
    W_N_values.append(W_N)
    
    # Выполняем обратную проверку
    verify_t_wl = t_wl(W_N, R_L, C_L)
    
    verify_t_wl_values.append(verify_t_wl)
    
    # Вычисляем погрешность
    error = verify_t_wl - target_t_wl
    errors.append(error)
    
verify_t_wl_values=np.array(verify_t_wl_values)*1e12
target_t_wl_values=np.array(target_t_wl_values)*1e12
errors=np.array(errors)*1e12
# Построение графика с двумя осями
fig, ax1 = plt.subplots(figsize=(12, 7))

# Первая ось - значения t_wl
color1 = 'red'
ax1.set_xlabel('Рассчитанное $W_N$, мкм')
ax1.set_ylabel('$t_{WR}$, пс')
ax1.plot(W_N_values, verify_t_wl_values, label='Вычисление', color=color1, linestyle='-')
ax1.scatter(W_N_values, target_t_wl_values, label='Цель', color='blue')
ax1.tick_params(axis='y')
# Вторая ось - погрешность
ax2 = ax1.twinx()
color2 = 'green'
ax2.set_ylabel('Погрешность, пс')
ax2.plot(W_N_values, errors, label='Погрешность', color=color2, linestyle='--')
ax2.tick_params(axis='y')
# Общие настройки
fig.tight_layout()
ax1.legend(loc='upper left')
ax2.legend(loc='upper right')
ax1.grid(True, which="both", ls="-")


plt.title('Зависимость значений и погрешности от $W_N$')
plt.show()

# =============================================================================
# # Построение графика погрешности
# plt.figure(figsize=(10, 6))
# plt.plot(W_N_values, verify_t_wl_values, label='Численный метод', color='red', linestyle='-')
# plt.scatter(W_N_values, target_t_wl_values, label='Цель', color='blue')
# plt.xlabel('Рассчитанное $W_N$, мкм')
# plt.ylabel('$t_{WR}$, нс')
# #plt.xscale('log')  # Логарифмическая шкала для target_t_wl
# #plt.yscale('log')  # Логарифмическая шкала для погрешности
# plt.legend()
# plt.grid(True, which="both", ls="--")
# 
# # Построение графика погрешности
# plt.figure(figsize=(10, 6))
# plt.plot(target_t_wl_values, errors, label='Погрешность', color='red', linestyle='-')
# #plt.xscale('log')  # Логарифмическая шкала для target_t_wl
# #plt.yscale('log')  # Логарифмическая шкала для погрешности
# plt.xlabel('Целевое значение $t_{WR}$, нс')
# plt.ylabel('Погрешность, нс')
# plt.title('Зависимость погрешности от target_t_wl')
# plt.legend()
# plt.grid(True, which="both", ls="--")
# plt.show()
# =============================================================================
