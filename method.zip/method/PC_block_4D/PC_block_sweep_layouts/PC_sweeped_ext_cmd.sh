#!/bin/bash

# Имя папки для результатов
layouts_dir="PC_sweep_layouts"
full_spice_dir="PC_full_spice"

if [ ! -d "$layouts_dir" ]; then
  mkdir "$layouts_dir"
  echo "Создана папка: $layouts_dir"
fi

if [ ! -d "$full_spice_dir" ]; then
  mkdir "$full_spice_dir"
  echo "Создана папка: $full_spice_dir"
fi

# === Параметры (можно менять под свои нужды) ===
start_i=800
end_i=3800
step=50

# Исходный файл для копирования
src_block="PC_exp_$start_i.mag"

# Проверка наличия исходного файла
if [ -f "$src_block" ]; then
    # Выполнение команд magic
    magic -d OGL "$src_block" -noconsole -nowrapper << EOF
    drc style drc(full)
    select top cell
    extract all
    ext2sim labels on
    ext2sim
    extresist all
    ext2spice cthresh 0
    ext2spice rthresh 0
    ext2spice subcircuit on
    ext2spice hierarchy on
    ext2spice scale off
    ext2spice extresist on
    ext2spice
    quit -noprompt
EOF
else
    echo "Ошибка: Исходный файл $src_block не найден!"
    exit 1
fi

# Цикл от start_i до end_i с шагом 100
for ((i=start_i; i<end_i; i+=step)); do
    next_i=$((i + step))
    
    src_file="PC_exp_$i.mag"
    
    mag_file="PC_exp_$next_i.mag"

    echo "Обрабатываем файл: $mag_file"

    # Создание копии файла
    cp "$src_file" "$mag_file"

    # Выполнение команд magic
    #magic -d XR "$mag_file" -noconsole -nowrapper << EOF
    #systemd-run --scope  --slice=memorylimit=2G magic -d XR "$mag_file" -noconsole -nowrapper << EOF
    magic -d OGL "$mag_file" -noconsole -nowrapper << EOF
    drc style drc(full)
    select top cell
    box move n 800nm
    select area
    stretch n 50nm
    select top cell
    box move s 800nm
    select area
    stretch s 50nm
    select top cell
    select area
    move n 50nm
    select top cell
    save $mag_file
    select top cell
    extract all
    ext2sim labels on
    ext2sim
    extresist all
    ext2spice cthresh 0
    ext2spice rthresh 0
    ext2spice subcircuit on
    ext2spice hierarchy on
    ext2spice scale off
    ext2spice extresist on
    ext2spice
    quit -noprompt
EOF

#if (( $i % 200 == 0)); then
#  sync; echo 3 | tee sudo /proc/sys/vm/drop_caches > /dev/null
#fi

done

for ((i=start_i; i<=end_i; i+=step)); do
  mag_file="PC_exp_$i.mag"
  spice_file="PC_exp_$i.spice"
  output_mag_file="$layouts_dir/$mag_file"
  output_full_spice="$full_spice_dir/$spice_file"
  
  if [ -f "$spice_file" ]; then
    sed -i '/^$/d; /^[.*]/d; /FLOATING/d;' "$spice_file"
    mv "$spice_file" "$output_full_spice"
  else
    echo "Внимание: Файл $spice_file не был создан командой magic для значения $i."
  fi
   
  if [ -f "$mag_file" ]; then
    mv "$mag_file" "$output_mag_file"
  else
    echo "Внимание: Файл $mag_file не был создан командой magic для значения $i."
  fi
done

echo "Все файлы успешно обработаны."
read
