#!/usr/bin/env python3
import os
import re
import subprocess

# =============================================================================
# Конфигурация: задайте пути к файлам и директориям
# =============================================================================
# Путь к файлу-шаблону, в котором выполняются замены
BASE_FILE = "PC_postlayout_tran_tmp_tb.spice"

# Директория, в которой лежат файлы с содержимым для замены блока.
# Файлы ожидаются в формате "PULSE_block_{i}", где i – номер итерации.
REPLACEMENT_DIR = "/home/kamil/vlsi/TopoPlot/new_method/PC_block_4D/PC_block_sweep_layouts/PC_full_spice/"

# Директория для сохранения обновлённых файлов
OUTPUT_DIR = "./generated_spice_files"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# =============================================================================
# Чтение файла-шаблона
# =============================================================================
try:
    with open(BASE_FILE, "r") as f:
        base_content = f.read()
except Exception as e:
    print(f"Ошибка чтения файла шаблона {BASE_FILE}: {e}")
    exit(1)

# =============================================================================
# Обработка файлов: для каждой итерации проверяем наличие файла PULSE_block_{i}
# =============================================================================
for i in range(800, 3900, 100):
    # Формируем имя файла-замены для данной итерации
    rep_filename = f"PC_exp_{i}.spice"
    rep_filepath = os.path.join(REPLACEMENT_DIR, rep_filename)
    
    if not os.path.isfile(rep_filepath):
        print(f"Файл '{rep_filepath}' не найден. Завершаем итерации.")
        break

    print(f"Обработка файла [{rep_filepath}] для итерации [{i}].")
    
    # Чтение содержимого файла-замены
    try:
        with open(rep_filepath, "r") as f:
            block_content = f.read()
    except Exception as e:
        print(f"Ошибка чтения файла {rep_filepath}: {e}")
        continue

    # Выполняем замены:
    # 1) заменяем маркер {WRITE_block} на содержимое файла-замены;
    # 2) заменяем маркер {i} на порядковый номер итерации.
    new_content = base_content.replace("{PC_block}", block_content)
    new_content = new_content.replace("{i}", str(i))

    # Задаём имена для spice-файла и файла raw
    #save_spice_filename = os.path.join(OUTPUT_DIR, f"updated_file_{i}.spice")
    
    tran_spice_filename = os.path.join("./", f"PC_postlayout_tran_tb.spice")
    tran_raw_filename = os.path.join("./", f"PC_postlayout_tran_tb.raw")

    ## Сохраняем новый spice-файл
    #try:
        #with open(save_spice_filename, "w") as f:
            #f.write(new_content)
    #except Exception as e:
        #print(f"Ошибка записи файла {save_spice_filename}: {e}")
        #continue

    # Сохраняем новый tb-файл и выполняем
    try:
        with open(tran_spice_filename, "w") as f:
            f.write(new_content)
    except Exception as e:
        print(f"Ошибка записи файла {save_spice_filename}: {e}")
        continue    
    
    subprocess.run(["./tran_run.sh"], check=True)


#print("Моделирование завершено.\n")
#subprocess.run(["/home/kamil/vlsi/TopoPlot/new_method/WRITE_block_new/WRITE_block_postlayout/tran_results/remove_copies.sh"], check=True, cwd="./tran_results")
#print("Копии утилизированы.\n")
#subprocess.run(["/home/kamil/vlsi/TopoPlot/new_method/WRITE_block_new/WRITE_block_postlayout/tran_results/combining.sh"], check=True, cwd="./tran_results")
#print("Файлы скомбинированы.\n")
