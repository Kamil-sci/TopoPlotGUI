def fix_bad_numbers_in_file(input_filename, output_filename, column_index):
    """
    Читаем файл `input_filename`, исправляем в нем все числа в указанном столбце `column_index` (отсчет с 0),
    где встречается комбинация "E-07", заменяя такое число на среднее между предыдущим и следующим.
    Результат пишем в `output_filename`.

    Если указан несуществующий столбец, будет ошибка IndexError.
    Если в файле меньше двух строк (нет предыдущего или следующего значения), 
    ошибочные значения в начале или конце просто пропускаются без замены.
    """
    with open(input_filename, 'r') as src_file, open(output_filename, 'w') as dst_file:
        prev_value = None  # сюда запомним предыдущее "хорошее" значение из нужного столбца
        bad_value_lines = []  # накопитель строк, где значение еще не исправлено (пригодится для след. шага)

        for line in src_file:
            parts = line.strip().split('\t')  # делим строку на части по табуляции
            current_value_str = parts[column_index]  # берем нужный столбец как строку

            # Проверяем, содержит ли текущее значение "E-07"
            if "E-07" in current_value_str:
                bad_value_lines.append(parts)  # запомнили строку целиком, но пока не исправляем
            else:
                # Текущее значение ОК, значит можем уже исправить предыдущее "плохое" если оно было
                if bad_value_lines:
                    for bad_line_parts in bad_value_lines:
                        # вот тут считаем среднее между prev_value и текущим значением (уже float)
                        try:
                            avg_value = (prev_value + float(current_value_str)) / 2.0
                            bad_line_parts[column_index] = str(avg_value)  # исправляем строку
                            fixed_line = '\t'.join(bad_line_parts)  # склеиваем обратно
                            dst_file.write(fixed_line + '\n')  # и пишем в итоговый файл
                        except ValueError:
                            # на случай если даже текущее или предыдущее значение не смогли в float
                            print(f"Warning: can't convert to float values {prev_value} or {current_value_str}, пропускаем")
                            # раз не смогли сконвертировать, запишем как есть, ничего не исправляя
                            for bad_line in bad_value_lines:
                                dst_file.write('\t'.join(bad_line) + '\n')
                    bad_value_lines.clear()  # очистили накопитель, все плохие строки уже записаны

                # Теперь записываем текущую "хорошую" строку как есть
                dst_file.write(line)
                # и запоминаем текущее значение (уже как float) чтобы потом использовать
                try:
                    prev_value = float(current_value_str)
                except ValueError:
                    prev_value = None  # если не смогли сконвертировать в число, сбросим

        # Обработка случая когда файл заканчивается на "плохом" значении (нет следующего "хорошего")
        if bad_value_lines:
            print(f"Warning: файл заканчивается ошибочными значениями в столбце {column_index}, они будут дописаны как есть.")
            for bad_line in bad_value_lines:
                dst_file.write('\t'.join(bad_line) + '\n')

# Теперь как это использовать
if __name__ == "__main__":
    input_file = "input_data.txt"   # имя исходного файла тут
    output_file = "fixed_data.txt"  # куда сохраним результат
    target_column = 3               # !!! ВАЖНО !!! номер столбца (с нуля!) где ищем E-07 
                                   # т.е. первый столбец это 0, второй это 1, третий это 2 и тд
    
    print(f"Начинаем исправлять файл {input_file} в столбце №{target_column} и писать результат в {output_file}")
    fix_bad_numbers_in_file(input_file, output_file, target_column)
    print("Готово!")