#!/bin/bash
ngspice -r "PC_postlayout_tran_tb.raw" "PC_postlayout_tran_tb.spice"
