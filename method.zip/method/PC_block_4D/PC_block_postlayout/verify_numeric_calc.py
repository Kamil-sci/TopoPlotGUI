import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import root

# Коэффициенты аппроксимации	
approx_coeffs = {
    'p00': {
        'a': -2.7831218672705364e-11,
        'b': 2.830723592706642e-10,
        'c': -1.0598363731957857e-09,
        'd': 1.653671173982053e-09,
        'e': 7.810938236315294e-10
    },
    'p10': {
        'a': -1.859669414420993e-14,
        'b': 1.6310095708766159e-13,
        'c': -3.4513111803815646e-13,
        'd': -6.818949830243888e-13,
        'e': -5.365486475283143e-13
    },
    'p01': {
        'a': -5806.833265182063,
        'b': 64505.84839166264,
        'c': -252827.359901273,
        'd': 374094.2124197386,
        'e': -87658.93516957371
    },
    'p20': {
        'a': -0.001992670912447105,
        'b': 0.021889249301619784,
        'c': -0.08864218220534521,
        'd': 0.17314122155133527,
        'e': 0.35419158236450005
    },
    'p11': {
        'a': 0.005089582546052044,
        'b': -0.04986886008071882,
        'c': 0.17535115752896696,
        'd': -0.2062507620718014,
        'e': 1.5669598259967379
    },
    'p02': {
        'a': -0.0018860537083543543,
        'b': 0.022516922317391243,
        'c': -0.10591802516680568,
        'd': 0.20680443684308691,
        'e': 0.9493162647663554
    }
}
# Извлечение списков коэффициентов
coefficients = {key: [value for value in coeffs.values()] for key, coeffs in approx_coeffs.items()}

def t_pc(W_P, R_L, C_L):
    p00 = np.polyval(coefficients['p00'], W_P)
    p10 = np.polyval(coefficients['p10'], W_P)
    p01 = np.polyval(coefficients['p01'], W_P)
    p20 = np.polyval(coefficients['p20'], W_P)
    p11 = np.polyval(coefficients['p11'], W_P)
    p02 = np.polyval(coefficients['p02'], W_P)
    
    return p00 + p10 * R_L ** p20 + p01 * C_L ** p02 + p11 * R_L * C_L 

def equation(W_P, R_L, C_L, target_t_pc):
    return t_pc(W_P, R_L, C_L) - target_t_pc

def jacobian(W_P, R_L, C_L):
    # Approximate the Jacobian using finite differences
    eps = 1e-6
    return (equation(W_P + eps, R_L, C_L, target_t_pc) - equation(W_P - eps, R_L, C_L, target_t_pc)) / (2 * eps)

def solve_W_P(R_L, C_L, target_t_pc, initial_guess=1):
    # Try using fsolve with a provided Jacobian
    # return fsolve(equation, initial_guess, args=(R_L, C_L, target_t_pc), fprime=jacobian)
    
    # Alternatively, try using root with a different method
    result = root(equation, initial_guess, args=(R_L, C_L, target_t_pc), method='lm')
    return result.x

# Задаем параметры
R_L = 100  # Пример значения для R_L
C_L = 100e-15  # Пример значения для C_L
initial_guess = 1  # Начальное предположение для W_P

# Массив значений target_t_pc
target_t_pc_values = np.linspace(0.1e-9, 2e-9, 1000)  # Диапазон значений target_t_pc

# Инициализация массивов для результатов
W_P_values = []
verify_t_pc_values = []
errors = []

# Цикл по значениям target_t_pc
for target_t_pc in target_t_pc_values:
    # Решаем уравнение для нахождения W_P
    W_P = solve_W_P(R_L, C_L, target_t_pc, initial_guess)
    W_P_values.append(W_P)
    
    # Выполняем обратную проверку
    verify_t_pc = t_pc(W_P, R_L, C_L)
    
    verify_t_pc_values.append(verify_t_pc)
    
    # Вычисляем погрешность
    error = abs(verify_t_pc - target_t_pc)
    errors.append(error)
    
verify_t_pc_values=np.array(verify_t_pc_values)*1e12
target_t_pc_values=np.array(target_t_pc_values)*1e12
errors=np.array(errors)*1e12
# Построение графика с двумя осями
fig, ax1 = plt.subplots(figsize=(12, 7))

# Первая ось - значения t_pc
color1 = 'red'
ax1.set_xlabel('Рассчитанное $W_P$, мкм')
ax1.set_ylabel('$t_{PC}$, пс')
ax1.plot(W_P_values, verify_t_pc_values, label='Вычисление', color=color1, linestyle='-')
ax1.scatter(W_P_values, target_t_pc_values, label='Цель', color='blue')
ax1.tick_params(axis='y')
# Вторая ось - погрешность
ax2 = ax1.twinx()
color2 = 'green'
ax2.set_ylabel('Абсолютная Погрешность, пс')
ax2.plot(W_P_values, errors, label='Погрешность', color=color2, linestyle='--')
ax2.tick_params(axis='y')
# Общие настройки
fig.tight_layout()
ax1.legend(loc='upper left')
ax2.legend(loc='upper right')
ax1.grid(True, which="both", ls="-")


plt.title('Зависимость значений и погрешности от $W_P$')
plt.show()

# =============================================================================
# plt.figure(figsize=(10, 6))
# plt.plot(W_P_values, verify_t_pc_values, label='Численный метод', color='red', linestyle='-')
# plt.scatter(W_P_values, target_t_pc_values, label='Цель', color='blue')
# plt.xlabel('Рассчитанное $W_P$, мкм')
# plt.ylabel('$t_{WR}$, нс')
# #plt.xscale('log')  # Логарифмическая шкала для target_t_pc
# #plt.yscale('log')  # Логарифмическая шкала для погрешности
# plt.legend()
# plt.grid(True, which="both", ls="--")
# 
# plt.figure(figsize=(10, 6))
# plt.plot(target_t_pc_values, errors, label='Погрешность', color='red', linestyle='-')
# #plt.xscale('log')  # Логарифмическая шкала для target_t_pc
# #plt.yscale('log')  # Логарифмическая шкала для погрешности
# plt.xlabel('Целевое значение $t_{WR}$, нс')
# plt.ylabel('Погрешность, нс')
# plt.title('Зависимость погрешности от target_t_pc')
# plt.legend()
# plt.grid(True, which="both", ls="--")
# plt.show()
# =============================================================================
