v {xschem version=3.4.6 file_version=1.2}
G {}
K {}
V {}
S {}
E {}
N 525 -430 545 -430 {
lab=PC}
N 545 -430 565 -430 {
lab=PC}
N 485 -480 485 -460 {
lab=#net1}
N 485 -480 605 -480 {
lab=#net1}
N 605 -480 605 -460 {
lab=#net1}
N 485 -400 485 -350 {
lab=#net2}
N 605 -400 605 -350 {
lab=#net3}
N 475 -430 485 -430 {
lab=#net1}
N 475 -480 475 -430 {
lab=#net1}
N 475 -480 485 -480 {
lab=#net1}
N 605 -430 615 -430 {
lab=#net1}
N 615 -480 615 -430 {
lab=#net1}
N 605 -480 615 -480 {
lab=#net1}
N 545 -520 545 -430 {
lab=PC}
N 605 -520 715 -520 {
lab=#net1}
N 715 -450 715 -430 {
lab=GND}
N 715 -520 715 -510 {
lab=#net1}
N 395 -415 395 -400 {
lab=GND}
N 395 -520 445 -520 {
lab=PC}
N 395 -490 395 -475 {
lab=PC}
N 395 -520 395 -490 {
lab=PC}
N 570 -520 570 -480 {
lab=#net1}
N 570 -520 605 -520 {
lab=#net1}
N 545 -430 545 -390 {
lab=PC}
N 485 -350 515 -350 {
lab=#net2}
N 575 -350 605 -350 {
lab=#net3}
N 545 -350 545 -325 {
lab=#net1}
N 500 -325 545 -325 {
lab=#net1}
N 500 -395 500 -325 {
lab=#net1}
N 500 -395 530 -395 {
lab=#net1}
N 530 -480 530 -395 {
lab=#net1}
N 445 -520 545 -520 {
lab=PC}
N 525 -255 565 -255 {lab=RST}
N 410 -255 485 -255 {lab=GND}
N 605 -255 705 -255 {lab=GND}
N 485 -350 485 -285 {lab=#net2}
N 605 -350 605 -285 {lab=#net3}
N 485 -225 545 -225 {lab=GND}
N 545 -225 545 -210 {lab=GND}
N 545 -225 605 -225 {lab=GND}
N 365 -270 365 -255 {lab=GND}
N 470 -350 485 -350 {lab=#net2}
N 605 -350 620 -350 {lab=#net3}
N 680 -350 680 -325 {lab=NBL}
N 410 -350 410 -325 {lab=BL}
N 365 -365 365 -330 {lab=RST}
C {sky130_fd_pr/pfet_01v8.sym} 585 -430 0 0 {name=M1
W=Wp
L=Lch
nf=1
mult=1
ad="'int((nf+1)/2) * W/nf * 0.29'" 
pd="'2*int((nf+1)/2) * (W/nf + 0.29)'"
as="'int((nf+2)/2) * W/nf * 0.29'" 
ps="'2*int((nf+2)/2) * (W/nf + 0.29)'"
nrd="'0.29 / W'" nrs="'0.29 / W'"
sa=0 sb=0 sd=0
model=pfet_01v8
spiceprefix=X
}
C {sky130_fd_pr/pfet_01v8.sym} 505 -430 0 1 {name=M2
W=Wp
L=Lch
nf=1
mult=1
ad="'int((nf+1)/2) * W/nf * 0.29'" 
pd="'2*int((nf+1)/2) * (W/nf + 0.29)'"
as="'int((nf+2)/2) * W/nf * 0.29'" 
ps="'2*int((nf+2)/2) * (W/nf + 0.29)'"
nrd="'0.29 / W'" nrs="'0.29 / W'"
sa=0 sb=0 sd=0
model=pfet_01v8
spiceprefix=X
}
C {vsource.sym} 715 -480 0 0 {name=Vdd value=1.8 savecurrent=false}
C {gnd.sym} 715 -430 0 0 {name=l1 lab=GND}
C {devices/code.sym} 565 -650 0 0 {name=TT_MODELS
only_toplevel=true
format="tcleval( @value )"
value="
** opencircuitdesign pdks install
.lib $::SKYWATER_MODELS/sky130.lib.spice tt

"
spice_ignore=false}
C {param.sym} 395 -635 0 0 {name=s1 value="
+Wp=0.8
+Lch=0.15
+CL=10f
+RL=100
"}
C {gnd.sym} 395 -400 0 0 {name=l2 lab=GND}
C {vsource.sym} 395 -445 0 1 {name=VPC value="
+PULSE(1.8 0.0 0.02u 10n 10n 2u 5u 1)
"}
C {lab_pin.sym} 545 -520 2 0 {name=p4 sig_type=std_logic lab=PC}
C {lab_pin.sym} 680 -335 2 0 {name=p5 sig_type=std_logic lab=NBL}
C {lab_pin.sym} 410 -335 2 1 {name=p6 sig_type=std_logic lab=BL}
C {code_shown.sym} 755 -515 0 0 {name=sample_tran_tb only_toplevel=false value=
"
.control
tran 0.01n 0.05u
set color0=white
set color1=black
set color2=blue
set color3=red
set color4=green
set color5=purple
set color6=orange
plot v(PC) v(RST) v(BL) v(NBL)

save all

.endc
"}
C {sky130_fd_pr/pfet_01v8.sym} 545 -370 3 1 {name=M3
W=Wp
L=Lch
nf=1
mult=1
ad="'int((nf+1)/2) * W/nf * 0.29'" 
pd="'2*int((nf+1)/2) * (W/nf + 0.29)'"
as="'int((nf+2)/2) * W/nf * 0.29'" 
ps="'2*int((nf+2)/2) * (W/nf + 0.29)'"
nrd="'0.29 / W'" nrs="'0.29 / W'"
sa=0 sb=0 sd=0
model=pfet_01v8
spiceprefix=X
}
C {parax_cap.sym} 410 -315 0 0 {name=C2 gnd=0 value=\{CL\} m=1}
C {parax_cap.sym} 680 -315 0 0 {name=C1 gnd=0 value=\{CL\} m=1}
C {sky130_fd_pr/nfet_01v8.sym} 585 -255 0 0 {name=M4
W=0.7
L=0.15
nf=1 
mult=1
ad="expr('int((@nf + 1)/2) * @W / @nf * 0.29')"
pd="expr('2*int((@nf + 1)/2) * (@W / @nf + 0.29)')"
as="expr('int((@nf + 2)/2) * @W / @nf * 0.29')"
ps="expr('2*int((@nf + 2)/2) * (@W / @nf + 0.29)')"
nrd="expr('0.29 / @W ')" nrs="expr('0.29 / @W ')"
sa=0 sb=0 sd=0
model=nfet_01v8
spiceprefix=X
}
C {sky130_fd_pr/nfet_01v8.sym} 505 -255 0 1 {name=M5
W=0.7
L=0.15
nf=1 
mult=1
ad="expr('int((@nf + 1)/2) * @W / @nf * 0.29')"
pd="expr('2*int((@nf + 1)/2) * (@W / @nf + 0.29)')"
as="expr('int((@nf + 2)/2) * @W / @nf * 0.29')"
ps="expr('2*int((@nf + 2)/2) * (@W / @nf + 0.29)')"
nrd="expr('0.29 / @W ')" nrs="expr('0.29 / @W ')"
sa=0 sb=0 sd=0
model=nfet_01v8
spiceprefix=X
}
C {gnd.sym} 410 -255 0 0 {name=l3 lab=GND}
C {gnd.sym} 705 -255 0 0 {name=l4 lab=GND}
C {gnd.sym} 545 -210 0 0 {name=l5 lab=GND}
C {vsource.sym} 365 -300 0 1 {name=VRST value="
+PULSE(1.8 0.0 0.0u 10n 10n 2u 5u 1)
"}
C {gnd.sym} 365 -255 0 0 {name=l6 lab=GND}
C {lab_pin.sym} 365 -365 2 0 {name=p1 sig_type=std_logic lab=RST}
C {lab_pin.sym} 545 -255 1 0 {name=p2 sig_type=std_logic lab=RST}
C {res.sym} 650 -350 3 0 {name=R1
value=\{RL\}
footprint=1206
device=resistor
m=1}
C {res.sym} 440 -350 3 0 {name=R2
value=\{RL\}
footprint=1206
device=resistor
m=1}
