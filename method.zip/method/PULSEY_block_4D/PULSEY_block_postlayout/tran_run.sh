#!/bin/bash
ngspice -r "PULSEY_postlayout_tran_tb.raw" "PULSEY_postlayout_tran_tb.spice"
