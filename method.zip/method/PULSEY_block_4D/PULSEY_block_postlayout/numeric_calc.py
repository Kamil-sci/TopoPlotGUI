import numpy as np
from scipy.optimize import fsolve, root

approx_coeffs = {    
    'p00': {'a': 6.405850769305928e-11, 'b': 0.6011232697841825, 'c': 6.198013650820446e-11},
    'p10': {'a': 2.0192613832182125e-13, 'b': 0.7793608865087375, 'c': -1.7502205627912913e-13},
    'p01': {'a': 6396.111800718637, 'b': 0.12050598828545535, 'c': 2624.5068106702, 'd': -0.9970333859034737},
    'p20': {'a': 7.59787580934806e-17, 'b': 1.0302452639569297, 'c': 3.4058821358456948, 'd': -0.25361053220508106},
    'p11': {'a': 0.2595041672037046, 'b': 0.6453333146676379, 'c': 1.179441681452691},
    'p02': {'a': 0.0, 'b': 0.0}
}

def t_wl(W_N, R_L, C_L):
    p00 = approx_coeffs['p00']['a'] * W_N ** approx_coeffs['p00']['b'] + approx_coeffs['p00']['c']
    p10 = approx_coeffs['p10']['a'] * np.exp(-approx_coeffs['p10']['b'] * W_N) + approx_coeffs['p10']['c']
    p01 = approx_coeffs['p01']['a'] * W_N ** approx_coeffs['p01']['d'] + approx_coeffs['p01']['b'] / W_N * approx_coeffs['p01']['c'] ** np.arctan(W_N)
    p20 = approx_coeffs['p20']['a'] * W_N ** approx_coeffs['p20']['b'] * np.arctan(approx_coeffs['p20']['c'] / W_N + approx_coeffs['p20']['d'])
    p11 = approx_coeffs['p11']['a'] * W_N ** approx_coeffs['p11']['b'] + approx_coeffs['p11']['c']
    p02 = approx_coeffs['p02']['a'] * W_N + approx_coeffs['p02']['b']
    
    return p00 + p10 * R_L + p01 * C_L + p20 * R_L ** 2 + p11 * R_L * C_L + p02 * C_L ** 2

def equation(W_N, R_L, C_L, target_t_wl):
    return t_wl(W_N, R_L, C_L) - target_t_wl

def jacobian(W_N, R_L, C_L):
    # Approximate the Jacobian using finite differences
    eps = 1e-6
    return (equation(W_N + eps, R_L, C_L, target_t_wl) - equation(W_N - eps, R_L, C_L, target_t_wl)) / (2 * eps)

def solve_W_N(R_L, C_L, target_t_wl, initial_guess=1):
    # Try using fsolve with a provided Jacobian
    # return fsolve(equation, initial_guess, args=(R_L, C_L, target_t_wl), fprime=jacobian)
    
    # Alternatively, try using root with a different method
    result = root(equation, initial_guess, args=(R_L, C_L, target_t_wl), method='lm')
    return result.x

# Example usage:
R_L = 100  # Example value for R_L
C_L = 100e-15  # Example value for C_L
target_t_wl = 1e-09  # Example target value for t_wl

old_t_wl = t_wl(0.7, R_L, C_L)
print("old_t_wl = ", old_t_wl)

W_N = solve_W_N(R_L, C_L, target_t_wl)
print("W_N =", W_N)

verify_t_wl = t_wl(W_N, R_L, C_L)
print("verify_t_wl =", verify_t_wl)