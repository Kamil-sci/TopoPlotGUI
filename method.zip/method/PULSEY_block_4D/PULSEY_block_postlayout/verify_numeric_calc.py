import numpy as np
import matplotlib.pyplot as plt
from scipy.optimize import root

# Коэффициенты аппроксимации
approx_coeffs = {    
    'p00': {'a': 6.405850769305928e-11, 'b': 0.6011232697841825, 'c': 6.198013650820446e-11},
    'p10': {'a': 2.0192613832182125e-13, 'b': 0.7793608865087375, 'c': -1.7502205627912913e-13},
    'p01': {'a': 6396.111800718637, 'b': 0.12050598828545535, 'c': 2624.5068106702, 'd': -0.9970333859034737},
    'p20': {'a': 7.59787580934806e-17, 'b': 1.0302452639569297, 'c': 3.4058821358456948, 'd': -0.25361053220508106},
    'p11': {'a': 0.2595041672037046, 'b': 0.6453333146676379, 'c': 1.179441681452691},
    'p02': {'a': 0.0, 'b': 0.0}
}

def t_wl(W_N, R_L, C_L):
    p00 = approx_coeffs['p00']['a'] * W_N ** approx_coeffs['p00']['b'] + approx_coeffs['p00']['c']
    p10 = approx_coeffs['p10']['a'] * np.exp(-approx_coeffs['p10']['b'] * W_N) + approx_coeffs['p10']['c']
    p01 = approx_coeffs['p01']['a'] * W_N ** approx_coeffs['p01']['d'] + approx_coeffs['p01']['b'] / W_N * approx_coeffs['p01']['c'] ** np.arctan(W_N)
    p20 = approx_coeffs['p20']['a'] * W_N ** approx_coeffs['p20']['b'] * np.arctan(approx_coeffs['p20']['c'] / W_N + approx_coeffs['p20']['d'])
    p11 = approx_coeffs['p11']['a'] * W_N ** approx_coeffs['p11']['b'] + approx_coeffs['p11']['c']
    p02 = approx_coeffs['p02']['a'] * W_N + approx_coeffs['p02']['b']
    
    return p00 + p10 * R_L + p01 * C_L + p20 * R_L ** 2 + p11 * R_L * C_L + p02 * C_L ** 2

def equation(W_N, R_L, C_L, target_t_wl):
    return t_wl(W_N, R_L, C_L) - target_t_wl

def jacobian(W_N, R_L, C_L):
    # Approximate the Jacobian using finite differences
    eps = 1e-6
    return (equation(W_N + eps, R_L, C_L, target_t_wl) - equation(W_N - eps, R_L, C_L, target_t_wl)) / (2 * eps)

def solve_W_N(R_L, C_L, target_t_wl, initial_guess=1):
    # Try using fsolve with a provided Jacobian
    # return fsolve(equation, initial_guess, args=(R_L, C_L, target_t_wl), fprime=jacobian)
    
    # Alternatively, try using root with a different method
    result = root(equation, initial_guess, args=(R_L, C_L, target_t_wl), method='lm')
    return result.x

# Задаем параметры
R_L = 100  # Пример значения для R_L
C_L = 500e-15  # Пример значения для C_L
initial_guess = 1  # Начальное предположение для W_N

# Массив значений target_t_wl
target_t_wl_values = np.linspace(0.1e-9, 4.609091221992429e-09, 1000)  # Диапазон значений target_t_wl

# Инициализация массивов для результатов
W_N_values = []
verify_t_wl_values = []
errors = []

# Цикл по значениям target_t_wl
for target_t_wl in target_t_wl_values:
    # Решаем уравнение для нахождения W_N
    W_N = solve_W_N(R_L, C_L, target_t_wl, initial_guess)
    W_N_values.append(W_N)
    
    # Выполняем обратную проверку
    verify_t_wl = t_wl(W_N, R_L, C_L)
    
    verify_t_wl_values.append(verify_t_wl)
    
    # Вычисляем погрешность
    error = abs(verify_t_wl - target_t_wl)
    errors.append(error)
    
# Построение графика погрешности
plt.figure(figsize=(10, 6))
plt.plot(W_N_values, verify_t_wl_values, label='verify_t_wl', color='red', linestyle='-')
plt.plot(W_N_values, target_t_wl_values, label='target_t_wl', color='blue', linestyle='--')
plt.xscale('log')  # Логарифмическая шкала для target_t_wl
plt.yscale('log')  # Логарифмическая шкала для погрешности
plt.legend()
plt.grid(True, which="both", ls="--")

# Построение графика погрешности
plt.figure(figsize=(10, 6))
plt.plot(target_t_wl_values, errors, label='Погрешность', color='red', linestyle='-')
plt.xscale('log')  # Логарифмическая шкала для target_t_wl
plt.yscale('log')  # Логарифмическая шкала для погрешности
plt.xlabel('Значение target_t_wl')
plt.ylabel('Погрешность')
plt.title('Зависимость погрешности от target_t_wl')
plt.legend()
plt.grid(True, which="both", ls="--")
plt.show()